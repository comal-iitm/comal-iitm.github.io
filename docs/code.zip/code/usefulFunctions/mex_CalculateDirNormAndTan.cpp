#include "mex.h"
#include <iostream>
#include <stdio.h>
#include <matrix.h>
#include <math.h>

using namespace std;

#define PI 3.14159265

void mexFunction(int nout, mxArray *out[], int nin, const mxArray *in[])
{
	/* Format: 1st column is y and 2nd column is x */
	if(nin !=2)
	{
		mexErrMsgTxt("Syntax error [thethaNormal, thetaTangent] = mex_CalculateDirNormAndTan(boundaryRight, boundaryLeft)");
	}

	enum {IN_R=0, IN_L};
	enum {OUT_tN=0, OUT_tT};

	double *boundaryRight, *boundaryLeft;
	double *thetaNormal, *thetaTangent;

	out[OUT_tN] = mxCreateDoubleMatrix(1, 1, mxREAL);
	out[OUT_tT] = mxCreateDoubleMatrix(1, 1, mxREAL);
	
	thetaNormal = mxGetPr(out[OUT_tN]);
	thetaTangent = mxGetPr(out[OUT_tT]);

	boundaryRight = mxGetPr(in[IN_R]);
	boundaryLeft = mxGetPr(in[IN_L]);

	const int *dims = mxGetDimensions(in[IN_R]); 
	
	double endPt1[2], endPt2[2];
	
	endPt1[0] = 0;
	endPt1[1] = 0;

	endPt2[0] = 0;
	endPt2[1] = 0;

	for(int i=0; i<dims[0]; i++)
	{
		endPt1[0] += boundaryRight[i];
		endPt1[1] += boundaryRight[i+dims[0]];

		endPt2[0] += boundaryLeft[i];
		endPt2[1] += boundaryLeft[i+dims[0]];

	}

	endPt1[0] /= dims[0];
	endPt1[1] /= dims[0];
	endPt2[0] /= dims[0];
	endPt2[1] /= dims[0];
	
	double slopeNew = (endPt1[0] - endPt2[0])/(endPt1[1] - endPt2[1]);
	double interceptNew = endPt2[0] - slopeNew*endPt2[1];
	
	thetaNormal[0] = atan(slopeNew)*180/PI;	
	
	if(thetaNormal < 0)
	{
		thetaNormal += 180;
	}

	thetaTangent[0] = thetaNormal[0] + 90;

}

