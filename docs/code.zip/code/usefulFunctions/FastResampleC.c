#include <math.h>
#include "mex.h"

/* Input Arguments */

#define	MAXBASISPTS	prhs[0]
#define	CUMBASISNORM prhs[1]
#define	XNORMCIRC prhs[2]
#define	YNORMCIRC prhs[3]
#define	INDMAP prhs[4]

/* Output Arguments */

#define	XNORMRESAMPLED plhs[0]
#define	YNORMRESAMPLED plhs[1]
#define	INDMAPNEW plhs[2]
#define RBDN plhs[3]

void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray*prhs[] )
     
{ 
    double *maxBasisPts,*cumBasisNorm,*xNormCirc,*yNormCirc, *indmap;
    double *xNormResampled,*yNormResampled,*indmapnew, *rbdn;
    mwSize N, sz;
    int i, curind = 1, ind1;
    float dist1,dist2,sumdist; 
    
    /* Check for proper number of arguments */
    
    if (nrhs != 5) { 
	mexErrMsgTxt("Five input arguments required."); 
    } else if (nlhs > 4) {
	mexErrMsgTxt("Too many output arguments."); 
    } 
    
    /* Get pointer to the input arrays */
    maxBasisPts = mxGetPr(MAXBASISPTS); 
    cumBasisNorm = mxGetPr(CUMBASISNORM); 
    xNormCirc = mxGetPr(XNORMCIRC);
    yNormCirc = mxGetPr(YNORMCIRC);
    indmap = mxGetPr(INDMAP);
    
 /*   N = mxGetM(MAXBASISPTS); */
    
    /* Allocate arrays for the output arrays */
    XNORMRESAMPLED = mxCreateDoubleMatrix(maxBasisPts[0], 1, mxREAL); 
    YNORMRESAMPLED = mxCreateDoubleMatrix(maxBasisPts[0], 1, mxREAL); 
    INDMAPNEW = mxCreateDoubleMatrix(maxBasisPts[0], 1, mxREAL); 
    RBDN = mxCreateDoubleMatrix(1, maxBasisPts[0]-2, mxREAL);

    /* Pointers to the output arrays */
    xNormResampled = mxGetPr(XNORMRESAMPLED);
    yNormResampled = mxGetPr(YNORMRESAMPLED);
    indmapnew = mxGetPr(INDMAPNEW); 
    rbdn = mxGetPr(RBDN);
    
    for (i=0;i<maxBasisPts[0];i++) {
         while (cumBasisNorm[curind+1 -1] < i) {
             curind = curind + 1; 
         }
    
        dist1 = i - cumBasisNorm[curind - 1];
        dist2 = cumBasisNorm[curind + 1 - 1] - i;
  
        sumdist = (dist1 + dist2);      
/*        printf("\nsumdist is %d %f\n",i,sumdist); */
    
        xNormResampled[i + 1 - 1] = (xNormCirc[curind - 1] * dist2  + xNormCirc[curind + 1 - 1] * dist1)/sumdist;
        yNormResampled[i + 1 - 1] = (yNormCirc[curind - 1] * dist2  + yNormCirc[curind + 1 - 1] * dist1)/sumdist;
    	
		if ( i > 0 && i < maxBasisPts[0]-1)
		{
			rbdn[i-1] = sqrt((xNormResampled[i] - xNormResampled[i-1])*(xNormResampled[i] - xNormResampled[i-1]) + (yNormResampled[i] - yNormResampled[i-1])*(yNormResampled[i] - yNormResampled[i-1]));
		}

        if (dist1 < dist2) {
            indmapnew[i + 1 -1] = curind; }
        else {
            indmapnew[i + 1 - 1] = curind+1; }
        
        sz = mxGetM(XNORMCIRC);
        if ((curind+1) == sz) {
            indmapnew[i + 1 -1] = 1; }
     
    
/* try {   */
		ind1 = indmapnew[i +1 -1];
		indmapnew[i+1 - 1] = indmap[ind1 - 1];
/* }
// catch {
//    printf("Stop");
// }*/

    }
}
