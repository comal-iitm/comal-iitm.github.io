function [ssdVal, shiftErrors] = AlignGetSSDFinal(templates, masks, numShifts)
    
    ssdVal=5000;
    
    if ~isempty(templates{1}) && ~isempty(templates{2}) ...
       && ~isempty(masks{1}) && ~isempty(masks{2})
        
        [Xshift, Yshift] = meshgrid(-numShifts:numShifts, -numShifts:numShifts);
        
        XshiftN = Xshift(:);
        YshiftN = Yshift(:);
        
        shiftErrors = 5000000*ones(numel(Xshift), 1);
        
        for shift = 1:numel(Xshift),
            
            [templateSh1, templateSh2] = imshiftMine([XshiftN(shift) YshiftN(shift)], ...
                                                    templates{1}, templates{2});
            [maskSh1, maskSh2] = imshiftMine([XshiftN(shift) YshiftN(shift)], ...
                                             masks{1}, masks{2});
            
            maskSh1Rep = repmat(maskSh1, [1 1 3]);
            maskSh2Rep = repmat(maskSh2, [1 1 3]);
            
            I_error = imabsdiff(templateSh1, templateSh2);
            
            selApp1 = find(maskSh1Rep); 
            selApp2 = find(maskSh2Rep);
            
            selAppCommon{shift} = intersect(selApp1, selApp2);
            I_errorSel = I_error(selAppCommon{shift});
            shiftErrors(shift) = sum(I_errorSel);
            
        end
        
        shiftErrors1 = reshape(shiftErrors, 2*numShifts+1, 2*numShifts+1);

        [minSSD, minSSDInd] = min(shiftErrors);
        ssdVal = shiftErrors(minSSDInd)/length(selAppCommon{minSSDInd});
    end

    if 0
        figure, imshow(templates{1}),figure, imshow(templates{2});
        
        [templateSh1 templateSh2] = imshiftMine([XshiftN(minSSDInd) YshiftN(minSSDInd)], ...
                                                templates{1},templates{2});
        
        figure, imshow(templateSh1),figure, imshow(templateSh2);
        [maskSh1 maskSh2] = imshiftMine([XshiftN(minSSDInd) YshiftN(minSSDInd)],masks{1},masks{2});
        figure, imshow(maskSh1),figure, imshow(maskSh2);
        %%%%%%%%%%%%%%%%
        template_shifted = imshift([XshiftN(minSSDInd) YshiftN(minSSDInd)],templates{2});
        maskDisp = zeros(szBlock,szBlock,3);
        maskDisp(selAppDilCommon{minSSDInd})=1;

        boundary = bwboundaries(maskDisp(:,:,1));
        numParts = length(boundary);
        figure, imshow(template_shifted); hold on,
        for i=1:numParts
            plot(boundary{numParts}(:,2),boundary{numParts}(:,1));
        end
        figure, imshow(templates{1}); hold on,
        for i=1:numParts
            plot(boundary{numParts}(:,2),boundary{numParts}(:,1));
        end
    end
end


function [imBlockSh1, imBlockSh2] = imshiftMine(shifts, imBlock1, imBlock2)
    
    shXA = abs(shifts(1));
    shYA = abs(shifts(2));
    
    imBlockSh1 = imBlock1;
    imBlockSh2 = imBlock2;

    switch sign(shifts(1))
        case -1
            imBlockSh1 = imBlockSh1(1:end-shXA, :, :);
            imBlockSh2 = imBlockSh2(1+shXA:end, :, :);

        case 1
            imBlockSh2 = imBlockSh2(1:end-shXA, :, :);
            imBlockSh1 = imBlockSh1(1+shXA:end, :, :);
    end


    switch sign(shifts(2))
        case -1
            imBlockSh1 = imBlockSh1(:, 1:end-shYA, :);
            imBlockSh2 = imBlockSh2(:, 1+shYA:end, :);

        case 1
            imBlockSh2 = imBlockSh2(:, 1:end-shYA, :);
            imBlockSh1 = imBlockSh1(:, 1+shYA:end, :);
    end
end