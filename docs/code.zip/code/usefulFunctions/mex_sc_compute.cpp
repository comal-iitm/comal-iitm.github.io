#include "mex.h"
#include <stdio.h>
#include <matrix.h>
#include <math.h>
#include <iostream>

#define PI  3.14159265358979323846

using namespace std;

double rem(double a, double b)
{
	return a - double(floor(a/b))*b;
}

void mexFunction(int nout, mxArray *out[], int nin, const mxArray *in[])
{
	//enum {IN_NBINS_T=0, IN_NBINS_R, IN_NSAMP, IN_VEC, IN_BSAMP, IN_TSAMP, IN_RA, IN_RI, IN_RO};
	enum {IN_NBINS_T=0, IN_NBINS_R, IN_NSAMP, IN_VEC, IN_BSAMP, IN_TSAMP, IN_RA, IN_RI, IN_RO};

	enum {OUT_BH=0, OUT_MD};
	//enum {OUT_BH=0};

	double *nbins_theta, *nbins_r, *nsamp, *theta_array_q, *theta_array, *r_array, *r_array_n;
   	double *r_bin_edges, *r_array_q, *r_inner, *r_outer, *mean_dist, *Bsamp, *Tsamp;
	mxLogical *in_vec;
	//mxLogical *fz;
	double *BH;
	int* fz;

	nbins_theta = mxGetPr(in[IN_NBINS_T]);
	nbins_r = mxGetPr(in[IN_NBINS_R]);
	nsamp = mxGetPr(in[IN_NSAMP]);
	in_vec = mxGetLogicals(in[IN_VEC]);
	r_array = mxGetPr(in[IN_RA]);
	//theta_array = mxGetPr(in[IN_TA]);
	//r_bin_edges = mxGetPr(in[IN_RBE]);
	
	//theta_array_q = mxGetPr(in[IN_TAQ]);
	//r_array_q = mxGetPr(in[IN_RAQ]);
	//fz = mxGetLogicals(in[IN_FZ]);
	//r_array = mxGetPr(in[IN_RA]);
	r_inner = mxGetPr(in[IN_RI]);
	r_outer = mxGetPr(in[IN_RO]);
	Bsamp = mxGetPr(in[IN_BSAMP]);
	Tsamp = mxGetPr(in[IN_TSAMP]);

	const int* dims = mxGetDimensions(in[IN_RA]);
	
	int nsize = (int)nsamp[0];

	theta_array = new double[int(nsamp[0]*nsamp[0])]();

	for(int i=0; i < nsize; i++)
	{
		for(int j=0; j < nsize; j++)
		{
			theta_array[j + i*nsize] = atan2(Bsamp[1 + i*2]-Bsamp[1 + j*2], Bsamp[i*2]-Bsamp[j*2]) - Tsamp[i];
		}
	}

	//for(int i=0; i < nsize; i++)
	//{
	//	for(int j=0; j < nsize; j++)
	//	{
	//		printf("%.3f:%.3f:%.3f ", Bsamp[1 + i*2]-Bsamp[1 + j*2], Bsamp[i*2]-Bsamp[j*2], theta_array[i + j*nsize]);
	//	}
	//	cout << endl;
	//}

	double mean = 0;
	int count_mean = 0;

	for(int i=0; i <dims[0]; i++)
	{
		if(in_vec[i] == 1)
		{
			for(int j=0; j < dims[0]; j++)
			{
				if(in_vec[j] == 1)
				{
					mean += r_array[i + j*dims[0]];
					count_mean ++;
				}
				
			}
		}
	}
	
	mean = mean/count_mean;
	

	r_bin_edges = new double[(int)nbins_r[0]]();
	for(int i=0; i < (int)nbins_r[0]; i++)
	{
		r_bin_edges[i] = pow(10, log10(r_inner[0]) + (log10(r_outer[0]) - log10(r_inner[0]))*i/(nbins_r[0]-1));
	}
	
	
	r_array_q = new double[dims[0]*dims[1]]();	
	
	fz = new int[dims[0]*dims[1]]();

	//for(int i=0; i < (int)nbins_r[0]; i++)
	//{
	//	cout << r_bin_edges[i] << ' ';
	//}	
	//cout << endl;
	
	for(int i=0; i < dims[0]; i++)
	{
		for(int j=0; j < dims[1]; j++)
		{
			for(int m=0; m<(int)nbins_r[0]; m++)
			{
				r_array_q[i + j*dims[0]] += (r_array[i + j*dims[0]]/mean < r_bin_edges[m]);
				//r_array_q[i + j*dims[0]] += (r_array_n[i + j*dims[0]] < r_bin_edges[m]);

			}

			//printf("%.2f ", r_array[i + j*dims[0]]/mean);
		}
		//cout << endl;
	}

	//cout << "Here 1" << endl;

	for(int i=0; i < dims[0]; i++)
	{
		for(int j=0; j < dims[1]; j++)
		{
			if(r_array_q[i + j*dims[0]] > 0)
				fz[i + j*dims[0]] = 1;
			//printf("%.2f ", r_array_q[i + j*dims[0]]);
		}
		//cout << endl;
	}
		
	//cout << "Here 2" << endl;

	int nbins = int(nbins_theta[0] * nbins_r[0]);
	
	out[OUT_BH] = mxCreateDoubleMatrix((int)*nsamp, nbins, mxREAL);
	out[OUT_MD] = mxCreateDoubleMatrix(1, 1, mxREAL);

	BH = mxGetPr(out[OUT_BH]);
	mean_dist = mxGetPr(out[OUT_MD]);
	mean_dist[0] = mean;
	
	theta_array_q = new double[dims[0]*dims[1]];
	
	for(int i=0; i < dims[0]; i++)
	{
		for(int j=0; j < dims[1]; j++)
		{
			theta_array_q[i + j*dims[0]] = double(1 + floor(rem(rem(theta_array[i + j*dims[0]], 2*PI)+2*PI, 2*PI)/(2*PI/nbins_theta[0])));
			//printf("%.2f:%.2f ", theta_array[i + j*dims[0]], theta_array_q[i + j*dims[0]]);
		}
		//cout << endl;
	}
	
	int *fzn = new int[dims[1]]();
	
	for(int n=0; n < (int)*nsamp; n++)
	{
		for(int i=0; i < dims[1]; i++)
		{
			fzn[i] = fz[dims[0]*i + n]  && in_vec[i];
			
		}
		
		for(int i=0; i < dims[1]; i++)
		{	
			if( fzn[i] == 1)
			{
				for(int j=0; j < dims[1]; j++)
				{
					if( fzn[j] == 1)
					{
						int d1 = (int)theta_array_q[n + dims[0]*i]-1;
						int d2 = (int)r_array_q[n + dims[0]*j]-1;

						BH[n + int(*nsamp)*(d1 + d2*(int)nbins_theta[0])] = 1;
					}
				}
			}
		}

	}

	delete [] theta_array;	
	delete [] r_bin_edges;
	delete [] fz;
	delete [] r_array_q;	
	delete [] theta_array_q;
	delete [] fzn;
}
