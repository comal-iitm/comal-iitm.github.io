#include "mex.h"
#include <stdio.h>
#include <matrix.h>
#include <math.h>
#include <iostream>

using namespace std;

#define	XNORMRESAMPLED out[0]
#define	YNORMRESAMPLED out[1]
#define INDCORRECTED out[2]
#define	INDMAPNEW out[3]
#define RBDN out[4]

void mexFunction(int nout, mxArray *out[], int nin, const mxArray *in[])
{
	//cout << "Here 0" << endl;
	enum {IN_X=0, IN_Y, IN_IDX, IN_INDMAP, IN_CIRC};
	
	double *xNorm, *yNorm, *circflag, *indmap, *idx;
	//	vector<double> xNormCirc, yNormCirc, cumBasisNorm;
	double *xNormCirc, *yNormCirc, *cumBasisNorm;
	double *xNormResampled,*yNormResampled,*indmapnew, *rbdn, *indcorrected;
	double maxBasisPts;
	
	int N, sz;
	int i, curind = 1, ind1;
    float dist1,dist2,sumdist; 
	
	const int* dims = mxGetDimensions(in[IN_X]);
	
	//cout << "Here 1" << endl;

	if( dims[0] < 2)
		printf("Problem with resampling: Size less than 2");

	int dims_new;

	//cout << "Here 2" << endl;

	xNorm = mxGetPr(in[IN_X]);
	yNorm = mxGetPr(in[IN_Y]);
	circflag = mxGetPr(in[IN_CIRC]);
	indmap = mxGetPr(in[IN_INDMAP]);
	idx = mxGetPr(in[IN_IDX]);
	
	//cout << "Here 3" << endl;

	if(*circflag == 1)
	{
		xNormCirc = new double[dims[0]+1];
		yNormCirc = new double[dims[0]+1];
		cumBasisNorm = new double[dims[0]+1];

		for(int i=0; i<dims[0]; i++)
		{
			xNormCirc[i] = xNorm[i];
			yNormCirc[i] = yNorm[i];
		}

		xNormCirc[dims[0]] = xNorm[0];
		yNormCirc[dims[0]] = yNorm[0];

		dims_new = dims[0]+1;
	}
	else
	{
		xNormCirc = new double[dims[0]];
		yNormCirc = new double[dims[0]];
		cumBasisNorm = new double[dims[0]];
		
		for(int i=0; i<dims[0]; i++)
		{
			xNormCirc[i] = xNorm[i];
			yNormCirc[i] = yNorm[i];
		}

		dims_new = dims[0];
	}

	//cout << "Here 4" << endl;

	for(int i=1; i < dims_new; i++)
	{
		if(i == 0)
		{
			cumBasisNorm[i] = 0;
		}
		else
		{
			cumBasisNorm[i] = cumBasisNorm[i-1] + sqrt((xNormCirc[i]-xNormCirc[i-1])*(xNormCirc[i]-xNormCirc[i-1]) + (yNormCirc[i] - yNormCirc[i-1])*(yNormCirc[i] - yNormCirc[i-1]));

		}
	}
	
	//cout << "Here 5" << endl;

	maxBasisPts = floor(cumBasisNorm[dims_new-1] + 0.5);
	
	XNORMRESAMPLED = mxCreateDoubleMatrix(maxBasisPts, 1, mxREAL); 
    YNORMRESAMPLED = mxCreateDoubleMatrix(maxBasisPts, 1, mxREAL); 
    INDMAPNEW = mxCreateDoubleMatrix(maxBasisPts, 1, mxREAL); 
    RBDN = mxCreateDoubleMatrix(1, maxBasisPts-2, mxREAL);
    INDCORRECTED = mxCreateDoubleMatrix(1, 1, mxREAL);
    
    xNormResampled = mxGetPr(XNORMRESAMPLED);
    yNormResampled = mxGetPr(YNORMRESAMPLED);
    indmapnew = mxGetPr(INDMAPNEW); 
    rbdn = mxGetPr(RBDN);
	indcorrected = mxGetPr(INDCORRECTED);
	
	indcorrected[0] = floor(cumBasisNorm[int(idx[0])-1]+0.5) + 1;
	
	//cout << "Here 6" << endl;

    for (i=0;i<maxBasisPts;i++) {
         while (cumBasisNorm[curind+1 -1] < i) {
             curind = curind + 1; 
         }
    
        dist1 = i - cumBasisNorm[curind - 1];
        dist2 = cumBasisNorm[curind + 1 - 1] - i;
  
        sumdist = (dist1 + dist2);      
/*        printf("\nsumdist is %d %f\n",i,sumdist); */
    
        xNormResampled[i + 1 - 1] = (xNormCirc[curind - 1] * dist2  + xNormCirc[curind + 1 - 1] * dist1)/sumdist;
        yNormResampled[i + 1 - 1] = (yNormCirc[curind - 1] * dist2  + yNormCirc[curind + 1 - 1] * dist1)/sumdist;
    	
		if ( i > 0 && i < maxBasisPts-1)
		{
			rbdn[i-1] = sqrt((xNormResampled[i] - xNormResampled[i-1])*(xNormResampled[i] - xNormResampled[i-1]) + (yNormResampled[i] - yNormResampled[i-1])*(yNormResampled[i] - yNormResampled[i-1]));
		}

        if (dist1 < dist2) {
            indmapnew[i + 1 -1] = curind; }
        else {
            indmapnew[i + 1 - 1] = curind+1; }
        
        sz = dims_new;

        if ((curind+1) == sz) {
            indmapnew[i + 1 -1] = 1; }
    
		ind1 = indmapnew[i +1 -1];
		indmapnew[i+1 - 1] = indmap[ind1 - 1];

    }
    
	//cout <<"Here 7" << endl;
    delete [] xNormCirc;
    delete [] yNormCirc;
    delete [] cumBasisNorm;

	//cout <<"Here 8" << endl;
    
}



			
