#include "mex.h"
#include <stdio.h>
#include <matrix.h>
#include <math.h>

void mexFunction(int nout, mxArray *out[], int nin, const mxArray *in[])
{
	enum {IN_SIZE=0, IN_ROW, IN_COL};
	enum {OUT_ARR=0};

	double *matrixSize, *rowSub, *colSub;
	double *linearInd;

	const int* dims = mxGetDimensions(in[IN_ROW]);
	int length = (dims[0] > dims[1])? dims[0]:dims[1];

	matrixSize = mxGetPr(in[IN_SIZE]);
	rowSub = mxGetPr(in[IN_ROW]);
	colSub = mxGetPr(in[IN_COL]);

	out[OUT_ARR] = mxCreateDoubleMatrix(dims[0], dims[1], mxREAL);

	linearInd = mxGetPr(out[OUT_ARR]);

	for(int i=0; i<length; i++)
	{
		linearInd[i] = matrixSize[0]*(colSub[i]-1) + rowSub[i]; 
	}
}

