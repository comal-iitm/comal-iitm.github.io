function [cornersAll ...
          maskCornerAll ...
          boundaryPartAll ...
          scAll ...
          areaPerAll ...
          topLeftImAll] = getCorners(img, regionsDecCell, ...                                                                                    
                                     variationNThreshCell, ...                                          
                                     plusOrMinusCell, ...                                     
                                     coordFg) %maskAll boundaryAll


commonVar  = globalVariables(1);
sigSCell = commonVar.sigSmin(1);
tCell = 1;

cornersAll=[];
maskCornerAll1=[];
boundaryPartAll1=[];
scAll1=[];
areaPerAll1=[];
topLeftImAll1=[];

indBlockCell = [1, 1];
indBlockSzCell = [size(img, 1), size(img, 2)];

if ~isempty(regionsDecCell),
    
    for split = 1:size(regionsDecCell, 1),
        %         disp(split);
        regionsDec = regionsDecCell{split};
        indBlock = indBlockCell;
        indBlockSz = indBlockSzCell;
        
        blockNo = 1;  %iter = iterCell(split);
        
        variationNThresh = variationNThreshCell{split};
        sigS = sigSCell(split);
        plusOrMinus = plusOrMinusCell{split};
        
        t = tCell;

        remsxl2 = 0.8*sigS;
        sxi2 = sigS*(commonVar.smoothingFactor);
        
        blockCentre = indBlockSz./2;
        variationMetric = variationNThresh(1,:);
        
        thresh = variationNThresh(2,:);
        range0 = sigS*commonVar.iterBlockFactor;
        range = round((range0*0.8)/5)*5;

        for ind=1:length(regionsDec),
            
            corners = [];
            maskCorners = [];
            boundaryParts = []; 
            scs = [];
            areaPers = [];
            topLeftIms = [];
            
            sel = regionsDec{ind};

            mask = zeros(indBlockSz(1), indBlockSz(2));
            mask(sel) =1;
            iter=0; %Sel has the column major index of which vals of mask are 1
            
            [boundary, ~, circflag] = CalculateERBoundary_pre(mask, iter, commonVar);
            %Calculate the boundary points and return whether it is a whole MSER or not
            
            if 0,
                boundaryAll{split}{ind} = boundary; %could be used later if necessary
                circflagList{split}(ind) = circflag;
            end

            if ~isempty(boundary)
                
                for bNo =  1:length(boundary)
                    
                    if ~isempty(boundary{bNo}),
                        %             sxl2 = smoothingFactor * sxi2;
                        corners0 = intpointdetom(boundary{bNo}(:, 2), ...
                                                 boundary{bNo}(:, 1), ...
                                                 remsxl2, sxi2, -1, ...
                                                 circflag, iter, t);

                        if ~isempty(corners0),
                            
                            szCorners = size(corners0, 1);
                            corners0Im =  corners0(:, 1:2) + repmat((indBlock-1), ...
                                                                    szCorners, 1);
                            
                            if 1     %removing pts that are outside the forground
                                
                                corners0XY = round(corners0Im(:, 1:2));
                                indValid0 = ismember(corners0XY, coordFg, 'rows');
                                % coordFg{2} contains a finer fg obj that can filter out init points
                                indValid = find(indValid0);
                                corners0 = corners0(indValid, :);
                                corners0Im = corners0Im(indValid, :);
                            
                            end
                            
                            if ~isempty(corners0)
                                
                                szCorners0 = size(corners0, 1);
                                maskCorner0 = cell(szCorners0, 1);
                                boundaryPart0 = cell(szCorners0, 1);
                                sc0 = cell(szCorners0, 1);
                                areaPer0 = zeros(szCorners0, 1);
                                lenRegion0 = zeros(szCorners0, 1);
                                topLeftIm0 = cell(szCorners0, 1);

                                indCor = 1:szCorners0;
                                
                                for iCor=1:szCorners0,
                                    
                                    [maskCorner boundaryPart sc ...
                                     areaPer lenRegion topLeftIm] = getMask(corners0(iCor, :), ...
                                                                            boundary{bNo}, ...
                                                                            circflag, ...
                                                                            range, ...
                                                                            mask);
                                    if isempty(maskCorner)
                                        
                                        indCor(iCor)=[];
                                    
                                    else
                                        
                                        maskCorner0{iCor} = maskCorner;
                                        boundaryPart0{iCor} = boundaryPart;
                                        sc0{iCor} = sc;
                                        areaPer0(iCor) = areaPer;
                                        lenRegion0(iCor) = lenRegion;
                                        topLeftIm0{iCor} = topLeftIm;
                                    
                                    end
                                    
                                end

                                corners0 = corners0(indCor, :);
                                maskCorner0 = maskCorner0(indCor);
                                boundaryPart0 = boundaryPart0(indCor);
                                sc0 = sc0(indCor);
                                areaPer0 = areaPer0(indCor);
                                lenRegion0 = lenRegion0(indCor);
                                topLeftIm0 = topLeftIm0(indCor);

                                if ~isempty(corners0),
                                    
                                    szCorners0 = size(corners0,1);

                                    corners0(:, 11) = blockNo;
                                    corners0(:, 12) = repmat(ind, szCorners0, 1);
                                    corners0(:, 14) = repmat(thresh(ind), szCorners0, 1);
                                    corners0(:, 15) = repmat(bNo, szCorners0, 1);
                                    corners0(:, 16) = areaPer0 ;
                                    corners0(:, 17) = lenRegion0;
                                    
                                    if ~iter,
                                        
                                        corMovtFromCentreXY = abs(corners0(:, 1:2) - ...
                                                                  repmat(blockCentre,...
                                                                  szCorners0, 1));
                                        corMovtFromCentre = (corMovtFromCentreXY).^2;
                                        corMovtFromCentre = sqrt(corMovtFromCentre(:,1) + ...
                                                                 corMovtFromCentre(:,2));
                                        corners0(:,18:19) = corMovtFromCentreXY; %new variable for uniquing
                                    
                                    end
                                    
                                    corners = [corners; [corners0Im corners0(:, 3:end)]];
                                    maskCorners = [maskCorners; maskCorner0];
                                    boundaryParts = [boundaryParts; boundaryPart0];
                                    scs = [scs; sc0];
                                    areaPers = [areaPers; areaPer0];
                                    topLeftIms = [topLeftIms ; topLeftIm0];
                                    
                                end
                                
                                commonVar.displayflag=0;
                                
                                if commonVar.displayflag, %all within imBlock
                                    
                                    figure, imshow(mask), hold on,
                                    szBoundary = length(boundary{bNo});
                                    plot(boundary{bNo}(:,2), boundary{bNo}(:,1),'r');
                                    plot(corners0(:,1),corners0(:,2),'*g');
                                    commonVar.displayflag=0;

                                    if 0,
                                        
                                        %for displaying onto image:
                                        figure, imshow(mask), hold on; % info not in here!
                                        boundary{bNo}(:,1) =  boundary{bNo}(:,1) + repmat(indBlock(2),szBoundary,1); %-1 needed to subtracted?
                                        boundary{bNo}(:,2) =  boundary{bNo}(:,2) + repmat(indBlock(1),szBoundary,1);
                                        plot(boundary{bNo}(:,2), boundary{bNo}(:,1),'r');
                                    
                                    end
                                    
                                end
                                
                                commonVar.displayflag=0;
                            
                            end
                            
                        end
                        
                    end
                    
                end
                
            end

            if ~iter & ~isempty(corners), %for translating corner onto main image
           
                corners(:, 13) = variationMetric(1, ind);
                corners(:, 20) = plusOrMinus(ind);
            
            end

            cornersAll = [cornersAll; corners];
            maskCornerAll1 = [maskCornerAll1; maskCorners];
            boundaryPartAll1 = [boundaryPartAll1; boundaryParts];
            scAll1 = [scAll1; scs]; areaPerAll1 = [areaPerAll1; areaPers];
            topLeftImAll1 = [topLeftImAll1; topLeftIms];
        
        end
        
        maskCornerAll{split} = maskCornerAll1;
        boundaryPartAll{split} = boundaryPartAll1;
        scAll{split} = scAll1;
        areaPerAll{split} = areaPerAll1;
        topLeftImAll{split} = topLeftImAll1;
    
    end
end
end