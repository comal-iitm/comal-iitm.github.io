function [cornersAll cornersAllOrig boundaryNewTrans regionsFinal blockSzFinal topLeftFinal plusOrMinusFinal] = getConvergedCornersBruteForce(cornersInitAll,regionDecAll,plusOrMinusAll,imgPath,boundaryAll,circFlagList,t,resizefactor,splitNo)

cornersAll = []; cornersAllOrig=[]; boundaryNewTrans=[]; regionsFinal=[]; blockSzFinal=[]; topLeftFinal=[]; plusOrMinusFinal=[];
radius=5;
numConvByRad = 0;
corRows = size(cornersInitAll,1);

for cornerIdx = 1:corRows
    [cornersAllRad cornersAllOrigRad boundaryNewTransRad regionsFinalRad blockSzFinalRad topLeftFinalRad plusOrMinusFinalRad] = getConvergedCorner(cornersInitAll(cornerIdx,:),regionDecAll(cornerIdx),plusOrMinusAll(cornerIdx),imgPath,boundaryAll(cornerIdx),circFlagList(cornerIdx),t,resizefactor,splitNo);
    
    if isempty(cornersAllRad)
        ptsRad = GetPointsWithinRad(cornersInitAll(cornerIdx,1),cornersInitAll(cornerIdx,2),radius,cornersInitAll(cornerIdx,3:end));
        numRadPts = size(ptsRad{1},1);        
        regionDecAllRad = repmat(regionDecAll(cornerIdx),numRadPts,1);
        plusOrMinusAllRad = repmat(plusOrMinusAll(cornerIdx),numRadPts,1);
        boundaryAllRad = repmat(boundaryAll(cornerIdx),numRadPts,1);
        circFlagListRad = repmat(circFlagList(cornerIdx),numRadPts,1);
        [cornersAllRad, cornersAllOrigRad, ~,regionsFinalRad, blockSzFinalRad, topLeftFinalRad, plusOrMinusFinalRad] = getConvergedCorner(ptsRad{1},regionDecAllRad,plusOrMinusAllRad,imgPath,boundaryAllRad,circFlagListRad,t,resizefactor,splitNo);
        %don't run iter, get one shot distance from center out and compare
        if ~isempty(cornersAllRad)
            [~,indBestInRad] = min(cornersAllRad(:,21));
            numConvByRad = numConvByRad +1;
            
            cornersAllRad = cornersAllRad(indBestInRad,:);
            cornersAllOrigRad = cornersAllOrigRad(indBestInRad,:) ;            
%             boundaryNewTransRad = boundaryNewTransRad(indBestInRad) ;
            regionsFinalRad = regionsFinalRad(indBestInRad) ;
            blockSzFinalRad = blockSzFinalRad(indBestInRad,:) ;
            topLeftFinalRad = topLeftFinalRad(indBestInRad,:) ;
            plusOrMinusFinalRad = plusOrMinusFinalRad(indBestInRad,:);
        end        
    end

    cornersAll = [cornersAll; cornersAllRad];

    cornersAllOrig = [cornersAllOrig; cornersAllOrigRad];
%     boundaryNewTrans = [boundaryNewTrans; boundaryNewTransRad] ;
    regionsFinal = [regionsFinal regionsFinalRad];
    blockSzFinal = [blockSzFinal; blockSzFinalRad];
    topLeftFinal = [topLeftFinal; topLeftFinalRad];
    plusOrMinusFinal = [plusOrMinusFinal; plusOrMinusFinalRad];
    
end
fprintf('%d points out of %d points converged in this block',numConvByRad,corRows);