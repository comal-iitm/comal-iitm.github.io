Cut  wehn it reaches 374;
(374-422 ran correctly done)

Run from 423 to end
tSet = getWrongRunImages(1:140)
caltech