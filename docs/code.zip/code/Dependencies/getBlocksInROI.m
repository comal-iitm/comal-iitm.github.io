function [imBlocks indBlock indBlockSz] = getBlocksInROI(IM,t, roi)
%imBlocks is the set of image blocks extracted from the image I
%indBlock is the top-left coordinates of each imBlock
%indBLockSz is the size of each imBlock
 
  commonVar = globalVariables(t);
  iSz = commonVar.sigSmin(t);
  shift =  round(iSz*commonVar.shiftSizeFactor/5)*5; %The shift or stride

  if shift > (roi.height)
    ysize = shift;
  else
    ysize = roi.height;
  end

  if shift > roi.width
    xsize = shift;
  else
    xsize = roi.width;
  end

  if xsize + roi.x > size(IM, 2)
    roi.x = size(IM, 2) - xsize + 1;
  end

  if ysize + roi.y > size(IM, 1)
    roi.y = size(IM, 1) - ysize + 1;
  end

  I = IM(roi.y:roi.y+ysize-1, roi.x:roi.x+xsize-1);

   %Obtain the image size

  [yInd xInd]=meshgrid(1:shift:ysize,1:shift:xsize); %Mesh grid gives us the list of points in the image where we take ROI
  [szIndX szIndY] = size(yInd);
  yInd=reshape(yInd,szIndX*szIndY,1); %List of all possible y coords with the correct number of repetitions
  xInd=reshape(xInd,szIndX*szIndY,1); %List of all possible x coords with the correct number of repetitions
  commonVar.displayflag = 0;
  
  if 0
      figure, imshow(IM,[]), hold on, plot(xInd,yInd,'*b');
  end

  sz0 =  round(iSz*commonVar.iterBlockFactor/5)*5; %Get the actual shift using some factor mentioned
  sz = round(sz0*commonVar.blockMultFactor);%block size
  xIndEnd = xInd+sz-1; yIndEnd = yInd+sz-1; %The shifted coordinates
  xBor = xIndEnd > xsize; %See which indices cross the border
  xInd(xBor) = xInd(xBor)  - (xIndEnd(xBor) - xsize); %For those points, shift the start point to the left
  xIndEnd(xBor) = xsize;

  yBor = yIndEnd > ysize; %Similar to the above
  yInd(yBor) = yInd(yBor)  - (yIndEnd(yBor) - ysize);
  yIndEnd(yBor) = ysize;

  xyInd = unique([xInd yInd],'rows'); %Obtain the unique pair of starting points
  xyIndEnd = unique([xIndEnd yIndEnd],'rows'); %Obtain the unique pair of end points 
  xInd = xyInd(:,1); yInd = xyInd(:,2); %All possible x and y start coordinates
  xIndEnd = xyIndEnd(:,1); yIndEnd = xyIndEnd(:,2); %All possible x and y end points
  
  xInd = xInd + roi.x - 1;
  yInd = yInd + roi.y - 1;
  xIndEnd = xIndEnd + roi.x - 1;
  yIndEnd = yIndEnd + roi.y - 1;
  if commonVar.displayflag
    imshow(IM);
    hold on, plot(xInd,yInd,'*r');
  end

  delList=[];

  for i=1:length(xInd) %Obtain all the image blocks and store them in the cells imBlocks
    IBlock = IM(yInd(i):yIndEnd(i),xInd(i):xIndEnd(i));
    imBlocks{i}  = IBlock;
    indBlockSz{i} = size(IBlock);
    if indBlockSz{i}(1)*indBlockSz{i}(2) < (sz^2)/2
        delList = [delList; i];
    end
  end

  xInd(delList) = []; yInd(delList) = [];
  imBlocks(delList) =[];
  indBlockSz(delList) =[];
  
  imBlocks = imBlocks';
  indBlockSz = indBlockSz';
  indBlock = mat2cell([xInd yInd],ones(length(xInd),1));
  %testing:
  
  %{
  if commonVar.displayflag
    %specify some a
    plot(xInd(a),yInd(a),'*r');
    figure, imshow(imBlocks{a});
  end
  %}
