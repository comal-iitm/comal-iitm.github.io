function RepeatabilityAllParallax() %For Parallax images
stereo=1;desciptor=1;
overErr = 4;
if 0
    %     Select;
    %     OtherDetectors('hr1');
    OtherDetectors('hr3');
    %     OtherDetectors('hs1');
    OtherDetectors('hs2');
    OtherDetectors('fas');
    OtherDetectors('fer');
end


if 1
    hFig1 = figure;clf;grid on;
    ylabel('Repeatability %','FontSize',28,'FontWeight','bold')
    
    xlabelString = sprintf('Boundary  \t\t Non-Boundary \t\t All ');
    figure(hFig1); %axis([1.8 6 0 102]);
    xAxis = 1:3;
    
    xlabel(xlabelString,'FontSize',26,'FontWeight','bold');
    
    hold on;
    hFig2 = figure;clf;
    grid on;
    ylabel('Number of Correspondences','FontSize',28,'FontWeight','bold')
    xlabel(xlabelString,'FontSize',26,'FontWeight','bold');
    hold on;
    
    hFig3 = figure;clf;
    grid on;
    ylabel('Matching Score%','FontSize',28,'FontWeight','bold')
    xlabel(xlabelString,'FontSize',26,'FontWeight','bold');
    hold on;
    
    hFig4 = figure;clf;grid on;
    ylabel('Number of Matches','FontSize',28,'FontWeight','bold')
    xlabel(xlabelString,'FontSize',26,'FontWeight','bold');
    hold on;
    
    hFig5 = figure;clf;grid on;
    ylabel('Repeatability %','FontSize',28,'FontWeight','bold')
    xlabel(xlabelString,'FontSize',26,'FontWeight','bold');
    hold on;
    
    hFig6 = figure;clf;
    grid on;
    ylabel('Number of Correspondences','FontSize',28,'FontWeight','bold')
    xlabel(xlabelString,'FontSize',26,'FontWeight','bold');
    hold on;
    
end

% detectorTypes = ['hr1';'hr2';'hr3';'msr';'hs1';'hs2';'sus';'shi';'dog';'fas';'hom'];
detectorTypes = ['hom';'hr3';'hs2';'fas';'fer';'msr'];
mark=['-kx';'-rv';'-gs';'-m+';'-bp'];
for det=1:6
    seqrepeat=[];seqrepeatB=[]; seqrepeatNB=[];
    seqcorresp=[];
    dirData = '../images';
    Tuples = getTuples(dirData);
    datasetsFull = Tuples(:,1);
    dataset = unique(datasetsFull);
    for d = 1:length(dataset)
        indDataset = strcmp(dataset{d},datasetsFull);
        numImgs = length(datasetsFull(indDataset));
        imageList = Tuples(indDataset,2);
        for imNo = 2:numImgs
            %     imgInd = regexp(Tuples{imNo,2}, '[0-9]');
            %     imgno2 =  Tuples{imNo,2}(imgInd);
            if detectorTypes(det,:)=='hom'
                detector = 'harronmser';
            else
                detector = detectorTypes(det,:);
            end
            if stereo
                file1=sprintf('../data/results/%s/img0.%s.txt',dataset{d},detector);
                file1b=sprintf('../data/results/%s/img0Boundary.%s.txt',dataset{d},detector);
                file1nb=sprintf('../data/results/%s/img0NonBoundary.%s.txt',dataset{d},detector);
                file1full=sprintf('../data/results/%s/img0Full.%s.txt',dataset{d},detector);
                file2=sprintf('../data/results/%s/img%d.%s.txt',dataset{d},imNo-1,detector);
                file2full=sprintf('../data/results/%s/img%dFull.%s.txt',dataset{d},imNo-1,detector);
                
                file1bDes=sprintf('../data/results/%s/img0BoundaryDes.%s.txt',dataset{d},detector);
                file1nbDes=sprintf('../data/results/%s/img0NonBoundaryDes.%s.txt',dataset{d},detector);
                file1fullDes=sprintf('../data/results/%s/img0FullDes.%s.txt',dataset{d},detector);
                file2fullDes=sprintf('../data/results/%s/img%dFullDes.%s.txt',dataset{d},imNo-1,detector);
                
                
                Hunity=sprintf('../data/results/%s/Hunity',dataset{d});
                if dataset{d}=='tsuk'
                    
                    img1=sprintf('../data/results/%s/imL.png',dataset{d});
                    img2=sprintf('../data/results/%s/imR.png',dataset{d});
                    
                else
                    img1=sprintf('../data/results/%s/im2.ppm',dataset{d});
                    img2=sprintf('../data/results/%s/im6.ppm',dataset{d});
                    
                    
                end
                if 0 %do this for 5
                    [f1New ysize xsize]= AddDisparityNDisplay(file1,file2,sprintf('../data/results/%s',dataset{d}),file1b,file1nb,file1full,file2full,file1bDes,file1nbDes,file1fullDes,file2fullDes);
                end
                
                if desciptor
                    
                    file1bDesOp=sprintf('../data/results/%s/img0Boundary.%s.sift.txt',dataset{d},detector);
                    file1nbDesOp=sprintf('../data/results/%s/img0NonBoundary.%s.sift.txt',dataset{d},detector);
                    file1fullDesOp=sprintf('../data/results/%s/img0Full.%s.sift.txt',dataset{d},detector);
                    file2fullDesOp=sprintf('../data/results/%s/img%dFull.%s.sift.txt',dataset{d},imNo-1,detector);
                    
                    if 1 %firsttime
                        runSift = sprintf('./compute_descriptors.ln -sift -i %s -p1 %s -o1 %s',img1,file1bDes,file1bDesOp);
                        system(runSift);
                        runSift = sprintf('./compute_descriptors.ln -sift -i %s -p1 %s -o1 %s',img1,file1nbDes,file1nbDesOp);
                        system(runSift);
                        runSift = sprintf('./compute_descriptors.ln -sift -i %s -p1 %s -o1 %s',img1,file1fullDes,file1fullDesOp);
                        system(runSift);
                        runSift = sprintf('./compute_descriptors.ln -sift -i %s -p1 %s -o1 %s',img1,file2fullDes,file2fullDesOp);
                        system(runSift);
                        
                    end
                    
                    resizeFactorPts = [1 1];
                    
                    [v_overlap,v_repeatability,v_nb_of_corespondences,matching_scoreB,nb_of_matchesB,twi] = repeatability(file2fullDesOp,file1bDesOp,Hunity,img1,img2,0,imNo,resizeFactorPts);
                    [v_overlap,v_repeatability,v_nb_of_corespondences,matching_scoreNB,nb_of_matchesNB,twi] = repeatability(file2fullDesOp,file1nbDesOp,Hunity,img1,img2,0,imNo,resizeFactorPts);
                    [v_overlap,v_repeatability,v_nb_of_corespondences,matching_score,nb_of_matches,twi] = repeatability(file2fullDesOp,file1fullDesOp,Hunity,img1,img2,0,imNo,resizeFactorPts);
                    
                    matching_scoreBDet(1,det) = matching_scoreB;  nb_of_matchesBDet(1,det) = nb_of_matchesB;
                    matching_scoreNBDet(1,det) = matching_scoreNB; nb_of_matchesNBDet(1,det) = nb_of_matchesNB;
                    matching_scoreDet(1,det) = matching_score; nb_of_matchesDet(1,det) = nb_of_matches;
                                        
                    if strcmp(detector,'msr');
                        mserFlag = 1;
                    else
                        mserFlag = 0;
                    end
                    
                    [erro,repeatB,correspB,~,~,~,twout,wout,featTest1,featTest2,strength1,strength2,cornerness1,cornerness2,repeatMultMatchesB,correspMultMatchesB]= repeatabilityHarronMser(file2full,file1b,Hunity,img1,img2, 1,1,imNo,1,resizeFactorPts,mserFlag); %numMserTot(1),numMserTot(imgNo)
                    [erro,repeatNB,correspNB,~,~,~,twout,wout,featTest1,featTest2,strength1,strength2,cornerness1,cornerness2,repeatMultMatchesNB,correspMultMatchesNB]= repeatabilityHarronMser(file2full,file1nb,Hunity,img1,img2, 1,1,imNo,1,resizeFactorPts,mserFlag); %numMserTot(1),numMserTot(imgNo)
                    [erro,repeat,corresp,~,~,~,twout,wout,featTest1,featTest2,strength1,strength2,cornerness1,cornerness2,repeatMultMatches,correspMultMatches]= repeatabilityHarronMser(file2full,file1full,Hunity,img1,img2, 1,1,imNo,1,resizeFactorPts,mserFlag); %numMserTot(1),numMserTot(imgNo)
                    
                    
                    repeatBDet(1,det) = repeatB(overErr);  corresBDet(1,det) = correspB(overErr);
                    repeatNBDet(1,det) = repeatNB(overErr); corresNBDet(1,det) = correspNB(overErr);
                    repeatDet(1,det) = repeat(overErr); corresDet(1,det) = corresp(overErr);
                    
                    repeatMultMatchesBDet(1,det) = repeatMultMatchesB(overErr);  corresMultMatchesBDet(1,det) = correspMultMatchesB(overErr);
                    repeatMultMatchesNBDet(1,det) = repeatMultMatchesNB(overErr); corresMultMatchesNBDet(1,det) = correspMultMatchesNB(overErr);
                    repeatMultMatchesDet(1,det) = repeatMultMatches(overErr); corresMultMatchesDet(1,det) = correspMultMatches(overErr);
                    
                    
                end
            end
        end
        
    end
end

figure(hFig1);  bar([repeatBDet; repeatNBDet; repeatDet]);
h_legend = legend('CoMIC','Harris','Hessian','Fast-9','Fast-er','Mser','Location','SouthEast');
set(h_legend, 'FontSize',45)
set(gca,'FontWeight','bold','LineWidth',5,'FontSize',40);
set(gca,'xtick',[1 2 3],'xticklabel',{});

figure(hFig2);  bar([corresBDet; corresNBDet; corresDet]);
h_legend = legend('CoMIC','Harris','Hessian','Fast-9','Fast-er','Mser','Location','SouthEast');
set(h_legend, 'FontSize',45)
set(gca,'FontWeight','bold','LineWidth',10,'FontSize',40);
set(gca,'xtick',[1 2 3],'xticklabel',{});

figure(hFig3);  bar([matching_scoreBDet; matching_scoreNBDet; matching_scoreDet]);
h_legend = legend('CoMIC','Harris','Hessian','Fast-9','Fast-er','Mser','Location','SouthEast');
set(h_legend, 'FontSize',45)
set(gca,'FontWeight','bold','LineWidth',5,'FontSize',40);
set(gca,'xtick',[1 2 3],'xticklabel',{});

figure(hFig4);  bar([nb_of_matchesBDet; nb_of_matchesNBDet; nb_of_matchesDet]);
h_legend = legend('CoMIC','Harris','Hessian','Fast-9','Fast-er','Mser','Location','SouthEast');
set(h_legend, 'FontSize',45)
set(gca,'FontWeight','bold','LineWidth',5,'FontSize',40);
set(gca,'xtick',[1 2 3],'xticklabel',{});

figure(hFig5);  bar([repeatMultMatchesBDet; repeatMultMatchesNBDet; repeatMultMatchesDet]);
h_legend = legend('CoMIC','Harris','Hessian','Fast-9','Fast-er','Mser','Location','SouthEast');
set(h_legend, 'FontSize',45)
set(gca,'FontWeight','bold','LineWidth',5,'FontSize',40);
set(gca,'xtick',[1 2 3],'xticklabel',{});

figure(hFig6);  bar([corresMultMatchesBDet; corresMultMatchesNBDet; corresMultMatchesDet]);
h_legend = legend('CoMIC','Harris','Hessian','Fast-9','Fast-er','Mser','Location','SouthEast');
set(h_legend, 'FontSize',45)
set(gca,'FontWeight','bold','LineWidth',10,'FontSize',40);
set(gca,'xtick',[1 2 3],'xticklabel',{});
end

