function [feat nb dim numFields]=loadFeaturesMSER(file)

fid = fopen(file, 'r');
dim=fscanf(fid, '%f',1);
if dim==1
    dim=0;
end


numFields=5;
nb = fscanf(fid, '%f',1);


feat = fscanf(fid, '%f', [numFields+dim, nb]);
fclose(fid);
end

% From 'displaydetpts.m'
%
% function [feat nb dim]=loadFeatures(file)
% fid = fopen(file, 'r');
% dim=fscanf(fid, '%f',1);
% if dim==1
% dim=0;
% end
% nb=fscanf(fid, '%d',1);
% feat = fscanf(fid, '%f', [5+dim, inf]);
% fclose(fid);
% %end
