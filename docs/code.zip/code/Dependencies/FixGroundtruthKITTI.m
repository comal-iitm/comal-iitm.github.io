function FixGroundtruthKITTI(d)
%it is easier to calculate this between two frames. So it is stored a  tuple, for each common numObj between two frames.

dirData = '../images';
if ~exist('datasets','var')
    Tuples = getTuples(dirData);
    [datasets indUnique] = unique(Tuples(:,1));
    indUnique = [0; indUnique];
    numImagesAll = indUnique(2:end) - indUnique(1:end-1); %add here if sth is not right
end
dataset = datasets{d};
numFrames = numImagesAll(d); %indUnique(d+1) - indUnique(d);
pairs = [(0:numFrames-1)' (1:numFrames)']; %[imToRun-1 imToRun ];
gtName = sprintf('../image/%s/groundtruth_fixed.txt');
for pNo=1:length(pairs,1)
    close all; gt=[];
    
    dSetNo = getParamsAndDataset(dataset); dilVal= 10;
    imgnoStr1= getImgnoInStrOrInt(pairs(pNo,1),dSetNo); imgnoStr2= getImgnoInStrOrInt(pairs(pNo,2),dSetNo);
    [~,coordFg1,gtAll1, featByBB1, featIndBB1, gtObjId1] = getFgBB([1 1], dset, imgnoStr1, dilVal,'');
    [~,coordFg2,gtAll2, featByBB2, featIndBB2, gtObjId2] = getFgBB([1 1], dset, imgnoStr2, dilVal,'');
    %check if coordFg1 is empty
    imgPath = sprintf('../images/%s/img%s.ppm',dataset,imgnoStr1);  img1 = imread(imgPath);
    imgPath = sprintf('../images/%s/img%s.ppm',dataset,imgnoStr2);  img2 = imread(imgPath);
    figure(1),imshow(img1);  hold on; figure(2),imshow(img2);  hold on;
    
    [commonId commonIdInd1 commonIdInd2]= intersect(gtObjId1,gtObjId2);
    for cId=1:length(commonId)
        numObj1 = commonIdInd1(cId); numObj2 = commonIdInd2(cId);
        
        if gtObjId1(numObj1) == gtObjId2(numObj2)
            figure(1), plot(gtAll1{numObj1}(5:6),'.r'); text(numObj1,gtAll1{numObj1}(5:6)+2);
            figure(2), plot(gtAll2{numObj2}(5:6),'.r'); text(numObj1,gtAll1{numObj1}(5:6)+2);
            
            dispGt = abs(gtAll1{numObj1}(5:6) - gtAll2{numObj2}(5:6))/2;
            figure(1); [xGt1 yGt1] = ginput(1); figure(2); [xGt2 yGt2] = ginput(1);
            gt = [gt; numObj1 xGt1 yGt1 xGt2 yGt2];
            if mod(pNo,20)==0
                save(gt,gtName); %save often so that you don't lose data
            end
            
        end
    end
end
end