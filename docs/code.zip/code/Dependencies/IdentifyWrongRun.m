function IdentifyWrongRun
dirData = '../images';
wrongDatasets=[]; wrongPairNos=[];
if ~exist('datasets','var')
    Tuples = getTuples(dirData);
    [datasets indUnique] = unique(Tuples(:,1));
    indUnique = [0; indUnique];
    numImagesAll = indUnique(2:end) - indUnique(1:end-1); %add here if sth is not right
end
for d=2:size(datasets)
    try
        run_wrong = csvread(sprintf('../data/results/feat-delta5/%s/pairsRunWrong_harronmser.txt',datasets{d}));
        szRunWrong = size(run_wrong,1);
        if szRunWrong>2
            wrongDatasets = [wrongDatasets; datasets(d)];
            wrongPairNos = [wrongPairNos; szRunWrong];
        end
    catch
        do_nothing='File empty';
    end
end
end