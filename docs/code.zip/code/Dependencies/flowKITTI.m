function [f f1Corres fNotPres] = flowKITTI(f1,f2,pair,imf1,imf2)

flowPath = sprintf('../images/flow/flow/flow%d_%d.png',pair(1),pair(2));
flow = flow_read(flowPath);
boundaryParts = (imread(sprintf('../images/flow/boundary/boundary%d_%d.png',pair(1),pair(2))));

if 0
imgnoStr1 = getImgnoInStrOrInt(imgno1,9);
imgnoStr2 = getImgnoInStrOrInt(imgno2,9);

imf1 = sprintf('../images/flow/img%s.ppm',imgnoStr1);
imf2 = sprintf('../images/flow/img%s.ppm',imgnoStr2);

flowToSmooth = uint8(imread(flowPath));
flowSmooth = BoundaryGaussianSmoothing_2D(flowToSmooth,2);
flowBin = im2bw(flowToSmooth); outerBoundary = bwconvhull(flowBin);
seBig1 = strel('disk',10); seBig2 = strel('disk',5); seSmall = strel('disk',1);
outerBoundary = imerode(outerBoundary,seBig1);

boundaryParts0 = edge(flowToSmooth,'canny',0.62,1.9); %try some params
boundaryParts = (boundaryParts0 & outerBoundary);

boundaryParts = imdilate(boundaryParts,seBig2);
boundaryParts = imerode(boundaryParts,seSmall);

if 0 %checking
  figure, imshow(boundaryParts); figure, imshow(boundaryParts0); figure, imshow(flowSmooth);
end

figure, imshow(imf1), [x y] = ginput(1);
valid = flow(y,x,3);
if valid
x1 = x + flow(y,x,2);  y1 = y + flow(y,x,1);
end

figure, imshow(imf1); hold on, plot(x,y,'*g');
figure, imshow(imf2); hold on, plot(x1,y1,'*g'); 
end


f=cell(3,1); f1Corres=cell(3,1); fNotPres=cell(3,1);
f1Round = floor(f1(:,1:2));
indZero = find(f1Round(:,1)==0 | f1Round(:,2)==0);
f1Round(indZero,:)=[];f1(indZero,:)=[];

for j=1:size(f1Round,1)
  toadd = flow(f1Round(j,2),f1Round(j,1),1:2);
  if boundaryParts(f1Round(j,2),f1Round(j,1))== 1%whitePixelVal %midPixelValchange this also!
    if toadd ~=0
      f2Disp = [f1(j,1)+toadd(1,1,1) f1(j,2)+toadd(1,1,2) f1(j,3:end)];
      if f2Disp(1)>0 && f2Disp(2)>0
        f{2}= [f{2} f2Disp'];
        f1Corres{2} = [f1Corres{2} f1(j,:)'];
      else
        fNotPres{2} = [fNotPres{2} f1(j,:)'];
      end
    else
      fNotPres{2} = [fNotPres{2} f1(j,:)'];
    end
    
  else
    
    if toadd ~= 0 %fNotPres is for recall prec calculation. It is unnecessary
      f2Disp = [f1(j,1)+toadd(1,1,1) f1(j,2)+toadd(1,1,2) f1(j,3:end)];
      if f2Disp(1)>0 && f2Disp(2)>0
        f{1}= [f{1} f2Disp'];
        f1Corres{1} = [f1Corres{1} f1(j,:)'];
      else
        fNotPres{1} = [fNotPres{1} f1(j,:)'];
      end
    else
      fNotPres{1} = [fNotPres{1} f1(j,:)'];
    end
    
  end
end


f{3} = [f{1} f{2}]; %non boundary, boundary, all
f1Corres{3} = [f1Corres{1} f1Corres{2}];
fNotPres{3} = [fNotPres{1} fNotPres{2}];

if 0
  figure, imshow(imf1), hold on; showellipticfeaturesSPL(f1Corres{3}');
  figure, imshow(imf2), hold on; showellipticfeaturesSPL(f{3}');
  
  figure, imshow(imf1), hold on; showellipticfeaturesSPL(f1Corres{2}');
  figure, imshow(imf2), hold on; showellipticfeaturesSPL(f{2}');
  figure, imshow(imf2), hold on; showellipticfeaturesSPL(f2);
end

end
