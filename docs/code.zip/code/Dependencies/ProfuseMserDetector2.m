function tupleBig = ProfuseMserDetector2(Tuples,dSetNo,dilValComp,fgTypeComp,delta,nonMserOverlapCheck,numCores)
initialClock=tic;
 tupleBig=[];
if 0
  MexCompile();
end
if nonMserOverlapCheck
  loopOver=0; ifInit=0;
  nonLcsBasedOverErr = 10; overErrMser=15;
  regionsFinal2=[]; blockSzFinal2=[]; topLeftFinal2=[]; plusOrMinusFinal2=[];boundaryFinal2=[];
else
  loopOver=1; ifInit=1;
  nonLcsBasedOverErr = 35; overErrMser=40;%nonLcsBasedOverErr = 10; overErrMser=15;
end
dupRem = 1;
dirData = '../images'; %The image datasets directory 

expandAmt = 50; coordFg = cell(1,3); detectedPts=[];
%Warning: Adjust scaleFactor inside globalVariables function
imgInd = regexp(Tuples{2}, '[0-9]');% Returns the indices in Tuples with the detected regex
imgno =  Tuples{2}(imgInd); % needs adjusting for non-single digit img nos
imgnoInt = str2num(imgno); % Obtain the image file number
commonVar  = globalVariables(imgnoInt);

fprintf('\n Processing %s:',Tuples{2});
imgPath = fullfile(dirData,Tuples{1},Tuples{2}); %Path of the image file
imgPath_temp = fullfile(dirData,Tuples{1},'temp.mat'); %Path of the smoothed image we are going to store
img = (imread(imgPath)); %give initial image a little smoothing
if ~strcmp(Tuples{1},'boat')
  img = rgb2gray(img);
end

img = uint32(img);
sizeIm  = size(img);
ysize = sizeIm(1) ; xsize = sizeIm(2);

%%
for i=1 %2:size(commonVar.sigSmin,2)
  fprintf(' Scale number %d, ',i);
  
  iSz = commonVar.sigSmin(i);
  if dSetNo==8
    iSz = 6;%4.5; %3.5 till image 216, 4 for rest %iSz/1.85;
  end
  img = BoundaryGaussianSmoothing_2D(img,2); %iSz/3 %Smooth the image
  save(imgPath_temp, 'img');    %Save the image, this will be loaded in runMatasMser

  [imBlocks indBlock indBlockSz] = getAllblocks(img,iSz,imgnoInt); %Obtains the different image blocks, indices and sizes
  
  if dSetNo==1 || dSetNo==2 || dSetNo==6 %getting the foreground patch blocks to run mser
    %fgTypeComp = 'full'; dilValComp = 4;% controls what regions of fg is used in comparison, rest in fgType have to be full
    dilVal = [expandAmt; 10; dilValComp]; fgType{1} = 'full';fgType{2} = 'full'; fgType{3} = fgTypeComp;
    [indValidFg coordFg] = getValidIndInFgBB(indBlock,Tuples{1},imgno,dSetNo,dilVal,fgType); %Obtain the "valid" blocks acc. to the FG data
    imBlocks = imBlocks(indValidFg{1},:); indBlock = indBlock(indValidFg{1},:); indBlockSz = indBlockSz(indValidFg{1},:);
  end
  
  %%
  if ifInit
    
    szCellBl = length(imBlocks); theta = 0;iter=0;
    %         if dSetNo==3 || dSetNo==4 || dSetNo==7 %|| dSetNo==6
    coordFgObj = coordFg{2}; dummy=0;
    fprintf('InitialClock: %f\n', toc(initialClock)/60);
    
    mserClock = tic;
    parfor iBl =1:szCellBl %parfor dSetNo==3,4,7 , for for rest
      %Obtain the regions using the runMatasMser function
      
      [~, regionsDecInit(iBl), variationNThreshInit(iBl), plusOrMinusInit(iBl)] = runMatasMser(imgPath_temp,theta,delta-5,iter,imgnoInt,dummy,indBlock(iBl),indBlockSz(iBl)); %imBlocksCell{split}
      
      [initCornersCell0{iBl}, maskCornerAll(iBl), boundaryPartAll(iBl), scAll(iBl),~, topLeftImAll(iBl)] = getCorners(regionsDecInit(iBl),indBlock(iBl),indBlockSz(iBl),iBl,variationNThreshInit(iBl),iSz,plusOrMinusInit(iBl),imgnoInt,dSetNo,coordFgObj);
    end
    fprintf('MserClock: %f\n', toc(mserClock)/60);
    
    duplicateClock = tic;
    maskCornerMat = []; boundaryPartMat = []; scMat=[]; topLeftImMat=[];
 
    for iBl =1:szCellBl
      maskCornerMat = [maskCornerMat ; maskCornerAll{iBl}];
      boundaryPartMat = [boundaryPartMat; boundaryPartAll{iBl}]; scMat = [scMat; scAll{iBl}];
      topLeftImMat = [topLeftImMat; topLeftImAll{iBl}];
    end
    
    %             regionsDec = regionsDecInit';
    initCornersMat = cell2mat(initCornersCell0');
    if dSetNo==8
      indNotUseful = find(initCornersMat(:,2)<120); %75 if you use indValid, you have to take into account points that don't have duplicates
      boundaryPartMat(indNotUseful,:)=[]; maskCornerMat(indNotUseful,:)=[]; scMat(indNotUseful,:)=[];
      topLeftImMat(indNotUseful,:)=[];
      initCornersMat(indNotUseful,:)=[];
    end
    
    %duplicate removal by looking at underlying MSER
    for fC=1:2
      floorOrCeil = 1-mod(fC,2);
      numDup = 1;
      if floorOrCeil
        [aa,indUniquePM1,indUniquePM2] = unique(floor(initCornersMat(:,1:2)/3.5)*3.5,'rows');
      else
        [aa,indUniquePM1,indUniquePM2] = unique(round(initCornersMat(:,1:2)/3.5)*3.5,'rows'); %increase this
      end
      countPM = accumarray(indUniquePM2,1);
      indDup0 = find(countPM>numDup);
      indInValid0 = collectParallel(indDup0,indUniquePM2,initCornersMat,scMat,boundaryPartMat,numCores); %Make for for dSetRest
      if 0
        figure, imshow(img,[]), hold on, plot(initCornersMat(:,1),initCornersMat(:,2),'*');
        initCornersMat0 = initCornersMat; initCornersMat0(indInValid0,:)=[];
        figure, imshow(img,[]), hold on, plot(initCornersMat0(:,1),initCornersMat0(:,2),'*');
      end
      initCornersMat(indInValid0,:)=[]; %if you use indValid, you have to take into account points that don't have duplicates
      boundaryPartMat(indInValid0,:)=[]; maskCornerMat(indInValid0,:)=[]; scMat(indInValid0,:)=[];
      topLeftImMat(indInValid0,:)=[];
    end
    
    clear initCorners initCornerBlocks initCornersMatSortd indInitUnique indOutofBdry;
  end
  %% Loop over Init
  fprintf('DuplicateClock: %f\n', toc(duplicateClock)/60);
  loopClock = tic;
  if loopOver
    numCorners = size(initCornersMat,1);
    numDiv = ceil(numCorners/numCores);
    indDiv = 1:numDiv:numCorners; indDiv(end+1) = numCorners;
    %initCornersCell = cell(1, length(indDiv)-1);
    %boundaryPartCell = cell(1, length(indDiv)-1);
    %maskCornerCell = cell(1, length(indDiv)-1);
    %scCell = cell(1, length(indDiv)-1);
    %topLeftImCell = cell(1, length(indDiv)-1);
    
    for a = 2:length(indDiv)
      initCornersCell{a-1} = initCornersMat(indDiv(a-1):indDiv(a),:);
      boundaryPartCell{a-1} = boundaryPartMat(indDiv(a-1):indDiv(a));
      maskCornerCell{a-1} = maskCornerMat(indDiv(a-1):indDiv(a));
      scCell{a-1} = scMat(indDiv(a-1):indDiv(a));
      topLeftImCell{a-1} = topLeftImMat(indDiv(a-1):indDiv(a));
    end
    
    parfor split= 1:length(scCell)%parfor, make for for rest
      [cornersConv0{split}, maskConvSz0{split}, regionConv0{split}, scConv0{split}, boundaryConv0{split}, topLeftConv0{split}] = getConvergedCorner2(initCornersCell{split},...
        boundaryPartCell{split},maskCornerCell{split}, scCell{split},topLeftImCell{split}, img,indBlock,imgnoInt,delta,split);
      %pass plusorminus and surrounding region area into getmAtas code.
    end
    
    cornersConv =cell2mat(cornersConv0');
    regionConv=[]; maskConvSz=[]; scConv=[];boundaryConv=[];topLeftConv=[];
    for split=1:size(scConv0,2)
      regionConv = [regionConv regionConv0{split}]; maskConvSz = [maskConvSz maskConvSz0{split}];
      scConv = [scConv scConv0{split}]; boundaryConv = [boundaryConv boundaryConv0{split}]; topLeftConv = [topLeftConv topLeftConv0{split}];
    end
    
    %need regions and block size for rep checking.
    [cornersConvSortd, indSorted] = sortrows(cornersConv,[1 2 13]); %is one with least strength better or least toggle dist better?
    [~,indUnique]= unique(round(cornersConvSortd(:,1:3).*100)./100,'rows'); %pick one with least variation
    %             fprintf('\n number of points before: %d and after unique: %d',size(cornersBlockMat,1),length(indUnique));
    indF = indSorted(indUnique);
    cornersConv = cornersConv(indF,:); regionConv = regionConv(indF); maskConvSz = maskConvSz(indF);
    scConv = scConv(indF); boundaryConv = boundaryConv(indF); topLeftConv = topLeftConv(indF);
    
    if 0                figure, imshow(img,[]), hold on, plot(cornersConv(:,1),cornersConv(:,2),'*');
    end
    %fprintf('Here\n');
  else
    cornersConv = initCornersMat;
  end
  fprintf('LoopClock: %f\n', toc(loopClock)/60);
  restClock = tic;
  %% Overlap checking
  if dupRem
    if loopOver==0 & ifInit==0
      cornersBlockMat=[]; scConv=[]; boundaryConv=[]; regionConv=[]; maskConvSz=[];
    end
    [indFinal cornersFinal]= overlapCheck(cornersConv,[ysize,xsize],nonLcsBasedOverErr,overErrMser,scConv,boundaryConv,regionConv,maskConvSz);%gets descriptor also
  end
  
  %% Saving and writing
  %{
  cornersConv = cornersConv(indFinal,:); regionConv = regionConv(indFinal);
  maskConvSz = maskConvSz(indFinal); scConv = scConv(indFinal);
  boundaryConv = boundaryConv(indFinal); topLeftConv = topLeftConv(indFinal);
  
  basicPath=fullfile('..','data','results',sprintf('feat-delta%d',delta),sprintf('%s',Tuples{1}));
  if ~exist(basicPath), mkdir(basicPath); end
  imgnoInt = str2num(imgno);isFiveCols=1;
  detPtsFile = fullfile(basicPath, sprintf('img%d.harronmser.txt',imgnoInt-1));
  writeToFileTest(detPtsFile,cornersFinal',1,xsize,ysize,0,imgnoInt,isFiveCols);
  
  basicPath0 = sprintf('../data/results/orig-delta%d/%s/',delta,Tuples{1});
  if ~exist(basicPath0), mkdir(basicPath0); end
  save(sprintf('%s/cornersConv%d.mat',basicPath0,imgnoInt),'cornersConv');
  save(sprintf('%s/regionConv%d.mat',basicPath0,imgnoInt),'regionConv');
  save(sprintf('%s/maskConvSz%d.mat',basicPath0,imgnoInt),'maskConvSz');
  save(sprintf('%s/boundaryConv%d.mat',basicPath0,imgnoInt),'boundaryConv');
  save(sprintf('%s/scConv%d.mat',basicPath0,imgnoInt),'scConv');
  save(sprintf('%s/topLeftConv%d.mat',basicPath0,imgnoInt),'topLeftConv');
  
  %run sift descriptor
  if dSetNo == 3 || dSetNo==4 || dSetNo==7
    detType = 'harronmser';
    ptDesFile = sprintf('../data/results/feat-delta%d/%s/img%d.%s.sift.txt',delta,Tuples{1},imgnoInt-1,detType);
    runSift = sprintf('./compute_descriptors.ln -sift -i %s -p1 %s -o1 %s',imgPath,detPtsFile,ptDesFile);
    system(runSift);
  end
  %}
  fprintf('RestClock Profusely : %f\n',toc(restClock)/60.0);
end

