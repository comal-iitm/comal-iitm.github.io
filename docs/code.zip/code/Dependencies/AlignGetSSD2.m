function [minShiftError minInd]= AlignGetSSD2(temp1,temp2,numShifts,display)
minShiftError=5000; minInd=[];
if ~exist('display','var')
    display=0;
end

ssdVal=5000;
if ~isempty(temp1) && ~isempty(temp2)
des1Emp = uint8(temp1); %uint8(reshape(des1,[szBlock szBlock 3]));
des2Emp = uint8(temp2);%uint8(reshape(des20,[szBlock szBlock 3]));

[Xshift,Yshift] = meshgrid(-numShifts:numShifts,-numShifts:numShifts);
shX = Xshift(:); shXA = abs(shX);
shY = Yshift(:); shYA = abs(shY);

if display
    figure, subplot(1,2,1), imshow(des1Emp); subplot(1,2,2), imshow(des2Emp);
end

for s=1:numel(Xshift)
    des1EmpSh = des1Emp; des2EmpSh = des2Emp;
    switch sign(shX(s))
        case -1
            des1EmpSh = des1EmpSh(1:end-shXA(s),:,:);
            des2EmpSh = des2EmpSh(1+shXA(s):end,:,:);
            
        case 1
            des2EmpSh = des2EmpSh(1:end-shXA(s),:,:);
            des1EmpSh = des1EmpSh(1+shXA(s):end,:,:);
    end
    
    
    switch sign(shY(s))
        case -1
            des1EmpSh = des1EmpSh(:,1:end-shYA(s),:);
            des2EmpSh = des2EmpSh(:,1+shYA(s):end,:);
            
        case 1
            des2EmpSh = des2EmpSh(:,1:end-shYA(s),:);
            des1EmpSh = des1EmpSh(:,1+shYA(s):end,:);
    end
    
try    I_error = (imabsdiff(des2EmpSh,des1EmpSh));
catch
  return 
end
    sumShiftErrors(s) = sum(I_error(:));
    
    if display
        des1EmpCell{s} = des1EmpSh; des2EmpCell{s} = des2EmpSh;
        I_errorCell{s} = I_error;
    end
    
end

[des1M des1N thirdDIm] = size(I_error);
sumShiftErrors = sumShiftErrors./(des1M*des1N*thirdDIm);
[minShiftError,minInd] = min(sumShiftErrors);
end
if display
    figure, subplot(1,2,1), imshow(des1EmpCell{minInd});
    subplot(1,2,2), imshow(des2EmpCell{minInd});
    figure, imshow(I_errorCell{minInd});
end

end