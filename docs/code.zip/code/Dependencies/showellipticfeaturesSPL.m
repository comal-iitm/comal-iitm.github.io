function img = showellipticfeaturesSPL(pos,fcol,linewidthAmt,useParam3Alone,ifFig, img)

%
% showellipticfeatures(pos,fcol)
%

if nargin<2 fcol=[0 0 1]; end
if nargin<3 linewidthAmt = 5; end
if nargin<4 flag=0; end
if nargin<5 useParam3Alone=0; end
if nargin<5 ifFig=1; end

colOutline = 0; %255;
for i=1:size(pos,1)
    x0=pos(i,1); y0=pos(i,2); %s0=1/sqrt(det([pos(i,3) pos(i,4); pos(i,4) pos(i,5)]));
    if useParam3Alone
        Sigma=[1 0; 0 1].*((pos(i,3))^2); %1.4*
    else
        %Sigma = [70.56 0; 0 70.56];
        Sigma=inv([pos(i,3) pos(i,4); pos(i,4) pos(i,5)]);
        %        Sigma=inv([(pos(i,3)*(1.4*1.4)) pos(i,4); pos(i,4) (pos(i,5)*(1.4*1.4))]);
    end
    
    [h ell] = drawellipse_cov(Sigma,[x0 y0],ifFig);
    %   set(h,'Color',fcol,'LineWidth',linewidthAmt)
    if size(fcol,1)==1
        if ifFig
            h=plot(x0,y0,'x','Color',fcol,'LineWidth',linewidthAmt);
        end
    else
        if ifFig
            hold on;
            h=plot(x0,y0,'x','Color',fcol(i,:),'LineWidth',linewidthAmt);
        else
            ell = round(ell);
            indZero = find(ell(:,1)<=0 | ell(:,2)<=0);
            ell(indZero,:)=[]; 
            
            x0L = round(x0-4:x0+4); y0L = round(y0-4:y0+4);
            indZero = find(x0L<=0 | y0L<=0);
            x0L(indZero)=[]; y0L(indZero)=[];
            
            colorMat = shiftdim(repmat(fcol(i,:)*255,[length(x0L),1,length(y0L)]),2);            
            img(y0L,x0L,:) =  colorMat;
           
            for e=1:length(ell)
              try 
              img(ell(e,2),ell(e,1),:) =  colOutline;
                 catch
              aaa=1;
            end
            end
        end
    end
    %   set(h,'Color','r')
    %   if flag
    %     title(sprintf('i=%d',i));
    %     pause
    %   end
end
pause(0.1)
