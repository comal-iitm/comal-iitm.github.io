function [featMatch1Final featMatch2Final matchFinal] = matchDescriptorsSSDSol(f1,f2,regions,maskSzs,boundarys,scs,topLefts,detType,desType,img1,img2,matchesSavePath,distThresh,descPath1,descPath2,gtImg,dSetNo)
threshSSD = 0.2; largeNum = 5000; szBlock = 23; numShifts = 2; % 1 for othersthreshSSD = 0.05;
img{1} = img1; img{2} = img2;
szFeat1 = size(f1,1); szFeat2 = size(f2,1); ssdVals = cell(szFeat1,1);match = cell(szFeat1,1); ssdVals =  largeNum*ones(szFeat1,1);

matchMat = 100*ones(szFeat1,szFeat2);
matchFinal=[];featMatch1Final=[]; featMatch2Final=[];
image1 = double(imread(img{1}))*(1/255);    image2 = double(imread(img{2}))*(1/255);

if ~strcmp(detType,'harronmser')
  switch desType
    case 'sol'
      sol1 = load(descPath1); sol2 = load(descPath2);
      nsdopt = nsd.opts(); opt = nsdopt.correspondence; opt.distance.verbose= 0;
      solDistEuc = nsd.distance(sol1.desc.d,sol1.desc.di,[],sol2.desc.d,sol2.desc.di,[],opt.distance.mode,opt.distance);
      opt.distance.mode = 'nesting';
      solDistNest = nsd.distance(sol1.desc.d,sol1.desc.di,[],sol2.desc.d,sol2.desc.di,[],opt.distance.mode,opt.distance);
    case 'sift'
      [sift1 n1 dim1] = loadFeatures(descPath1); [sift2 n2 dim2] = loadFeatures(descPath2);
      s1 = sqrt(1/sift1(3,1)); scaleSet1 = repmat(s1,4,n1); s2 = sqrt(1/sift2(3,1)); scaleSet2 = repmat(s2,4,n2);
      sift1Mod= [sift1(1:5,:); scaleSet1; sift1(6:end,:)];  sift2Mod= [sift2(1:5,:); scaleSet2; sift2(6:end,:)];
      [~, ~, ~, siftDistAll]=c_eoverlap(sift1Mod,sift2Mod,0); %feat1 has been changed to feat2 for dSset=4
      siftDistAll = siftDistAll';
  end
end

for i = 1 : szFeat1 % send in ind, and loop for i=ind for tsuk etc
  switch dSetNo
    case 8
      valid = gtImg(round(f1(i,2)),round(f1(i,1)));
    case 9
      valid = gtImg(round(f1(i,2)),round(f1(i,1)),3) - 1;
    case 6
      indA = find(gtImg.indF1(:,1)==i);
      if ~isempty(indA)
        valid = sum(gtImg.indF1(indA,2)) - 1 ;
      else valid = -1; end
    case 10
      indA = find(gtImg.indF1(:,1)==i);
      if ~isempty(indA)
        valid = sum(gtImg.indF1(indA,2)) - 1 ;
      else valid = -1; end
    case 11
      indA = find(gtImg.indF1(:,1)==i);
      if ~isempty(indA)
        valid = sum(gtImg.indF1(indA,2)) - 1 ;
      else valid = -1; end
    case 1
      valid = 1;
  end
  
  
  %% search for point
  if valid > -1
    indCloseSSD=[];ssdVal=[];
    [distVals ,indClose] = closestPt(f1(i,:), f2,1,size(f2,1));
    %       ind0 = find(distVals < distThresh);
    
    switch dSetNo
      case 8
        distGt = gtImg(round(f1(i,2)),round(f1(i,1))); %check this
        ind0 = find(distVals <= (distGt + distThresh) & distVals >= (distGt - distThresh));
        
      case 9
        distGt = sqrt(gtImg(round(f1(i,2)),round(f1(i,1)),2)^2 + gtImg(round(f1(i,2)),round(f1(i,1)),1)^2);
        %         f1F1 = f1(i,1) + flowImg(round(f1(i,2)),round(f1(i,1)),1); f1F2 = f1(i,2) + flowImg(round(f1(i,2)),round(f1(i,1)),2);
        %         figure, imshow(img1), hold on, plot(f1(i,1),f1(i,2),'*g'); figure,imshow(img2), hold on, plot(f1F1,f1F2,'*g');
        ind0 = find(distVals <= (distGt + distThresh) & distVals >= (distGt - distThresh));
        
      case 6
        if length(indA)>1
          aaa=1;
        end
        distGt = max(gtImg.indF1(indA,3));
        ind0 = find(distVals <= (distGt + distThresh) & distVals >= (distGt - distThresh));
        
      case 10
        if length(indA)>1
          aaa=1;
        end
        distGt = max(gtImg.indF1(indA,3));
        ind0 = find(distVals <= (distGt + distThresh) & distVals >= (distGt - distThresh));
      case 11
        if length(indA)>1
          aaa=1;
        end
        distGt = max(gtImg.indF1(indA,3));
        ind0 = find(distVals <= (distGt + distThresh) & distVals >= (distGt - distThresh));  
      case 1
        ind0 = find(distVals < distThresh);
        
    end
    
    
    indClose = indClose(ind0);
    corsClose = f2(indClose,:);
    if 0
      figure, imshow(image1), hold on, plot(f1(i,1),f1(i,2),'*g');
      figure, imshow(image2), hold on, plot(corsClose(:,1),corsClose(:,2),'*g');
    end
    if strcmp(detType,'harronmser')
      %% first mask
      f1InBlock = f1(i,1:2) - [topLefts{1}{i}(2) topLefts{1}{i}(1)]+ 1;
      template1 = getTemplate(image1,f1(i,:),szBlock,numShifts);
      mask0 = zeros(maskSzs{1}{i}); mask0(regions{1}{i})=1;
      mask1{1} = getTemplate(mask0,f1InBlock,szBlock,numShifts);
      mask1{2} = getTemplate(1-mask0,f1InBlock,szBlock,numShifts);
      selCut1{1} = find(mask1{1}); selCut1{2} = find(mask1{2});
      
      mask2 = cell(1,szFeat2); selCut2 = cell(1,szFeat2);template2=cell(1,szFeat2);
      for j=1:length(indClose)
        %% second mask
        if isempty(selCut2{indClose(j)})
          f2InBlock = corsClose(j,1:2) - [topLefts{2}{indClose(j)}(2) topLefts{2}{indClose(j)}(1)] + 1;
          mask0 = zeros(maskSzs{2}{indClose(j)}); mask0(regions{2}{indClose(j)})=1;
          mask20{1} = getTemplate(mask0,f2InBlock,szBlock,numShifts);
          mask20{2} = getTemplate(1-mask0,f2InBlock,szBlock,numShifts);
          selCut20{1} = find(mask20{1}); selCut20{2} = find(mask20{2});
          selCut2{indClose(j)} = selCut20;
          mask2{indClose(j)} = mask20;
        end
      end
      
      combs = [1 1; 1 2; 2 1; 2 2];ssdComb=largeNum*ones(1,4);indComb=zeros(1,4);
      for c=1:size(combs,1) %four combinations of masks
        ssdVal = largeNum*ones(length(indClose),1); areaDiff = largeNum*ones(length(indClose),1);
        for j=1:length(indClose)
          minLengthRegion = max(length(selCut1{combs(c,1)}),length(selCut2{indClose(j)}{combs(c,2)}));
          areaDiffSamp = length(setxor(selCut1{combs(c,1)},selCut2{indClose(j)}{combs(c,2)}));
          sc_cost0 = getbestMatch(scs{1}{i},scs{2}{indClose(j)});
          if areaDiffSamp < 0.6*minLengthRegion% && sc_cost0 < 0.25
            areaDiff(j) = areaDiffSamp;
          end
        end
        [areaLeastVal aLInd] = sort(areaDiff);
        
        for least=1:min(10,length(indClose))%
          if areaLeastVal(least) < largeNum %areaLeastVal
            templates{1} = template1;
            if isempty(template2{indClose(aLInd(least))})
              template2{indClose(aLInd(least))} = getTemplate(image2,corsClose(aLInd(least),:),szBlock,numShifts);
            end
            templates{2} = template2{indClose(aLInd(least))};
            masksComb{1} = mask1{combs(c,1)}; masksComb{2} = mask2{indClose(aLInd(least))}{combs(c,2)};
            try
              ssdVal(aLInd(least)) = mex_AlignGetSSDFinal(templates,masksComb,numShifts);
            catch
              ssdVal(aLInd(least)) = 5000;
            end
          end
        end
        if ~isempty(ssdVal)
          [ssdVal indCloseSSD] = sort(ssdVal);
          %         if ssdVal(1) < threshSSD
          ssdComb(c) = ssdVal(1); indComb(c) = indClose(indCloseSSD(1));
          %         end
        end
      end
      if ~isempty(ssdComb)
        [minSSD minIndC] = min(ssdComb); %get best side from c2;
        if minSSD < largeNum
          ind2Final = indComb(minIndC);
          match{i} = [i ind2Final minSSD minIndC];
        end
      end
      %         if ~strcmp(detType,'harronmser') matchMat(i,ind2Final) = minSSD;end for one-one matching
    else
      switch desType
        case 'ssd'
          numShifts = 1;
          template1 = getTemplate(image1,f1(i,:),szBlock,numShifts);
          template2=cell(1,szFeat2);ssdVal = largeNum*ones(length(indClose),1);
          for j=1:length(indClose)
            if isempty(template2{indClose(j)})
              template2{indClose(j)} = getTemplate(image2,corsClose(j,:),szBlock,numShifts);
            end
            try
              ssdVal(j) = AlignGetSSD2(template1,template2{indClose(j)},numShifts);%/length(template1(:)); %minShiftError/length(selCutRGBMain); %sum(I_error)
            catch
              ssdVal(j) = 5000;
            end
          end
          if ~isempty(ssdVal)
            [minSSD minIndC] = min(ssdVal);
            %           if minSSD < threshSSD %& minInd==i
            ind2Final = indClose(minIndC);
            match{i} = [i ind2Final minSSD];
            %           end
          end
          
        case 'sol'
          if ~isempty(indClose)
            solDist  = solDistNest(i,indClose);
            [minDist, minIndC] = min(solDist);
            indNonUnique = find(solDist==minDist);
            solDEuc  = solDistEuc(i,indClose(indNonUnique));
            if length(indNonUnique)>1
              dupFlag=1;
              [minEucDist, minIndCEuc] = min(solDEuc);
              %             if minEucDist < 100 %threshold
              minIndC = indNonUnique(minIndCEuc);
              ind2Final = indClose(minIndC);
            else
              dupFlag=0; minEucDist = solDEuc;
              ind2Final = indClose(indNonUnique);
            end
            match{i} = [i ind2Final double(minDist) minEucDist dupFlag];%
            
          end
          
        case 'sift'
          if ~isempty(indClose)
            siftDist  = siftDistAll(i,indClose);
            [minDist, minIndC] = min(siftDist);
            ind2Final = indClose(minIndC);
            match{i} = [i ind2Final minDist];%
            
          end
      end
    end
  end
end


% %one-to-one
% if ~isempty(matchFinal)
%     matchMatF = zeros(size(des1,1),size(des2,1));
%     minVal = 0;
%     while 1
%         minValNew  = min(min(matchMat));
%         if minValNew >= 100
%             break;
%         end
%         [mini minj] = find(matchMat==minValNew);
%         matchMat(mini,:) = 100;
%         matchMat(:,minj) = 100;
%         matchMatF(mini(1),minj(1)) = minValNew;
%         minVal = minValNew;
%     end
%     [fx fy] = find(matchMatF>0);
%     [~, del] = setdiff(matchFinal(:,1:2),[fx fy],'rows');
%     matchFinal(del,:)=[];
%
%     featMatch1Final = f1(matchFinal(:,1),:);
%     featMatch2Final = f2(matchFinal(:,2),:);
% end
matchFinal = cell2mat(match);

if ~isempty(matchFinal)
  featMatch1Final = f1(matchFinal(:,1),:);
  featMatch2Final = f2(matchFinal(:,2),:);
end
save(matchesSavePath,'matchFinal'); % for tsuk don't save

if 0
  figure, imshow(img1), hold on; showellipticfeaturesSPL(f1(i,:));
  figure, imshow(img2), hold on; showellipticfeaturesSPL(f2(ind2Final,:));
  
  figure, imshow(img2), hold on; showellipticfeaturesSPL(f2(indClose,:));
  hold on; showellipticfeaturesSPL(f1(i,:),'g');
  
  figure, imshow(img1), hold on; showellipticfeaturesSPL(featMatch1Final);
  figure, imshow(img2), hold on; showellipticfeaturesSPL(featMatch2Final);
end

end

function idxCorrected = IndDetType(detType,idx)
if strcmp(detType,'harronmser')
  idxCorrected = ceil(idx./2);
else
  idxCorrected = idx;
end

end