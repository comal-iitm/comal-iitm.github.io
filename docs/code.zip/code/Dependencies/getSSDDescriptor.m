function detPtsNoDupDes = getSSDDescriptor(img,feat,radiusForSSD,ifSc)

[M N third] = size(img);
for i=1:size(feat,2)
    topSSD = max(1,round(feat(2,i))-radiusForSSD);
    bottomSSD = min(M,round(feat(2,i))+radiusForSSD);
    leftSSD = max(1,round(feat(1,i))-radiusForSSD);
    rightSSD = min(N,round(feat(1,i))+radiusForSSD);
    blockValidFinal = img(topSSD:bottomSSD,leftSSD:rightSSD,:);
    if ifSc
         boundMap = edge(blockValidFinal,'canny');
         boundaryAll = find(boundMap);
         [distToBdry, indClose] = closestPt([feat(2,i) feat(1,i)],boundaryAll);
         sc = getShapeContext(boundaryAll,indClose); %write it into a file
    end
    
    if 0
        figure, imshow(imgPath), showellipticfeaturesSPL(detectedPtsOther(i,:));
        figure, imshow(blockValidFinal);
    end
    [MBl NBl third] = size(blockValidFinal);
    desSize = (2*radiusForSSD+1)^2*3;
    diffLength = (desSize - MBl*NBl*third);
    if diffLength > 0
        szBlock = 2*radiusForSSD+1;
        
        if MBl < szBlock
            padded = zeros(szBlock - MBl,NBl,3);
            blockValidFinal(MBl+1:szBlock,:,:) = padded;
            MBl = szBlock;
        end
        if NBl < szBlock
            padded = zeros(MBl,szBlock - NBl,3);
            blockValidFinal(:,NBl+1:szBlock,:) = padded;
        end
    end
    blockValidFinal = reshape(uint8(blockValidFinal),1,desSize);
    detPtsNoDupDes(i,:) = blockValidFinal;
end

end