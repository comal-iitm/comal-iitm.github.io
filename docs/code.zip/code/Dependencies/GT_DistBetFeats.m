function correctInd = GT_DistBetFeats(featMatch1, featMatch2,thresh)

distFeats = sqrt(sum((featMatch1(:,1:2) - featMatch2(:,1:2)).^2,2));
correctInd = find(distFeats<thresh);

end