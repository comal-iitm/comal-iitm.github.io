function sc_cost = getbestMatch(sc1,sc2)
% indCor = ceil(size(sc1,1)/2);
% sc_cost = 0.5*sum((sc1(indCor,:) - sc2(indCor,:)).^2./(sc1(indCor,:) + sc2(indCor,:) + eps));

if 1
costmat=hist_cost_2(sc1,sc2); % compute pairwise cost between all shape contexts
% calculate shape context cost
[a1,b1]=min(costmat,[],1);
[a2,b2]=min(costmat,[],2);
sc_cost =max(mean(a1),mean(a2));
end
end