function [cornersConv, maskSzConv, regionConv, scConv, ...
          boundaryConv, topLeftConv, maskConv] = getConverged(cornersInitAll, ...
                                                                     boundaryPartMat, ...
                                                                     maskCornerMat, ...
                                                                     scMat, topLeftMat, ...
                                                                     img, indBlockAll, ...
                                                                     t, delta, split)

commonVar = globalVariables(t);

cornersConv = [];
maskSzConv = {};
regionConv = {};
scConv = {};
boundaryConv = {};
topLeftConv = {};

maxIterPt = 5;
maxIterScale = 10;
totalLoop = 0;
numConv = 0;

if ~isempty(cornersInitAll),
    
    sigS = cornersInitAll(1, 3)/commonVar.smoothingFactor;
    range0 = sigS*commonVar.iterBlockFactor;
    sz = round(round(range0/5)*5*commonVar.blockMultFactor);%block size
    corRows = size(cornersInitAll, 1);
    
    for cornerIdx = 1:corRows
        %             fprintf('\n\n\n  %d %d\n\n\n\n\n',cornerIdx,splitNo);
        %% get Inputs
        cornerOld = cornersInitAll(cornerIdx, :);
        boundaryOld = boundaryPartMat{cornerIdx};
        maskOld = maskCornerMat{cornerIdx};
        scOld = scMat{cornerIdx};
        
        topLeft = topLeftMat{cornerIdx};
        indBlock = indBlockAll{cornerOld(11)};
        boundaryOld(:, 1:2) =  boundaryOld(:, 1:2)+ repmat([indBlock(2)-1 indBlock(1)-1], ...
                                                           size(boundaryOld, 1), 1) ;
        % only for display not needed otherwise
        
        if 0,
            
            figure, imshow(maskOld);
            figure, hold on; plot(boundaryOld(:, 2),boundaryOld(:, 1));
            plot(cornerOld(1), cornerOld(2), '*g')
        
        end
        
        numIter = 0; numLoop = 0; divergenceflag = 0;
        scaleConv = 500; sxi2Init = cornerOld(3);
        scaleIter = 0; bestScaleMultiplier = 0.1;
        
        topLeft = topLeft + [indBlock(2) indBlock(1)] -1; %leftTop = indBlock;
        
        while scaleConv~=0 &&  divergenceflag~=1,
            
            % Distance of the latest mask from the original is the variation. 
            % Corner distnce is used to bring about convergence
            
            numIter = 0; corMovt= 50; 
            
            %% Iterations: region and corner
            while corMovt > 0.01 && numIter < maxIterPt,
                
                [boundaryNew, maskNew, ...
                 regionNew, scNew, ...
                 cornerOldUpd, ...
                 left, top] = getCorCentBlockAndMserInd2(cornerOld, boundaryOld, ...
                                                         maskOld, scOld, img, ...
                                                         indBlock, topLeft, t, delta);
                                                     
                topLeft = [top left];
                
                if ~isempty(boundaryNew),
                    
                    cornerNew = []; sxi2 = cornerOld(3);
                    remsxl2 = 0.8*(sxi2/commonVar.smoothingFactor);
                    circflag = 0; iter = 1;
                    
                    cornerNew = intpointdetom(boundaryNew(:, 2), boundaryNew(:, 1), ...
                                              remsxl2, sxi2, -1, circflag, iter, t);
                    
                    szCorNew = size(cornerNew, 1);
                    
                    if ~isempty(cornerNew)
                        
                        numLoop = 1; % in the loop
                        cornerNew(:, 1:2) =  cornerNew(:, 1:2) + ...
                                             repmat([left-1 top-1], szCorNew, 1) ;
                        
                        corMovt = repmat(cornerOld(:, 1:2), szCorNew, 1)  - cornerNew(:, 1:2);
                        corMovt = sqrt(corMovt(:, 1).^2 + corMovt(:, 2).^2);
                        [~, minCloseInd] = min(corMovt);
                        corMovt = corMovt(minCloseInd);
                        cornerNew = cornerNew(minCloseInd, :);
                        
                        cornerNew(:, 11:20) = cornerOldUpd(11:20); %update strength,threshold, plusOrMinus etc
                        boundaryNew(:, 1:2) =  boundaryNew(:, 1:2)+ repmat([top-1 left-1], size(boundaryNew, 1), 1) ;
                        
                        if (commonVar.displayflag || 0 ),
                            
                            figure, imshow(img,[]), hold on;
                            plot(boundaryOld(:, 2), boundaryOld(:, 1), 'm', 'LineWidth', 2);
                            
                            plot(cornerOld(1, 1), cornerOld(1, 2), '*m', 'MarkerSize', 17);
                            plot(boundaryNew(:, 2), boundaryNew(:, 1), 'y', 'LineWidth', 2);
                            plot(cornerNew(1, 1), cornerNew(1, 2), '*y', 'MarkerSize', 17);
                            szSubBlock = size(maskNew);
                            rectangle('Position', [left top szSubBlock(1) szSubBlock(2)], ...
                                      'LineWidth', 2);
                            rectangle('Position', [indBlock(1) indBlock(2) sz sz], ...
                                      'LineWidth', 2);
                            %                 selCur0 = find(subBlock<thresh); % do bwboundaries and corner detection for for drawing up and down level lines
                        end
                        %% update
                        cornerOld  = cornerNew;  boundaryOld = boundaryNew;
                        maskOld = maskNew;
                        numIter = numIter +1;
                    
                    else corMovt = -1;
                    
                    end
                    
                else corMovt = -1;
                
                end
                
            end
            
            totalLoop =  totalLoop + numLoop;
            
            %% Scale Adaptation
            if (numIter == maxIterPt && corMovt <= 2.1) || (corMovt == 0),
                
                   if commonVar.adaptflag(2),
                       
                        if bestScaleMultiplier==0.1 & commonVar.displayflag,
                            
                            hFig1 = figure; hFig2 = figure;
                        
                        else
                            
                            hFig1 = 0; hFig2 = 0;
                        
                        end
                        
                        [sxi2New, bestScaleMultiplier, ...
                         divergenceflag, scaleconvFlag, ...
                         hFig1, hFig2] = AdaptScale(cornerNewTrans, boundaryNewTrans(:, 2), ...
                                                    boundaryNewTrans(:, 1), bestScaleMultiplier, ...
                                                    sxi2Init, hFig1, hFig2, t, MaxOrMinScaleFlag);
                         %cornerNew,boundaryNew{bNoNew}(:,2),boundaryNew{bNoNew}(:,1)
                        
                        if 0,
                            
                            fprintf('%f, %f \n', cornerNew(3), sxi2New);
                        
                        end
                        
                        if sxi2New > 24, 
                        
                            aa=1;
                        
                        end
                        
                        scaleConv = sxi2New - cornerNew(3);
                        cornerOld(3) = sxi2New;
                        scaleIter = scaleIter+1;
                        bestScaleMultiplier = 0.1;%bestScaleMultiplier^2;
                        
                        if scaleIter > maxIterScale
                            
                            divergenceflag=1;
                        
                        end
                        
                   else
                       
                       scaleConv=0;
                   
                   end
                    
            else
                
                divergenceflag =1;
                scaleConv=0;
            
            end
            
        end
        
        %% Final Convergence
        if ((numIter == maxIterPt && (corMovt <= 2.1)) || ...
            (abs(corMovt) < 0.05)) && scaleConv==0 , 
            
            % minCorMovt<=2.1 & scaleConv==0 & ~isempty(cornerNewTrans) 
            % Empty corner condition ensures that only toggle case comes in
            % Otherwise corner not found means that the er was not stable;
            % not checking divergenceFlag, not bothered if it didn't converge in the end.
            
            numConv = numConv+1;
            cornersConv(numConv, :) = cornerNew;
            boundaryConv{numConv} = boundaryNew; 
            maskSzConv{numConv} = size(maskNew);
            scConv{numConv} = scNew;
            maskConv{numConv} = maskNew;
            regionConv{numConv} = regionNew;
            topLeftConv{numConv} = topLeft;
            
        end
        
    end
    
end
%% Display all converged points
commonVar.displayflag=0;
if commonVar.displayflag
    figure, imshow('../images/hero/img001.ppm'), hold on, showellipticfeaturesSPL(cornerConv,[1 1 0],1,0,1);
    for i=1:size(cornersAll,1)
        text(cornerConv(i,1)+2,cornerConv(i,2)+2,num2str(cornerConv(i,13)),'BackgroundColor',[.9 .5 .5]);
    end
end

if 0
    fprintf('\nNo of corners entering the loop: %d out of %d\n',totalLoop,corRows);
end
