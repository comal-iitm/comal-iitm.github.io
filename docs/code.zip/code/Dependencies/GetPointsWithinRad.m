function ptsRad = GetPointsWithinRad(x,y,radius,extraVals)

stepGap = 2;
for i=1:length(x)
    [X,Y] = meshgrid(x(i)-radius:stepGap:x(i)+radius,y(i)-radius:stepGap:y(i)+radius);
    
    totalPts = size(X,1)*size(X,2);
    X1=reshape(X,totalPts,1);
    Y1=reshape(Y,totalPts,1);
    
    [vals inds] = closestPt([x(i) y(i)],[X1 Y1],1,totalPts);
    indNeighbours = find(vals>radius);
    xRad  = X1(1:indNeighbours(1)-1); yRad = Y1(1:indNeighbours(1)-1);
    
    if nargin>3
        extraValsRad = repmat(extraVals(i,:),indNeighbours(1)-1,1);
        ptsRad{i} = [xRad yRad extraValsRad];
    else
        ptsRad{i} = [xRad yRad];
    end
end

end