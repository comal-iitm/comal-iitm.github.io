function GetBetterBG(dataset,ifOtherDatasets)

if ~exist('ifOtherDatasets','var')
    ifOtherDatasets = 0;
end

if ifOtherDatasets
    decVal =4;
else
    decVal =3; 
end

dirData = '../images';
bg = imread(sprintf('../bg/%s/imgB.ppm',dataset));
[imX imY dummy] = size(bg);
bgBetter = zeros(imX,imY,dummy); %double(bg);

for imgno=140
    frac = 0.05*(imgno/15);
    imgnoStr = getImgnoInStrOrInt(imgno,decVal);
    im1 = imread(sprintf('%s/%s/img%s.ppm',dirData,dataset,imgnoStr));
    imCut = round((1-frac)*imY);
    imNew = [bg(:,1:imCut,:) im1(:,imCut+1:end,:)];
    bgBetter = imNew;
%     bgBetter = (bgBetter+double(imNew))/2;
%     imwriteSwarna(uint8(bgBetter),sprintf('../bg/%s/imgB0%d.ppm',dataset,imgno));

%     figure, imshow(imNew),
%     figure, imshow(uint8(bgBetter));
end
bgBetter = uint8(bgBetter);

% figure,imshow(imNew);
imwriteSwarna(bgBetter,sprintf('../bg/%s/imgB1.ppm',dataset));
