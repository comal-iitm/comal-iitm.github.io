function getFigurePR(datastring,xlabelString, yLabelString, matches,delta,desTypes,indx,d)

mark{1}=['-kx';'-gs';'-bp';'-m+';'-rd';'-cv']; %Mser 'Color',[1 0.6 0]
mark{2}=[':kx';':gs';':bp';':m+';':rd';':cv']; %Mser 'Color',[1 0.6 0]
mark{3} =['-.kx';'-.gs';'-.bp';'-.m+';'-.rd';'-.cv']; %Mser 'Color',[1 0.6 0]

detStr = ['CoMiC   ';'Harris  ';'Hessian ';'Mser    ';'Fast-9  '];
% mark=['-cv';'-gs';'-m+';'-bp';'-rd';'-kx']; % .. for dashed line
lineWidthVal = 4; MarkerSizeVal = 10; FontSizeVal = 40; %10, 24 and 40
numImages = max(size(recallA{1}{1}));
xAxis = 1:(numImages);%/3);

legendStr = [];
hFig1 = figure;clf;
grid on;
title(datastring,'FontSize',FontSizeVal,'FontWeight','bold');
ylabel(yLabelString,'FontSize',FontSizeVal,'FontWeight','bold')
xlabel(xlabelString,'FontSize',FontSizeVal,'FontWeight','bold');
figure(hFig1); axis([0 1 0 1]);
hold on;

for des=1 %length(desTypes):-1:1
    desType = desTypes{des}; 
    if ~strcmp(desType,'sift')
      desTypeStr = sprintf('+ %s ',desType);
    else
      desTypeStr = sprintf('+ %s',desType);
    end
    recall = recallA{des}{d}; prec = precA{des}{d};
    numDetectors = size(recall,2);
    
    if strcmp(desType,'ssd')
        allDets = numDetectors:-1:1;
    else allDets = numDetectors:-1:2; end
    
    for i=allDets%CoMIC only for last
        oneMinusPrec = 1 - prec{i}(:,indx); %oneMinusPrec
        figure(hFig1);  plot(xAxis, matches{i}(:,indx),mark{des}(i,:),'Linewidth',lineWidthVal,'MarkerSize',MarkerSizeVal,'MarkerEdgeColor','k'); %'MarkerFaceColor','g'
        legendStr = [legendStr ; sprintf('%s  %s',detStr(i,:),desTypeStr)];
    end
    % '-d','Color',[1 0.6 0], '-k'
    
    figure(hFig1);
    h_legend= legend(legendStr);%,'Random','Fast-9','Mser','Location','SouthEast'); %legend('CoMIC','Harris1','Harris2','Hessian1','Hessian2','Fast-9','Location','SouthEast');
    set(h_legend, 'FontSize',15);%45)
    set(gca,'FontWeight','bold','LineWidth',lineWidthVal,'FontSize',FontSizeVal);
    savePath = sprintf('../data/graphs-delta%d/%s/',delta,datastring);
    if ~exist(savePath,'dir')
        mkdir(savePath);
    end
    
%     saveas(hFig1,sprintf('%s/%s_%s.jpg',savePath,xlabelString,yLabelString));
%     saveas(hFig1,sprintf('%s/%s_%s.fig',savePath,xlabelString,yLabelString));
end
end
