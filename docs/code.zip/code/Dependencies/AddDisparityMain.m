function [f1New ysize xsize] = AddDisparityMain(file1,file2,datapath)

resizefactor=1; whitePixelVal=1; %255;
resizeFactorPts = [4.5/10 37.5/70]; %for each method, get a resizeFactor set
%change for cones
cones=1;
if cones
    dispDivFactor = 4; %4
    windSz=4; %1 and 4;
    
else
    dispDivFactor = 16;
    windSz=1; %1 and 4;
end

indices = strfind(file2,'.');
imgno = str2num(file2(indices(end)-1));
detType = file2(indices(1):indices(2));

disparity = double(imread(sprintf('%s/groundtruth.pgm',datapath)));
[ysize,xsize] = size(disparity);
boundaryParts = imread(sprintf('%s/boundary2.png',datapath)); %imread(sprintf('%s/occ_and_discont.png',datapath));

if 0 %~mod(imgno,2) %making the boundary image if it doesn't already exist
    se = strel('disk',4);
    boundaryParts = imdilate(boundaryParts,se);
    boundaryParts2 = zeros(ysize,xsize);
    [row col] = find(boundaryParts==whitePixelVal);
    for i1=1:length(row)
        colNew = round(col(i1) - (disparity(row(i1),col(i1))/dispDivFactor));
        if colNew>0
            boundaryParts2(row(i1),colNew) = whitePixelVal;
            
        end
    end
    
    %     se = strel('disk',3);
    %     boundaryParts2 = imdilate(boundaryParts2,se);
    %     se = strel('disk',6);
    %     boundaryParts2 = imerode(boundaryParts2,se);
    
    if cones
    % se = strel('disk',1);
    % boundaryParts = imerode(boundaryParts,se);
    % se = strel('disk',2);
    % boundaryParts2 = imerode(boundaryParts2,se);
    end
    
else
    boundaryParts2 = imread('./stereo/boundary22.png');%imread('./stereo/boundary2.png');
    boundaryParts2 = im2bw(boundaryParts2);
end



f1Orig =loadFeatures(file1); f1=f1Orig';
f2Orig =loadFeatures(file2); f2=f2Orig';

    scaleFact = sqrt(resizeFactorPts(1)^2 + resizeFactorPts(2)^2);   %Detection of features is done at the standard size of 700X1000, points are resized to the value specified in the groundtruth
    f1(:,1)=f1(:,1).*resizeFactorPts(1); f1(:,2)=f1(:,2).*resizeFactorPts(2);
    f1(:,3:5)=f1(:,3:5)./(scaleFact*scaleFact);
    f2(:,1)=f2(:,1).*resizeFactorPts(1); f2(:,2)=f2(:,2).*resizeFactorPts(2);
    f2(:,3:5)=f2(:,3:5)./(scaleFact*scaleFact);



f1New=[];
f1Round = floor(f1(:,1:2));

for j=1:size(f1Round,1)
    if mod(imgno,2)
        if boundaryParts(f1Round(j,2),f1Round(j,1))==whitePixelVal
            
            if 0
                %                 x = round(f1(j,2)/2); y= round(f1(j,1)/2);
                toadd = -disparity(f1Round(j,2),f1Round(j,1))/dispDivFactor;
                f1disp = [f1(j,1)+toadd f1(j,2:end)];
                %     f1dispRound = round(f1disp(:,1:2));
            else
                xlim1 = max(1,f1Round(j,2)-windSz); ylim1 = max(1,f1Round(j,1)-windSz);
                xlim2 = min(f1Round(j,2)+windSz,ysize); ylim2 = min(f1Round(j,1)+windSz,xsize);
                try
                    disparity_neigh = disparity(xlim1:xlim2,ylim1:ylim2);
                catch
                    aa=1;
                end
                disparity_neigh = unique(disparity_neigh);
                minvalLeast=1000; bestPt=[];
                for n=1:length(disparity_neigh)
                    toadd = -disparity_neigh(n)/dispDivFactor;
                    f1disp = [f1(j,1)+toadd f1(j,2:end)];
                    
                    scale = sqrt(1/f1(1,3));
                    scaleArray = repmat(scale,4,size(f2,1));
                    feat1=[f1disp(1:5)'; scale; scale; scale; scale];
                    feat2=[f2(:,1:5)'; scaleArray];
                    [wout, twoutFull, dout, tdout]=c_eoverlap(feat1,feat2,1);
                    
                    minval = min(wout);
                    if minval<minvalLeast
                        minvalLeast = minval;
                        bestPt = f1disp;
                    end
                end
                
                
            end
            f1New = [f1New; bestPt];
        end
    else
        if 0 %boundaryParts2(f1Round(j,2),f1Round(j,1))==whitePixelVal            
            toadd=0;
            f1disp = [f1(j,1)+toadd f1(j,2:end)];
            f1New = [f1New; f1disp];
        end
    end
end


commonVar.displayflag=1;
if commonVar.displayflag
    
    %%%% %checking if the disparity file works correctly
    f1disp=[]; 
    f1Round = round(f1(:,1:2));
    for j=1:size(f1,1)
        toadd = -disparity(f1Round(j,2),f1Round(j,1))/dispDivFactor;
        f1disp = [f1disp; f1(j,1)+toadd f1(j,2:end)];
        
    end
    
    figure, imshow('../data/results/cone/imL.png');
    showellipticfeaturesSPL(f1);
    
%     figure, imshow('../images/cone/img1.ppm');
%     showellipticfeaturesSPL(f1Orig');
    
    figure, imshow('../data/results/cone/imR.png');
    showellipticfeaturesSPL(f1disp);
    
    %%%% Points along boundary
    f1disp =[];
    for j=1:size(f1Round,1)    
        if boundaryParts(f1Round(j,2),f1Round(j,1))==whitePixelVal            
            
                %                 x = round(f1(j,2)/2); y= round(f1(j,1)/2);
                toadd = -disparity(f1Round(j,2),f1Round(j,1))/dispDivFactor;
                f1disp = [f1disp ; f1(j,1)+toadd f1(j,2:end)];            
        end    
    end
    figure, imshow('../data/results/cone/imL.png');
    showellipticfeaturesSPL(f1disp );
    
                %%%%%
    
    f1New=f1New';
    ptSize = size(f1New,2);
    sizeFeat = sqrt(1/f1New(3,1)).*ones(1,ptSize);
    [detPtsNoDup detPtsOrig]  = overlapCheck([f1New(1:2,:); sizeFeat; zeros(1,ptSize); sizeFeat; zeros(4,ptSize); f1New(7,:); zeros(2,ptSize); f1New(6,:)],[ysize,xsize],10,0); %some extra value
    %                 figure, imshow(imgPath);
    %                 [detPtsNoDup detPtsOrig]  = overlapCheck(detPtsOrig,[ysize,xsize],20,25); %some extra value
    detPtsNoDup = [detPtsNoDup; detPtsOrig(10,:)];
    
    f1New = detPtsNoDup';
    %     writeToFileTest(file1,detPtsNoDup',1,xsize,ysize,0);
    
end