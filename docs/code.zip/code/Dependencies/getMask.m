function [maskCorner boundaryPart sc areaPer lenRegion topLeftIm] = getMask(cornerWrtBlock,boundary,circFlag,range,mask)

sc=[]; boundaryPart=[]; areaPer=0; lenRegion=0;
[sz1 sz2] = size(mask);

boundaryPart = getFixedBoundPts(boundary,cornerWrtBlock,circFlag);
if ~isempty(boundaryPart)
    [sc,mean_dist_1] = getShapeContext(boundaryPart);
    
    topIm = max(1,round(cornerWrtBlock(2)-range));
    bottomIm = min(sz1,round(cornerWrtBlock(2)+range));
    leftIm = max(1,round(cornerWrtBlock(1)-range));
    rightIm = min(sz2,round(cornerWrtBlock(1)+range));
    topLeftIm = [topIm leftIm];
    
    maskCorner = mask(topIm:bottomIm,leftIm:rightIm);
    szSubBlock = size(maskCorner); lenRegion = length(find(maskCorner)); areaPer = lenRegion/(szSubBlock(1)*szSubBlock(2));
else
    maskCorner=[];
end
if 0
    figure, imshow(mask); hold on, plot(boundaryPart(:,2),boundaryPart(:,1))
    plot(cornerWrtBlock(1),cornerWrtBlock(2),'*g');
end
end