function imfr = myDisplayDetPtsOuter(dataset,tArray,ext,featName,imgName)

imfr = [];

dirData = '../images';
Tuples = getTuples(dirData);
resizefactor=1;
   
if exist('featName','var') & exist('imgName','var')
    detPtsFile=fullfile('..','data','results',sprintf('%s',Tuples{1,1}),featName);
    imgPath = fullfile(dirData,Tuples{1,1},imgName);
    
    displaydetpts(detPtsFile,imgPath,resizefactor);    %displaydetpts(detPtsFile,imgPath,numPts);
    
else
    dSetNo = getParamsAndDataset(dataset);
    for i=1:size(tArray,2)
        imgno=tArray(i);
        imgnoStr = getImgnoInStrOrInt(imgno, dSetNo);
        imgPath = fullfile(dirData,dataset,sprintf('img%s.ppm',imgnoStr)); %fullfile(dirData,Tuples{t,1},Tuples{t,2});
%         imgInd = regexp(Tuples{t,2}, '[0-9]');
%         imgno =  Tuples{t,2}(imgInd); % needs adjusting for non-single digit img nos
        detPtsFile=fullfile('..','data','results','feat-delta5',sprintf('%s',dataset),sprintf('img%d.%s.txt',imgno-1,ext));
%             detPtsFile=fullfile('..','data','results',sprintf('%s',Tuples{t,1}),sprintf('img%d.hs2.txt',str2num(imgno)-1));
        imfr = displaydetpts(detPtsFile,imgPath,1,1);    %displaydetpts(detPtsFile,imgPath,numPts);
        
        
    end
end

