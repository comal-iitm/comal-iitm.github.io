function [cornersAll cornersAllOrig boundaryNewTrans regionsFinal blockSzFinal topLeftFinal plusOrMinusFinal] = getConvergedCornerAffine(cornersInitAll,regionDecAll,plusOrMinusAll,imgPath,boundaryAll,t) %boundaryAll not in parfor method1 method2, as op imgPath
% close all;
commonVar = globalVariables(t);
cornersAll = []; cornersAllOrig=[]; boundaryNewTrans=[]; regionsFinal=[]; blockSzFinal=[]; topLeftFinal=[]; plusOrMinusFinal=[];
iter=1; maxIterPt=10; maxIterScale=10; times=0;
closeNotFound=0; numConv=1; resizefactor=1;

scale = cornersInitAll(1,3)/commonVar.smoothingFactor;
img = imread(imgPath);
if ~strcmp(imgPath(end-2:end),'pgm')
    img = rgb2gray(img);
end

%         img = adapthisteq(img);
img = uint32(img);
img = BoundaryGaussianSmoothing_2D(img,3);
img = imresize(img,resizefactor);

[imBlocksAll,indBlockAll,indBlockSzAll] = getAllblocks(img,scale,t);

corRows = size(cornersInitAll,1);
totalLoop=0;
for cornerIdx = 1:corRows
    fprintf('\n\n\n  %d \n\n\n\n\n',cornerIdx);
    times=0; %for debugging
    cornerOld = cornersInitAll(cornerIdx,:);
    blockNo = cornersInitAll(cornerIdx,11);
    indNo = cornersInitAll(cornerIdx,12);
    thresh = cornersInitAll(cornerIdx,14);
    variationMetric = cornersInitAll(cornerIdx,13); %not needed as of now
    bNo = cornersInitAll(cornerIdx,15);
    octaveIdx = cornersInitAll(cornerIdx,17); %store in corner and bring in from there in future
    
    imBlock = imBlocksAll{blockNo};
    indBlock = indBlockAll{blockNo};
    indBlockSz = indBlockSzAll{blockNo};
    %     boundaryOld = boundaryOld';
    if 0
        regionCur = regionDecAll{blockNo}{indNo};
        plusOrMinus = plusOrMinusAll{blockNo}(indNo);
    else
        regionCur = regionDecAll{cornerIdx};
        plusOrMinus = plusOrMinusAll(cornerIdx);
        
    end
    if ~commonVar.isparfor
        boundaryOld = boundaryAll{cornerIdx}; %{blockNo}{indNo}{bNo};
        boundaryOld(:,1:2) =  boundaryOld(:,1:2)+ repmat([indBlock(2)-1 indBlock(1)-1],size(boundaryOld,1),1) ;
    end
    
    cornerOld(:,1:2) =  cornerOld(:,1:2); %- (indBlock - 1);
    
    numIter = 0; corMovt= 50; cornerNewTrans=[]; numLoop=0; divergenceflag=0; scaleConv = 500; sxi2Init = cornerOld(3);
    scaleIter=0;bestScaleMultiplier=0.1;
    while scaleConv~=0 &&  divergenceflag~=1 %Note: not updating the mask. the distance of the latest mask from the original is the variation. corner distnce is used to bring about convergence
        numIter = 0; corMovt= 50; cornerNewTrans=[];
        rangeVal = round(cornerOld(3)/commonVar.smoothingFactor*commonVar.iterBlockFactor/5)*5;
        iSz = cornerOld(3)/commonVar.smoothingFactor; %commonVar.sigSmin(octaveIdx);
    
        while corMovt > 0 && numIter < maxIterPt
            cornerNew = []; cornerNewTrans = [];convergedThroughNoDuplicates=0;
            mask = zeros(indBlockSz(1),indBlockSz(2)); mask(regionCur) =1; %mask must also be changed
            [subBlock, regionsClose, variation, top, left, minMserDist,thresh, maskBlock] = getCorCentBlockAndMserInd(cornerOld,imBlock,mask,rangeVal,closeNotFound,plusOrMinus,img,indBlock,t);%topPrev,leftPrev,bottomPrev,rightPrev); %mserIndAll(2,erIdx) %only translation after this
            
            
            if ~isempty(regionsClose)
                regionCurCell{1} = regionsClose;
                [cornerNew boundaryNew maskNew]= getCorners(regionCurCell,indBlock,size(subBlock),blockNo,octaveIdx,iter,[variation; thresh],iSz,plusOrMinus,t,cornerOld(1:2) - [left-1 top-1]); %maskAll boundaryAll
                
%                commonVar.displayflag=0;
                if commonVar.displayflag & ~isempty(cornerNew)
                    figure, imshow(maskNew), hold on,
                    for aa=1:size(cornerNew,1)
                        plot(cornerNew(aa,1),cornerNew(aa,2),'*g','LineWidth',2);
                    end
                end
%                 commonVar.displayflag=0;
                
                boundaryNewTrans=[];
                szCorNew = size(cornerNew,1);
                cornerNewTrans = cornerNew;
                
                if ~isempty(cornerNew)
                    %                 cornerNewTrans(:,1:2) =  cornerNew(:,1:2).*(iSz/commonVar.sigSminInit) + repmat([left-1 top-1],szCorNew,1) ;
                    cornerNewTrans(:,1:2) =  cornerNew(:,1:2) + repmat([left-1 top-1],szCorNew,1) ;
                    corMovt = repmat(cornerOld(:,1:2),szCorNew,1)  - cornerNewTrans(:,1:2);
                    corMovt = sqrt(corMovt(:,1).^2 + corMovt(:,2).^2);
                    [minCornVal,minCloseInd] = min(corMovt);
                    corMovt = corMovt(minCloseInd);
                    %                 if minCornVal < minCornerThresh
                    if corMovt > 2.85*iSz
                        %                     disp('Corner moving out of block'); %happens for non standard sizes of blocks
%                         commonVar.displayflag=0;
                        break;
                    end
                    cornerNew = cornerNew(minCloseInd,:);
                    cornerNewTrans = cornerNewTrans(minCloseInd,:); %to map to closest corner, also to  determine end point of loop
                    bNoNew = cornerNew(15); %bNoNewVals = cornerNew(:,16); bNoNew = bNoNewVals(minCloseInd,:); but this needs conditions in case cornerNew is empty
                    boundaryNewTrans(:,1:2) =  boundaryNew{1}{bNoNew}(:,1:2)+ repmat([top-1 left-1],size(boundaryNew{1}{bNoNew},1),1) ;
                    %                 boundaryNewTrans(:,1:2) =  boundaryNew{1}{bNoNew}(:,1:2).*(iSz/commonVar.sigSminInit) + repmat([top-1 left-1],size(boundaryNew{1}{bNoNew},1),1) ;
                    if cornerNew(8) > round(1.3*3.1*cornerNew(3)) & cornerNew(8) < size(boundaryNewTrans,1) - round(1.3*3.1*cornerNew(3))
                        
                        if (commonVar.displayflag || 0 ) && (times<=15) %& corMovt > 2
                            figure, imshow(img,[]), hold on, plot(boundaryOld(:,2), boundaryOld(:,1),'m','LineWidth',2);
                            showellipticfeatures(cornerOld);
                            %                         plot(cornerOld(1,1),cornerOld(1,2),'*r','LineWidth',2);
                            plot(boundaryNewTrans(:,2), boundaryNewTrans(:,1),'y','LineWidth',2);
                            showellipticfeatures(cornerNewTrans,[1 1 0]);
                            %                         plot(cornerNewTrans(1,1),cornerNewTrans(1,2),'*g','LineWidth',2);
                            
                            rectangle('Position', [left top size(subBlock,2) size(subBlock,1)],'LineWidth',2);
                            %                         hold off;
                            %                         pause;
                            %%%%%%%%%%%%%%
                            times = times + 1;
                        end
                        %                     commonVar.displayflag = 0;
                        if commonVar.displayflag
                            figure, imshow(subBlock,[]), hold on, plot(cornerNew(1,1), cornerNew(1,2), '*g');
                            bNo = cornerNew(15);
                            plot(boundaryNew{1}{bNo}(:,2), boundaryNew{1}{bNo}(:,1));
                            plot(cornerOld(:,1),cornerOld(:,2),'*r','LineWidth',4);
                        end
                        %                     commonVar.displayflag=0;
                        if 0 %minCornVal > 4 & minCornVal < 5
                            figure, subplot(1,3,1), imshow(maskBlock);
                            subplot(1,3,2), imshow(maskNew), hold on, plot(cornerNew(1,1), cornerNew(1,2), '*g');
                            subplot(1,3,3), imshow(mask),hold on, plot(cornersInitAll(1,1), cornersInitAll(1,2), '*g');
                        end
                        numLoop = 1;
                        
                        cornerOld  = cornerNewTrans; %update
                        if ~commonVar.isparfor
                            boundaryOld = boundaryNewTrans;
                        end
                        
                        
                        numIter = numIter +1;
                        %                 topPrev = top; leftPrev = left;
                        %                 bottomPrev = top + rangeVal; rightPrev = left + rangeVal;
                    else
                        corMovt = -1;
                    end
                else
                    corMovt = -1; %movement becomes invalid.
                end
            else
                corMovt = -1;
            end
            
        end
        totalLoop =  totalLoop + numLoop;
        
        if (numIter==maxIterPt && corMovt <= 2.1) || (corMovt == 0)
            
            if commonVar.displayflag
                selCur0 = find(subBlock<thresh);
%                 regionsDecCur{1} = selCur0; %termporatily turned off for parfor. Uncomment if this figure needs to be displayed
                [cornerNew boundaryNew maskNew]= getCorners(regionsDecCur,indBlock,size(subBlock),blockNo,octaveIdx,iter,[variation; thresh],iSz,plusOrMinus,cornerOld(1:2) - [left-1 top-1]); %maskAll boundaryAll
                figure, imshow(imBlock,[]), hold on,
                plot(boundaryNewTrans(:,2), boundaryNewTrans(:,1),'y','LineWidth',2);
                showellipticfeatures(cornerNewTrans,[1 1 0]);
                
                plot(boundaryNew{1}{1}(:,2), boundaryNew{1}{1}(:,1),'m','LineWidth',2);
                showellipticfeatures(cornerNew);
                
                rectangle('Position', [left top size(subBlock,2) size(subBlock,1)],'LineWidth',2);
                
            end
            
           
            if variation < 5000
%                 commonVar.displayflag=0;
                if commonVar.displayflag
                    figure, subplot(1,3,1), imshow(maskBlock), subplot(1,3,2), imshow(maskNew);
                    figure, imshow(imBlock,[]), hold on,
                    bNo = cornersInitAll(16);
%                     plot(boundary{bNo}(:,2), boundary{bNo}(:,1),'m','LineWidth',2);
                    plot(cornersInitAll(1,1),cornersInitAll(1,2),'*r','LineWidth',2);
                    rectangle('Position', [left top size(subBlock,2) size(subBlock,1)],'LineWidth',2);
                    
                    plot(boundaryNewTrans(:,2), boundaryNewTrans(:,1),'LineWidth',2);
                    plot(cornerNewTrans(1,1),cornerNewTrans(1,2),'*g','LineWidth',2);
                end
%                 commonVar.displayflag = 0;
                
                %scale adaptation
                bestScaleMultiplier=0.1;
                momScaleFactor = commonVar.momScaleFactor;
                        while momScaleFactor >=1
                            MaxorMinflag = 1;
    
                            % Initializing Sigma (covariance), since 2 are needed now.
                            % ~Ramkumar
                            %Sigma = cell(NUMSCALES, 1);
                            %Sigma{PREVIOUS} = [1 0; 0 1];
                            Sigma     = [1 0; 0 1];
                            sxl2init = cornerNewTrans(3)*commonVar.smoothingFactor;
                            % Just displaying the actual starting Point (Corner). ~Ramkumar
                            fprintf(fileID, 'Co-ordinates - X : %f, Y: %f\n', cornerNewTrans(1), cornerNewTrans(2));
    
                            [ptPos, ~, divergenceflag] = adaptintpointaffine(cornerNewTrans,boundaryNewTrans(:,2),boundaryNewTrans(:,1),img,MaxorMinflag,Sigma,sxl2init,0.1);
    
                            % ptPos is an entry of the required cor_len_stab
                            % format. ~Ramkumar
    
                            if ~divergenceflag
                                pos = [pos; ptPos];
                            end
    
                            momScaleFactor = momScaleFactor - 0.4;
                            cornerNewTrans(9) = momScaleFactor;
    
                        end % end while(isempty(ptPos) && momScaleFactor >=1) ~Ramkumar
    
                    
%                 [sxi2New divergenceflag]=AdaptScale(cornerNew,boundaryNew{1}{1}(:,2),boundaryNew{1}{1}(:,1),bestScaleMultiplier,sxi2Init);                                  
%cornerNewTrans?                
if 0
                fprintf('%f, %f \n', cornerNew(3), sxi2New);
                end
                if sxi2New > 24
                    aa=1;
                end
                scaleConv = sxi2New - cornerNew(3);
                cornerOld(3) = sxi2New;
                scaleIter = scaleIter+1;
                if scaleIter > maxIterScale
                    divergenceflag=1;
                end
                
            end
        else
            divergenceflag =1;
            
        end
    end
    
    if ((numIter==maxIterPt && corMovt <= 2.1) || (corMovt == 0)) && scaleConv==0
        
        cornerNewTrans(11) = blockNo;
        cornerNewTrans(12) = indNo; %determines which mser now
        cornerNewTrans(13) = variation;
        cornerNewTrans(14) = thresh;
        cornerNewTrans(15) = bNo; %do you even need bNo, if so make it 15, and this 16?
        cornerNewTrans(16) = minMserDist;
        cornerNewTrans(17) = octaveIdx;
        cornersAllOrig = [cornersAllOrig; cornerNewTrans];
%         cornerNewTrans(1:2) =  cornerNewTrans(1:2) + (indBlock-1);
        
        %                 subplot(1,3,3), imshow(img,[]), hold on, plot(cornerNewTrans(1,1),cornerNewTrans(1,2),'*g','LineWidth',5);
        cornersAll = [cornersAll; cornerNewTrans];
        regionsFinal{numConv} = regionsClose;
        blockSzFinal(numConv,:) = size(subBlock);
        topLeftFinal(numConv,:) = [top, left];
        plusOrMinusFinal(numConv,1) = plusOrMinus;
        
        numConv = numConv+1;
    end
    
    %     else
%     commonVar.displayflag=0;
    if commonVar.displayflag
        disp('Trace route');
        figure, subplot(1,3,1), imshow(maskBlock), subplot(1,3,2), imshow(maskNew);
        figure, imshow(imBlock,[]), hold on,
        bNo = cornersInitAll(12);
%         plot(boundary{bNo}(:,2), boundary{bNo}(:,1),'m','LineWidth',2);
        plot(cornersInitAll(1,1),cornersInitAll(1,2),'*r','LineWidth',2);
        rectangle('Position', [left top size(subBlock,2) size(subBlock,1)],'LineWidth',2);
        
        if ~isempty(cornerNewTrans)
            plot(boundaryNewTrans(:,2), boundaryNewTrans(:,1),'LineWidth',2);
            plot(cornerNewTrans(1,1),cornerNewTrans(1,2),'*g','LineWidth',2);
        end
    end
    %     end
    
end

commonVar.displayflag=0;
if commonVar.displayflag
    figure, imshow('../images/boat/img1.pgm'), hold on, showellipticfeatures(cornersAll);
    for ii=1:size(cornersAll,1)
        text(cornersAll(ii,1)+2,cornersAll(ii,2)+2,num2str(cornersAll(ii,13)),'BackgroundColor',[.9 .5 .5]);
    end
    
    
end

fprintf('\nNo of corners entering the loop: %d out of %d\n',totalLoop,corRows);

