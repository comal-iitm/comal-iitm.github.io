function [vals inds distvalRaw] = closestOrFarthestPt(cornerpos,relCornerpos,isClose,numClose,numInd,ssd)


if ~exist('isClose')
    isClose = 1;
end

if ~exist('numClose')
    numClose = 1;
end

if ~exist('numInd')
    numInd=2;
end

if ~exist('ssd')
    ssd=0;
end

numCornersRel = size(relCornerpos,1);

distvalRaw=repmat(cornerpos(1:numInd), numCornersRel(1),1) - relCornerpos(:,1:numInd); % find closest corner on parent extremal region
distval=distvalRaw.^2;
if ssd
    distval= (sum(distval,2));    
else
    distval= sqrt(sum(distval,2));
end
if isClose
    [distvalSort indSort] = sort(distval);
else
    [distvalSort indSort] = sort(distval,'descend');
end
vals = distvalSort(1:numClose);
inds = indSort(1:numClose);
distvalRaw = distvalRaw(inds,:);

end