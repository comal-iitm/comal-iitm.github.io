function [cornerpoints cornervalues numberofpoints]= localMinMax_block(cornernessvals,windowszby2,padded,iter)


if 1
[cornerpoints cornervalues numberofpoints]= localmaxima_block(cornernessvals,windowszby2,padded,1);

else

[cornerpointsMax cornervaluesMax numberofpointsMax]= localmaxima_block(cornernessvals,windowszby2,padded,1);
[cornerpointsMin cornervaluesMin numberofpointsMin]= localmaxima_block(cornernessvals,windowszby2,padded,0);
cornerpoints = [cornerpointsMax; cornerpointsMin];
cornervalues = [cornervaluesMax; cornervaluesMin];
numberofpoints = [numberofpointsMin; numberofpointsMin];
end