function copyFiles
detTypes{1} = 'harronmser'; detTypes{2} = 'har'; detTypes{3} = 'hes'; detTypes{4} = 'msr'; detTypes{5} = 'fas'; %detTypes{6} = 'fer';
dirData = '../images';
Tuples = getTuples(dirData);
[datasets indUnique] = unique(Tuples(:,1));

for d=1:length(datasets)
    command0 = sprintf('mkdir /media/New%sVolume/feat-delta5/%s','\ ',datasets{d});
    system(command0);
    for det=2:length(detTypes)
        detType = detTypes{det};
        command = sprintf('cp /media/swarna_nfs/data/results/feat-delta5/%s/*.%s.txt /media/New%sVolume/feat-delta5/%s/',datasets{d},detType,'\ ',datasets{d});
        system(command);
    end
end