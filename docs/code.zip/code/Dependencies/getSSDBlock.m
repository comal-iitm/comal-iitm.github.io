function getSSDBlock
if strcmp(dataset,'tsuk'), ext = 'png'; else  ext = 'ppm'; end
imgPath = sprintf('../images/%s/img%s.%s',dataset,imgnoStr,ext);
image = imread(imgPath);

desFinal=[];meanDistAll=[];boundaryLocalAll=[];
if dSetNo==1 || dSetNo==2 || dSetNo==6
    FinalFeatR = round(FinalFeat(1:2,:))';
    indValid0 = ismember(FinalFeatR,coordFg,'rows'); % coordFg{2} contains a finer fg obj that can filter out init points
    indValid = find(indValid0);
    FinalFeat = FinalFeat(:,indValid);
    f1Init = f1Init(:,indValid);
    topLeftFinal = topLeftFinal(indValid,:); %indValid for regionsFinal to boundaryFinal
    boundaryFinal = boundaryFinal(indValid,:);
    if (isrow(indValid) && iscolumn(regionsFinal)) || (isrow(regionsFinal) && iscolumn(indValid) )
        regionsFinal = regionsFinal';
    end
    regionsFinal = regionsFinal(indValid,:);
    blockSzFinal = blockSzFinal(indValid,:);
    
    for idx = 1: size(FinalFeat,2)
        reduceSize = 1; ifMask=1;
        sz1 = blockSzFinal(idx,1); sz2 = blockSzFinal(idx,2);
        top = topLeftFinal(idx,1); left = topLeftFinal(idx,2);
        bottom = top + (sz1-1); right = left + (sz2-1);
        blockImg = image(top:bottom,left:right,:);
        if ifMask
            selCutBothSides{1} = regionsFinal{idx};
%             selCutBothSides{2} = setdiff(1:sz1*sz2,selCutBothSides{1});
            mask1 = zeros(sz1,sz2);  mask1(selCutBothSides{1}) = 1;
%             mask2 = zeros(sz1,sz2);  mask2(selCutBothSides{2}) = 1;
        end
        
        if reduceSize
            radiusForSSD = 11; % 11
            corner = FinalFeat(1:5,idx); %change to within indBlock
            cornerInSubBlock = corner;
            cornerInSubBlock(1:2) = corner(1:2) - [left-1 top-1]';
            
            topSSD = max(1,round(cornerInSubBlock(2))-radiusForSSD);
            bottomSSD = min(sz1,round(cornerInSubBlock(2))+radiusForSSD);
            leftSSD = max(1,round(cornerInSubBlock(1))-radiusForSSD);
            rightSSD = min(sz2,round(cornerInSubBlock(1))+radiusForSSD);
            
            blockImgSmall = blockImg(topSSD:bottomSSD,leftSSD:rightSSD,:);
            if ifMask                
                mask1Small = mask1(topSSD:bottomSSD,leftSSD:rightSSD);
%                 mask2Small = mask2(topSSD:bottomSSD,leftSSD:rightSSD);
            end
            
            [MBl NBl third] = size(blockImgSmall);
            desSize = (2*radiusForSSD+1)^2*3;
            diffLength = (desSize - MBl*NBl*third);
            if diffLength > 0
                szBlock = 2*radiusForSSD+1;                
                if MBl < szBlock
                    padded = zeros(szBlock - MBl,NBl,3);
                    blockImgSmall(MBl+1:szBlock,:,:) = padded;
                    if ifMask
                        mask1Small(MBl+1:szBlock,:,:) = padded;
%                         mask2Small(MBl+1:szBlock,:,:) = padded;
                    end
                    MBl = szBlock;
                end
                if NBl < szBlock
                    padded = zeros(MBl,szBlock - NBl,3);
                    blockImgSmall(:,NBl+1:szBlock,:) = padded;
                    if ifMask
                        mask1Small(:,NBl+1:szBlock,:) = padded;
%                         mask2Small(:,NBl+1:szBlock,:) = padded;
                    end
                end
            end
            if 0
                figure, imshow(blockValidFinal),
                figure, imshow(blockValidRGB), hold on, plot(cornerInSubBlock(1),cornerInSubBlock(2),'*');
            end
            
            boundaryFull = boundaryFinal{idx};
            boundaryPart = getFixedBoundPts(boundaryFull,cornerWrtBlock,[],szBlock);% or corner, sz1?
            %Checking
            [distToBdry, cornerIdx] = closestPt([corner(2) corner(1)],boundaryFull);
            if distToBdry > 1
                disp('Boundary not close to corner point');
            end
            desFinal(idx).colorInfo = blockImgSmall;
            if 0
                desFinal(idx).mask1 = mask1Small;
                desFinal(idx).mask2 = mask2Small;
            else
                desFinal(idx).region = find(mask1Small);
                desFinal(idx).boundary = boundaryPart;
            end
        else
            
            desFinal(idx).colorInfo = blockImg;
            if 0
                desFinal(idx).mask1 = mask1;
                desFinal(idx).mask2 = mask2;
            else
                desFinal(idx).region = regionsFinal{idx};
                desFinal(idx).boundary = boundaryPart;
            end
        end
        %                 block1 = uint8(reshape(blockValidFinal,[szBlock szBlock 3]));
        %                 figure, imshow(block1);
    end
    
    detPtsNoDupDes = desFinal;
    save(sprintf('../data/results/feat-delta%d/%s/detPtsNoDupDes%d_%s.mat',delta,dataset,imgnoInt,'harronmser'),'detPtsNoDupDes');
end