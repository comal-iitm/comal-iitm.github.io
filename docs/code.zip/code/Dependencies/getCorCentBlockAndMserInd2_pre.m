function [boundaryNew, maskNew, regionNew, scNew, cornerOldUpd, leftIm, topIm] = getCorCentBlockAndMserInd2_pre(cornerWrtImage,boundaryOld,maskOld,scOld,img,indBlock,topLeftPrev,commonVar,delta)
%Previous mask only for display
%Comparing only boundaries. SC does not need these to be alinged. Therefore
%there is no need to align blocks. Since you are taking a 40X40 block for every point,
% and discarding what's smaller, you don't have to worry about case where masks are not equal.

%commonVar = globalVariables(t);
boundaryNew=[]; maskNew=[]; scNew=[]; regionNew=[]; cornerOldUpd=0; iter_val = 1;
scCostThresh = 0.25; threshMinLim = 10; lenLimit = 0.4; areaDiffThresh = 0.5; %threshMinLim = 7;
threshCor = cornerWrtImage(14);

sigS = cornerWrtImage(3)/commonVar.smoothingFactor;
range0 = sigS*commonVar.iterBlockFactor;
range = round((range0*0.8)/5)*5;
sz = round(round(range0/5)*5*commonVar.blockMultFactor);%block size

[szIm1 szIm2] = size(img);
topIm = max(1,round(cornerWrtImage(2))-range); bottomIm = min(szIm1,round(cornerWrtImage(2))+range);
leftIm = max(1,round(cornerWrtImage(1))-range); rightIm = min(szIm2,round(cornerWrtImage(1))+range);
subBlock = img(topIm:bottomIm,leftIm:rightIm);
szCut = size(subBlock); sz1Cut = szCut(1); sz2Cut  = szCut(2);

topPrev = topLeftPrev(1); leftPrev = topLeftPrev(2); [szMask1 szMask2] = size(maskOld);
bottomPrev = topPrev + szMask1 -1;rightPrev = leftPrev + szMask2 -1;

% topImCommon = max([topIm topPrev indBlock(2)]);bottomImCommon = min([bottomIm bottomPrev indBlock(2)+(sz-1)]);leftImCommon = max([leftIm leftPrev indBlock(1)]);rightImCommon = min([rightIm rightPrev indBlock(1)+(sz-1)]);
topImCommon = max([topIm topPrev]);bottomImCommon = min([bottomIm bottomPrev]);leftImCommon = max([leftIm leftPrev]);rightImCommon = min([rightIm rightPrev]);
topShiftPrev = topImCommon - topPrev;leftShiftPrev = leftImCommon - leftPrev;bottomShiftPrev = bottomPrev - bottomImCommon ;rightShiftPrev = rightPrev - rightImCommon;
topShiftCur = topImCommon - topIm;leftShiftCur = leftImCommon - leftIm;bottomShiftCur = bottomIm - bottomImCommon ;rightShiftCur = rightIm - rightImCommon;
% top = topImCommon - indBlock(2) +1;bottom = bottomImCommon - indBlock(2) +1;left = leftImCommon - indBlock(1) +1;right = rightImCommon - indBlock(1) +1;

% if top<0 | bottom<0 | left<0 | right<0 Just gen error checking
%   disp('Error error error in block indices')
% end

maskBlock = maskOld(1+topShiftPrev:end - bottomShiftPrev,1+leftShiftPrev:end-rightShiftPrev);

if commonVar.displayflag
  figure, imshow(img,[]); hold on; rectangle('Position', [leftIm topIm rightIm-leftIm+1 bottomIm-topIm+1],'LineWidth',2);
  plot(indBlock(1), indBlock(2),'*g');
end

if all(szCut>(0.8*2*range))
  windowWidth = (1 + ceil(commonVar.smoothingFactor*sigS/1.5));% + extraLen);
  
  cornerInIter(:,1:2) =  cornerWrtImage(:,1:2) - [leftIm-1 topIm-1]; %(indBlock - 1);
  %     leftTopImBl = [leftIm topIm] - (indBlock-1);
  %     cornerInIter = corner(1:2) - [leftTopImBl(1)-1 leftTopImBl(2)-1];
  centBound = round((length(boundaryOld)-1)/2);
  boundaryRight = boundaryOld(centBound-windowWidth:centBound,:);
  boundaryLeft = boundaryOld(centBound:centBound+windowWidth,:);
  [thetaNormal thetaTangent] = mex_CalculateDirNormAndTan(boundaryRight,boundaryLeft);
  %[thetaNormal thetaTangent] = CalculateDirNormAndTan(boundaryRight,boundaryLeft);
  
  %{
  if commonVar.displayflag,
    boundaryOldT(:,1:2) =  boundaryOld(:,1:2) - repmat([leftIm(2)-1  topIm(1)-1 ],size(boundaryOld,1),1) ; % only for display not needed otherwise
    figure, imshow(maskOld), hold on; plot(boundaryOldT(:,2),boundaryOldT(:,1),'g'); plot(cornerInIter(1),cornerInIter(2),'*r')
    
    slopeTangent = tand(thetaTangent); interceptTangent=cornerInIter(1,2)-slopeTangent*cornerInIter(1,1);
    yi2 = polyval([slopeTangent,interceptTangent],[1 50]); plot([1 50],yi2,'r');
    slopeNormal = tand(thetaNormal); interceptNormal=cornerInIter(1,2)-slopeNormal*cornerInIter(1,1);
    yi2 = polyval([slopeNormal,interceptNormal],[1 50]); plot([1 50],yi2,'r');
  end
  %}
  
  theta = deg2rad(thetaTangent); plusOrMinus = cornerWrtImage(20);
  %dilate mask as the next step
  [~,regions,variationNThresh] =  runMatasMser_pre(subBlock,subBlock,theta,delta,iter_val,commonVar,plusOrMinus); %next thing to do is to normalise the boundary
  
  if ~isempty(regions)
    lenRegions = cellfun('size',regions,2); lenRegionCur = cornerWrtImage(17);
    lenDiff = abs(lenRegions - repmat(lenRegionCur,1,size(regions,1)))/lenRegionCur;
    indRange = find(variationNThresh(2,:)<threshCor+threshMinLim & variationNThresh(2,:)>threshCor-threshMinLim); % & lenDiff < lenLimit);
    regions = regions(indRange); variationNThresh = variationNThresh(:,indRange); lenRegions = lenRegions(indRange);
    
    if ~isempty(regions)
      variationBest = 0; minMserDiff = 5000; mserInd0=[];
      [boundaryPts,connComp,numObjects] = mex_bwboundaries(maskBlock);
      %[boundaryPts,connComp,numObjects] = bwboundaries(maskBlock,'noholes');
      if numObjects > 1
        for numComp = 1:numObjects
          distToBdry(numComp) = mex_closestPt([cornerInIter(2) cornerInIter(1)],boundaryPts{numComp}, 1);
          %distToBdry(numComp) = closestPt([cornerInIter(2) cornerInIter(1)],boundaryPts{numComp}, 1);
        end
        [~,indMin] = min(distToBdry); [rSel cSel] = find(connComp==indMin);
      else [rSel cSel] = find(maskBlock==1); end
      
      selMainTrans = uint32(sub2ind(size(maskBlock), rSel, cSel)); %maskDummy = zeros(sz1Cut,sz2Cut); maskDummy(selMainTrans) = 1; subplot(1,3,3), imshow(maskDummy);
      
      for i=1:length(regions)
        selCut = regions{i}; maskRedet = zeros(sz1Cut, sz2Cut); maskRedet(selCut) = 1;
        [boundReDet,~,circFlag0] = CalculateERBoundary_pre(maskRedet,iter_val,commonVar,cornerInIter);
        maskRedetR = maskRedet(1+topShiftCur:end - bottomShiftCur,1+leftShiftCur:end-rightShiftCur);
        [rSel1 cSel1] = find(maskRedetR==1);
        selCutR = uint32(sub2ind(size(maskRedetR), rSel1, cSel1)); %maskDummy = zeros(sz1Cut,sz2Cut); maskDummy(selMainTrans) = 1; subplot(1,3,3), imshow(maskDummy);
        
        if ~isempty(boundReDet)
          numBound = size(boundReDet,2); closeVal=5000*ones(1,numBound); indClose=[];
          for bNo=1:numBound
            if ~isempty(boundReDet{bNo})
              [closeVal(bNo),indClose(bNo)] = mex_closestPt([cornerInIter(2) cornerInIter(1)],boundReDet{bNo},1);
              %[closeVal(bNo),indClose(bNo)] = closestPt([cornerInIter(2) cornerInIter(1)],boundReDet{bNo},1);
            end
          end
          [minCloseVal, minInd] = min(closeVal);
          if minCloseVal<10
           boundaryPart2 =  getFixedBoundPts(boundReDet{minInd},[cornerInIter(1:2) cornerWrtImage(3) zeros(1,4) indClose(minInd)],circFlag0);
            sc2 = getShapeContext(boundaryPart2);
            sc_cost = getbestMatch(scOld,sc2);
            
            areaDiffVal = setxor(selMainTrans, selCutR); % areaDiffValWtd = sum(gaussianKernel(areaDiffVal));
            areaDiff(i) = length(areaDiffVal);
            smallerRegion = min(length(selMainTrans), length(selCut));
            
            if sc_cost < scCostThresh && areaDiff(i)/smallerRegion < areaDiffThresh
              %{
                if commonVar.displayflag %the boundaries have not been shifted with leftShift etc
                boundaryOldA(:,1) = boundaryOld(:,1)-  (topIm-1) ; boundaryOldA(:,2) = boundaryOld(:,2) - (leftIm-1);
                figure; subplot(1,2,1), imshow(maskBlock);hold on; plot(boundaryOldA(:,2),boundaryOldA(:,1),'r');
                subplot(1,2,2), imshow(maskRedetR);hold on; plot(boundaryPart2(:,2),boundaryPart2(:,1),'r'); %plot(boundReDet{minInd}(:,2),boundReDet{minInd}(:,1),'r');
              end
              %}
              variationRegion = variationNThresh(1,i);
              if variationRegion > variationBest
                mserInd0 = i; variationBest = variationRegion; minMserDiff = lenDiff(i);
                boundaryNew=boundaryPart2; maskNew=maskRedet; scNew=sc2;
              else
                if variationRegion == variationBest
                  if lenDiff(i) < minMserDiff,
                    mserInd0 = i; boundaryNew=boundaryPart2; maskNew=maskRedet; scNew=sc2;
                  end
                end
              end
            end
          end
        end
      end
      if ~isempty(mserInd0), cornerOldUpd(13:14) = variationNThresh(1:2,mserInd0);
        cornerOldUpd(16:17) = [lenRegions(mserInd0)/(sz1Cut*sz2Cut) lenRegions(mserInd0)]; cornerOldUpd(20) = plusOrMinus;
        regionNew = regions{mserInd0};
      end
      
      %{
      commonVar.displayflag=0;
      if commonVar.displayflag
        if ~isempty(mserInd0)
          figure; subplot(1,2,1), imshow(maskOld);
          selCut = regions{mserInd0}; maskRedet = zeros(sz1Cut, sz2Cut); maskRedet(selCut) = 1;
          subplot(1,2,2),imshow(maskRedet); % displaying the beset match
        end
        figure; %displaying all the candidates
        for aa=1:length(regions)
          subplot(1,2,1), imshow(maskOld);
          selCut = regions{i}; maskRedet = zeros(sz1Cut, sz2Cut); maskRedet(selCut) = 1;
          subplot(1,2,2), imshow(maskRedet);
        end
      end
      
      commonVar.displayflag=0;
      if commonVar.displayflag
        figure;
        subplot(1,2,1), imshow(maskBlock);
        %                                 subplot(1,2,2), imshow(maskRedetR);
        
        maskBlock1 = zeros(sz1Cut,sz2Cut);
        selCut1 = regions{mserInd0};
        maskBlock1(selCut1) = 1;
        maskBlock1 = maskBlock1(1+topShiftCur:end - bottomShiftCur,1+leftShiftCur:end-rightShiftCur);
        subplot(1,2,2), imshow(maskBlock1);
      end
      %}
      
    end
  end
end

end
