function [matchFinal_new totValidPts_new] = compareDisplKine(featMatch1,featMatch2,matchesFull,frameTuple,dataset,dilVal,fgBound,deltaDisp,imSize)
                                                            
ifExact=0;matchFinal=[];matchFinalExact=[]; totValidPts=0;
deltaDispBy2 = deltaDisp/2; 

dSetNo = getParamsAndDataset(dataset); 
imgnoStr1= getImgnoInStrOrInt(frameTuple(1),dSetNo);

featMatchR = round(featMatch2(1:2,:))';
indBound0 = ismember(featMatchR,fgBound{2},'rows');%this will not work for dSet=2 for now
indBound = find(indBound0);
ind{2} = indBound; ind{3} = 1:size(featMatch1,2);

for b = 2:3,
    
    if dSetNo == 10 || dSetNo == 11
        [~,~,gtAll1, featByBB1, featIndBB1, gtObjId1] = getFgBBkine(featMatch1(1:2, ind{b})', dataset, imgnoStr1, dilVal,'',imSize);
    else
        [~,~,gtAll1, featByBB1, featIndBB1, gtObjId1] = getFgBB(featMatch1(1:2, ind{b})', dataset, imgnoStr1, dilVal,'',imSize);
    end

    imgnoStr2 = getImgnoInStrOrInt(frameTuple(2),dSetNo);

    if dSetNo == 10 || dSetNo == 11
        [~,~,gtAll2, featByBB2, featIndBB2, gtObjId2] = getFgBBkine(featMatch2(1:2, ind{b})', dataset, imgnoStr2, dilVal,'',imSize);
    else
        [~,~,gtAll2, featByBB2, featIndBB2, gtObjId2] = getFgBB(featMatch2(1:2, ind{b})', dataset, imgnoStr2, dilVal,'',imSize);
    end

    if 0 %display
      imgPath = sprintf('../images/%s/img%s.ppm',dataset,imgnoStr1);  img1 = imread(imgPath);
      imgPath = sprintf('../images/%s/img%s.ppm',dataset,imgnoStr2);  img2 = imread(imgPath);
      color = rand(size(featMatch1,2),3); colorF = color;
      figure,imshow(img1); hold on; showellipticfeaturesSPL(featMatch1',colorF,5,0,1,img1);
      figure,imshow(img2); hold on; showellipticfeaturesSPL(featMatch2',colorF,5,0,1,img2);

      text(featMatch(1,:)+3,featMatch(2,:)+3,num2str(m2.matchFinal(:,frD-1)),'FontSize',10,'Color','w')
    end

    [commonId commonIdInd1 commonIdInd2]= intersect(gtObjId1,gtObjId2);
    for cId=1:length(commonId)
      numObj1 = commonIdInd1(cId); numObj2 = commonIdInd2(cId);

      if gtObjId1(numObj1) == gtObjId2(numObj2)
        [indCommonBB] = intersect(featIndBB1{numObj1},featIndBB2{numObj2}); %check what these are. Maybe it must go to feat.
        totValidPts = length(indCommonBB) + totValidPts;
        if ~ifExact
          dispPts = abs(featMatch1(1:2,indCommonBB) - featMatch2(1:2,indCommonBB));
          %     mean(dispPts,2); std(dispPts(:,1)); std(dispPts(:,2)) %get some
          %     statistics as additional checking
          dispGt = abs(gtAll1{numObj1}(5:6) - gtAll2{numObj2}(5:6));%/2;
          indMatch = find(dispPts(1,:) <= (dispGt(1)+deltaDisp) & dispPts(2,:) <= (dispGt(2)+deltaDisp)); %only these are matches

          matchFinal=[matchFinal; matchesFull(indCommonBB(indMatch),:)]; % indMatchExact
          [matchFinal indUnique] = unique(matchFinal,'rows');
          %     if numObj1>1 && length(indCommonBB(indMatch)) >10 aaaa=1; end % checking
        else
          dispPtsExact = featMatch1(1:2,indCommonBB) - featMatch2(1:2,indCommonBB);
          dispGtExact = (gtAll1{numObj1}(5:6) - gtAll2{numObj2}(5:6))/2;
          indMatchExact = find(dispPtsExact(1,:) <= (dispGtExact(1)+deltaDispBy2) & dispPtsExact(1,:) >= (dispGtExact(1)-deltaDispBy2) ...
            & dispPtsExact(2,:) <= (dispGtExact(2)+deltaDispBy2) & dispPtsExact(2,:) >= (dispGtExact(2)-deltaDispBy2)); %only these are matches
          matchFinalExact=[matchFinalExact; matchesFull(indCommonBB(indMatchExact),:)];
          [matchFinalExact indUnique] = unique(matchFinalExact,'rows');
          matchFinal = matchFinalExact;
        end

      end

      if 0 %display
      imgPath = sprintf('../images/%s/img%s.ppm',dataset,imgnoStr1);  img1 = imread(imgPath);
      imgPath = sprintf('../images/%s/img%s.ppm',dataset,imgnoStr2);  img2 = imread(imgPath);
      color = rand(size(featMatch1,2),3); colorF = color;
      figure,imshow(img1); hold on; showellipticfeaturesSPL(featMatch1(:,indCommonBB(indMatch))',colorF,5,0,1,img1);
      figure,imshow(img2); hold on; showellipticfeaturesSPL(featMatch2(:,indCommonBB(indMatch))',colorF,5,0,1,img2);

      if 0 %iccv fig      
            figure,imshow(img1); hold on; showellipticfeaturesSPL(featMatch1(:,indCommonBB(indMatch))',colorF,5,0,1,img1);
            numPt = 2; [x y] = ginput(numPt);
            featM1 = featMatch1(:,indCommonBB(indMatch));
            featM2 = featMatch2(:,indCommonBB(indMatch));
            for i=1:numPt
                [~,indRem(i)] = closestPt([x(i) y(i)],featM1(1:2,:)',1);
            end
            featM1= featM1(:,indRem); featM2 = featM2(:,indRem);
    %         featM1(:,indRem)=[]; featM2(:,indRem)=[];
            color = rand(numPt,3); colorF = color;
            fig1 = showellipticfeaturesSPL(featM1',colorF,5,0,0,img1);
            fig2 =showellipticfeaturesSPL(featM2',colorF,5,0,0,img2);
            figure,imshow(fig1); figure,imshow(fig2); 
      end

      figure,imshow(img1); hold on; showellipticfeaturesSPL(featMatch1(:,indCommonBB(indMatchExact))',colorF,5,0,1,img1);
      figure,imshow(img2); hold on; showellipticfeaturesSPL(featMatch2(:,indCommonBB(indMatchExact))',colorF,5,0,1,img2);

      %checking
      figure,imshow(img1); hold on; showellipticfeaturesSPL(feat1(:,matchFinal(:,1))',colorF,5,0,1,img1);
      figure,imshow(img2); hold on; showellipticfeaturesSPL(feat2(:,matchFinal(:,2))',colorF,5,0,1,img2);

      end

    end
    
    matchFinal_new{b} = matchFinal;
    totValidPts_new(b) = totValidPts;
    
end

matchFinal_new{1} = setdiff(matchFinal_new{3},matchFinal_new{2},'rows'); totValidPts_new(1) = totValidPts_new(3) - totValidPts_new(2);

end