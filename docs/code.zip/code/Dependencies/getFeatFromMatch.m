function [featMatch1 featMatch2 matchesFull flagFileFault feat1 feat2] = getFeatFromMatch(dataset,detType,desType,frameTuple,delta,matchDisplStr,fgTypeCompB,thresh,numIndex,ifGetFeat)
if ~exist('ifGetFeat','var')
  ifGetFeat = [1 1];
end

featMatch1=[]; featMatch2=[]; matchesFull=[];feat1=[]; feat2=[];
flagFileFault=0;
matchesSavePath = sprintf('../data/results/matches-delta%d/%s/match%s_%d_%d%s_%s_%s',delta,dataset,detType,frameTuple(1),frameTuple(2),matchDisplStr,fgTypeCompB,desType);

if exist(strcat(matchesSavePath,'.mat'),'file')
  try m = load(matchesSavePath);
  catch; flagFileFault=1; end
  if ~flagFileFault
    if all(size(m.matchFinal))==0, flagFileFault=1; end
  end
else
  flagFileFault=1;
end
try
  
  if ifGetFeat(1)
    ptFile = sprintf('../data/results/feat-delta%d/%s/img%d.%s.txt',delta,dataset,frameTuple(1)-1,detType);
    feat1 = loadFeatures(ptFile); %subtraction has to be done here before display
  end
  
  if ifGetFeat(2)
    ptFile = sprintf('../data/results/feat-delta%d/%s/img%d.%s.txt',delta,dataset,frameTuple(2)-1,detType);
    feat2 = loadFeatures(ptFile); %subtraction has to be done here before display
  end
catch
  flagFileFault=1;
end

if ~flagFileFault
    matchesFull0 = m.matchFinal;
    indThresh = find(matchesFull0(:,numIndex)<thresh);
    
    matchMat = [matchesFull0(indThresh,1:2) matchesFull0(indThresh,numIndex)];
    tempMat = sortrows(matchMat,[2 -3]); [~,indUnique] = unique(tempMat(:,2),'rows');
    
%     if strcmp(detType,'harronmser')
%         matchesFull = tempMat(indUnique,:);
%     else
        matchesFull = tempMat(indUnique,1:2);
%     end

    if(~isempty(matchesFull))
        while ( matchesFull(end, 1) > size(feat1, 2) || matchesFull(end, 2) > size(feat2, 2))
            fprintf('Here\n');
            matchesFull(end, :) = [];
            fprintf('Here 2\n');
            ptf1 = sprintf('../data/results/feat-delta%d/%s/img%d.%s.txt',delta,dataset,frameTuple(1)-1,detType);
            ptf2 = sprintf('../data/results/feat-delta%d/%s/img%d.%s.txt',delta,dataset,frameTuple(2)-1,detType);            
            fprintf('Error in %s and %s\n', ptf1, ptf2);
        end
    end

    featMatch1 = feat1(:,matchesFull(:,1));
    featMatch2 = feat2(:,matchesFull(:,2));
    
end


if 0 %display
  dSetNo = getParamsAndDataset(dataset); imgnoStr1= getImgnoInStrOrInt(frameTuple(1),dSetNo); imgnoStr2 = getImgnoInStrOrInt(frameTuple(2),dSetNo);
  imgPath = sprintf('../images/%s/img%s.ppm',dataset,imgnoStr1);  img1 = imread(imgPath);
  imgPath = sprintf('../images/%s/img%s.ppm',dataset,imgnoStr2);  img2 = imread(imgPath);
  color = rand(size(featMatch1,2),3); colorF = color;
  figure,imshow(img1); hold on; showellipticfeaturesSPL(featMatch1',colorF,5,0,1,img1);
  figure,imshow(img2); hold on; showellipticfeaturesSPL(featMatch2',colorF,5,0,1,img2);
  
end
