function GetFigures(dataset)

% myDisplayDetPtsOuter('cara',[40 50 80 90],'harronmser'); 

%%%
imgPath = sprintf('../images/%s/img001.ppm',dataset);
img = imread(imgPath);
fig = figure(1);

set(fig,'position',[0,30,0.6*2*size(img,2),0.6*2*size(img,1)]);

h(1).axes = axes('position',[0.5,0.5,0.5,0.5]);
h(2).axes = axes('position',[0,0.5,0.5,0.5]);
h(3).axes = axes('position',[0.5,0,0.5,0.5]);
h(4).axes = axes('position',[0,0,0.5,0.5]);

% 40,80 illumination
cla(h(1).axes); cla(h(2).axes);cla(h(3).axes); cla(h(4).axes);

imfr = myDisplayDetPtsOuter(dataset,[50],'harronmser'); %imfr = getframe(gca); close(gcf);
imshow(imfr,'parent',h(1).axes); axis(h(1).axes,'image','off'); hold(h(1).axes, 'on');
imfr = myDisplayDetPtsOuter(dataset,[50],'har'); 
imshow(imfr,'parent',h(2).axes); axis(h(2).axes,'image','off'); hold(h(2).axes, 'on');
imfr = myDisplayDetPtsOuter(dataset,[60],'harronmser'); 
imshow(imfr,'parent',h(3).axes); axis(h(3).axes,'image','off'); hold(h(3).axes, 'on');
imfr = myDisplayDetPtsOuter(dataset,[60],'har'); 
imshow(imfr,'parent',h(4).axes); axis(h(4).axes,'image','off'); hold(h(4).axes, 'on');

text(size(img,2)/2,3,sprintf('CoMIC Points'),'parent',h(1).axes,'color','g','HorizontalAlignment','center','VerticalAlignment','top','FontSize',24,'FontWeight','bold','BackgroundColor','black');
text(size(img,2)/2,3,sprintf('Harris Points'),'parent',h(2).axes,'color','g','HorizontalAlignment','center','VerticalAlignment','top','FontSize',24,'FontWeight','bold','BackgroundColor','black');


end