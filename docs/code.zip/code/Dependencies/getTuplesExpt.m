function Tuples = getTuplesExpt(dirPath)


dirData = dir(dirPath);
dirIndex = [dirData.isdir];
subDirs = {dirData(dirIndex).name};
validIndex = ~ismember(subDirs,{'.','..'});
Tuples = [];
for iDir = find(validIndex)
    nextDir = fullfile(dirPath,subDirs{iDir});
    dirData = dir(nextDir);
    fileList = {dirData.name}';
    try
        imgInd = cellfun(@(x) isempty(strfind(x,'.p')),fileList,'UniformOutput',false);
    catch
        error('Error: Input must be .ppm images');
    end
    imgList = cell2mat(imgInd);
    dirList = repmat(subDirs{iDir},length(find(~imgList)),1);
    try
        dirListCell=mat2cell(dirList,ones(size(dirList,1),1),4);
    catch
        error('Error: Directories must be 4 charcters in length');
    end
    try
        Tuples = [Tuples; dirListCell fileList(~imgList,:)];
    catch
        error('Error: Directories must be 4 charcters in length and contain .jpg images');
        
    end
end

