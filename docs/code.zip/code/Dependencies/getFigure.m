function getFigure(yLabelString1, yLabelString2,numImages,HomPC,Hr3PC,Hs2PC,FasPC,MsrPC,HomNum,Hr3Num,Hs2Num,FasNum,MsrNum)


% yLabelString1 = 'Repeatability %';
% yLabelString2 = 'Number of Correspondences';
datastring='pens';
switch datastring
    case 'bike'
        xlabelString = 'Increasing blur';
    case 'uubc'
        xlabelString = 'JPEG compression %';
    case 'luvn'
        xlabelString = 'Decreasing light';
    otherwise
        xlabelString = sprintf('Frame Number Set');
end

mark=['-*cv';'-.gs';'--m+';'-.bp';'--rd';'--kx';];
lineWidthVal = 5; MarkerSizeVal = 2; FontSizeVal = 40; %10, 24 and 40
xAxis = 1:(numImages/3);

hFig1 = figure;clf;
grid on;
title(datastring);
ylabel(yLabelString1,'FontSize',FontSizeVal,'FontWeight','bold')
xlabel(xlabelString,'FontSize',FontSizeVal,'FontWeight','bold');
figure(hFig1); axis([0.9*2 numImages 0 102]);
hold on;

hFig2 = figure;clf;
grid on;
title(datastring);
ylabel(yLabelString2,'FontSize',FontSizeVal,'FontWeight','bold')
xlabel(xlabelString,'FontSize',FontSizeVal,'FontWeight','bold');
hold on;

figure(hFig1);  plot(xAxis,HomPC,mark(6,:),'Linewidth',lineWidthVal,'MarkerSize',MarkerSizeVal);
figure(hFig1);  plot(xAxis,Hr3PC,mark(2,:),'Linewidth',lineWidthVal,'MarkerSize',MarkerSizeVal);
figure(hFig1);  plot(xAxis,Hs2PC,mark(4,:),'Linewidth',lineWidthVal,'MarkerSize',MarkerSizeVal);
figure(hFig1);  plot(xAxis,FasPC,mark(5,:),'Linewidth',lineWidthVal,'MarkerSize',MarkerSizeVal);
figure(hFig1);  plot(xAxis,MsrPC,'-d','Color',[1 0.6 0],'Linewidth',lineWidthVal,'MarkerSize',MarkerSizeVal);
figure(hFig1);  plot(xAxis,HomPC,'-k','Linewidth',lineWidthVal,'MarkerSize',MarkerSizeVal);

figure(hFig2);  plot(xAxis,HomNum,mark(6,:),'Linewidth',lineWidthVal,'MarkerSize',MarkerSizeVal);
figure(hFig2);  plot(xAxis,Hr3Num,mark(2,:),'Linewidth',lineWidthVal,'MarkerSize',MarkerSizeVal);
figure(hFig2);  plot(xAxis,Hs2Num,mark(4,:),'Linewidth',lineWidthVal,'MarkerSize',MarkerSizeVal);
figure(hFig2);  plot(xAxis,FasNum,mark(5,:),'Linewidth',lineWidthVal,'MarkerSize',MarkerSizeVal);
figure(hFig2);  plot(xAxis,MsrNum,'-d','Color',[1 0.6 0],'Linewidth',lineWidthVal,'MarkerSize',MarkerSizeVal);
figure(hFig2);  plot(xAxis,HomNum,'-k','Linewidth',lineWidthVal,'MarkerSize',MarkerSizeVal);

figure(hFig1);set(gca,'FontWeight','bold');
h_legend= legend('CoMIC','Harris','Hessian','Fast-9','Mser','Location','SouthEast'); %legend('ProfuseMser','Harris1','Harris2','Hessian1','Hessian2','Fast-9','Location','SouthEast');
set(gca,'FontWeight','bold');
set(h_legend, 'FontSize',45)
set(gca,'FontWeight','bold','LineWidth',lineWidthVal,'FontSize',FontSizeVal);

figure(hFig2);set(gca,'FontWeight','bold');
h_legend = legend('CoMIC','Harris','Hessian','Fast-9','Mser','Location','SouthEast');
set(h_legend, 'FontSize',45)
set(gca,'FontWeight','bold','LineWidth',lineWidthVal,'FontSize',FontSizeVal);
