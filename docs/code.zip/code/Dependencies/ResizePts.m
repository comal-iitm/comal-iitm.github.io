function featResize = ResizePts(feat,resizeFactorPts)
featResize = feat;
scaleFact = sqrt((resizeFactorPts(1)^2 + resizeFactorPts(2)^2)/2);   %Detection of features is done at the standard size of 700X1000, points are resized to the value specified in the groundtruth

featResize(1,:)=feat(1,:).*resizeFactorPts(1); featResize(2,:)=feat(2,:).*resizeFactorPts(2);
featResize(3:5,:)=feat(3:5,:)./(scaleFact*scaleFact);
featResize(6:9,:)=feat(6:9,:).*(scaleFact);
end