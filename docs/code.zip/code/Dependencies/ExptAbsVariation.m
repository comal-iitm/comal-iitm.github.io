%run mser with abs variation on images without scale change and check performance

function ExptAbsVariation
MexCompile;

detectorsAll=1;  detectorMain=1; getOrigDetPts=1; useStabThresh=0; ifExtraOverErr=0; %to 40

dirData = '../images1';
Tuples = getTuples(dirData);
detectorTypes = ['harr';'lapl';'hess'];
commonVar  = globalVariables;

for t = 1:size(Tuples,1)
    if detectorsAll
        %     detectedPtsOrigFormAll={};
        disp(t);
        tic;
        imgPath = fullfile(dirData,Tuples{t,1},Tuples{t,2});
        img = uint32(imread(imgPath)); %give initial image a little smoothing
        if ~strcmp(Tuples{t,1},'boat')
            img = rgb2gray(img);
        end
        %         img = BoundaryGaussianSmoothing_2D(img,1);
        detectedPts=[]; detectedPtsOrigForm=[]; %smoothing over all scales , smoothFactor = sz*const
        [ysize,xsize] = size(img);
        
        if detectorMain
            for i=1:size(commonVar.allBlockSz,2)
                %             disp(i)
                iSz = commonVar.allBlockSz(i);
                [imBlocks indBlock] = getAllblocks(img,iSz); %check correctness
                deltaCell = num2cell(repmat(commonVar.deltaIter,length(imBlocks),1));
                [mserIndAll variationMetric] = cellfun(@mser_mexExpt,imBlocks,deltaCell,'UniformOutput',false);   %imBlocks must be uint32
                [mserIndAllAbs variationMetricAbs] = cellfun(@mser_mexExptAbs,imBlocks,deltaCell,'UniformOutput',false);   %imBlocks must be uint32
                octaveIdx=1; %for now
                for j=1:length(mserIndAllAbs)
                    mserIndAbs = mserIndAllAbs{j}(1,:);
                    mserInd = mserIndAll{j}(1,:);
%                     if length(mserIndAbs) ~= length(mserInd)
                        [missingMserInAbs indNotInAbs] = setdiff(mserInd,mserIndAbs);
                        [missingMserInOrig indNotInOrig] = setdiff(mserIndAbs,mserInd);
                        commonMser = intersect(mserInd,mserIndAbs);
                        varOrig = variationMetric{j}(2,indNotInAbs); varAbs = variationMetricAbs{j}(2,indNotInOrig);
                        for erIdx = 1:length(missingMserInAbs)
                            [~, mserNotInAbs] = getERBoundCor(missingMserInAbs(erIdx),imBlocks{j},octaveIdx);
                            imshow(mserNotInAbs);  %subplot(1,2,1);
                        end
                        
                        for erIdx = 1:length(missingMserInOrig)
                            [~,mserNotInOrig] = getERBoundCor(missingMserInOrig(erIdx),imBlocks{j},octaveIdx);
                            imshow(mserNotInOrig);
                        end
%                     end
                end
            end
        end
    end
end