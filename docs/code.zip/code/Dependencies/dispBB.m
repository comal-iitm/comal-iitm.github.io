function dispBB(dset,imToRun)
datasetsOther = ['bord';'boxz';'cann';'cupp';'cycl';'dino';'lemm'];
datasetsOtherCell = mat2cell(datasetsOther,ones(1,7),4);

dirData = '../images';
if ~exist('dset','var')
    Tuples = getTuples(dirData);
    [datasets indUnique] = unique(Tuples(:,1));
    indUnique = [0; indUnique];
    numImagesAll = indUnique(2:end) - indUnique(1:end-1);
end


aa = [2];%[1 3:7 12];
for a=1:length(aa)%d=1:length(datasets)
    d = aa(a);
    %     for d=1:length(datasets)
    numFrames = numImagesAll(d); %indUnique(d+1) - indUnique(d);
    gtInds = 1:5:numFrames;
    %         imNew = GetBGFromVideo(dset,numFrames);
    %         ExtractBackground(dset,numFrames);
    
        dset = datasets{d};
    if any(strcmp(dset,datasetsOtherCell))
        ifOtherDatasets = 1;
        decVal = 4;
    else
        ifOtherDatasets = 0;
        decVal = 3;
    end
          
    indValid  = strcmp(Tuples(:,1),dset);
    TuplesD = Tuples(indValid,:);
    
    imAll = (0:numFrames-1)';
    imToRun = imAll;
    imToRun = imToRun +1;
    dSetNo = getParamsAndDataset(dset);
    groundtruth = csvread(sprintf('../images/%s/groundtruth.txt',dset));
        gt_base = csvread(sprintf('../images/%s/board_gt.txt',dset));
        
    %     imToRun = [464 465];
    for iR = 1:length(imToRun)  %t=1:size(TuplesD,1)
        imgnoInt = imToRun(iR);
%         imgno = getImgnoInStrOrInt(imgnoInt,dSetNo);
        %         imTuple = TuplesD(t,:);
        %             disp(imTuple)
        %     convertGt(dataset,dataset); %convert for PROST dataset
        sizeOrig = dlmread(sprintf('../images/%s/original_size.txt',dset));
        scaleFac = 700./sizeOrig(2); %sizeOrig;
        %get gt values
        leftGtInit = groundtruth(imgnoInt,1); topGtInit = groundtruth(imgnoInt,2);
        widInit = groundtruth(imgnoInt,3); htInit = groundtruth(imgnoInt,4);
        
        topLeftGt = [topGtInit-1 leftGtInit-1].*(scaleFac) + 1;
        topGt = topLeftGt(1); leftGt = topLeftGt(2);
        widHtGt = [htInit widInit].*(scaleFac);
        wid = widHtGt(2); ht = widHtGt(1);
        
        dist2Gt = mod(imgnoInt-1,5);
        if 0
             imgnoStr = getImgnoInStrOrInt(imgnoInt,dSetNo);
            imgPath = sprintf('../images/%s/img%s.ppm',dset,imgnoStr);
            figure, imshow(imgPath);
            rectangle('Position', [leftGt topGt wid ht],'LineWidth',2);
            
            img = imread(imgPath);
            aa = imresize(img,[sizeOrig(2) sizeOrig(1)]);
            hFig = figure; imshow(aa,[])
            rectangle('Position', [leftGtInit topGtInit widInit htInit],'LineWidth',2);
            
        end
        if dist2Gt
            [sortGtInds,sortInd] = sort([imgnoInt gtInds]);
            indCur = find(sortInd==1);
            closestGtIndL = sortGtInds(indCur-1);
            closestGtIndU = sortGtInds(indCur+1); %check if it's 5 or 6
            leftGtInitL = gt_base(closestGtIndL,1); topGtInitL = gt_base(closestGtIndL,2);
            widInitL = gt_base(closestGtIndL,3); htInitL = gt_base(closestGtIndL,4);
            
            leftGtInitU = gt_base(closestGtIndU,1); topGtInitU = gt_base(closestGtIndU,2);
            widInitU = gt_base(closestGtIndU,3); htInitU = gt_base(closestGtIndU,4);
            
            leftGtDist = leftGtInitL + dist2Gt*(leftGtInitL - leftGtInitU)/5;
            topGtDist = topGtInitL + dist2Gt*(topGtInitL - topGtInitU)/5;
            
            topLeftGtDist = [topGtDist-1 leftGtDist-1].*(scaleFac) + 1;
            leftGtDist = topLeftGtDist(2); topGtDist = topLeftGtDist(1);
            htDist = mean(htInitL, htInitU)*(scaleFac) ;
            widDist = mean(widInitL,widInitU)*(scaleFac);
            botGtDist = topGtDist + htDist; rightGtDist = leftGtDist + widDist;
            
            if 0
             imgnoStr = getImgnoInStrOrInt(imgnoInt,dSetNo);
            imgPath = sprintf('../images/%s/img%s.ppm',dset,imgnoStr);
            figure, imshow(imgPath);
            rectangle('Position', [leftGt topGt wid ht],'LineWidth',2);
            rectangle('Position', [leftGtDist topGtDist widDist htDist],'LineWidth',2,'EdgeColor','r');
            end
            botGt = topGt + ht; rightGt = leftGt + wid;
            [col row] = meshgrid(round(leftGt:rightGt), round(topGt:botGt));
            [colDist rowDist] = meshgrid(round(leftGtDist:rightGtDist), round(topGtDist:botGtDist));
            if length(setdiff(row(:),rowDist(:))) > 0.1*ht & length(setdiff(col(:),colDist(:)))> 0.1*wid
%                 open gt file and overwrite stuff or plug this into the old file.
            end
            
        end
        if 0
        imgSave1 = sprintf('../bb/%s',dset);
        imgSave = sprintf('../bb/%s/img%s.ppm',dset,imgnoInt);
        %         if ~exist('imgSave1','dir')
        %             mkdir(imgSave1);
        %         end
        saveas(hFig,imgSave);
        %         close all;
        end
    end
end