function [ptPosition,indGlobal, divergenceflag]=intpointdetom_pre(xRecenteredCut,yRecenteredCut,remsxl2,sxi2,idx,circflag,iter,commonVar)

ptPosition = [];
indGlobal = [];

cornernessthresh = 0.025;
%ANKITA: separate values for cornerness and the maximality measure
% so that while considering closest corners we can consider those corners also that were detected but are not as stable
% as the maximally stable ones.This increases the chances of finding closest corners on neighbors

%     x = boundary(:,2);
%     y = boundary(:,1);

% MinDistFromBoundary = min distance from the image boundary for it to be a valid corner.
% granularity is needed here ONLY for this purpose.
MinDistFromBoundary = 3*commonVar.granularity;

sxM2 = commonVar.momScaleFactor*sxi2;
ind=[];
divergenceflag = 0;

if  (   size(xRecenteredCut,1)<=2*ceil(commonVar.cornerSigmaFactor*sxM2*commonVar.granularity2) || ...
        size(xRecenteredCut,1)<=2*ceil(commonVar.cornerSigmaFactor*sxi2*commonVar.granularity2) ...
        ) %Ensures that there are enough points to begin with 
    %remsxl2 must be added to the sxi2 and sxM2 if this quantity is to even
    %be used.
    divergenceflag = 1;
    pos = [];
    val = [];
    return; % Quit intpointdet ~Ramkumar
end

localMaxSz = round(sxi2/commonVar.smoothingFactor);
szpt = localMaxSz; %max(localMaxSz,round(sxM2*2));  % localMaxSz; %must be set based on commonVar.ScaleDependCornerMax

if commonVar.ScaleDependCornerMax
    %     szpt = max(localMaxSz,round(sxM2*2)); % max(9,round(sxM2*2));
    szpt = szpt-mod(szpt,3);
end

if 0
    x0 =BoundaryGaussianSmoothingPre(xRecenteredCut,remsxl2,circflag,commonVar); % Smoothing the contours ~Ramkumar
    y0 =BoundaryGaussianSmoothingPre(yRecenteredCut,remsxl2,circflag,commonVar);
    % hold on, plot(x0,y0,'r');
else
    x0 = xRecenteredCut; y0 = yRecenteredCut;
end

xMean=BoundaryGaussianSmoothingPre(x0,sxi2,circflag,commonVar);

yMean =BoundaryGaussianSmoothingPre(y0,sxi2,circflag,commonVar);

x02=(x0.*x0);

y02=(y0.*y0);

x0y=(x0.*y0);

x02weighted =BoundaryGaussianSmoothingPre(x02,sxi2,circflag,commonVar);

y02weighted =BoundaryGaussianSmoothingPre(y02,sxi2,circflag,commonVar);

x0yweighted =BoundaryGaussianSmoothingPre(x0y,sxi2,circflag,commonVar); % Scale is sxi2

% ANKITA
% find extra elements=(1*(sxM2 - sxi2)) after applying smoothing with sxi2 and sxM2 and remove them

if (circflag ==0)
    shift=ceil(commonVar.cornerSigmaFactor*(sxM2*commonVar.granularity2 - sxi2*commonVar.granularity2));
    
    xMean=xMean(shift+1:size(xMean,1)-shift,1);
    yMean=yMean(shift+1:size(yMean,1)-shift,1);
    
    x02weighted=x02weighted(shift+1:size(x02weighted,1)-shift,1);
    y02weighted =y02weighted(shift+1:size(y02weighted,1)-shift,1);
    x0yweighted=x0yweighted(shift+1:size(x0yweighted,1)-shift,1);
end

xm2weighted=(x02weighted-(xMean.^2));
ym2weighted=(y02weighted-(yMean.^2));
xmyweighted=(x0yweighted-(xMean.*yMean));

% more smoothing for the moment matrix computation
xMeanM = BoundaryGaussianSmoothingPre(x0,sxM2,circflag,commonVar);
yMeanM = BoundaryGaussianSmoothingPre(y0,sxM2,circflag,commonVar);

x02M=(x0.*x0);
y02M=(y0.*y0);
x0yM=(x0.*y0);

x02weightedM =BoundaryGaussianSmoothingPre(x02M,sxM2,circflag,commonVar);
y02weightedM =BoundaryGaussianSmoothingPre(y02M,sxM2,circflag,commonVar);
x0yweightedM =BoundaryGaussianSmoothingPre(x0yM,sxM2,circflag,commonVar);

xm2weightedM=(x02weightedM-(xMeanM.^2));
ym2weightedM=(y02weightedM-(yMeanM.^2));
xmyweightedM=(x0yweightedM-(xMeanM.*yMeanM));

% NOTE: The 2nd moment matrix is computed NOT over Intensity of the Image.
% It is only a measure of inflexion of the points on the contour. ~Ramkumar

detC=(xm2weighted.*ym2weighted)-(xmyweighted.^2);
trace2C=(xm2weighted+ym2weighted).^2;

cornerness=detC./trace2C;

cor_xy_sig =(abs(cornerness))';


if circflag == 1
    cor_xy_sig=[cor_xy_sig(:,end-szpt+1:end) cor_xy_sig cor_xy_sig(:,1:szpt)]; %appending
end
%   cor_xy_sig=[repmat(cor_xy_sig(:,1),1,szpt) cor_xy_sig repmat(cor_xy_sig(:,end),1,szpt)]; %appending
% end
% fprintf(1,'circflag = %d\n', circflag);

if circflag==1
    [validindex validvalues]=localMinMax_block(cor_xy_sig,szpt,1,iter); %pts coming out of this are wrt unpadded cor_xy_sig. the coords of fit are also translated like that
else
    [validindex validvalues]=localMinMax_block(cor_xy_sig,szpt,0,iter);
    
end

if idx ~= -1 %find corner closest to idx, used in call from adaptintpointaffine() - on cut contours
    
    if ~isempty(validindex)
        ind = validindex;
        indGlobal = AdjustIndex(xRecenteredCut,cor_xy_sig,idx,ind); %CHECK THIS SWARNA MAY 30 12%These values are adjusted NOT to be in the UNPADDED cor_sig_xy ~Swarna
        %        4 sigma how many times, subtract that much from ind, display both
        %             ptMovement = idx - diff - ind;
        %             indGlobal = idx - ptMovement;
        numPts = size(indGlobal,1);
        if numPts>1
            
            idxArr = repmat(idx,[numPts 1]);
            [~, indBest] = min(min(abs(idxArr-indGlobal),abs(indGlobal-idxArr)));
            indGlobal = indGlobal(indBest);
            ind = ind(indBest);
            
        end
        
        % indGlobal = (mod(ind + validleftglobal - 2,sizeX)) + 1;
        
        ptPosition = [xRecenteredCut(indGlobal) yRecenteredCut(indGlobal)];
        
    else
        ptPosition =[];
        indGlobal = [];
        
    end
    
else
    
    % find all corners - used in init stage AND parent and child in
    % adaptintpointaffine
    if ~isempty(validindex)
        ind = validindex(validvalues>cornernessthresh); % find the indices of those corners which have cornerness>thresh
                
        if ~isempty(ind)
            diffSize = (length(xRecenteredCut) - length(cornerness))/2; %CHECK
            indAdj = ind + diffSize;
            ptPosition = [xRecenteredCut(indAdj) yRecenteredCut(indAdj)]; %x and y co-ordinates of the selected corners
            if 0 %~iter This pruning is done later. To switch this on, add xsize and ysize to 
                idxTooCloseToEdge = ptPosition(:,2)< MinDistFromBoundary |ptPosition(:,1)<MinDistFromBoundary | ...
                    ptPosition(:,2)>ysize-MinDistFromBoundary | ptPosition(:,1)>xsize-MinDistFromBoundary;
                
                ptPosition(idxTooCloseToEdge,:)=[]; % ... and empty them out
                indAdj(idxTooCloseToEdge,:)=[];
                ind(idxTooCloseToEdge,:)=[];
            end
            indGlobal = indAdj;
        else
            ptPosition =[];
        end
    else
        ptPosition =[];
        
    end
    
end

sigmaInvs=[];

for i=1:size(indGlobal,1)
    c11=xm2weightedM(ind(i));
    c12=xmyweightedM(ind(i));
    c22=ym2weightedM(ind(i));
    
    sigmaInv = inv([c11 c12; c12 c22]);
    sigmaInvs=[sigmaInvs ; sigmaInv(1,1) sigmaInv(1,2) sigmaInv(1,2) sigmaInv(2,2)];
end


if size(ptPosition,1) > 0
    ptPosition=[ptPosition(:,1:2) sxi2*ones(size(ptPosition,1),1) sigmaInvs indGlobal commonVar.momScaleFactor*ones(size(ptPosition,1),1) cornerness(ind)];
    
    if commonVar.displayflag
        figure, plot(x0,y0), axis equal, hold on;  plot(ptPosition(:,1), ptPosition(:,2), '*g'); % hold on; %plot(poscheck(:,1), poscheck(:,2), '*r')
        showellipticfeatures(ptPosition);
    end
    
else
    %         disp('no point redetected');
end

end
