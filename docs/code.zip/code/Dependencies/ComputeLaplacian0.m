function lapval = ComputeLaplacian0(xRecentered,yRecentered,idx,remsxl2)

commonVar = globalVariables;
granularity2=1;
fastSmoothing = 1;
% stack = dbstack;
%
% Timing('ComputeLaplacian',1,stack(2).name);
sx = remsxl2;
dxMask = [-1 0 1]/2;
dyMask = [-1 0 1]/2;


% switch on for smoothing only the relavant points

numPtsContour = size(xRecentered,1);

sigma = sx*granularity2;
kernelLength = floor(min(numPtsContour - 5,  floor((6*sigma)/2)*2+1)/2)*2 - 1 ; %used to be 6
smoothingKernel = fspecial('gaussian',[kernelLength 1],sigma);

%ANKITA: a cut has been included here also we are calculating
%cutlower and cutupper to find only the relevant points(which is 5 in this case) on the
%boundary for which lapval has to be calculated

numExtPts = round((kernelLength-1)/2); %ceil((numPtsContour - kernelLength)/2);
endVal = round(0.2*numPtsContour);

[xExt0 yExt0] = ExtendCurve(xRecentered(1:endVal),yRecentered(1:endVal),1,numExtPts); %change one and end
% 
if any(abs(yExt0)>1000) %~isempty(yExt0) & all(sign(yExt0)==-1)
    [yExt0 xExt0] = ExtendCurve(yRecentered(1:endVal),xRecentered(1:endVal),1,numExtPts);
end

[xExtN yExtN] = ExtendCurve(xRecentered(end-endVal:end),yRecentered(end-endVal:end),0,numExtPts);

if any(abs(yExtN)>1000) %~isempty(yExtN) & all(sign(yExtN)==-1)
    [yExtN xExtN] = ExtendCurve(yRecentered(end-endVal:end),xRecentered(end-endVal:end),0,numExtPts);
end

if ~isempty(yExt0) & ~isempty(yExtN)
    numExt0 = length(xExt0);
    
    xRecenteredExt = [fliplr(xExt0)'; xRecentered; xExtN'];
    yRecenteredExt = [fliplr(yExt0)'; yRecentered; yExtN'];
    numPtsContourExt = length(yRecenteredExt);
    
    if fastSmoothing
        idxShifted = idx + numExt0;
        cutLower = mod(idxShifted -2 - (kernelLength-1)/2 - 1, numPtsContourExt) + 1; % -1 and +1 due to matlab indices
        cutUpper = mod(idxShifted +2 + (kernelLength-1)/2 - 1, numPtsContourExt) + 1; % -1 and +1 due to matlab indices
        
        if (cutLower < cutUpper)
            xRecenteredCut = xRecenteredExt(cutLower:cutUpper);
            yRecenteredCut = yRecenteredExt(cutLower:cutUpper);
        else
            disp('Cutting out of bounds: Problem');
            cutUpperActual = idxShifted +2 + (kernelLength-1)/2 - 1;
            fprintf('CutUpper %f, and kernellength %f and total points %f',cutUpperActual,kernelLength,numPtsContourExt');
            %         xRecenteredCut = [xRecentered(cutLower:end); xRecentered(1:cutUpper)];
            %         yRecenteredCut = [yRecentered(cutLower:end); yRecentered(1:cutUpper)];
        end
        
        if commonVar.displayflag
            %        figure, plot(xRecentered,yRecentered,'*'); hold on, plot(xRecentered(idx),yRecentered(idx),'*g');
            figure, plot(xRecenteredExt,yRecenteredExt,'*'); hold on, plot(xRecenteredExt(idxShifted),yRecenteredExt(idxShifted),'*g');
            plot(xRecenteredExt(cutLower),yRecenteredExt(cutLower),'*g'); plot(xRecenteredExt(cutUpper),yRecenteredExt(cutUpper),'*r');
        end
        
        szsmoothingKernel=size(smoothingKernel,1);
        
        for shift=1:5
            Lx(shift) = dot(xRecenteredCut(shift:szsmoothingKernel+shift-1),smoothingKernel);
            Ly(shift) = dot(yRecenteredCut(shift:szsmoothingKernel+shift-1),smoothingKernel);
        end
        
        % switch on for full convolutional smoothing
        %     if (idx <= 2)
        %          xRecentered = [xRecentered(1:end-2); xRecentered(end-2:end)];
        %          yRecentered = [yRecentered(1:end-2); yRecentered(end-2:end)];
        %          idx = idx + 2;
        %     end
        %
        %     if (idx >= size(xRecentered,1) - 1)
        %          xRecentered = [xRecentered(1:2); xRecentered(3:end)];
        %          yRecentered = [yRecentered(1:2); yRecentered(3:end)];
        %          idx = idx - 2;
        %     end
        %
        %
    else
        
        Lx0= imfilter(xRecenteredExt,smoothingKernel,'conv'); %aa = BoundaryGaussianSmoothing(xRecentered,sx,0,1);
        Ly0= imfilter(yRecenteredExt,smoothingKernel,'conv'); %aa = BoundaryGaussianSmoothing(yRecentered,sx,0,1);
        
        idxShifted = idx + numExt0; %round((idx/length(xRecentered)) * length(Lx0));
        Lx = Lx0(idxShifted-2:idxShifted+2)';
        Ly = Ly0(idxShifted-2:idxShifted+2)';
        
    end
    
    if commonVar.displayflag
        figure, plot(xRecentered,yRecentered), hold on, plot(xExtN,yExtN,'r');
        plot(xExt0,yExt0,'r');
        plot(Lx0(numExtPts:end - numExtPts),Ly0(numExtPts:end - numExtPts),'*m');
        plot(Lx,Ly,'*k');
    end
    
    % %     LxvalUnnorm=imfilter(Lx',dxmask,'circular','conv');
    % %     LyvalUnnorm=imfilter(Ly',dymask','circular','conv');
    
    %     LxvalUnnorm=imfilter(Lx',dxMask,'circular','conv');
    %     LyvalUnnorm=imfilter(Ly',dyMask,'circular','conv');
    
    % if size(Lx,1) ~= 5
    %     disp('Stop');
    % end
    
    LxvalUnnorm = conv(Lx, dxMask,'valid');
    LyvalUnnorm = conv(Ly, dyMask,'valid');
    curveLength = ((LxvalUnnorm).^2+(LyvalUnnorm).^2).^(1/2);
    
    Lxval = LxvalUnnorm./curveLength;
    Lyval = LyvalUnnorm./curveLength;
    
    LxxvalUnnorm=conv(Lxval',dxMask,'valid');
    LyyvalUnnorm=conv(Lyval',dyMask','valid');
    
    Lxxval = LxxvalUnnorm./curveLength(2);
    Lyyval = LyyvalUnnorm./curveLength(2);
    %
    %     LxxxvalUnnorm=imfilter(Lxxval,dxmask,'circular','conv');
    %     LyyyvalUnnorm=imfilter(Lyyval,dymask','circular','conv');
    %
    %     Lxxxval = LxxxvalUnnorm./curveLength;
    %     Lyyyval = LyyyvalUnnorm./curveLength;
    %
    %     LxxxxvalUnnorm=imfilter(Lxxxval,dxmask,'circular','conv');
    %     LyyyyvalUnnorm=imfilter(Lyyyval,dymask','circular','conv');
    %
    %     Lxxxxval = LxxxxvalUnnorm./curveLength;
    %     Lyyyyval = LyyyyvalUnnorm./curveLength;
    
    % normalized Laplacian and its derivative w.r.t. scale
    %         lapval=sqrt(Lxxval(idx)^2+Lyyval(idx)^2)*sx;
    %     lapval=(Lxval(idx)*Lyyval(idx)-Lxxval(idx)*Lyval(idx))*sx;
    %         /(((Lxval(idx))^2+(Lyval(idx))^2)^(3/2));
    
    % normalized Laplacian and its derivative w.r.t. scale
    lapval=abs((Lxval(2).*Lyyval-Lxxval.*Lyval(2))*sx);
    %    lapval=BoundaryGaussianSmoothing_1D(lapval',5,0);
    
    
    %     lapsxval=(Lxxval+Lyyval)+(sx/2)*(Lxxxxval+Lyyyyval+2*Lxxyyval);
    %     lapsxval=(Lxval(idx)+Lyyval(idx))+(sx/2)*(Lxxxxval(idx)+Lyyyyval(idx));
    %     lapsxval = (Lxval(idx)*Lyyyyval(idx))+(Lxxval(idx)*Lyyyval(idx))- ...
    %         (Lxxxxval(idx)*Lyval(idx))-(Lxxxval(idx)*Lxxval(idx));
    
    %
    %     lapsxval = (Lxval.*Lyyyyval)+(Lxxval.*Lyyyval)- ...
    %         (Lxxxxval.*Lyval)-(Lxxxval.*Lxxval);
    %
    %     granularity2 = oldgranularity2;
    %
    % Timing('ComputeLaplacian',0,stack(2).name);
    
else
    lapval = [];
end
end

