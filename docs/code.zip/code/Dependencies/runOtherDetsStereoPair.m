function runOtherDetsStereoPair(imTuple,ifDesc,detType,desType,sxi2,corThresh,dSetNo,dilValComp,fgTypeComp,delta)

imgInd = regexp(imTuple{2}, '[0-9]'); imgnoStr =  imTuple{2}(imgInd); % needs adjusting for non-single digit img nos
imNo = str2double(imgnoStr);
   
if mod(imNo,4)==1
    thresh=[];
    imgnoBase = imNo;
    thresh = SubtractAndGetSiftDescriptor(imTuple,ifDesc,detType,desType,sxi2,corThresh,dSetNo,dilValComp,fgTypeComp,delta,imgnoBase,thresh);
    for i=1%:3
        imgnoStr = getImgnoInStrOrInt(imNo+i,dSetNo);
        imTuple{2} = sprintf('img%s.ppm',imgnoStr);
        SubtractAndGetSiftDescriptor(imTuple,ifDesc,detType,desType,sxi2,corThresh,dSetNo,dilValComp,fgTypeComp,delta,imgnoBase,thresh);
    end
end

end