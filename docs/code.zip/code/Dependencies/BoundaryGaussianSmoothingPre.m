function filteredResult = BoundaryGaussianSmoothingPre(coords,sigma,circflag,commonVar)

%smoothingKernel_filteredResult oldsigma_filteredResult window
sigma = sigma*commonVar.granularity2;

KernelWidth = ceil(commonVar.cornerSigmaFactor*sigma); %4*sigma/5;
if circflag == 1
    padCoords = [coords(end-KernelWidth+1:end) ;coords ;coords(1:KernelWidth)];
else
    padCoords = coords;
end

filteredResult = smoothdynamic(padCoords,KernelWidth);

%      smoothingKernel_filteredResult = fspecial('gaussian',[kernelLength 1],sigma);
%      filteredResult = imfilter(coords,smoothingKernel_filteredResult,'circular','conv');

end
