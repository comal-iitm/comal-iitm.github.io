function descr = getSiftDescriptor(img,f1)

if 0 % you wanna send in the points itself, ~exist('f1','var') %getSiftDescriptor(dataset,detType,imgNo,f1)
    for imgno=imgNo%1:endImgNo
        dirData = '../images'; ext = 'ppm';
        decVal = 3;
        imgnoStr = getImgnoInStrOrInt(imgno,decVal);
        imgPath = sprintf('%s/%s/img%s.%s',dirData,dataset,imgnoStr,ext);
        img = rgb2gray(imread(imgPath));
        ptFile = sprintf('../data/results/%s/img%d.%s.txt',dataset,str2num(imgnoStr)-1,detType);
        f1 = loadFeatures(ptFile);
    end
end

[M N] = size(img);

S      =  3 ; omin   = -1 ;
O      = floor(log2(min(M,N)))-omin-3 ; % up to 8x8 images
sigma0 = 1.6*2^(1/S) ;                  % smooth lev. -1 at 1.6
sigman = 0.5 ; NBP    = 4 ; NBO    = 8 ; magnif = 3.0 ;
gss = gaussianss(img,sigman,O,S,omin,-1,S+1,sigma0) ;
octaveIdx =2; numPts = size(f1,2);

% radius = maginf * sigma * NBP / 2
% sigma = sigma0 * 2^s/S,
%radius 6*sigma approx => sigma should be 1 for a scale of 6. rad2 =
%6*(sigma0 * 2.^(-3.034/S)) = 6;

s = 0;
cornerMat = [f1(1:2,:)-1; s*ones(1,numPts);zeros(1,numPts) ];
featDesc = siftdescriptor(gss.octave{octaveIdx}, cornerMat,gss.sigma0,gss.S, gss.smin, ...
    'Magnif', magnif, 'NumSpatialBins', NBP, 'NumOrientBins', NBO) ;
descr = uint8(512*featDesc) ;
if 0
    featFinal = [f1; descr];
    ptDes = sprintf('../data/results/%s/featDesc%d_%s',dataset,str2num(imgnoStr)-1,detType);
    save('ptDes','featDesc');
end

end