function [feat, thresh] = ObtainFeaturePoints(imTuple,ifDesc,detType,sxi2,threshInit,dSetNo,dilVal,fgTypeComp,delta,imgnoBase,thresh)

ptDirData = sprintf('../data/results/feat-delta%d',delta);
descDirData = sprintf('../data/results/desc-delta%d',delta);
imDirData = '../Images';

%% Detector - others
dataset = imTuple{1};
imgInd = regexp(imTuple{2}, '[0-9]');
imgnoStr =  imTuple{2}(imgInd); % needs adjusting for non-single digit img nos
imgnoInt = str2double(imgnoStr);

imgPath = sprintf('%s/%s/%s',imDirData,dataset,imTuple{2});
ptFile = sprintf('%s/%s/img%d.%s.txt',ptDirData,dataset,imgnoInt-1,detType);
ptFileCoMIC = sprintf('%s/%s/img%d.%s.txt',ptDirData,dataset,imgnoInt-1,'harronmser');

fgType{1}=fgTypeComp;
if ~ifDesc %if only running descriptor and not points also simulataneously
  [feat thresh] = OtherDetectors(imgPath,ptFile,dataset,imgnoInt,detType,sxi2,threshInit,dSetNo,thresh,imgnoBase,ptFileCoMIC,dilVal,fgType);
else
    thresh=[];
end %some random initialisation to be sent out
