function [subBlock regionsClose variation topIm leftIm minMserDist thresholdIndClose maskBlock szCut] = getCorCentBlockAndMserInd(cornerWrtImage,boundaryOld,circflag,imBlock,mask,plusOrMinusCur,img,indBlock,topLeftPrev,t,delta)

commonVar = globalVariables(t);

thresholdIndClose=[]; maskBlock=[]; regionsClose=[]; subBlock=[]; topIm=[]; leftIm=[] ; szCut=[];
areaDiff=0; variation =5000; minMserDist=5000; iter_val = 1;
extraBlocklength = 1.3*cornerWrtImage(3); % extraBlocklength = 0.1;  testting
smoothingLen = round(1.2*3*cornerWrtImage(3))+1; %smoothingLen = 10;
threshCor = cornerWrtImage(14);

[szMask1 szMask2] = size(mask);

if szMask1 == size(imBlock,1)
    threshMinLim = 10; areaDiffThresh = 0.5;
else
    threshMinLim = 7; areaDiffThresh = 0.5;
end

[szIm1 szIm2] = size(img);
sigS = cornerWrtImage(3)/commonVar.smoothingFactor;
topPrev = topLeftPrev(1); leftPrev = topLeftPrev(2);
minCloseVal = 2;

range0 = sigS*commonVar.iterBlockFactor;
range = round((range0*0.8)/5)*5;
sz = round(round(range0/5)*5*commonVar.blockMultFactor);%block size

windowWidth = (1 + ceil(commonVar.smoothingFactor*sigS/1.5));% + extraLen);

% if circflag | (cornerWrtImage(8) > smoothingLen & cornerWrtImage(8) < size(boundaryOld,1) - smoothingLen) %fix this
if 0
    leftBoundInd = cornerWrtImage(8) - smoothingLen;
    rightBoundInd = cornerWrtImage(8) + smoothingLen; %round(cornerOld(3)/commonVar.smoothingFactor*commonVar.iterBlockFactor/5)*5;
    if circflag
        if leftBoundInd < 1
            if leftBoundInd ==0
                leftBoundInd = size(boundaryOld,1); %for ==0 case
            else
                leftBoundInd = mod(leftBoundInd,size(boundaryOld,1)); %for ==0 case
            end
        end
        if rightBoundInd > size(boundaryOld,1)
            rightBoundInd = mod(rightBoundInd,size(boundaryOld,1));
        end
    end
    
    if leftBoundInd < rightBoundInd
        boundaryCut = boundaryOld(leftBoundInd:rightBoundInd,:);
        boundaryLeft = boundaryOld(leftBoundInd:cornerWrtImage(8),:);
        boundaryRight = boundaryOld(cornerWrtImage(8):rightBoundInd,:);
    else
        boundaryCut = [boundaryOld(leftBoundInd:end,:);boundaryOld(1:rightBoundInd,:)];
        if cornerWrtImage(8)>leftBoundInd
            boundaryLeft = boundaryOld(leftBoundInd:cornerWrtImage(8),:);
            boundaryRight = [boundaryOld(cornerWrtImage(8):end,:); boundaryOld(1:rightBoundInd,:)];
        else
            boundaryLeft = [boundaryOld(leftBoundInd:end,:); boundaryOld(1:cornerWrtImage(8),:)];
            boundaryRight = boundaryOld(rightBoundInd:cornerWrtImage(8),:);
        end
        
    end
    
    
    topIm= round(max(min([boundaryCut(:,1);cornerWrtImage(2)])  - extraBlocklength ,1));
    bottomIm = round(min(max([boundaryCut(:,1);cornerWrtImage(2)]) + extraBlocklength, szIm1)) ;
    leftIm  = round(max(min([boundaryCut(:,2);cornerWrtImage(1)]) - extraBlocklength ,1));
    rightIm =  round(min(max([boundaryCut(:,2);cornerWrtImage(1)]) + extraBlocklength, szIm2));
end

topIm = max(1,round(cornerWrtImage(2))-range);
bottomIm = min(szIm1,round(cornerWrtImage(2))+range);
leftIm = max(1,round(cornerWrtImage(1))-range);
rightIm = min(szIm2,round(cornerWrtImage(1))+range);

%      [thetaNormal thetaTangent xMin xMax yMin yMax] = CalculateDirNormAndTan(boundaryRight,boundaryLeft,cornerWrtImage,img,boundaryOld,getBlockDim,leftIm,rightIm);

corner(:,1:2) =  cornerWrtImage(:,1:2) - (indBlock - 1);

bottomPrev = topPrev + szMask1 -1;
rightPrev = leftPrev + szMask2 -1;

topImCommon = max([topIm topPrev indBlock(2)]);
bottomImCommon = min([bottomIm bottomPrev indBlock(2)+(sz-1)]);
leftImCommon = max([leftIm leftPrev indBlock(1)]);
rightImCommon = min([rightIm rightPrev indBlock(1)+(sz-1)]);

%%%
topShiftPrev = topImCommon - topPrev;
leftShiftPrev = leftImCommon - leftPrev;

bottomShiftPrev = bottomPrev - bottomImCommon ;
rightShiftPrev = rightPrev - rightImCommon;
%%%
topShiftCur = topImCommon - topIm;
leftShiftCur = leftImCommon - leftIm;

bottomShiftCur = bottomIm - bottomImCommon ;
rightShiftCur = rightIm - rightImCommon;

top = topImCommon - indBlock(2) +1;
bottom = bottomImCommon - indBlock(2) +1;
left = leftImCommon - indBlock(1) +1;
right = rightImCommon - indBlock(1) +1;

if top<0 | bottom<0 | left<0 | right<0
    disp('Error error error in block indices')
end

if commonVar.displayflag
    figure, imshow(img,[]); hold on; rectangle('Position', [leftIm topIm rightIm-leftIm+1 bottomIm-topIm+1],'LineWidth',2);
    rectangle('Position', [leftPrev topPrev szMask2 szMask1],'LineWidth',2);
    rectangle('Position', [leftImCommon topImCommon rightImCommon-leftImCommon+1 bottomImCommon-topImCommon+1],'EdgeColor',[0 0 1],'LineWidth',2);
    plot(indBlock(1), indBlock(2),'*g');
end


subBlock = img(topIm:bottomIm,leftIm:rightIm);
szCut = size(subBlock);
sz1Cut = szCut(1); sz2Cut  = szCut(2);


if all(szCut>(0.8*2*range))
    if any(szCut <= 0.8*2*range)
        disp(szCut);
    end
    szSubBlock = sz1Cut*sz1Cut; %(bottom-top + 1)*(right-left+1);
    sz1New = sz1Cut-(bottomShiftCur+topShiftCur); sz2New = sz2Cut-(rightShiftCur+leftShiftCur);
    gaussianKernel = fspecial('gaussian',[sz1Cut sz2Cut],max(sz1Cut,sz2Cut)/6);
    maxGaussVal = max(max(gaussianKernel));
    gaussianKernel = maxGaussVal - gaussianKernel;
    
    
    commonVar.displayflag=0;
    if commonVar.displayflag
        figure;subplot(1,3,1), imshow(imBlock,[]),subplot(1,3,2), imshow(subBlock,[]);
        subplot(1,3,3),imshow(mask), hold on, plot(corner(1),corner(2),'*')
    end
    commonVar.displayflag=0;
    
    gaussianKernel = gaussianKernel(1+topShiftCur:end - bottomShiftCur,1+leftShiftCur:end-rightShiftCur);
    if topPrev==indBlock(2) & leftPrev ==indBlock(1)
        cornerInIter = corner(1:2) - [left-1 top-1];
        maskBlock = mask(top:bottom,left:right); %subplot(1,3,1), imshow(mask); subplot(1,3,2), imshow(maskBlock);
        
    else
        topPrevWrtBl = topPrev - indBlock(2) +1;
        leftPrevWrtBl = leftPrev - indBlock(1) +1;
        %     cornerInIter = corner(1:2) - [leftPrevWrtBl-1 topPrevWrtBl-1];
        cornerInIter = corner(1:2) - [left-1 top-1];
        maskBlock = mask(1+topShiftPrev:end - bottomShiftPrev,1+leftShiftPrev:end-rightShiftPrev);
    end
    
    calcForTgt = 1;
    [boundary,~,circflag] = CalculateERBoundary(maskBlock,iter_val,t,cornerInIter);
    
    if ~isempty(boundary)
        for a=1:size(boundary,2)
            %         for b=1:size(boundary{a},2)
            if ~isempty(boundary{a})
                [closeVal,indClose] = closestPt([cornerInIter(2) cornerInIter(1)],boundary{a});
                
                if closeVal < minCloseVal
                    minCloseVal = closeVal;
                    minIndClose = indClose;
                    minAB = [a];
                    skipTest = 0;
                end
            end
            %         end
        end
        
        if ~exist('minIndClose','var')
            skipTest = 1;
        else
            skipTest = 0;
        end
        
        if ~skipTest
            if (minIndClose > windowWidth) & ((minIndClose+windowWidth) <= size(boundary{minAB(1)},1))
                %             endPt1 = mean(boundary{minAB(1)}(minIndClose-windowWidth:minIndClose,:));
                %             endPt2 = mean(boundary{minAB(1)}(minIndClose:minIndClose+windowWidth,:));
                
                %             figure, plot(boundaryNearCorner(:,2),boundaryNearCorner(:,1)), hold on;
                if 0 %another way of finding centre point
                    boundaryNearCorner = boundary{minAB(1)}(minIndClose-windowWidth:minIndClose+windowWidth,:);
                    boundaryNearCornerSmooth(1,:)=BoundaryGaussianSmoothing(boundaryNearCorner(:,1),constantSmooth,0); %must be made some constant
                    boundaryNearCornerSmooth(2,:)=BoundaryGaussianSmoothing(boundaryNearCorner(:,2),constantSmooth,0);
                    %             plot(boundaryNearCornerSmooth(2,:),boundaryNearCornerSmooth(1,:),'g');
                    boundaryMean = mean(boundaryNearCorner);
                    poly = polyfit([boundaryNearCorner(1,2) boundaryNearCorner(end,2)],[boundaryNearCorner(1,1) boundaryNearCorner(end,1)],1); %change one and end
                    testWarn = lastwarn;
                    polyWarning =  'Polynomial is badly conditioned';
                    isPolyWarning = strfind(testWarn, polyWarning);
                    
                    if ~isempty(isPolyWarning)
                        aa=1;
                    end
                    slope = poly(1); intercept = poly(2);
                    theta1  = atand(slope);
                    if theta1<0
                        theta1=180+theta1;
                    end
                    
                end
                
                %
                %             polyNew = polyfit([endPt1(2) endPt2(2)],[endPt1(1) endPt2(1)],1); %change one and end
                %
                %             slopeNew = polyNew(1); interceptNew = polyNew(2);
                %             theta1New  = atand(slopeNew);
                %             if theta1New<0
                %                 theta1New=180+theta1New;
                %             end
                
                boundaryRight = boundary{minAB(1)}(minIndClose-windowWidth:minIndClose,:);
                boundaryLeft = boundary{minAB(1)}(minIndClose:minIndClose+windowWidth,:);
                [theta1New thetaTangent] = CalculateDirNormAndTan(boundaryRight,boundaryLeft,cornerInIter,maskBlock,boundary{minAB(1)});
                
                commonVar.displayflag=0;
                if commonVar.displayflag
                    figure, imshow(maskBlock), hold on, plot(boundary{minAB(1)}(:,2),boundary{minAB(1)}(:,1));
                    %
                    thetaTangent = theta1New+90;%theta1 + 90;
                    slopeTangent = tand(thetaTangent);
                    interceptTangent=cornerInIter(1,2)-slopeTangent*cornerInIter(1,1);
                    yi2 = polyval([slopeTangent,interceptTangent],[1 50]);
                    plot([1 50],yi2,'r');
                    
                    thetaNormal = theta1New;%theta1 + 90;
                    slopeNormal = tand(thetaNormal);
                    interceptNormal=cornerInIter(1,2)-slopeNormal*cornerInIter(1,1);
                    yi2 = polyval([slopeNormal,interceptNormal],[1 50]);
                    plot([1 50],yi2,'r');
                    %                 plot(endPt1(1),endPt1(2),'*m'); plot(endPt2(1),endPt2(2),'*m')
                    plot(endPt1(2),endPt1(1),'*g'); plot(endPt2(2),endPt2(1),'*g')
                    plot(cornerInIter(1), cornerInIter(2),'*b');
                    plot(cornerInIter(2), cornerInIter(1),'*b');
                    
                    if 0
                        yi2 = polyval([slope,intercept],[1 50]);
                        plot([1 50],yi2,'m');
                        
                        thetaTangent = theta1+90;%theta1 + 90;
                        slopeTangent = tand(thetaTangent);
                        interceptTangent=cornerInIter(1,1)-slopeTangent*cornerInIter(1,2);
                        yi2 = polyval([slopeTangent,interceptTangent],[1 50]);
                        plot([1 50],yi2,'m');
                        
                    end
                end
                commonVar.displayflag=0;
                
                theta = deg2rad(theta1New+90);
                [~,regions,variationNThresh,plusOrMinus] =  runMatasMser(subBlock,theta,delta,iter_val,t); %next thing to do is to normalise the boundary
                
                if 0
                    figure;
                    for aa=1:length(regions)
                        subplot(1,2,1), imshow(maskBlock);
                        maskBlock1 = zeros(sz1Cut,sz2Cut);
                        selCut1 = regions{aa};
                        maskBlock1(selCut1) = 1; subplot(1,2,2), imshow(maskBlock1);
                    end
                end
                
                if ~isempty(regions)
                    indPlusOrMinus = plusOrMinus==plusOrMinusCur;
                    regions = regions(indPlusOrMinus);
                    variationNThresh = variationNThresh(:,indPlusOrMinus);
                    if ~isempty(regions)
                        indRange = find(variationNThresh(2,:)<threshCor+threshMinLim & variationNThresh(2,:)>threshCor-threshMinLim);
                        regions = regions(indRange);
                        variationNThresh = variationNThresh(:,indRange);
                        
                        if ~isempty(regions)
                            szIndCut = length(regions);
                            [boundaryPts,connComp,numObjects] = bwboundaries(maskBlock,'noholes');
                            if numObjects > 1
                                for numComp = 1:numObjects
                                    cornerInSubBlock = corner(1:2) - [left-1 top-1];
                                    distToBdry(numComp) = closestPt([cornerInSubBlock(2) cornerInSubBlock(1)],boundaryPts{numComp});
                                end
                                [~,indMin] = min(distToBdry);
                                [rSel cSel] = find(connComp==indMin);
                            else
                                [rSel cSel] = find(maskBlock==1);
                            end
                            
                            selMainTrans = uint32(sub2ind(size(maskBlock), rSel, cSel)); %maskDummy = zeros(sz1Cut,sz2Cut); maskDummy(selMainTrans) = 1; subplot(1,3,3), imshow(maskDummy);
                            
                            variationBest = 0; minMserDist = 5000; mserInd0=[];
                            for i=1:length(regions)
                                
                                
                                selCut = regions{i};
                                maskRedet = zeros(sz1Cut, sz2Cut);
                                maskRedet(selCut) = 1;
                                %                         if plusOrMinus==0
                                %                             maskRedet = 1 - maskRedet;
                                %                         end
                                maskRedet = maskRedet(1+topShiftCur:end - bottomShiftCur,1+leftShiftCur:end-rightShiftCur);
                                %                         maskRedet = maskRedet(1+topShift:end-bottomShift,1+leftShift:end-rightShift);
                                [rSel1 cSel1] = find(maskRedet==1);
                                selCuta = uint32(sub2ind(size(maskRedet), rSel1, cSel1)); %maskDummy = zeros(sz1Cut,sz2Cut); maskDummy(selMainTrans) = 1; subplot(1,3,3), imshow(maskDummy);
                                
                                
                                if 0 %this is faster, but fix it later
                                    
                                    selCut = regions{i};
                                    [xVal,yVal] = ind2sub([sz1Cut sz2Cut],selCut);
                                    [rowDel colDel] = find(xVal<1+topShift | xVal>sz1Cut+bottomShift | yVal<1+leftShift | yVal>sz2Cut+rightShift);
                                    if ~isempty(rowDel)
                                        xVal(colDel)=[]; yVal(colDel)=[];
                                        selCutb = uint32(sub2ind([sz1Cut-(max(bottomShift,topShift)) sz2Cut-(max(rightShift,leftShift))], xVal, yVal));
                                    else
                                        selCutb = selCut;
                                    end
                                    
                                end
                                
                                selCut = selCuta;
                                %  if length(selCut) > 0.02*szSubBlock & length(selCut) < 0.98*szSubBlock
                                areaDiffVal = setxor(selMainTrans, selCut); % areaDiffValWtd = sum(gaussianKernel(areaDiffVal));
                                areaDiff(i) = length(areaDiffVal);
                                
                                if 1
                                    smallerRegion = min(length(selMainTrans), length(selCut));
                                    variationRegion = variationNThresh(1,i);
                                    if areaDiff(i)/smallerRegion < areaDiffThresh
                                        if variationRegion > variationBest
                                            mserInd0 = i;
                                            variationBest = variationRegion;
                                            minMserDist = areaDiff(i);
                                        else
                                            if variationRegion == variationBest
                                                if areaDiff(i) < minMserDist
                                                    mserInd0 = i;
                                                    minMserDist = areaDiff(i);
                                                end
                                            end
                                        end
                                    end
                                end
                            end
                            
                            if 0
                                [minMserDist,mserInd0] = min(areaDiff); %get entire list of min
                            end
                            
                            if ~isempty(mserInd0)
                                regionsClose = regions{mserInd0};
                                variation = variationNThresh(1,mserInd0); %could use the boundary length in another function outside to normalize this
                                thresholdIndClose = variationNThresh(2,mserInd0);
                            end
                            
                            %     displaying the beset match
                            commonVar.displayflag=0;
                            if commonVar.displayflag
                                figure;
                                subplot(1,2,1), imshow(maskBlock);
                                subplot(1,2,2), imshow(gaussianKernel,[]);
                                
                                maskBlock1 = zeros(sz1Cut,sz2Cut);
                                selCut1 = regions{mserInd0};
                                maskBlock1(selCut1) = 1;
                                maskBlock1 = maskBlock1(1+topShiftCur:end - bottomShiftCur,1+leftShiftCur:end-rightShiftCur);
                                subplot(1,2,2), imshow(maskBlock1);
                            end
                            
                            %displaying all the candidates
                            commonVar.displayflag=0;
                            %                     variationNThresh
                            if commonVar.displayflag
                                figure;
                                for aa=1:length(regions)
                                    subplot(1,2,1), imshow(maskBlock);
                                    maskBlock1 = zeros(sz1Cut,sz2Cut);
                                    selCut1 = regions{aa};
                                    maskBlock1(selCut1) = 1; subplot(1,2,2), imshow(maskBlock1);
                                end
                            end
                            commonVar.displayflag=0;
                            
                        else
                            regionsClose=[];
                            variation = 5000;
                        end
                    end
                end
            end
        end
    end
end
% end

if commonVar.displayflag
    figure, imshow(subBlock,[]), hold on, plot(cornerNew(1,1), cornerNew(1,2), '*g'); hold off;
    plot(boundaryNew{1}(:,2), boundaryNew{1}(:,1));
    plot(cornerOld(:,1),cornerOld(:,2),'*r','LineWidth',4);
end

end
