function status = MexCompile(compileInsideFn)

if ~exist('compileInsideFn','var')
    compileInsideFn=0;
end
t=1; %dummy value for this case
[~,repVar] = globalVariables(t);

ovErrResolutionNscaling=0;
status = 0;
try
    if 0 %should be made 1 soon
        mex -I. smoothdynamic.c
        mex -I. FastResampleC.c
        mex -I. LocalMaximaC.cpp
        
        %Not used anymore
        %     mex -I. mser_mex.c
        %     mex -I. mser_mexExpt.c
        %     mex -I. msermex.c
        %     mex -I. mser_mexExptAbs.c
        %     mex -I. mser_mexExptBackup.c
        
    end
    %%
    if compileInsideFn
        
        system('cd ./extrema-edu; make clean');  % This is the command used to get the static libraries compiled from within MATLAB (the .out is also ready but we won't be using that)
        system('cd ./extrema-edu; make all');
        
        system('cd ./extrema-edu-iter; make clean');  % This is the command used to get the static libraries compiled from within MATLAB (the .out is also ready but we won't be using that)
        system('cd ./extrema-edu-iter; make all');
    end
    %     mex -v -g -I../LL -I../utls -I../imageutls -I../optionGM libExtrema.a ../LL/libLL.a ../utls/libutls.a ../optionGM/libOptionGM.a -lrt extremaExpt.cpp % This is the command that compiles the mex after the libraries are available using the usual makefile supplied with the Matas code.
    
    mex -v -g -I./extrema-edu/LL -I./extrema-edu/utls -I./extrema-edu/imageutls -I./extrema-edu/optionGM ./extrema-edu/extrema/libExtrema.a ./extrema-edu/LL/libLL.a ./extrema-edu/utls/libutls.a ./extrema-edu/optionGM/libOptionGM.a -lrt ./extrema-edu/extrema/extremaExpt.cpp % This is the command that compiles the mex after the libraries are available using the usual makefile supplied with the Matas code.
    mex -v -g -I./extrema-edu-iter/LL -I./extrema-edu-iter/utls -I./extrema-edu-iter/imageutls -I./extrema-edu-iter/optionGM ./extrema-edu-iter/extrema/libExtrema.a ./extrema-edu-iter/LL/libLL.a ./extrema-edu-iter/utls/libutls.a ./extrema-edu-iter/optionGM/libOptionGM.a -lrt ./extrema-edu-iter/extrema/extremaExptIter.cpp % This is the command that compiles the mex after the libraries are available using the usual makefile supplied with the Matas code.
    
    %     mex -v -g -I./extrema-edu-iter-more-dup/LL -I./extrema-edu-iter-more-dup/utls -I./extrema-edu-iter-more-dup/imageutls -I./extrema-edu-iter-more-dup/optionGM ./extrema-edu-iter-more-dup/extrema/libExtrema.a ./extrema-edu-iter-more-dup/LL/libLL.a ./extrema-edu-iter-more-dup/utls/libutls.a ./extrema-edu-iter-more-dup/optionGM/libOptionGM.a -lrt ./extrema-edu-iter-more-dup/extrema/extremaExptIterMoreDup.cpp % This is the command that compiles the mex after the libraries are available using the usual makefile supplied with the Matas code.
    
    %%
    if ovErrResolutionNscaling
        mex -I. ellipse_overlap5.cxx
    else
        mex -I. c_eoverlap.cxx
    end
    
    if repVar.optimizeRepeatabilityMemory && ~repVar.optimizedRepCorresp
        mex -I. repOut.c
    end
    
    status = 1;
catch
    status = 0;
end

