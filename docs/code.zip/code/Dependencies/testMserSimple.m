function [repeat, corresp, matching_score,nb_of_matches,overlapPer] = testMserSimple(pair,dataset,detType,dSetNo,delta,overRad,changeRepFormula)

overErr= 3;
repeat=[]; corresp=[]; matching_score=[];nb_of_matches =[]; overlapPer=[];
matches=[];matching_scoreNFrames=[];nb_of_matchesNFrames=[];matchAllFrames=1;

ptDirData = sprintf('../data/results/feat-delta%d',delta);
imDirData = '../images';

% parfor pNo = 1:100 %size(pairs,1)
imgno1= pair(1);  imgno2 = pair(2);
imgnoStr1 = getImgnoInStrOrInt(imgno1,dSetNo);
imgnoStr2 = getImgnoInStrOrInt(imgno2,dSetNo);

imgPath1 = sprintf('%s/%s/img%s.ppm',imDirData,dataset,imgnoStr1); %switch to dataset depending on whatever
imgPath2 = sprintf('%s/%s/img%s.ppm',imDirData,dataset,imgnoStr2);

if 0 %dSetNo==3 || dSetNo==4 || dSetNo==7
    %% Getting Matching Score for each application
    pt1= sprintf('%s/%s/img%d.%s.sift.txt',ptDirData,dataset,imgno1-1,detType);
    pt2= sprintf('%s/%s/img%d.%s.sift.txt',ptDirData,dataset,imgno2-1,detType);
    if dSetNo==7
        imgnoStr1M1 = getImgnoInStrOrInt(imgno1-1,dSetNo); imgnoStr2M1 = getImgnoInStrOrInt(imgno2-1,dSetNo);
        Hom = sprintf('../images/%s/H%sto%s.txt',dataset,imgnoStr2M1,imgnoStr1M1);
    else
        Hom = sprintf('../images/%s/H1to%dp',dataset,imgno2);
    end
    
    if exist(Hom,'file')
        if exist(pt2,'file')
            origSizeFile = sprintf('../images/%s/original_size.txt',dataset);
            pathToLoad = sprintf('../data/results/orig-delta%d/%s',delta,dataset);
            [repeat,corresp,matching_score,nb_of_matches,overlapPer]= repeatability(pt1,pt2,Hom,imgPath1,imgPath2, imgno2, origSizeFile,dSetNo,pathToLoad,overRad,changeRepFormula); 
            repeat = repeat(overErr); corresp = corresp(overErr);
            %Calc red rep and send it out; What do you do for Tsuk? Do both
            %and check
            %         matching_score = matching_score; nb_of_matches = nb_of_matches;
            
            %         [match2,match1] = find(wout<=40);%For debugging ((wout<=10 | wout>=40) & wout<100); % find (wout>=10 & wout<=40) ;
            %         nonMatch2 = setdiff(1:size(wout,1),match2);
        else
            repeat = 0; corresp = 0;
            matching_score = 0; nb_of_matches = 0;
        end
    end
    
    if 0
        figure; imshow(img2); hold on, showellipticfeaturesSPL(featRep2(:,nonMatch2)',[1 1 0]); %match2 for other conditions
        figure; imshow(img1); hold on, showellipticfeaturesSPL(featRep1(:,match1)',[1 1 0]); %match2 for other conditions
        figure; imshow(img2); hold on, showellipticfeaturesSPL(featRep2(:,match2)',[1 1 0]); %match2 for other conditions
        
        figure; imshow(img1); hold on, showellipticfeaturesSPL(featRep1',[1 1 0]);
        figure; imshow(img2); hold on, showellipticfeaturesSPL(featRep2',[1 1 0]);
    end
end
%%
if dSetNo==1 || dSetNo==2 || dSetNo==6 || dSetNo==4
    %     pairs=[(1:numImages-1)' (2:numImages)'];
    %     for pNo = 1:size(pairs,1)
    %         imgno1= pairs(pNo,1);  imgno2 = pairs(pNo,2);
    %         imgnoStr1 = getImgnoInStrOrInt(imgno1,decVal);
    %         imgnoStr2 = getImgnoInStrOrInt(imgno2,decVal);
    %
    %         img1 = sprintf('../%s/%s/img%s.%s',direc,dataset,imgnoStr1,ext);
    %         img2 = sprintf('../%s/%s/img%s.%s',direc,dataset,imgnoStr2,ext);
    
    pathSC1 = sprintf('%s/%s/detPtsNoDupDes%d_%s',ptDirData,dataset,imgno1,detType);
    pathSC2 = sprintf('%s/%s/detPtsNoDupDes%d_%s',ptDirData,dataset,imgno2,detType);
    detPtsNoDupDes1 = load(pathSC1); detPtsNoDupDes2 = load(pathSC2);
    detPtsNoDupDes1 = detPtsNoDupDes1.detPtsNoDupDes;
    detPtsNoDupDes2 = detPtsNoDupDes2.detPtsNoDupDes;
    
    ptFile1 = sprintf('%s/%s/img%d.%s.txt',ptDirData,dataset,str2num(imgnoStr1)-1,detType);
    ptFile2 = sprintf('%s/%s/img%d.%s.txt',ptDirData,dataset,str2num(imgnoStr2)-1,detType);
    f1 = loadFeatures(ptFile1); f2 = loadFeatures(ptFile2);
    f1=f1'; f2=f2';
    
    fprintf('\n time for pair %d-%d',str2num(imgnoStr1),str2num(imgnoStr2));
    matchesSavePath0 = sprintf('../data/results/matches-delta%d/%s',delta,dataset);
    if ~exist(matchesSavePath0), mkdir(matchesSavePath0); end
    matchesSavePath = sprintf('%s/match%s_%d_%d_full',matchesSavePath0,detType,str2num(imgnoStr1),str2num(imgnoStr2));
    
    tic; %getSSDBlock
    [featMatch1, featMatch2, ~, overlapPer] = matchDescriptorsFirst(detPtsNoDupDes1,detPtsNoDupDes2,f1,f2,detType,imgPath1,imgPath2,matchesSavePath,overRad); %matches{pNo}
    
    tMatch=toc;
    fprintf('is %f',tMatch);
    if 0
        figure, imshow(img1),showellipticfeaturesSPL(f1);
        figure, imshow(img2),showellipticfeaturesSPL(f2);
        
        num1 = round(rand(1)*200); num2 = round(rand(1)*200)
        figure(num1), imshow(img1), figure(num2), imshow(img2),
        for i=1:size(featMatch1,1)
            color = rand(1,3);
            figure(num1), showellipticfeaturesSPL(featMatch1(i,:),color);
            figure(num2), showellipticfeaturesSPL(featMatch2(i,:),color);
        end
        debugNonMatchingPts(f1,f2,detPtsNoDupDes1,detPtsNoDupDes2,imgPath1,imgPath2)
    end
    
    nb_of_matches = size(featMatch1,1);
    matching_score = (nb_of_matches/size(f1,1))*100; %We check that given point in the first image, does it occur in the second. Different from calculation for mosaicing in oxford, where it is reverse
    
end
% end
end