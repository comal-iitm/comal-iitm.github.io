function indInvalid  = checkDupMSERDebugging(cornersDup,boundary,regions,indBlockDup,plusOrMinus,circFlags)

ifMaskCompare=0;
numCorners = size(cornersDup,1);
% pairs = nchoosek(1:numCorners,2);

valid = ones(numCorners,1);
commonVar = globalVariables(1);
sigS = cornersDup(1,3)/commonVar.smoothingFactor;
range = round(sigS*commonVar.iterBlockFactor/5)*5;
sz = round(range*commonVar.blockMultFactor);%block size
%%
range = 0.8*range; %Since you are taking a 40X40 block for every point, and discarding what's smaller, you don't have to worry about case where masks are not equal.
windowWidth = round(cornersDup(1,3)*2);
scCostThresh = 0.18;
for i=1:numCorners
    if valid(i)
        [maskCorner1 strength1 sc1 mask1 boundaryPart1 cornerWrtBlock1] = getMask(cornersDup(i,:),indBlockDup{i},regions{i},boundary{i},circFlags(i),ifMaskCompare,range,sz,windowWidth);
        if any(size(maskCorner1)<2*range)
            valid(i)=0;
        else
            indDup = setdiff(find(valid>0),i);
            for j=1:length(indDup)
                plusOrMinusBoth = [plusOrMinus(i) plusOrMinus(indDup(j))];
                [maskCorner2 strength2 sc2 mask2 boundaryPart2 cornerWrtBlock2] = getMask(cornersDup(indDup(j),:),indBlockDup{indDup(j)},regions{indDup(j)},boundary{indDup(j)},circFlags(indDup(j)),ifMaskCompare,range,sz,windowWidth,plusOrMinusBoth);
                if any(size(maskCorner2)<2*range)
                    valid(indDup(j))=0;
                else
                    if ifMaskCompare
                        diffAmt = imabsdiff(maskCorner1,maskCorner2) ; %equivalent to setxor
                        sumAmt = or(maskCorner1,maskCorner2) ;
                        %         indCommon = intersect(indValid{1},indValid{2});
                        %         maxLen = max(length(indValid{1}),length(indValid{2}));
                        diffAmtFull = sum(sum(diffAmt));%/maxLen;
                        sumAmtFull = sum(sum(sumAmt));
                        diffAvg = diffAmtFull/sumAmtFull;
                        qtyCompare = diffAvg;
                        qtyThresh=0.35;
                    else
                        sc_cost = getbestMatch(sc1,sc2);
                        qtyCompare = sc_cost;
                        qtyThresh = scCostThresh;
                    end
                    
                    if qtyCompare < qtyThresh
                        if 0
                            figure, imshow(mask1); hold on, plot(boundaryPart1(:,2),boundaryPart1(:,1))
                            plot(cornerWrtBlock1(1),cornerWrtBlock1(2),'*g');
                            
                            figure, imshow(mask2); hold on, plot(boundaryPart2(:,2),boundaryPart2(:,1))
                            plot(cornerWrtBlock2(1),cornerWrtBlock2(2),'*g');
                            
                            figure, imshow(maskCorner1); hold on, plot(boundary1(:,2),boundary1(:,1),'*')
                            figure, imshow(maskCorner2); hold on, plot(boundary2(:,2),boundary2(:,1),'*')
                            close all;
                        end
                        if strength1 <= strength2
                            valid(i)=0;
                        else
                            valid(indDup(j))=0;
                        end
                    else
                        aa=1;
                        if 0
                            figure, imshow(mask1); hold on, plot(boundaryPart1(:,2),boundaryPart1(:,1))
                            plot(cornerWrtBlock1(1),cornerWrtBlock1(2),'*g');
                            
                            figure, imshow(mask2); hold on, plot(boundaryPart2(:,2),boundaryPart2(:,1))
                            plot(cornerWrtBlock2(1),cornerWrtBlock2(2),'*g');
                            %%%%
                            figure, imshow(maskCorner1);
                            figure, imshow(maskCorner2);
                            close all;
                        end
                    end
                end
            end
        end
    end
end

indInvalid = find(valid==0);
end

function [maskCorner strength sc mask boundaryPart cornerWrtBlock] = getMask(cornerWrtImage,indBlockDup,regions,boundary,circFlag,ifMaskCompare,range,sz,windowWidth,plusOrMinusBoth)
maskCorner=zeros(2*range+1,2*range+1); sc=[]; mask=[]; boundaryPart=[]; 
boundaryL=[]; boundaryR=[];

cornerWrtBlock = cornerWrtImage(1:2) - indBlockDup + 1;
strength = cornerWrtImage(13);

if ~ifMaskCompare
    topIm = round(cornerWrtBlock(2)-range);
    bottomIm = round(cornerWrtBlock(2)+range);
    leftIm = round(cornerWrtBlock(1)-range);
    rightIm = round(cornerWrtBlock(1)+range);
    
    if topIm<1 || leftIm<1 || bottomIm > sz+1 || rightIm > sz+1
        maskCorner=[];
    else
        [closeVal,indClose] = closestPt([cornerWrtBlock(2) cornerWrtBlock(1)],boundary);
        bLeft = indClose-windowWidth; bRight = indClose+windowWidth;
        
        if bRight>size(boundary,1) && circFlag,
            boundaryR = boundary(1:bRight - size(boundary,1),:); 
            bRight = size(boundary,1);
        end
        if bLeft<1 && circFlag, 
            boundaryL = boundary(size(boundary,1)-abs(bLeft):end,:); 
            bLeft=1;
        end
        try
        boundaryPart = [boundaryL; boundary(bLeft:bRight,:); boundaryR];
        catch
            aaa=1;
        end
        
        [sc,mean_dist_1] = getShapeContext(boundaryPart);
        mask = zeros(sz+1,sz+1);mask(regions) = 1;
        
        if 0
            figure, imshow(mask); hold on, plot(boundaryPart(:,2),boundaryPart(:,1))
            plot(cornerWrtBlock(1),cornerWrtBlock(2),'*g');
        end
    end
    
else
    topIm = max(1,round(cornerWrtBlock(2)-range));
    bottomIm = min(sz+1,round(cornerWrtBlock(2)+range));
    leftIm = max(1,round(cornerWrtBlock(1)-range));
    rightIm = min(sz+1,round(cornerWrtBlock(1)+range));
    
    mask = zeros(sz+1,sz+1);
    mask(regions) = 1;
    maskCorner = mask(topIm:bottomIm,leftIm:rightIm);
    %             sel = find(maskCorner);
    %Since this is being cut out from a larger block, everything mask will have
    %components.
    if exist('plusOrMinusBoth','var') && ~isequal(plusOrMinusBoth(1),plusOrMinusBoth(2))
        maskCorner = 1 - maskCorner;
        [boundaryPts,connComp,numObjects] = bwboundaries(maskCorner,'noholes');
        if numObjects > 1
            for numComp = 1:numObjects
                cornerInSubBlock = cornerWrtBlock(1:2) - [leftIm-1 topIm-1];
                distToBdry(numComp) = closestPt([cornerInSubBlock(2) cornerInSubBlock(1)],boundaryPts{numComp});
                %             distToBdry(numComp) = closestPt([cornerWrtBlock(2) cornerWrtBlock(1)],boundaryPts{numComp});
            end
            [~,indMin] = min(distToBdry);
            indOff = setdiff(1:numObjects,indMin);
            connComp(connComp==indOff) = 0;
            maskCorner = double(im2bw(connComp));
            %         [rSel cSel] = find(connComp==indMin);
            %     else
            %         [rSel cSel] = find(maskCorner==1);
        end
        %     szMask = size(maskCorner);
        %         selMainTrans = uint32(sub2ind(szMask, rSel, cSel)); %maskDummy = zeros(sz1Cut,sz2Cut); maskDummy(selMainTrans) = 1; subplot(1,3,3), imshow(maskDummy);
    end
end
end

function sc_cost = getbestMatch(sc1,sc2)
costmat=hist_cost_2(sc1,sc2); % compute pairwise cost between all shape contexts
% calculate shape context cost
[a1,b1]=min(costmat,[],1);
[a2,b2]=min(costmat,[],2);
sc_cost =max(mean(a1),mean(a2));
end