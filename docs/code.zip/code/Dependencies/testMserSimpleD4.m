function [repeat, corresp, repeatNonRed, correspNonRed, matching_score,nb_of_matches, msNonRed, matNonRed, overlapPer,matching_scoreD4,nb_of_matchesD4] = testMserSimple2(pair,dataset,detType,dSetNo,delta,overRad,nonRedRep)

overErr= 4;
repeat=[]; corresp=[]; matching_score=[];nb_of_matches =[]; overlapPer=[];matching_scoreD4=[];nb_of_matchesD4=[];
matches=[];matching_scoreNFrames=[];nb_of_matchesNFrames=[];matchAllFrames=1; repeatNonRed=[]; correspNonRed=[];msNonRed=[]; matNonRed=[];
ptDirData = sprintf('../data/results/feat-delta%d',delta);
imDirData = '../images';

% parfor pNo = 1:100 %size(pairs,1)
imgno1= pair(1);  imgno2 = pair(2);
imgnoStr1 = getImgnoInStrOrInt(imgno1,dSetNo);
imgnoStr2 = getImgnoInStrOrInt(imgno2,dSetNo);

imgPath1 = sprintf('%s/%s/img%s.ppm',imDirData,dataset,imgnoStr1); %switch to dataset depending on whatever
imgPath2 = sprintf('%s/%s/img%s.ppm',imDirData,dataset,imgnoStr2);

if dSetNo==3 || dSetNo==4 || dSetNo==7
    %% Getting Matching Score for each application
    pt1= sprintf('%s/%s/img%d.%s.sift.txt',ptDirData,dataset,imgno1-1,detType);
    pt2= sprintf('%s/%s/img%d.%s.sift.txt',ptDirData,dataset,imgno2-1,detType);
    if dSetNo==7
        imgnoStr1M1 = getImgnoInStrOrInt(imgno1-1,dSetNo); imgnoStr2M1 = getImgnoInStrOrInt(imgno2-1,dSetNo);
        Hom = sprintf('%s/%s/H%sto%s.txt',imDirData, dataset,imgnoStr2M1,imgnoStr1M1);
    else
        Hom = sprintf('%s/%s/H1to%dp',imDirData ,dataset,imgno2);
    end
    
    if exist(Hom,'file')
        if exist(pt2,'file')
            origSizeFile = sprintf('%s/%s/original_size.txt',imDirData, dataset);
            pathToLoad = sprintf('../data/results/orig-delta%d/%s',delta,dataset);
            [repeat,corresp,matching_score,nb_of_matches,overlapPer,sf,feat1Rep, feat2Rep,feat1Mat,...
                feat2Mat,resizeFactorPts,f1Im1]= repeatability(pt1,pt2,Hom,imgPath1,imgPath2, imgno2, origSizeFile,dSetNo,dataset,pathToLoad,overRad);
            %            feat1All,feat2tAll repeat = repeat(overErr); corresp = corresp(overErr);
            
            if 0 %nonRedRep
                gauss = 3.3;flag = 0;trunc = 0.83; %2.83 % 1.83 % 14.142 % gauss = 3.3;
                [h,w] = size(rgb2gray(im2double(imread(imgPath1))));  %all coordinates are relative to image 1
                rk  = sprintf('%s/%s/img%d.rep.%s.txt', ptDirData, dataset, imgno1-1,detType);
                if size(feat1Rep,1)>0
                    writeToFileTest(rk,feat1Rep',1,w,h,0,1,1);
                    com = sprintf('./methods/map_ellipses %s %i %i %f %f label %i ', rk, w, h, trunc, gauss, flag);
                    [st, res] = system(com); g = textscan(res, '%f %f %f %f');
                    correspNonRed = g{2}(1); repeatNonRed = 100*correspNonRed/sf; %sum_sum = g{1}(1);% no need
                else, repeatNonRed = 0; correspNonRed=0; end
                
                rk  = sprintf('%s/%s/img%d.sift.rep.%s.txt', ptDirData, dataset, imgno1-1,detType);
                if size(feat1Mat,1)>0
                    writeToFileTest(rk,feat1Mat(:,1:5),1,w,h,0,1,1);
                    com = sprintf('./methods/map_ellipses %s %i %i %f %f label %i ', rk, w, h, trunc, gauss, flag);
                    [st, res] = system(com); g = textscan(res, '%f %f %f %f');
                    matNonRed = g{2}(1); msNonRed = 100*matNonRed/sf; %sum_sum = g{1}(1);% no need
                else, msNonRed =0; matNonRed=0; end
            end
            
        else
            repeat = 0; corresp = 0;correspNonRed=0;repeatNonRed=0;
            matching_score = 0; nb_of_matches = 0;matNonRed=0;correspNonRed=0;
        end
    end
    
    if 0
        figure; imshow(img2); hold on, showellipticfeaturesSPL(featRep2(:,nonMatch2)',[1 1 0]); %match2 for other conditions
        figure; imshow(img1); hold on, showellipticfeaturesSPL(featRep1(:,match1)',[1 1 0]); %match2 for other conditions
        figure; imshow(img2); hold on, showellipticfeaturesSPL(featRep2(:,match2)',[1 1 0]); %match2 for other conditions
        
        figure; imshow(img1); hold on, showellipticfeaturesSPL(featRep1',[1 1 0]);
        figure; imshow(img2); hold on, showellipticfeaturesSPL(featRep2',[1 1 0]);
    end
end
%%
if dSetNo==4
    %     pairs=[(1:numImages-1)' (2:numImages)'];
    %     for pNo = 1:size(pairs,1)
    %         imgno1= pairs(pNo,1);  imgno2 = pairs(pNo,2);
    %         imgnoStr1 = getImgnoInStrOrInt(imgno1,decVal);
    %         imgnoStr2 = getImgnoInStrOrInt(imgno2,decVal);
    %
    %         img1 = sprintf('../%s/%s/img%s.%s',direc,dataset,imgnoStr1,ext);
    %         img2 = sprintf('../%s/%s/img%s.%s',direc,dataset,imgnoStr2,ext);
    pathExtra=fullfile('..','data','results',sprintf('orig-delta%d',delta),sprintf('%s',dataset));
    %    load(sprintf('%s/cornersConv%d.mat',pathExtra,imgno1),'cornersConv');
    r1 = load(sprintf('%s/regionConv%d.mat',pathExtra,imgno1),'regionConv'); r2 = load(sprintf('%s/regionConv%d.mat',pathExtra,imgno2),'regionConv');
    m1= load(sprintf('%s/maskConvSz%d.mat',pathExtra,imgno1),'maskConvSz'); m2= load(sprintf('%s/maskConvSz%d.mat',pathExtra,imgno2),'maskConvSz');
    b1 = load(sprintf('%s/boundaryConv%d.mat',pathExtra,imgno1),'boundaryConv'); b2 = load(sprintf('%s/boundaryConv%d.mat',pathExtra,imgno2),'boundaryConv');
    s1 = load(sprintf('%s/scConv%d.mat',pathExtra,imgno1),'scConv'); s2 = load(sprintf('%s/scConv%d.mat',pathExtra,imgno2),'scConv');
    t1 = load(sprintf('%s/topLeftConv%d.mat',pathExtra,imgno1),'topLeftConv');  t2 = load(sprintf('%s/topLeftConv%d.mat',pathExtra,imgno2),'topLeftConv');
    regions{1} = r1.regionConv; regions{2} = r2.regionConv; maskSzs{1} = m1.maskConvSz; maskSzs{2} = m2.maskConvSz;
    boundarys{1} = b1.boundaryConv; boundarys{2} = b2.boundaryConv; scs{1} = s1.scConv; scs{2} = s2.scConv;
    topLefts{1} = t1.topLeftConv; topLefts{2} = t2.topLeftConv;
    
    ptFile1 = sprintf('%s/%s/img%d.%s.txt',ptDirData,dataset,str2num(imgnoStr1)-1,detType);
    ptFile2 = sprintf('%s/%s/img%d.%s.txt',ptDirData,dataset,str2num(imgnoStr2)-1,detType);
    f1 = loadFeatures(ptFile1); f2 = loadFeatures(ptFile2);
    f1=f1'; f2=f2';
    
    fprintf('\n time for pair %d-%d',str2num(imgnoStr1),str2num(imgnoStr2));
    matchesSavePath0 = sprintf('../data/results/matches-delta%d/%s',delta,dataset);
    if ~exist(matchesSavePath0), mkdir(matchesSavePath0); end
    matchesSavePath = sprintf('%s/match%s_%d_%d_full',matchesSavePath0,detType,str2num(imgnoStr1),str2num(imgnoStr2));
    
    distThresh = 80;
    tic; %getSSDBlock
    szFeat = size(f1,1);
    parfor hari=1:szFeat
        [~, ~,matchC{hari}] = matchDescriptorsSept2(f1,f2,hari,regions,maskSzs,boundarys,scs,topLefts,....
            detType,imgPath1,imgPath2,matchesSavePath,distThresh,1); %matches{pNo}
    end
    matchMat = cell2mat(matchC');
    featMatch1 = f1(matchMat(:,1),:);
    featMatch2 = f2(matchMat(:,2),:);
    
    tMatch=toc;
    fprintf('is %f',tMatch);
    if 0
        figure, imshow(imgPath1),hold on;showellipticfeaturesSPL(f1);
        figure, imshow(imgPath2),hold on;showellipticfeaturesSPL(f2);
        
        num1 = round(rand(1)*200); num2 = round(rand(1)*200)
        figure(num1), imshow(imgPath1), figure(num2), imshow(imgPath2),
        for i=1:size(featMatch1,1)
            color = rand(1,3);
            figure(num1), hold on; showellipticfeaturesSPL(featMatch1(i,:),color);
            figure(num2), hold on; showellipticfeaturesSPL(featMatch2(i,:),color);
        end
        debugNonMatchingPts(f1,f2,detPtsNoDupDes1,detPtsNoDupDes2,imgPath1,imgPath2)
    end
    if dSetNo==4
        [matching_score,nb_of_matches] = getGtMatches(featMatch1,featMatch2,resizeFactorPts,dataset,imgPath1,imgPath2,f1Im1);
        nb_of_matchesD4 = size(featMatch1,1);
        matching_scoreD4 = (nb_of_matchesD4/size(f1,1))*100; %We check that given point in the first image, does it occur in the second. Different from calculation for mosaicing in oxford, where it is reverse
        fprintf('& %.1f & %.1f &  %.1f \n',matching_score(1),matching_score(2),matching_score(3))
        fprintf('& %.1f & %.1f &  %.1f \n',nb_of_matches(1),nb_of_matches(2),nb_of_matches(3))
    else
        nb_of_matches = size(featMatch1,1);
        matching_score = (nb_of_matches/size(f1,1))*100; %We check that given point in the first image, does it occur in the second. Different from calculation for mosaicing in oxford, where it is reverse
    end
end
% end
end

function [feat nb dim]=loadFeatures(file)
fid = fopen(file, 'r');
dim=fscanf(fid, '%f',1);
if dim==1
    dim=0;
end
nb=fscanf(fid, '%d',1);
feat = fscanf(fid, '%f', [5+dim, inf]);
fclose(fid);
end
