function valAll = printTableRep(datasets,detTypes,valToPrint,dSetNoComp)
numIndex = 1; ifgraph=1;

valAll = cell(1,length(detTypes));
sumDet = zeros(3,length(detTypes));
for d1=1:length(datasets)
  dset = datasets{d1};
  dSetNo = getParamsAndDataset(dset);
  if dSetNo == dSetNoComp %|| dSetNo == 2
    fprintf('%s',dset);
    if dSetNo== 1 || dSetNo== 8 %|| dSetNo == 3 %|| dSetNo==1 || dSetNo== 2 %|| dSetNo== 6 %|| dSetNo== 6 %|| dSetNo==4 %dSetNo==1 || dSetNo== 2 || dSetNo== 6 %~(strcmp(dset,'boxx') || strcmp(dset,'doll'))%
      for b=1:3
        for det=1:length(detTypes)
          sumDet(b,det) = sumDet(b,det) + valToPrint{d1}{1}{det}(numIndex); % end
        end
      end
      
    end
  end
end
sumDet = sumDet./length(datasets);
fprintf('Total');
for det=1:length(detTypes)
  fprintf('& %.1f ',sumDet(det)); %mScoreNFrameDet{b+1}{det},mScoreNFrameDet{b+2}{det}
end