function op_posallarray = writeToFileTestForDesc(detPtsFile,posallarray,granularity,xsize,ysize,adaptScaleFlag,t,otherDetector)
if nargin < 8
    otherDetector = 0;
end

if otherDetector
   numCols = 5;
else
    numCols =7;
end
   
commonVar = globalVariables(t);

if isempty(posallarray)
    %         disp('posallarray is empty');
    op_posallarray=[];
else
    posallarray=posallarray./granularity;
    [u v]=find(posallarray(:,2)<=1 |posallarray(:,1)<=1 | posallarray(:,2)>=ysize | posallarray(:,1)>=xsize);
    posallarray(u,:)=[];
    
    op_posallarray = [];
    op_posallarray(:,1:2)=posallarray(:,1:2);
    if adaptScaleFlag
        for i=1:size(posallarray,1) %needs change
            
            sigroot=[posallarray(i,4) posallarray(i,5);posallarray(i,6) posallarray(i,7)]^(1/2);
            sigmatrix=sigroot'*sigroot;
            sigmatrix=reshape(sigmatrix,1,4);
            
            op_posallarray(i,3)=sigmatrix(1,1).*(1./(posallarray(i,3).^2));
            op_posallarray(i,4)=sigmatrix(1,2).*(1./(posallarray(i,3).^2));
            op_posallarray(i,5)=sigmatrix(1,4).*(1./(posallarray(i,3).^2));
            
        end
        
        %             op_posallarray(i,7)= posallarray(i,8);
        %             op_posallarray(i,8)= posallarray(i,end);
    else
        op_posallarray(:,3:numCols)=posallarray(:,3:end);
    end
    
end
numFieldsDetPts = size(op_posallarray,2);


initial=[1.0; size(op_posallarray,1)]; %numFieldsDetPts];
fid = fopen(detPtsFile, 'wt');
fprintf(fid, '%1.1f\n%d\n%d\n', initial);
fprintf(fid, '%3.2f %3.2f %3.7f %3.7f %3.7f\n', op_posallarray(:,1:5)'); %%3.7f %3.7f

fclose(fid);
