/*--------------------------------------------------------------------------*/
/* Copyright 2006, Jiri Matas & Michal Perdoch       matas@cmp.felk.cvut.cz */
/*--------------------------------------------------------------------------*/

// #include<mexutils.c>
#include <mex.h>
#include "libExtrema.h"
#include <../optionGM/optionGM.h>
#include <../optionGM/optionPriv.h>
#include <../imageutls/imageread.h>
#include <../utls/timeutls.h>
#include "boundary.h"
#include "preprocess.h"
#include "suballoc.h"
#include "sortPixels.h"
#include "optThresh.h"
#include "getExtrema.h"
#include <stdio.h>
#include <iostream>
#define MAX_PATH_LEN 1024

#ifdef WIN32
#define snprintf _snprintf
#endif

using namespace extrema;

void mexFunction(int nout, mxArray *out1[], int nin, const mxArray *in[])
{
	enum {IN_I=0, IN_PARAMS, IN_DELTA};
	//enum {OUT_REGIONS_P=0, OUT_REGIONS_M, OUT_VARIATION_P,OUT_VARIATION_M} ; //OUT_BOUND_P=0, OUT_BOUND_M,
	enum {OUT_REGIONS=0, OUT_VARIATION, OUT_PLUS_OR_MINUS}; //OUT_TEMP OUT_BOUND_P=0, OUT_BOUND_M,
	
	//cout << "Here 1" << endl;

	ExtremaParams p; int rep_count,i;
	int bi,bj;
	double *iter_pt;
	double delta = mxGetScalar(in[IN_DELTA]) ;
	/*  replace by default values */
	//char *image_fname = "img1.ppm";
	double scale_factor = 1.0; //OptionDouble("es", 1.0, "ellipse scale, (output types 2 and 4)");
	scale_factor = scale_factor * 2; /* compensate covariance matrix */
	p.preprocess = 0; //OptionInt("pre", 0, "image preprocessing type");
	p.max_area = 0.9; //OptionDouble("per", 0.01, "maximum relative area");
	p.min_margin = delta; //OptionInt("mm", 10, "minimum margin");
	//     printf("delta: %f\n",p.min_margin);

	p.relative = 0; //OptionToggle("rel", 0, "use relative margins")!=0;
	p.verbose = 0; //OptionToggle("v", 0, "verbose output");
	p.debug = 0; //OptionInt("d", 0, "debug outputs");
	rep_count = 1; //OptionInt("r", 1, "number of runs (for timing purposes)");
	int output_type = 1; //OptionInt("t", 0, "output file type 0 - RLE, 1 - ExtBound., 2 - Ellipse, 3 - GF, 4 - Aff.\n");
	//     vector <BoundaryRegion> boundary_vector_plus, boundary_vector_minus;
	vector <RLERegion> rle_vector_plus, rle_vector_minus ;
	//vector <BoundaryRegion> be_vector_plus, be_vector_minus ;

	unsigned char * I_pt; //input has to be in the following format: R G B values of each pixel picked column-wise in the img array- after imread
	double *imgdim, *pt, *pt_temp, *ptstrength, *ptplusorminus;
	//     mxArray    *boundFinal,
	mxArray *regionFinal, *strength;// *regionTemp;
	int bdims[2], bdims2[2], bndims, bndims2, nel, dims[3];
	const char *classcheck;

	I_pt  = (unsigned char *)mxGetData(in[IN_I]) ;
	
	imgdim = mxGetPr(in[IN_PARAMS]) ;
	for(i=0; i<3; ++i) {
		dims[i] = *imgdim++;
	}
	
	//cout << "Here 2" << endl;
	ExtremaImage im;
	im.data = I_pt;
	im.width = dims[1]; im.height = dims[0]; im.channels = dims[2];
	p.pwidth = dims[1]; p.pheight = dims[0];

		
	FILE* f = fopen("/home/santhosh/Desktop/file2.txt", "w");
	for(int iteri=0; iteri < im.height; iteri++)
	{
		for(int iterj=0; iterj < im.width; iterj++)
		{
			fprintf(f, "%d ", (int)I_pt[iteri + iterj*im.height]);
		}
		fprintf(f, "\n");
	}
	fclose(f);
	

	p.min_size = p.pwidth*3;

	if (!p.preprocess)
	{
		if (im.channels<2)
			p.preprocess = PREPROCESS_CHANNEL_none; //must check how this behaves for grayscale image
		else
			p.preprocess = PREPROCESS_CHANNEL_intensity;
	}

	bndims = 2;
	bndims2 = 2;
	// region values
	
	//cout << "Here 2.1" << endl;

	RLEExtrema resultRLE;
	//BoundaryExtrema resultBE;

	resultRLE = getRLEExtrema(p, im);
	rle_vector_plus = resultRLE.MSERplus;
	rle_vector_minus = resultRLE.MSERmin;
	
	//resultBE = getBoundaryExtrema(p, im);
	//be_vector_plus = resultBE.MSERplus;
	//sort(be_vector_plus.begin(), be_vector_plus.end());
	//be_vector_minus = resultBE.MSERmin;
	//sort(be_vector_minus.begin(), be_vector_minus.end());

	//cout << "Here 2.2" << endl;
	bdims[0] = 1; bdims[1] = rle_vector_plus.size()+rle_vector_minus.size();
	//bdims2[0] = 1; bdims2[1] = be_vector_plus.size()+be_vector_minus.size();
	//cout << "Here 3" << endl;

	out1[OUT_REGIONS] = mxCreateCellArray(bndims, bdims);
	//out1[OUT_TEMP] = mxCreateCellArray(bndims, bdims);
	//out1[OUT_BE] = mxCreateCellArray(bndims2, bdims2);
	out1[OUT_VARIATION] = mxCreateDoubleMatrix(2,rle_vector_plus.size()+rle_vector_minus.size(),mxREAL);
	ptstrength = mxGetPr(out1[OUT_VARIATION]) ;
	out1[OUT_PLUS_OR_MINUS] = mxCreateDoubleMatrix(1,rle_vector_plus.size()+rle_vector_minus.size(),mxREAL);
	ptplusorminus = mxGetPr(out1[OUT_PLUS_OR_MINUS]);
	//cout << "Here 4" << endl;

	//Implementing decodeRLE portion also here
	for(bi=0; bi < rle_vector_plus.size(); bi++)
	{
		const RLERegion *r = &rle_vector_plus[bi];
		
		int size1 = 0;

		double runLen;
		int count = 0;
		int iter_beg = 0, iter_end;

		for (bj=0; bj<r->rle.size(); bj++) {
			size1 += r->rle[bj].col2 - r->rle[bj].col1 + 1;
			runLen = r->rle[bj].col2 - r->rle[bj].col1 + 1;
			iter_end = iter_beg + runLen - 1;
			
			//*pt_temp++ = r->rle[bj].line;
			//*pt_temp++ = r->rle[bj].col1;
			//*pt_temp++ = r->rle[bj].col2;
			
			for(int jter=iter_beg; jter<=iter_end; jter++)
			{
				if(r->rle[bj].line+1 <= 0 || r->rle[bj].col1 + jter - iter_beg + 1 <= 0)
				{
					count++;
				}
			}
			iter_beg = iter_end+1;
		}
		
		regionFinal = mxCreateDoubleMatrix(2, size1-count, mxREAL);
		//regionTemp = mxCreateDoubleMatrix(3, r->rle.size(), mxREAL);
		
		pt =  mxGetPr(regionFinal);
		//pt_temp = mxGetPr(regionTemp);

		iter_beg = 0; iter_end = 0;
		for(bj=0; bj<r->rle.size(); bj++) {
			runLen = r->rle[bj].col2 - r->rle[bj].col1 + 1;
			iter_end = iter_beg + runLen - 1;
			
			//*pt_temp++ = r->rle[bj].line;
			//*pt_temp++ = r->rle[bj].col1;
			//*pt_temp++ = r->rle[bj].col2;
			
			for(int jter=iter_beg; jter<=iter_end; jter++)
			{

				if(!(r->rle[bj].line+1 <= 0 || r->rle[bj].col1 + jter - iter_beg + 1 <= 0))
				{
					*pt++ = r->rle[bj].line + 1;
					*pt++ = r->rle[bj].col1 + jter - iter_beg + 1;
				}
			}
			iter_beg = iter_end+1;
		}

		mxSetCell(out1[OUT_REGIONS], bi, mxDuplicateArray(regionFinal));
		//mxSetCell(out1[OUT_TEMP], bi, mxDuplicateArray(regionTemp));

		*ptstrength++ = r->margin;
		*ptstrength++ = r->threshold;
		*ptplusorminus++ = 1;
	}

	//cout << "Here 5" << endl;

	for(bi=rle_vector_plus.size(); bi < rle_vector_plus.size()+rle_vector_minus.size(); bi++)
	{
		const RLERegion *r = &rle_vector_minus[bi-rle_vector_plus.size()];
		
		int size1 = 0;
		int iter_beg = 0, iter_end;
		double runLen;
		int count = 0;	
		for (bj=0; bj<r->rle.size(); bj++) {
			size1 += r->rle[bj].col2 - r->rle[bj].col1 + 1;
			runLen = r->rle[bj].col2 - r->rle[bj].col1 + 1;
			iter_end = iter_beg + runLen - 1;
			
			for(int jter=iter_beg; jter<=iter_end; jter++)
			{
				if(r->rle[bj].line+1 <= 0 || r->rle[bj].col1 + jter - iter_beg + 1 <= 0)
				{
					count++;
				}
			}
			iter_beg = iter_end+1;
		}
		
		regionFinal = mxCreateDoubleMatrix(2, size1-count, mxREAL);
		//regionTemp = mxCreateDoubleMatrix(3, r->rle.size(), mxREAL);

		pt =  mxGetPr(regionFinal);
		//pt_temp = mxGetPr(regionTemp);

		iter_beg = 0; iter_end = 0;
		for(bj=0; bj<r->rle.size(); bj++) {
			runLen = r->rle[bj].col2 - r->rle[bj].col1 + 1;
			iter_end = iter_beg + runLen - 1;
			
			//*pt_temp++ = r->rle[bj].line;
			//*pt_temp++ = r->rle[bj].col1;
			//*pt_temp++ = r->rle[bj].col2;

			for(int jter=iter_beg; jter<=iter_end; jter++)
			{
				if(!(r->rle[bj].line+1 <= 0 || r->rle[bj].col1 + jter - iter_beg + 1 <= 0))
				{
					*pt++ = r->rle[bj].line + 1;
					*pt++ = r->rle[bj].col1 + jter - iter_beg + 1;
				}
			}
			iter_beg = iter_end+1;
		}
		
		
		mxSetCell(out1[OUT_REGIONS], bi, mxDuplicateArray(regionFinal));
		//mxSetCell(out1[OUT_TEMP], bi, mxDuplicateArray(regionTemp));

		*ptstrength++ = r->margin;
		*ptstrength++ = r->threshold;
		*ptplusorminus++ = 0;
	}
	/*
	for(bi = 0; bi < be_vector_plus.size(); bi++)
	{
		const BoundaryRegion *r = &be_vector_plus[bi];
		regionFinal = mxCreateDoubleMatrix(2, r->boundary.size(), mxREAL);
	
		pt =  mxGetPr(regionFinal);
		
		for(bj = 0; bj<r->boundary.size(); bj++)
		{
			*pt++ = r->boundary[bj].col;
			*pt++ = r->boundary[bj].line;
		}

		mxSetCell(out1[OUT_BE], bi, mxDuplicateArray(regionFinal));
	}

	for(bi = be_vector_plus.size(); bi < be_vector_plus.size()+be_vector_minus.size(); bi++)
	{
		const BoundaryRegion *r = &be_vector_minus[bi-be_vector_plus.size()];
		regionFinal = mxCreateDoubleMatrix(2, r->boundary.size(), mxREAL);

		pt = mxGetPr(regionFinal);

		for(bj = 0; bj < r->boundary.size(); bj++)
		{
			*pt++ = r->boundary[bj].line;
			*pt++ = r->boundary[bj].col;
		}

		mxSetCell(out1[OUT_BE], bi, mxDuplicateArray(regionFinal));
	}*/

	//cout << "Here 6" << endl;
}
