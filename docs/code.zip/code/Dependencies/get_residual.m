function res = get_residual(x1,x2,F)
d_x2_Fx1 = get_D_point_line(x2,F*x1); d_x1_Fx2 = get_D_point_line(x1,F'*x2);
res = sqrt(d_x2_Fx1.^2 + d_x1_Fx2.^2);
end

% function d = get_D_point_line(X1,Lp2)
% computes the distance of points X1 (homogeneous coordinates) to the lines
% Lp2. 
function d = get_D_point_line(X1,Lp2)
if sum(X1(3,:)~=1), error('the points are assumed to be normalized (last dimension = 1)'); end
d = abs(sum(X1 .* Lp2,1))./sqrt(sum(Lp2(1:2,:).^2));
end
