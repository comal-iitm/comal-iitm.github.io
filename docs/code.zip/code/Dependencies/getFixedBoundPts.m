function boundaryPart =  getFixedBoundPts(boundary,cornerWrtBlock,circFlag)
windowWidth = floor(cornerWrtBlock(1,3)*2.2); %check this before

boundaryPart=[];
if size(cornerWrtBlock,2)< 8
  [closeVal,indClose] = closestPt([cornerWrtBlock(2) cornerWrtBlock(1)],boundary);
else
  indClose = cornerWrtBlock(8);
end

bLeft = indClose-windowWidth; bRight = indClose+windowWidth;
boundaryL=[]; boundaryR=[];

if bRight>size(boundary,1)
  if circFlag && bRight < 2*size(boundary,1)
    boundaryR = boundary(1:bRight - size(boundary,1),:);
    bRight = size(boundary,1);
  else
    bRight = size(boundary,1);
  end
end

if bLeft<1
  if circFlag && abs(bLeft)<size(boundary,1)
    boundaryL = boundary(size(boundary,1)-abs(bLeft):end,:);
    bLeft=1;
  else
    bLeft=1;
  end
end

boundaryPart = [boundaryL; boundary(bLeft:bRight,:); boundaryR];
