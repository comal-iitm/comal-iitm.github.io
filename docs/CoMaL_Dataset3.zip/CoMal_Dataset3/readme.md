Please use the images in the background-images folder to perform the background subtraction and the object boundary.

These images have been resized at 50% lesser resolution. Please email me at swarnakr@cs.duke.edu if you want the full size images.
