function getThreshFg(xyCoord,dataset,imgnoStr,dilVal,fgType)

dirData='../images'; imext='.ppm';
imgPath = fullfile(dirData,dataset,sprintf('img%s.ppm',imgnoStr));
bbInit = [180 90 520 565];

dSetNo = getParamsAndDataset(dset);
img=imread(imgPath);
[imX,imY,third] = size(img);
imBinary = zeros(imX,imY);

left = bbInit(1); top = bbInit(2); wid = bbInit(3); ht = bbInit(4);
if 0
    hFig = figure; imshow(img);
    rectangle('Position',bbInit);
    imgSave1 = sprintf('../bb/%s',dset);
    imgSave = sprintf('../bb/%s/img%s.ppm',dset,imgnoStr);
    if ~exist('imgSave1','dir')
        mkdir(imgSave1);
    end
    saveas(hFig,imgSave);
    close all;
end
if 1
    imgGray = rgb2gray(img); szImg = size(imgGray);
    if 0
        imgBinary = zeros(szImg(1),szImg(2));
        indValid = find(imgGray<170 & imgGray>100);
        imgBinary(indValid)=1;
        %                 imgBinary = 1-imgBinary;
        figure, imshow(imgBinary);
        imgBinaryCut(top:top+ht,left:left+wid,:) = imgBinary(top:top+ht,left:left+wid,:);
        figure, imshow(imgBinary);
    end
    thresh = graythresh(imgGray);
    fgBinary1 = im2bw(imgGray,thresh);
    figure, imshow(fgBinary1);
    imgBinary = 1 - imgBinary;
    imgBinaryCut(top:top+ht,left:left+wid,:) = imgBinary(top:top+ht,left:left+wid,:);
    figure, imshow(imgBinary);
    
    %             imgGray = 255-imgGray;
    %             thresh = graythresh(imgGray);
    %             fgBinary2 = im2bw(imgGray,thresh);
    %             figure, imshow(fgBinary2);
    %             fgBinary = 1 - fgBinary;
    
    se = strel('disk',40); fgBinaryDil = imdilate(imgBinaryCut,se);
    figure, imshow(fgBinaryDil);
end
end
%do setdiff on Fg
%run bw boundary on this and give several levels of FgType
%run for loop through dilVal