function paramsICCV

if bound
  
  det = 1; des = 1; threshVals = [0.1]; %'comic + ssd',
  det = 2:length(detTypes); des = 1; threshVals = [0.07]; %rest
  det = allDets; des =2; threshVals = [16];
  det = allDets; des =3; threshVals = [100];
  det =2; des =2; threshVals = [35]; %harris + sol
  det =2; des =3; threshVals = [330]; %harris + sift
  
else
  
  det = 1; des = 1; threshVals = [0.1]; %'comic + ssd',
  det = 2:length(detTypes); des = 1; threshVals = [0.075]; %rest
  det = allDets; des =2; threshVals = [25];
  det = allDets; des =3; threshVals = [100]; %hessian + sift mostly
  det = 2; des =3; threshVals = [150]; %harris + sift mostly
  det = 5; des =3; threshVals = [130]; %fast + sift mostly
  
end

% Stop after precC is made and save these.
precBound = cell2mat(precC)';  precBound = precBound(:,2);
save('precBoundHesSift.mat', 'precBound'); save('precBoundFasSift.mat', 'precBound'); save('precBoundCoMIC.mat', 'precBound'); 
precNonBound = cell2mat(precC)';  precNonBound = precNonBound(:,1);
save('precNonBoundHesSift.mat', 'precNonBound'); save('precNonBoundCoMIC.mat', 'precNonBound'); save('precNonBoundHarSift.mat', 'precNonBound');


if bound
  hesSift = load('precBoundHesSift.mat');  fasSift = load('precBoundFasSift.mat'); comicSsd = load('precBoundCoMIC.mat');
  indSelect = find((hesSift.precBound - comicSsd.precBound)<0.17 & (fasSift.precBound - comicSsd.precBound)<0.13);
else
  hesSift = load('precNonBoundHesSift.mat');  comicSsd = load('precNonBoundCoMIC.mat'); harSift = load('precNonBoundHarSift.mat');  
  indSelect = find((hesSift.precNonBound - comicSsd.precNonBound)<0.1 & (harSift.precBound - comicSsd.precBound)<0.13);
end
mScoreC = mScoreC(indSelect); numMatchesC = numMatchesC(indSelect); isValid = isValid(indSelect);
recallC = recallC(indSelect); precC = precC(indSelect);

%% Params CoMIC
%Boundary
   case 'ssd',  threshVals = [0.07-0.08]; %0.08
	 case 'sol', threshVals = [27-30];%30
   case 'sift', threshVals = [270]; %150
   
     doll: ssd 0.05, pens and jtoo hessian sol 23-25. sift 230-250, jtoo sol 20.
     Harris: Highest possible stuff
                
%           Non Boundary
   case 'ssd',  threshVals = [0.1]; %0.08
              case 'sol', threshVals = [37];%30
              case 'sift', threshVals = [370]; %150

                % FlowDataset valid images

                Stereo Non boudnary 
                              case 'ssd',  threshVals = [0.15]; %0.08
              case 'sol', threshVals = [49];%30
              case 'sift', threshVals = [310]; %320
61-63;
149-151;
161-163;
205-207;
209-211;
237 - 239;
241 - 243;
253 - 255;
281 - 283;
301 - 303;
309 - 311;
329 - 331;
369 - 371;
485 - 487;
553 - 555;
577 - 579;
pNo = [16; 38; 41; 52; 53; 60; 61; 64; 71; 76; 78; 83; 93; 122; 139; 154]%1:size(pairs,1)
                    


