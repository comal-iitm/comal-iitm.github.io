function [featMatch1Final featMatch2Final matchFinal] = matchDescriptorsSept2(f1,f2,regions,maskSzs,boundarys,scs,topLefts,detType,img1,img2,matchesSavePath,distThresh)

threshSSD = 0.2; largeNum = 5000; szBlock = 23; numShifts = 2; % 1 for othersthreshSSD = 0.05;
img{1} = img1; img{2} = img2;
szFeat1 = size(f1,1); szFeat2 = size(f2,1); ssdVals = cell(szFeat1,1);match = cell(szFeat1,1); ssdVals =  largeNum*ones(szFeat1,1);

matchMat = 100*ones(szFeat1,szFeat2);
matchFinal=[];featMatch1Final=[]; featMatch2Final=[];
image1 = double(imread(img{1}))*(1/255);    image2 = double(imread(img{2}))*(1/255);
for i = 1 : szFeat1 % send in ind, and loop for i=ind for tsuk etc
    %% search for point
    indCloseSSD=[];ssdVal=[];
    [distVals ,indClose] = closestPt(f1(i,:), f2,1,min(round(distThresh*1.5),size(f2,1)));
    ind0 = find(distVals < distThresh); indClose = indClose(ind0);
    corsClose = f2(indClose,:);
    if 0
      figure, imshow(image1), hold on, plot(f1(i,1),f1(i,2),'*g');
      figure, imshow(image2), hold on, plot(corsClose(:,1),corsClose(:,2),'*g');
    end
    if strcmp(detType,'harronmser')
        %% first mask
        f1InBlock = f1(i,1:2) - [topLefts{1}{i}(2) topLefts{1}{i}(1)]+ 1;
        template1 = getTemplate(image1,f1(i,:),szBlock,numShifts);
        mask0 = zeros(maskSzs{1}{i}); mask0(regions{1}{i})=1;
        mask1{1} = getTemplate(mask0,f1InBlock,szBlock,numShifts);
        mask1{2} = getTemplate(1-mask0,f1InBlock,szBlock,numShifts);
        selCut1{1} = find(mask1{1}); selCut1{2} = find(mask1{2});
        
        mask2 = cell(1,szFeat2); selCut2 = cell(1,szFeat2);template2=cell(1,szFeat2);
        for j=1:length(indClose)
            %% second mask
            if isempty(selCut2{indClose(j)})
                f2InBlock = corsClose(j,1:2) - [topLefts{2}{indClose(j)}(2) topLefts{2}{indClose(j)}(1)] + 1;
                mask0 = zeros(maskSzs{2}{indClose(j)}); mask0(regions{2}{indClose(j)})=1;
                mask20{1} = getTemplate(mask0,f2InBlock,szBlock,numShifts);
                mask20{2} = getTemplate(1-mask0,f2InBlock,szBlock,numShifts);
                selCut20{1} = find(mask20{1}); selCut20{2} = find(mask20{2});
                selCut2{indClose(j)} = selCut20;
                mask2{indClose(j)} = mask20;
            end
        end
        
        combs = [1 1; 1 2; 2 1; 2 2];ssdComb=largeNum*ones(1,4);indComb=zeros(1,4);
        for c=1:size(combs,1) %four combinations of masks
            ssdVal = largeNum*ones(length(indClose),1); areaDiff = largeNum*ones(length(indClose),1);
            for j=1:length(indClose)
                minLengthRegion = max(length(selCut1{combs(c,1)}),length(selCut2{indClose(j)}{combs(c,2)}));
                areaDiffSamp = length(setxor(selCut1{combs(c,1)},selCut2{indClose(j)}{combs(c,2)}));
                sc_cost0 = getbestMatch(scs{1}{i},scs{2}{indClose(j)});
                if areaDiffSamp < 0.6*minLengthRegion% && sc_cost0 < 0.25
                    areaDiff(j) = areaDiffSamp;
                end
            end
            [areaLeastVal aLInd] = sort(areaDiff);
            
            for least=1:min(4,length(indClose))%
                if areaLeastVal(least) < largeNum %areaLeastVal
                    templates{1} = template1;
                    if isempty(template2{indClose(aLInd(least))})
                        template2{indClose(aLInd(least))} = getTemplate(image2,corsClose(aLInd(least),:),szBlock,numShifts);
                    end
                    templates{2} = template2{indClose(aLInd(least))};
                    masksComb{1} = mask1{combs(c,1)}; masksComb{2} = mask2{indClose(aLInd(least))}{combs(c,2)};
                    try
                    ssdVal(aLInd(least)) = AlignGetSSDFinal(templates,masksComb,numShifts);
                    catch
                    ssdVal(aLInd(least)) = 5000;
                    end
                end
            end
            if ~isempty(ssdVal)
                [ssdVal indCloseSSD] = sort(ssdVal);
                if ssdVal(1) < threshSSD
                    ssdComb(c) = ssdVal(1); indComb(c) = indClose(indCloseSSD(1));
                end
            end            
        end
        if ~isempty(ssdComb)
            [minSSD minIndC] = min(ssdComb); %get best side from c2;
            if minSSD < largeNum
                ind2Final = indComb(minIndC);
                match{i} = [i ind2Final minIndC];
            end
        end
        %         if ~strcmp(detType,'harronmser') matchMat(i,ind2Final) = minSSD;end for one-one matching
    else
        numShifts = 1;
        template1 = getTemplate(image1,f1(i,:),szBlock,numShifts);
        template2=cell(1,szFeat2);ssdVal = largeNum*ones(length(indClose),1);
        for j=1:length(indClose)
            if isempty(template2{indClose(j)})
                template2{indClose(j)} = getTemplate(image2,corsClose(j,:),szBlock,numShifts);
            end
            try
            ssdVal(j) = AlignGetSSD2(template1,template2{indClose(j)},numShifts); %minShiftError/length(selCutRGBMain); %sum(I_error)
            catch
              ssdVal(j) = 5000;
            end
        end
        if ~isempty(ssdVal)
            [minSSD minIndC] = min(ssdVal);
            if minSSD < threshSSD %& minInd==i
                ind2Final = indClose(minIndC);
                match{i} = [i ind2Final];
            end
        end
        
    end
end

% %one-to-one
% if ~isempty(matchFinal)
%     matchMatF = zeros(size(des1,1),size(des2,1));
%     minVal = 0;
%     while 1
%         minValNew  = min(min(matchMat));
%         if minValNew >= 100
%             break;
%         end
%         [mini minj] = find(matchMat==minValNew);
%         matchMat(mini,:) = 100;
%         matchMat(:,minj) = 100;
%         matchMatF(mini(1),minj(1)) = minValNew;
%         minVal = minValNew;
%     end
%     [fx fy] = find(matchMatF>0);
%     [~, del] = setdiff(matchFinal(:,1:2),[fx fy],'rows');
%     matchFinal(del,:)=[];
%
%     featMatch1Final = f1(matchFinal(:,1),:);
%     featMatch2Final = f2(matchFinal(:,2),:);
% end
matchFinal = cell2mat(match);

if ~isempty(matchFinal)
    featMatch1Final = f1(matchFinal(:,1),:);
    featMatch2Final = f2(matchFinal(:,2),:);
end
save(matchesSavePath,'matchFinal'); % for tsuk don't save

if 0
    figure, imshow(img1), hold on; showellipticfeaturesSPL(featMatch1Final);
    figure, imshow(img2), hold on; showellipticfeaturesSPL(featMatch2Final);
end

end



function idxCorrected = IndDetType(detType,idx)
if strcmp(detType,'harronmser')
    idxCorrected = ceil(idx./2);
else
    idxCorrected = idx;
end

end