function getDispThreshKitti
dirData = '../../images1'; %'../../imagesOrigSize';
imext = '.png'; %'png', 'ppm' and 'jpg'
Tuples = getTuples(dirData,imext);

[datasets indUnique] = unique(Tuples(:,1));

for i=1:indUnique
    filename = sprintf('%s/%s/%s',dirData,Tuples{1,1},Tuples{i,2});
    dispImg = disparity_read(filename);
    maxDisp(i) = max(max(dispImg(dispImg>-1)));
end

val = max(maxDisp);