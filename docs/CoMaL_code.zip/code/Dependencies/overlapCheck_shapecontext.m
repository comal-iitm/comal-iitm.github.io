function [FinalFeat f1Init ind select desFinal meanDistAll regionsFinal blockSzFinal topLeftFinal plusOrMinusFinal boundaryFinal boundaryLocalAll] = overlapCheck(f1Init,szImage,lcsBasedOverErr,regionsFinal,blockSzFinal,topLeftFinal,plusOrMinusFinal,boundaryFinal, imgNo,nonLcsBasedOverErr,datastring)

commonVar  = globalVariables(imgNo);
if ~exist('nonLcsBasedOverErr','var');
    nonLcsBasedOverErr = lcsBasedOverErr;
    lcsBased = 0;
else
    lcsBased = 1;
end


H=[1 0 0; 0 1 0; 0 0 1];
common_part=1;
select=[]; areaDiffWtd=[]; weightsSum = [];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% allocate vectors for the features
s1 = size(f1Init,2);
for i=1:s1
    sizeCol(i) = 1/(f1Init(3,i).^2);
end

f1 = [f1Init(1:2,:); sizeCol; zeros(1,s1); sizeCol];

feat1(1:5,1:s1)=f1(1:5,1:s1);
[feat1, ~, ~]=project_regions(feat1',H);
strengthMetric = f1Init(13,:); %use toggle distance
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if common_part==1
    im1x=szImage;
    im1y=im1x(1);
    im1x=im1x(2);
    feat1(:,10) = feat1(:,1)+feat1(:,8);
    feat1(:,11) = feat1(:,1)-feat1(:,8);
    feat1(:,12) = feat1(:,2)+feat1(:,9);
    feat1(:,13) = feat1(:,2)-feat1(:,9);
    
    ind=find((feat1(:,1)+feat1(:,8))<im1x & (feat1(:,1)-feat1(:,8))>0 & (feat1(:,2)+feat1(:,9))<im1y & (feat1(:,2)-feat1(:,9))>0);
    FinalFeat=feat1(ind,:)';
    f1Init = f1Init(:,ind);
    strengthMetric = strengthMetric(ind);
end

enter=20;
% while enter > 10
enter= 0; FinalFeatReplace=[];
s1 = size(FinalFeat,2);
[FinalFeat, ~, ~]=project_regions(FinalFeat',H);
FinalFeat(:,10) = FinalFeat(:,1)+FinalFeat(:,8); FinalFeat(:,11) = FinalFeat(:,1)-FinalFeat(:,8);
FinalFeat(:,12) = FinalFeat(:,2)+FinalFeat(:,9); FinalFeat(:,13) = FinalFeat(:,2)-FinalFeat(:,9);
FinalFeat = FinalFeat';
valid = ones(s1,1);
if 1
    for partIdx = 1:s1
        if valid(partIdx) % for useAverage they wud all be the same
            feat1Part = FinalFeat(:,partIdx);
            feat2tPart = FinalFeat;
            [~, twout, ~, ~]=c_eoverlap(feat1Part,feat2tPart,common_part);
            twout(partIdx) = 100;
            dupIdx = find(twout<=lcsBasedOverErr & twout>=0);
            if ~isempty(dupIdx)
                for i=1:size(dupIdx,1)
                    if lcsBased %temp
                        selCutP = regionsFinal{partIdx};
                        selCutD = regionsFinal{dupIdx(i)};
                        
                        szP1 = blockSzFinal(partIdx,1); szP2 = blockSzFinal(partIdx,2);
                        szD1 = blockSzFinal(dupIdx(i),1); szD2 = blockSzFinal(dupIdx(i),2);
                        
                        
                        if ~isequal(blockSzFinal(partIdx,:),blockSzFinal(dupIdx(i),:))
                            topP = topLeftFinal(partIdx,1); leftP = topLeftFinal(partIdx,2);
                            bottomP = topP + (szP1-1); rightP = leftP + (szP2-1);
                            
                            topD = topLeftFinal(dupIdx(i),1); leftD = topLeftFinal(dupIdx(i),2);
                            bottomD = topD + (szD1-1); rightD = leftD + (szD2-1);
                            
                            %%
                            top = max(topP,topD);left = max(leftP,leftD);
                            bottom = min(bottomP,bottomD);right = min(rightP,rightD);
                            
                            topShiftP = top - topP;leftShiftP = left - leftP;
                            bottomShiftP = bottomP - bottom ;rightShiftP = rightP - right;
                            
                            topShiftD = top - topD;leftShiftD = left - leftD;
                            bottomShiftD = bottomD - bottom ; rightShiftD = rightD - right;
                            
                            %%
                            %resizing partIdx MSER
                            maskP0 = zeros(szP1, szP2); %bring both blocks to comparable form
                            maskP0(regionsFinal{partIdx}) = 1;
                            maskP = maskP0(1+topShiftP:end-bottomShiftP,1+leftShiftP:end-rightShiftP);
                            [rSelP cSelP] = find(maskP==1);
                            selCutP = uint32(sub2ind(size(maskP), rSelP, cSelP)); %maskDummy = zeros(sz1Cut,sz2Cut); maskDummy(selMainTrans) = 1; subplot(1,3,3), imshow(maskDummy);
                            
                            %resizing partIdx MSER
                            maskD0 = zeros(szD1, szD2); %bring both blocks to comparable form
                            maskD0(regionsFinal{dupIdx(i)}) = 1;
                            %                                     if ~isequal(plusOrMinusFinal(partIdx,:),plusOrMinusFinal(dupIdx(i),:))
                            %                                         maskD0 = 1 - maskD0;
                            %                                     end
                            maskD = maskD0(1+topShiftD:end-bottomShiftD,1+leftShiftD:end-rightShiftD);
                            [rSelD cSelD] = find(maskD==1);
                            [szD1 szD2] = size(maskD);
                            selCutD = uint32(sub2ind([szD1 szD2], rSelD, cSelD)); %maskDummy = zeros(sz1Cut,sz2Cut); maskDummy(selMainTrans) = 1; subplot(1,3,3), imshow(maskDummy);
                        end
                        
                        if ~isequal(plusOrMinusFinal(partIdx,:),plusOrMinusFinal(dupIdx(i),:))
                            allInd = 1:szD1*szD2;
                            selCutD = setdiff(allInd,selCutD);
                            maskD01 = zeros(szD1, szD2); %bring both blocks to comparable form
                            maskD01(selCutD) = 1;
                            [boundaryPts,connComp,numObjects] = bwboundaries(maskD01,'noholes');
                            if numObjects > 1
                                for numComp = 1:numObjects
                                    topD = topLeftFinal(dupIdx(i),1); leftD = topLeftFinal(dupIdx(i),2);
                                    feat1Dup = FinalFeat(:,dupIdx(i))';
                                    cornerInSubBlock = feat1Dup(1:2) - [leftD-1 topD-1];
                                    distToBdry(numComp) = closestPt([cornerInSubBlock(2) cornerInSubBlock(1)],boundaryPts{numComp});
                                end
                                [~,indMin] = min(distToBdry);
                                [rSel cSel] = find(connComp==indMin);
                            else
                                [rSel cSel] = find(maskD01==1);
                            end
                            selCutD = uint32(sub2ind(size(maskD01), rSel, cSel)); %maskDummy = zeros(sz1Cut,sz2Cut); maskDummy(selMainTrans) = 1; subplot(1,3,3), imshow(maskDummy);
                        end
                        if commonVar.displayflag
                            if ~(exist('maskD','var') & exist('maskP','var'))
                                maskD = zeros(szD1, szD2); %bring both blocks to comparable form
                                maskD(selCutD) = 1;
                                maskP = zeros(szP1, szP2); %bring both blocks to comparable form
                                maskP(selCutP) = 1;
                            end
                            figure;imshow(maskP); figure;imshow(maskD);
                            figure; imshow(maskP0); figure;imshow(maskD0);
                        end
                        
                        areaDiff = setxor(selCutP, selCutD);
                        areaDiffWtd= length(areaDiff);
                        if length(selCutP) < length(selCutD);
                            weightsSum = length(selCutD); %sum(gaussianKernel(selCutP)); %sum(sum(gaussianKernel));
                        else
                            weightsSum = length(selCutP); %sum(gaussianKernel(selCutD)); %sum(sum(gaussianKernel));
                        end
                    end
                    
                    sz1 = min(szP1,szD1); sz2 = min(szP2,szD2);
                    if (twout(dupIdx(i)) < nonLcsBasedOverErr || areaDiffWtd < 0.5*weightsSum) & areaDiffWtd <  0.3*(sz1*sz2) %|| areaDiffWtdOtherSide < 0.2*weightsSum %length(areaDiff) < 0.5*minRegionLen %if both points belong to the same level line
                        if (strengthMetric(partIdx) >= strengthMetric(dupIdx(i))) %(strengthMetric(partIdx) >= strengthMetric(dupIdx(i))) %also try area instead of strength
                            valid(dupIdx(i)) = 0;
                        else
                            valid(partIdx) = 0;
                        end
                        
                    else
                        if 0
                            disp(feat1Part);
                            disp(plusOrMinusFinal(partIdx,:)); disp(plusOrMinusFinal(dupIdx(i),:));
                            
                            maskD01 = zeros(szD1, szD2); %bring both blocks to comparable form
                            maskD01(selCutD) = 1;
                            maskP01 = zeros(szP1, szP2); %bring both blocks to comparable form
                            maskP01(selCutP) = 1;
                            figure, imshow(maskD01);figure, imshow(maskP01);
                        end
                    end
                end
                enter = 0;
            else
                FinalFeatReplace = [FinalFeatReplace FinalFeat(1:5,partIdx)];
            end
        end
    end
end
%%
select = find(valid == 1);
FinalFeatTemp = FinalFeat;
FinalFeat = [FinalFeat(1:5,select); strengthMetric(select)];
f1Init = f1Init(:,select);
f1Init(1:2,:) = FinalFeat(1:2,:) ; %why?

regionsFinal = regionsFinal(ind); regionsFinal = regionsFinal(select);
blockSzFinal = blockSzFinal(ind,:); blockSzFinal = blockSzFinal(select,:);
topLeftFinal = topLeftFinal(ind,:); topLeftFinal = topLeftFinal(select,:);
plusOrMinusFinal = plusOrMinusFinal(ind,:); plusOrMinusFinal = plusOrMinusFinal(select,:);
if ~isempty(boundaryFinal)
    boundaryFinal = boundaryFinal(ind,:); boundaryFinal = boundaryFinal(select,:);
end

desFinal=[];meanDistAll=[];boundaryLocalAll=[];
if exist('datastring','var')
    [FinalFeat indUnique indValid] = getBgSubtractedFeat(datastring, 'harronmser',imgNo,FinalFeat);
    f1Init = f1Init(:,indUnique); f1Init = f1Init(:,indValid);
    topLeftFinal = topLeftFinal(indUnique,:); %indValid for regionsFinal to boundaryFinal 
    topLeftFinal = topLeftFinal(indValid,:); %indValid for regionsFinal to boundaryFinal 
    boundaryFinal = boundaryFinal(indUnique,:); boundaryFinal = boundaryFinal(indValid,:);
    regionsFinal = regionsFinal(indUnique,:); regionsFinal = regionsFinal(indValid,:); 
    blockSzFinal = blockSzFinal(indUnique,:); blockSzFinal = blockSzFinal(indValid,:);

    for idx = 1: size(FinalFeat,2)
        %% Get block and blank it out
        boundaryFull = boundaryFinal{idx};
        top = topLeftFinal(idx,1); left = topLeftFinal(idx,2);
%         cornerIdx = f1Init(8,idx); %change to within indBlock
        if 0
            boundaryTrans(:,1:2) = boundaryFull(:,1:2) - repmat([top-1 left-1],50,1); % no need for this translation I think
        end
        %Checking
        distToBdry=[];cornerIdx=[];
        corner = FinalFeat(1:5,idx); %change to within indBlock
        cornerInSubBlock = corner;
        cornerInSubBlock(1:2) = corner(1:2) - [left-1 top-1]';
        
        [distToBdry, cornerIdx] = closestPt([corner(2) corner(1)],boundaryFull);
        if distToBdry > 1
            disp('Boundary not close to corner point');
        end
        try
        boundary = boundaryFull(max(1,cornerIdx-15):min(cornerIdx+15,size(boundaryFull,1)),:);
        catch
            aa=1;
        end
        [BH,mean_dist] = getShapeContext(boundary);
        desFinal{idx} = BH; meanDistAll(idx,1) = mean_dist;
        boundaryLocalAll{idx} = boundary;
        
    end
end

if commonVar.displayflag
    %all the possible masks
    szP1 = blockSzFinal(1,1); szP2 = blockSzFinal(1,2);
    for a=1:length(valid)
        mask0 = zeros(szP1,szP2);    %same size for both
        mask0(regionsFinal{a}) = 1;
        figure, imshow(mask0); hold on;
        
        topLeft = topLeftFinal(a,:);
        cor = FinalFeatTemp(1:2,a) - (topLeft(1:2)'-1);
        showellipticfeaturesSPL(cor);
        plot(cor(1),cor(2),'*');
    end
    %masks that are seleceted finally
    for a=1:length(select)
        mask0 = zeros(szP1,szP2);    %same size for both
        mask0(regionsFinal{select(a)}) = 1;
        figure, imshow(mask0); hold on;
        
        topLeft = topLeftFinal(select(a),:);
        cor = FinalFeatTemp(1:2,a) - (topLeft(1:2)'-1);
        showellipticfeaturesSPL(cor);
        plot(cor(1),cor(2),'*');
    end
    
    figure, imshow('../images/bike/img3.ppm');
    hold on, showellipticfeatures(f1Init',[1 0 0]);
    figure, imshow('../images/bike/img3.ppm');
    hold on, showellipticfeaturesSPL(FinalFeatReplace',[1 0 0]);
end


end

function [feat,featp,scales]=project_regions(feat,H)

s=size(feat);
s1=s(1);

featp=feat;
scales=zeros(1,s1);

for c1=1:s1,%%%%%%%%%%%%%%%%%
    %feat(c1,3:5)=(1/25)*feat(c1,3:5);
    
    Mi1=[feat(c1,3) feat(c1,4);feat(c1,4) feat(c1,5)];
    
    %compute affine transformation
    
    [v1 e1]=eig(Mi1);
    
    d1=(1/sqrt(e1(1)));
    d2=(1/sqrt(e1(4)));
    sc1=sqrt(d1*d2);
    feat(c1,6)=d1;
    feat(c1,7)=d2;
    scales(c1)=sqrt(feat(c1,6)*feat(c1,7));
    
    %bounding box
    feat(c1,8) = sqrt(feat(c1,5)/(feat(c1,3)*feat(c1,5) - feat(c1,4)^2));
    feat(c1,9) = sqrt(feat(c1,3)/(feat(c1,3)*feat(c1,5) - feat(c1,4)^2));
    
    
    Aff=getAff(feat(c1,1),feat(c1,2),sc1, H);
    
    %project to image 2
    l1=[feat(c1,1),feat(c1,2),1];
    l1_2=H*l1';
    l1_2=l1_2/l1_2(3);
    featp(c1,1)=l1_2(1);
    featp(c1,2)=l1_2(2);
    if det(Mi1)
        BMB=inv(Aff*inv(Mi1)*Aff');
        try
            [v1 e1]=eig(BMB);
        catch
            disp('Stop');
        end
        featp(c1,6)=(1/sqrt(e1(1)));
        featp(c1,7)=(1/sqrt(e1(4)));
        featp(c1,3:5)=[BMB(1) BMB(2) BMB(4)];
        %bounding box in image 2
        featp(c1,8) = sqrt(featp(c1,5)/(featp(c1,3)*featp(c1,5) - featp(c1,4)^2));
        featp(c1,9) = sqrt(featp(c1,3)/(featp(c1,3)*featp(c1,5) - featp(c1,4)^2));
    end
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function Aff=getAff(x,y,sc,H)
h11=H(1);
h12=H(4);
h13=H(7);
h21=H(2);
h22=H(5);
h23=H(8);
h31=H(3);
h32=H(6);
h33=H(9);
fxdx=h11/(h31*x + h32*y +h33) - (h11*x + h12*y +h13)*h31/(h31*x + h32*y +h33)^2;
fxdy=h12/(h31*x + h32*y +h33) - (h11*x + h12*y +h13)*h32/(h31*x + h32*y +h33)^2;

fydx=h21/(h31*x + h32*y +h33) - (h21*x + h22*y +h23)*h31/(h31*x + h32*y +h33)^2;
fydy=h22/(h31*x + h32*y +h33) - (h21*x + h22*y +h23)*h32/(h31*x + h32*y +h33)^2;

Aff=[fxdx fxdy;fydx fydy];
end
