function imgnoOp = getImgnoInStrOrInt(imgnoIp,dSetNo)

imgnoStr = num2str(imgnoIp);
numDigits = length(imgnoStr);
[~,decVal] = getParamsAndDataset(dSetNo);
numZeros = decVal - numDigits;


imgnoOp = [repmat(num2str(0),1,numZeros) imgnoStr] ;
end
