function fig_generateICSUpDown(imName0,threshI,delta,deltastep)

imgName = sprintf('./images_figure/%s',imName0);
[imGraySmooth szIm] = fig_getSmoothImage(imgName);

figure, imshow(imgName); hold on,
for thresh=threshI-delta:deltastep:threshI+delta
    
    [bICSSmX bICSSmY] = fig_getSmoothICS(imGraySmooth, thresh);
    
    bICSSm = [bICSSmX bICSSmY];
    plot(bICSSm(:,2),bICSSm(:,1),'Linewidth',6,'Color','k');
    plot(bICSSm(:,2),bICSSm(:,1),'Linewidth',2,'Color','w');
    
end

end

%  fig_generateICSUpDown('ll9.jpg',90,40,10);
%  fig_generateICSUpDown('lll1.jpg',150,80,10);
% fig_generateICSUpDown('lll4.jpg',150,80,10);
% fig_generateICSUpDown('lll2.jpeg',100,60,10)

