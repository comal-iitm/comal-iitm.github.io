function [indValid coordFg] = getValidIndInFgBB(xyCoord,dataset,imgnoStr,dSetNo,dilVal,fgType)
%specify howmanyever sets of dilation values and the foregroundtype you
%want (full, boundary or nonboundary regions), it will give out that many
%sets of output params.
if size(dilVal,1) ~= size(fgType,1)
    indValid=[]; coordFg=[];
end
if iscell(xyCoord)
    xyCoord = cell2mat(xyCoord);
end

if ~ischar(imgnoStr)
    imgnoStr = getImgnoInStrOrInt(imgnoStr,dSetNo);
end

if dSetNo == 1 || dSetNo == 10 || dSetNo == 11
    [indValid coordFg] = getBgSubtractedFeat(xyCoord,dataset,imgnoStr,dilVal,fgType, dSetNo);
    if 0
        img = imread(sprintf('../images/%s/img%s.ppm',dataset,imgno));
        figure, imshow(img,[]), hold on,plot(indBlockMat(1,:),indBlockMat(2,:),'*');
    end
end

if dSetNo == 2 || dSetNo == 6
    [indValid coordFg] = getFgBB(xyCoord,dataset,imgnoStr,dilVal,fgType);
    %in the future do some color segmetnation to get exact background, Reuse
    %stuff from BGSubtraction. I/p, O/p of this function will be the same.
end

if dSetNo==5
    [indValid coordFg] = getThreshFg(xyCoord,dataset,imgnoStr,dilVal,fgType);
end
