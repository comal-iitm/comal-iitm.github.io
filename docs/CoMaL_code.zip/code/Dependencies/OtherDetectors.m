function [feat thresh] = OtherDetectors(imgPath,ptFile,dataset,imgnoInt,detType,sxi2,threshInit,dSetNo,thresh,imgnoBase,ptFileCoMIC,dilVal,fgType)
%Harris. Hessian. MSER. FAST.FAST-ER
% better design: if imgno==1, threshInit = corThresh, else threshInit =
% thresh. detn thresh inside OtherDetectors.
feat=[];coordFg{1}=[]; perc=1;
switch detType
    case {'hes','har'} %'har',
        command = sprintf('sudo ./detect_points.ln -i %s -%s -s %d -thres %f -o %s',imgPath,detType,sqrt(sxi2),threshInit,ptFile); %use some threshold; -DR to draw regions
        system(command);
        feat =loadFeatures(ptFile,1);
        strength = feat(3,:);
        %     case 'har'
        %         pointtype = 1;
        %         feat  = MultiScaleDetectors(imgPath,sxi2,pointtype,imgnoInt);
        %         strength = feat(:,8)'; feat = feat';
    case 'msr'
        mserFile = sprintf('./mser.ln -i %s -mm %d -o %s -t %d',imgPath,threshInit,ptFile,2); %make way for size, change loadfeatures, get 1/size
        system(mserFile);
        ptFile2 = [ptFile(1:end-7) '2' ptFile(end-7:end)];
        mserFile = sprintf('./mser.ln -i %s -mm %d -o %s -t %d',imgPath,threshInit,ptFile2,4); %make way for size, change loadfeatures, get 1/size
        system(mserFile);
        feat2 = dlmread(ptFile2);
        feat = dlmread(ptFile);
        feat = feat(3:end,:)';
        strength = feat2(:,7)'; strength = strength(strength>0);
        %get msers of appropriate size only
        delScale = 2;
        indScale = getFeatOfScale(feat,sxi2,delScale);
        feat = feat(:,indScale); strength = strength(indScale);
        if 0
            img = imread(imgPath); figure, imshow(img); hold on; showellipticfeaturesSPL(feat','g',1,0,1, img);
            img = imread(imgPath); figure, imshow(img); hold on; showellipticfeaturesSPL(detectedPtsOtherFinal','g',1,0,1, img);
        end
        remFile = sprintf('rm %s',ptFile2);
        system(remFile);
    case 'fas'
        %         com = sprintf('./fast_opencv.py %s > %s', imgPath, ptFile); system(com);
        perc = 0.92;
        I1 = imread(imgPath);
        I1 = rgb2gray(I1);
        if dSetNo==1 || dSetNo==2 || dSetNo==6 %the subtracting image part might go out in the future, to make one subtraction for all types of detectors, or detector loop might come inside
            dilValMax = 50;
            [~, coordFg] = getValidIndInFgBB([1 1],dataset,imgnoInt,dSetNo,dilValMax,fgType);
        end
        if ~isempty(coordFg{1})
            minX = min(min(coordFg{1}(:,1))); maxX = max(max(coordFg{1}(:,1)));
            minY = min(min(coordFg{1}(:,2))); maxY = max(max(coordFg{1}(:,2)));
            [szX szY] = size(I1);
            I = uint8(zeros(szX,szY));
            I(minY:maxY,minX:maxX) = I1(minY:maxY,minX:maxX);
        else
            I = I1;
        end
        [feat strength] = fast9(I, threshInit,1); %fast9(I, 30,1);
        feat = feat';
        
    case 'ebr'
        ebrFile = sprintf('./ebr.ln %s %s',imgPath,ptFile); %make way for size, change loadfeatures, get 1/size
        system(ebrFile);
        feat = loadFeaturesMSER(ptFile); delScale = 4;
        indScale = getFeatOfScale(feat,sxi2,delScale);
        feat = feat(:,indScale);
        strength = ones(size(feat,2),1);
    case 'fer'
        %result gotten from c code outside
        featNew = dlmread(detPtsFileOther);
        sizeFeat = size(featNew,1);
        scale = repmat(sxi2,sizeFeat,1); %feat(1,3)
        featF = [featNew(:,1:2) scale zeros(sizeFeat,1) scale];
    case 'rnd'
        img = imread(imgPath);
        [sz1 sz2 temp] = size(img);
        if dSetNo==6
            scRnd = round(2*sxi2);
        else
            scRnd = round(2*sxi2);
        end
        
        [featX featY] = meshgrid(1:scRnd:sz2,1:scRnd:sz1);
        feat = [featX(:)'; featY(:)'];
        strength = ones(1,size(feat,2));
end

if ~isempty(feat)
    if dSetNo==1 || dSetNo==2 || dSetNo==6 || dSetNo==10 || dSetNo == 11%the subtracting image part might go out in the future, to make one subtraction for all types of detectors, or detector loop might come inside
        [indValidFg coordFg] = getValidIndInFgBB(feat(1:2,:)',dataset,imgnoInt,dSetNo,dilVal,fgType);
        feat = feat(:,indValidFg{1});
        strength = strength(indValidFg{1});
    end
    if dSetNo==8
        indNotUseful = find(feat(2,:)<120); %75 if you use indValid, you have to take into account points that don't have duplicates
        feat(:,indNotUseful)=[];
        strength(indNotUseful)=[];
        
    end
    
    if ~isempty(coordFg{1}) || (dSetNo~=1 || dSetNo~=2 || dSetNo~=6 || dSetNo~=10 || dSetNo ~= 11)
        [strengthSortd,indSort] = sort(-strength);
        strengthSortd = abs(strengthSortd);
        if strcmp(detType,'fas') %several points in fast have the same threshold. To chose the same number of points after the threshold, we give the points with the same threshold an extra value depending on its order.
            strengthUnique = unique(strengthSortd);
            count = histc(strengthSortd,strengthUnique);
            count= flipud(count);
            countVal=[];
            for i=1:length(count)
                countVal = [countVal; (1:count(i))'./100];
            end
            strengthSortd = strengthSortd + countVal;
        end
        feat = feat(:,indSort);
        
        %     if dSetNo==3 || dSetNo==4 || dSetNo==7
        if imgnoInt==imgnoBase
            detPts = loadFeaturesMSER(ptFileCoMIC); numPtsHarrOnMser= size(detPts,2);
            numPtsMin = round(perc*min(numPtsHarrOnMser,size(feat,2)));
            thresh = strengthSortd(numPtsMin);
            delThresh = getDelta(dataset,detType);
            thresh = thresh + delThresh;
            feat = feat(:,1:numPtsMin);
            
        else
            delThresh = getDelta(dataset,detType);
            thresh = thresh + delThresh;
            try
            indOverThresh = find(strengthSortd>=thresh);
            catch, aa=1; end
            if ~isempty(indOverThresh)
                feat = feat(:,indOverThresh);
            end
        end
        %     else
        %         indOverThresh = find(strengthSortd>=threshInit);
        %         if ~isempty(indOverThresh)
        %             feat = feat(:,indOverThresh);
        %         end
        %     end
        
        sizeFeat = size(feat,2);
        sizeCol = repmat(1/(sxi2.^2),1,sizeFeat); % works only for single scale: No reason for duplicates to exist for more.
        if strcmp(detType,'msr')
            detectedPtsOtherFinal = feat;
        else
            detectedPtsOtherFinal = [feat(1:2,:); sizeCol; zeros(1,sizeFeat); sizeCol];
        end
        I = rgb2gray(imread(imgPath));
        [ysize xsize]  = size(I);
        writeToFileTest(ptFile,detectedPtsOtherFinal',1,xsize,ysize,0,imgnoInt,1);
    else
        remFile = sprintf('rm %s',ptFile);
        system(remFile);
        fprintf('No object in frame\n');
    end
else
    remFile = sprintf('rm %s',ptFile);
    system(remFile);
    fprintf('No point detected\n');
    
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%The other detector: the executable
if 0
    system(sprintf('./detect_points.ln -%s -s %d -thres %d -i %s -o %s',detType,iSz/2,thresh(pointtype),imgPath,detPtsFileOther)); %
    system(sprintf('./detect_points.ln -%s -s %d -thres %d -i %s -o %s',detType,iSz/2,threshImg1(pointtype),imgPath,detPtsFileOther)); %
    %to get a certain number of points: sort the third column which has cornerness vals
    
    %needs jpg image as input
    opFastFile = sprintf('../data/results/%s/img%d.%s.txt',dataset,(imgno)-1,detType);
    imgPathJpg = sprintf('%s/%s/img%s.jpg',dirData,dataset,imgno);
    fastFile = sprintf('./fast -lst %s %s',imgPathJpg,opFastFile);
    system(fastFile);
    feat =loadFeatures(opFastFile,1);
end
end

function indScale = getFeatOfScale(feat,sxi2,delScale)

scaleM=[];
numMsers = size(feat,2);
for iM=1:numMsers
    ellipseEvals = sqrtm(inv([feat(3,iM), feat(4,iM); feat(4,iM), feat(5,iM)])); %1/sqrt(determinant) also ok
    scaleM(iM) = sqrt(det(ellipseEvals));
end
indScale = find(scaleM < (sxi2 + delScale) & scaleM > (sxi2 - delScale));

end
