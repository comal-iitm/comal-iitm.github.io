function [FinalFeat f1Init ind select] = overlapCheckOther(f1Init,szImage,overErr)

display=0;
H=[1 0 0; 0 1 0; 0 0 1];
common_part=1;
select=[];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% allocate vectors for the features
s1 = size(f1Init,2);
% feat1=zeros(9+dimdesc,s1);
% prob = f1(6,:); %we wanna remove duplicates based on prob, threshold in the end based on pTot
% probTot = f1(7,:);
% combVert = f1(8:end,:);
try
sizeCol = repmat(sqrt(1/f1Init(3,1)),1,s1); % works only for single scale: No reason for duplicates to exist for more.
catch
    aa=1;
end
f1 = f1Init(1:5,:); %[f1Init(1:2,:); sizeCol; zeros(1,s1); sizeCol];
cornerness = f1Init(6,:); %used to be f1Init(8,:); with matlab code
feat1(1:5,1:s1)=f1(1:5,1:s1);
[feat1, ~, ~]=project_regions(feat1',H);

% if numParts~=s1
%     feat1Rest = feat1(numParts+1:end,:);
%     probRest = prob(numParts+1:end);
%     combVertRest = combVert(:,numParts+1:end);
%     probTotRest=probTot(numParts+1:end);
% else
%     feat1Rest =[];
%     probRest=[];
%     combVertRest =[];
%     probTotRest=[];
% end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if common_part==1
    im1x=szImage;
    im1y=im1x(1);
    im1x=im1x(2);
    ind=find((feat1(:,1)+feat1(:,8))<im1x & (feat1(:,1)-feat1(:,8))>0 & (feat1(:,2)+feat1(:,9))<im1y & (feat1(:,2)-feat1(:,9))>0);
    FinalFeat=feat1(ind,:)';
    f1Init = f1Init(:,ind);
    cornerness = cornerness(ind);
    numParts = size(ind,1);
    %     probPart = [prob(ind)];
    %     probTot = [probTot(ind) probTotRest];
    %     combVert = [combVert(:,ind) combVertRest];
    
end

valid = ones(numParts,1);
for partIdx = 1:numParts
    if valid(partIdx)
        feat1Part = FinalFeat(:,partIdx);
        feat2tPart = FinalFeat;
        
        [~, twout, ~, ~]=c_eoverlap(feat1Part,feat2tPart,common_part);
        %     disp(['Removing Duplicates for ell ' num2str(partIdx)]);
        twout(partIdx) = 100;
        dupIdx = find(twout<=overErr & twout>=0);
        for i=1:size(dupIdx,1)
            %                 if (invstab1Part(partIdx) <= invstab1Part(dupIdx(i))) && (cornernessPart(partIdx) >= cornernessPart(dupIdx(i)))
            %                 if (cornernessPart(partIdx) >= cornernessPart(dupIdx(i)))
            if (cornerness(partIdx) >= cornerness(dupIdx(i)))
                valid(dupIdx(i)) = 0;
            else
                valid(partIdx) = 0;
            end
        end
        
        
    end
end

select = find(valid == 1);
FinalFeat = [FinalFeat(1:5,select); cornerness(select)];

if display
    figure, showellipticfeatures(FinalFeat',[1 1 0]);
    hold on, showellipticfeatures(FinalFeat(:,discard)',[0 0 0]);
    figure, showellipticfeatures(FinalFeat(:,select)',[1 0 1]);
    %     hold on, showellipticfeatures(feat1Part',[1 0 0]);
end


end

function [feat,featp,scales]=project_regions(feat,H)

s=size(feat);
s1=s(1);

featp=feat;
scales=zeros(1,s1);

for c1=1:s1,%%%%%%%%%%%%%%%%%
    %feat(c1,3:5)=(1/25)*feat(c1,3:5);
    
    Mi1=[feat(c1,3) feat(c1,4);feat(c1,4) feat(c1,5)];
    
    %compute affine transformation
    
    [v1 e1]=eig(Mi1);
    
    d1=(1/sqrt(e1(1)));
    d2=(1/sqrt(e1(4)));
    sc1=sqrt(d1*d2);
    feat(c1,6)=d1;
    feat(c1,7)=d2;
    scales(c1)=sqrt(feat(c1,6)*feat(c1,7));
    
    %bounding box
    feat(c1,8) = sqrt(feat(c1,5)/(feat(c1,3)*feat(c1,5) - feat(c1,4)^2));
    feat(c1,9) = sqrt(feat(c1,3)/(feat(c1,3)*feat(c1,5) - feat(c1,4)^2));
    
    
    Aff=getAff(feat(c1,1),feat(c1,2),sc1, H);
    
    %project to image 2
    l1=[feat(c1,1),feat(c1,2),1];
    l1_2=H*l1';
    l1_2=l1_2/l1_2(3);
    featp(c1,1)=l1_2(1);
    featp(c1,2)=l1_2(2);
    if det(Mi1)
        BMB=inv(Aff*inv(Mi1)*Aff');
        try
            [v1 e1]=eig(BMB);
        catch
            disp('Stop');
        end
        featp(c1,6)=(1/sqrt(e1(1)));
        featp(c1,7)=(1/sqrt(e1(4)));
        featp(c1,3:5)=[BMB(1) BMB(2) BMB(4)];
        %bounding box in image 2
        featp(c1,8) = sqrt(featp(c1,5)/(featp(c1,3)*featp(c1,5) - featp(c1,4)^2));
        featp(c1,9) = sqrt(featp(c1,3)/(featp(c1,3)*featp(c1,5) - featp(c1,4)^2));
    end
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function Aff=getAff(x,y,sc,H)
h11=H(1);
h12=H(4);
h13=H(7);
h21=H(2);
h22=H(5);
h23=H(8);
h31=H(3);
h32=H(6);
h33=H(9);
fxdx=h11/(h31*x + h32*y +h33) - (h11*x + h12*y +h13)*h31/(h31*x + h32*y +h33)^2;
fxdy=h12/(h31*x + h32*y +h33) - (h11*x + h12*y +h13)*h32/(h31*x + h32*y +h33)^2;

fydx=h21/(h31*x + h32*y +h33) - (h21*x + h22*y +h23)*h31/(h31*x + h32*y +h33)^2;
fydy=h22/(h31*x + h32*y +h33) - (h21*x + h22*y +h23)*h32/(h31*x + h32*y +h33)^2;

Aff=[fxdx fxdy;fydx fydy];
end

