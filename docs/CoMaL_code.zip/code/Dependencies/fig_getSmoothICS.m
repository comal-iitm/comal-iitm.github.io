function [bICSSmX bICSSmY] = fig_getSmoothICS(im, threshI)

maskICS = (im > threshI);
bICS = bwboundaries(maskICS);
try
    bICSSmX = BoundaryGaussianSmoothing(bICS{1}(:,1),8,0,1);
    bICSSmY = BoundaryGaussianSmoothing(bICS{1}(:,2),8,0,1);
catch
    bICSSmX = BoundaryGaussianSmoothing(bICS{2}(:,1),8,0,1);
    bICSSmY = BoundaryGaussianSmoothing(bICS{2}(:,2),8,0,1);
end