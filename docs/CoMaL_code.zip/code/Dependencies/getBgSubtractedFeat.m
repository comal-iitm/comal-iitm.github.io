function [indValid coordFg coordFgBound] = getBgSubtractedFeat(xyCoord, datastring, imgnoStr,dilVal,fgType, dSetNo)

dirData ='../Images';
indValid=[];
% if ~exist('detPtsInit','var') %this won't happen mostly
%     ptFile = sprintf('../data/results/%s/img%d.%s.txt',datastring,str2num(imgnoStr)-1,detType);
%     detPtsInit = loadFeatures(ptFile);
% end

if dSetNo == 1 || dSetNo == 10,
    bgPath = fullfile('../bg',datastring,sprintf('imgB.ppm')); %this might have to be changed for some images
    imgPath = fullfile(dirData,datastring,sprintf('img%s.ppm',imgnoStr));
    [coordFg coordFgBound] = BGSubtraction(bgPath,imgPath,dilVal,datastring,sprintf('img%s.ppm',imgnoStr));
elseif dSetNo == 11,
    bgPath = fullfile('../bg',datastring,sprintf('img%s.ppm', imgnoStr)); %this might have to be changed for some images
    imgPath = fullfile(dirData,datastring,sprintf('img%s.ppm',imgnoStr));
    [coordFg coordFgBound] = BGSubtractionUT(bgPath,imgPath,dilVal,datastring,sprintf('img%s.ppm',imgnoStr));
else
    bgPath = fullfile('../bg',datastring,sprintf('imgB.png')); %this might have to be changed for some images
    imgPath = fullfile(dirData,datastring,sprintf('%s.png',imgnoStr));
    [coordFg coordFgBound] = BGSubtraction(bgPath,imgPath,dilVal,datastring,sprintf('%s.png',imgnoStr));
% else 
%     bgPath = fullfile('../bg',datastring,sprintf('%s.png', imgnoStr)); %this might have to be changed for some images
%     imgPath = fullfile(dirData,datastring,sprintf('%s.png',imgnoStr));
%     [coordFg coordFgBound] = BGSubtraction_Kinect(bgPath,imgPath,dilVal,sprintf('%s.png',imgnoStr));
end

if ~isempty(xyCoord)
    for numDil = 1:length(dilVal)
        xyCoord0 = round(xyCoord(:,1:2));
        
        switch fgType{numDil}
            case 'full'
                indValid0 = ismember(xyCoord0,coordFg{numDil},'rows');
                indValid{numDil} = find(indValid0);
                
            case 'bound'
                indValid0 = ismember(xyCoord0,coordFgBound{numDil},'rows');%this will not work for dSet=2 for now
                indValid{numDil} = find(indValid0);
                
            case 'nonBound'
                indValid0Full = ismember(xyCoord0,coordFg{numDil},'rows');
                indValidFull = find(indValid0Full);
                
                indValid0Bound = ismember(xyCoord0,coordFgBound{numDil},'rows');
                indValidBound = find(indValid0Bound);
                
                indValid{numDil} = setdiff(indValidFull,indValidBound);
        end
        
        if 0
            figure, imshow(imgPath), hold on, plot(xyCoord0(:,1),xyCoord0(:,2),'*g');
            figure, imshow(imgPath), hold on, plot(coordFgBound{1}(:,1),coordFgBound{1}(:,2),'*b');
            figure, imshow(imgPath), hold on, plot(xyCoord0(indValid{1},1),xyCoord0(indValid{1},2),'*g');
            figure, imshow(imgPath), hold on, plot(coordFg{1}(:,1),coordFg{1}(:,2),'*b');
        end
    end
end