function getFigureBar(datastring,xlabelString, yLabelString1, yLabelString2,score,corres,delta)

figure(hFig1);  bar([repeatBDet; repeatNBDet; repeatDet]);
h_legend = legend('CoMIC','Harris','Hessian','Fast-9','Fast-er','Mser','Location','SouthEast');
set(h_legend, 'FontSize',45)
set(gca,'FontWeight','bold','LineWidth',5,'FontSize',40);
set(gca,'xtick',[1 2 3],'xticklabel',{});

mark=['-kx';'-gs';'-bp';'-m+';'-rd';'-cv']; %Mser 'Color',[1 0.6 0]

% mark=['-cv';'-gs';'-m+';'-bp';'-rd';'-kx']; % -- for dashed line
lineWidthVal = 4; MarkerSizeVal = 10; FontSizeVal = 40; %10, 24 and 40

numImages = size(score{1},2);
xAxis = 1:(numImages);%/3);

hFig1 = figure;clf;
grid on;
title(datastring,'FontSize',FontSizeVal,'FontWeight','bold');
ylabel(yLabelString1,'FontSize',FontSizeVal,'FontWeight','bold')
xlabel(xlabelString,'FontSize',FontSizeVal,'FontWeight','bold');
figure(hFig1); axis([0.99 numImages 0.99 102]);
hold on;

hFig2 = figure;clf;
grid on;
title(datastring,'FontSize',FontSizeVal,'FontWeight','bold');
ylabel(yLabelString2,'FontSize',FontSizeVal,'FontWeight','bold')
xlabel(xlabelString,'FontSize',FontSizeVal,'FontWeight','bold');
hold on;

numDetectors = size(score,2);
for i=numDetectors:-1:1
    for b=1:3
        repeatBDet(1,numDetectors) = score{1}{i};  corresBDet(1,numDetectors) = corres{1}{i};
        repeatNBDet(1,numDetectors) = score{2}{i};  corresNBDet(1,numDetectors) = corres{1}{i};
        repeatDet(1,numDetectors) = score{3}{i};  corresDet(1,numDetectors) = corres{1}{i};
    end
end

figure(hFig1);  bar([repeatBDet; repeatNBDet; repeatDet]);
figure(hFig1);  bar([corresBDet; corresNBDet; corresDet]);

end