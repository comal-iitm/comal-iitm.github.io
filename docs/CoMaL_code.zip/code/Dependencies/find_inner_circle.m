function [cx,cy,r]=find_inner_circle(x,y)


[vx,vy]=voronoi(x,y);

% find voronoi nodes inside the polygon [x,y]
Vx=vx(:);
Vy=vy(:);

if 0
    figure, plot(x,y,'g');
    hold on; plot(Vx,Vy,'*r');
end

% Here, you could also use a faster version of inpolygon
IN=inpolygon(Vx,Vy, x,y);
ind=find(IN==1);
Vx=Vx(ind);
Vy=Vy(ind);

if 0
    hold on; plot(Vx,Vy,'*b');
end

% maximize the distance of each voronoi node to the closest node on the
% polygon.
minDist=0;
minDistInd=-1;
for i=1:length(Vx)
    dx=(Vx(i)-x);
    dy=(Vy(i)-y);
    [r xyInd]=min(dx.*dx+dy.*dy);
    if (r>minDist)
        minDist=r;
        minDistInd=i;
        minxyInd = xyInd;
    end
    if 0
        hold on; plot([Vx(i) x(xyInd)],[Vy(i) y(xyInd)],'*b');
    end    
end

if ~isempty(Vx)
    % take the center and radius
    cx=Vx(minDistInd);
    cy=Vy(minDistInd);
    r=sqrt(minDist);
    if 0
        hold on; plot([cx x(minxyInd)],[cy y(minxyInd)],'m');
    end 
else
    cx=0;cy=0;r=0;
end

end