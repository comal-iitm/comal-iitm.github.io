function [f f1Corres] = AddDisparityNDisplay2(f1,disparity,boundaryPartsPlus,dataset,imF1,imF2,f2,resizeFactorPts)
verifyDisp=0;expand=0;displayflag=0;
[ysize xsize] = size(disparity);
d{1}='cone'; d{2}='tedy';

if any(strcmp(dataset,d))
    dispDivFactor = 2; whitePixelVal=1;
    depthPixVal = max(max(boundaryPartsPlus==1));

else
    dispDivFactor = 16;whitePixelVal=255;depthPixVal=128;
end


%% Disaprity Verification
if verifyDisp
    %Some points get overwritten in this
    im1 = imread(imgPath1);
    for t=1:2
        im2Map = zeros(ysize,xsize,3);
        [xInd yInd] = meshgrid(1:xsize,1:ysize);
        dispValid = find(disparity>0);
        %     dispValid = 1:length(disparity(:));
        yIndV = yInd(dispValid) ; xIndV = xInd(dispValid);
        dispValResc = (disparity(dispValid)/dispDivFactor);
        if t==1
            xIndIm2A = xIndV - floor(dispValResc);
            xIndIm2B = xIndV - ceil(dispValResc);
            iV0 = find(xIndIm2B>1); xIndIm2B = xIndIm2B(iV0,:);
            xIndVB = xIndV(iV0) ; yIndVB = yIndV(iV0);
            indSetFinal = union([xIndV  yIndV xIndIm2A], [xIndVB yIndVB xIndIm2B],'rows');
            iV = find(indSetFinal(:,3)>0); indSetFinal = indSetFinal(iV,:);
        else
            xIndIm2A = xIndV + floor(dispValResc);
            xIndIm2B = xIndV + ceil(dispValResc);
            indSetFinal = union([xIndV  yIndV xIndIm2A], [xIndV yIndV xIndIm2B],'rows');
        end
        for a=1:size(indSetFinal,1)
            im2Map(indSetFinal(a,2),indSetFinal(a,3),:) = im1(indSetFinal(a,2),indSetFinal(a,1),:);
        end
        im2Map = uint8(im2Map);
        figure, imshow(im2Map);
    end
end

%% Boundary
boundaryParts1 = zeros(ysize,xsize);
boundaryParts1(boundaryPartsPlus ==depthPixVal) = 1;

if expand
    seDilate = strel('disk',4); seErode = strel('disk',1);
    boundaryParts = imdilate(boundaryParts,seDilate);
    boundaryParts = imerode(boundaryParts,seErode);
end

if 0 %calculating boundary pixels don't think is right/
    boundaryParts2 = zeros(ysize,xsize);
    [row col] = find(boundaryParts==whitePixelVal);
    for i1=1:length(row)
        colNew = round(col(i1) - (disparity(row(i1),col(i1))/dispDivFactor));
        if colNew>0
            boundaryParts2(row(i1),colNew) = depthPixVal;
        end
    end
    boundaryParts2 = imdilate(boundaryParts2,se);
end

if displayflag
    figure, imshow(boundaryParts1,[]);
    figure, imshow(boundaryParts2,[]);
end
%%

f=cell(3,1); f1Corres=cell(3,1);
f1Round = floor(f1(:,1:2));
indZero = find(f1Round(:,1)==0 | f1Round(:,2)==0);
f1Round(indZero,:)=[];f1(indZero,:)=[];

for j=1:size(f1Round,1)
    toadd = -disparity(f1Round(j,2),f1Round(j,1))/dispDivFactor;
    f2Disp = [f1(j,1)+toadd f1(j,2:end)];
    if f2Disp(1)>0 && f2Disp(2)>0
        if boundaryParts1(f1Round(j,2),f1Round(j,1))== 1%whitePixelVal %midPixelValchange this also!
            f{2}= [f{2}; f2Disp];
            f1Corres{2} = [f1Corres{2}; f1(j,:)];
        else
            f{1} = [f{1}; f2Disp];
            f1Corres{1} = [f1Corres{1}; f1(j,:)];
        end
    end
end
f{1} = ResizePts(f{1}',1./resizeFactorPts);
f{2} = ResizePts(f{2}',1./resizeFactorPts);

f1Corres{1} = ResizePts(f1Corres{1}',1./resizeFactorPts);
f1Corres{2} = ResizePts(f1Corres{2}',1./resizeFactorPts);

f{3} = [f{1} f{2}];
f1Corres{3} = [f1Corres{1} f1Corres{2}];

if displayflag
    im1 = imresize(imread(imF1),sqrt(sum(resizeFactorPts.^2)/2));
    im2 = imresize(imread(imF2),sqrt(sum(resizeFactorPts.^2)/2));
    figure, imshow(im1), hold on; showellipticfeaturesSPL(f1);
    figure, imshow(im2), hold on; showellipticfeaturesSPL(f{3});
    figure, imshow(im2), hold on; showellipticfeaturesSPL(f2);    
    figure, imshow(im2), hold on; showellipticfeaturesSPL(f{1}');
end


