function [repeat, corresp, mScore, numMatches] = testMserSimple2(pair,dataset,detType,desType,dSetNo,delta,distThresh,ifRep,imSize)

repeat=0; corresp=0; mScore=0;numMatches =0;
ptDirData = sprintf('../data/results/feat-delta%d',delta);
descDirData = sprintf('../data/results/desc-delta%d',delta);
imDirData = '../Images';

imgno1= pair(1);  imgno2 = pair(2);
imgnoStr1 = getImgnoInStrOrInt(imgno1,dSetNo);
imgnoStr2 = getImgnoInStrOrInt(imgno2,dSetNo);

imgPath1 = sprintf('%s/%s/img%s.ppm',imDirData,dataset,imgnoStr1); %switch to dataset depending on whatever
imgPath2 = sprintf('%s/%s/img%s.ppm',imDirData,dataset,imgnoStr2);

%% Repeatability for detections alone
if ifRep && (dSetNo==3 || dSetNo==4 || dSetNo==7 || dSetNo==8 || dSetNo==9)
  if dSetNo==7
    imgnoStr1M1 = getImgnoInStrOrInt(imgno1-1,dSetNo); imgnoStr2M1 = getImgnoInStrOrInt(imgno2-1,dSetNo);
    Hom = sprintf('%s/%s/H%sto%s.txt',imDirData, dataset,imgnoStr2M1,imgnoStr1M1);
  else Hom = sprintf('%s/%s/H1to%dp',imDirData ,dataset,imgno2); end
  
  if dSetNo==8
    dispPath = sprintf('%s/%s/disp/disp%d_%d.png',imDirData ,dataset,imgno1,imgno2);
    descStr = ''; Hom = sprintf('%s/%s/H1to1p',imDirData ,dataset);
  else dispPath='';descStr = '.sift'; end
  
  pt1= sprintf('%s/%s/img%d.%s%s.txt',ptDirData,dataset,imgno1-1,detType,descStr);
  pt2= sprintf('%s/%s/img%d.%s%s.txt',ptDirData,dataset,imgno2-1,detType,descStr);
  
  if dSetNo==8 || exist(Hom,'file')
    if exist(pt2,'file')
      origSizeFile = sprintf('%s/%s/original_size.txt',imDirData, dataset); %pathToLoad = sprintf('../data/results/orig-delta%d/%s',delta,dataset);
      [repeat,corresp,mScore,numMatches]= repeatability(pt1,pt2,Hom,imgPath1,imgPath2, imgno2, origSizeFile,dSetNo,dataset,dispPath);
    end
  end
end

%% Matching score

if ~ifRep && (dSetNo==1 || dSetNo==2 || dSetNo==6 || dSetNo==4 || dSetNo==8 || dSetNo==9 || dSetNo==10 || dSetNo == 11)
  pathExtra=fullfile('..','data','results',sprintf('orig-delta%d',delta),sprintf('%s',dataset)); %    load(sprintf('%s/cornersConv%d.mat',pathExtra,imgno1),'cornersConv');
  try
    r1 = load(sprintf('%s/regionConv%d.mat',pathExtra,imgno1),'regionConv'); r2 = load(sprintf('%s/regionConv%d.mat',pathExtra,imgno2),'regionConv');
    m1= load(sprintf('%s/maskConvSz%d.mat',pathExtra,imgno1),'maskConvSz'); m2= load(sprintf('%s/maskConvSz%d.mat',pathExtra,imgno2),'maskConvSz');
    b1 = load(sprintf('%s/boundaryConv%d.mat',pathExtra,imgno1),'boundaryConv'); b2 = load(sprintf('%s/boundaryConv%d.mat',pathExtra,imgno2),'boundaryConv');
    s1 = load(sprintf('%s/scConv%d.mat',pathExtra,imgno1),'scConv'); s2 = load(sprintf('%s/scConv%d.mat',pathExtra,imgno2),'scConv');
    t1 = load(sprintf('%s/topLeftConv%d.mat',pathExtra,imgno1),'topLeftConv');  t2 = load(sprintf('%s/topLeftConv%d.mat',pathExtra,imgno2),'topLeftConv');
  catch
    return;
  end
  regions{1} = r1.regionConv; regions{2} = r2.regionConv; maskSzs{1} = m1.maskConvSz; maskSzs{2} = m2.maskConvSz;
  boundarys{1} = b1.boundaryConv; boundarys{2} = b2.boundaryConv; scs{1} = s1.scConv; scs{2} = s2.scConv;
  topLefts{1} = t1.topLeftConv; topLefts{2} = t2.topLeftConv;
  
  if dSetNo == 10
      ptFile1 = sprintf('%s/%s/img%d.%s.txt',ptDirData,dataset,str2num(imgnoStr1)-1,detType);
      ptFile2 = sprintf('%s/%s/img%d.%s.txt',ptDirData,dataset,str2num(imgnoStr2)-1,detType);
  else
      ptFile1 = sprintf('%s/%s/img%d.%s.txt',ptDirData,dataset,str2num(imgnoStr1)-1,detType);
      ptFile2 = sprintf('%s/%s/img%d.%s.txt',ptDirData,dataset,str2num(imgnoStr2)-1,detType);
  end
  
  try
    f1 = loadFeatures(ptFile1); f2 = loadFeatures(ptFile2);
  catch, return; end
  
  f1=f1'; f2=f2';
  
  fprintf('\n time for pair %d-%d',str2num(imgnoStr1),str2num(imgnoStr2));
  matchesSavePath0 = sprintf('../data/results/matches-delta%d/%s',delta,dataset);
  if ~exist(matchesSavePath0), mkdir(matchesSavePath0); end
  matchesSavePath = sprintf('%s/match%s_%d_%d_full_%s',matchesSavePath0,detType,str2num(imgnoStr1),str2num(imgnoStr2),desType);
  
  switch desType %nothing for 'ssd'
    case 'sol'
      descPath1 = sprintf('%s/%s/solDesc%d_%s.mat',descDirData,dataset,str2num(imgnoStr1)-1,detType);
      descPath2 = sprintf('%s/%s/solDesc%d_%s.mat',descDirData,dataset,str2num(imgnoStr2)-1,detType);
    case 'sift'
      descPath1 = sprintf('%s/%s/img%d.%s.sift.txt',descDirData,dataset,str2num(imgnoStr1)-1,detType);
      descPath2 = sprintf('%s/%s/img%d.%s.sift.txt',descDirData,dataset,str2num(imgnoStr2)-1,detType);
    case 'ssd'
      descPath1='';descPath2='';
  end
  
  switch dSetNo
    case 8
      gtPath = sprintf('%s/%s/disp/disp%d_%d.png',imDirData ,dataset,imgno1,imgno2);
      gtImg = disparity_read(gtPath);
    case 9
      gtPath = sprintf('%s/%s/flow/flow%d_%d.png',imDirData ,dataset,imgno1,imgno2);
      gtImg = flow_read(gtPath);
    case 6
      gtPath = sprintf('%s/%s/groundtruth.mat',imDirData,dataset);
      gt = load(gtPath); groundtruth1 = gt.tracklets{imgno1}; groundtruth2 = gt.tracklets{imgno2};
      if ~(isempty(groundtruth1) | isempty(groundtruth2))
        dilVal=10; indF1=[];
        [~,~,gtAll1, featByBB1, featIndBB1, gtObjId1] = getFgBB(f1,dataset, imgnoStr1, dilVal,'',imSize);
        [~,~,gtAll2, featByBB2, featIndBB2, gtObjId2] = getFgBB(f2,dataset, imgnoStr2, dilVal,'',imSize);
        indF1=[];
        for g=1:length(featIndBB1)
          lenFtObj = size(featIndBB1{g},1);
          indGt2 = find(gtObjId2 ==gtObjId1(g));
          if ~isempty(indGt2)
            valid = 1;
            distGt = abs(gtAll1{g}(5:6) - gtAll2{indGt2}(5:6));
            distGt = (sum(distGt));
          else
            valid = 0; distGt = 0;
          end
          indF1 = [indF1; featIndBB1{g} repmat(valid,lenFtObj,1) repmat(distGt,lenFtObj,1)];
        end
        gtImg.indF1 = indF1;
      end
    case 10 
      gtPath = sprintf('%s/%s/groundtruth.mat',imDirData,dataset);
      gt = load(gtPath); groundtruth1 = gt.groundtruth{imgno1-147}; groundtruth2 = gt.groundtruth{imgno2-147};
      if ~(isempty(groundtruth1) | isempty(groundtruth2))
        dilVal=10; indF1=[];
        [~,~,gtAll1, featByBB1, featIndBB1, gtObjId1] = getFgBBkine(f1,dataset, imgnoStr1, dilVal,'',imSize);
        [~,~,gtAll2, featByBB2, featIndBB2, gtObjId2] = getFgBBkine(f2,dataset, imgnoStr2, dilVal,'',imSize);
        indF1=[];
        for g=1:length(featIndBB1)
          lenFtObj = size(featIndBB1{g},1);
          indGt2 = find(gtObjId2 ==gtObjId1(g));
          if ~isempty(indGt2)
            valid = 1;
            distGt = abs(gtAll1{g}(5:6) - gtAll2{indGt2}(5:6));
            distGt = (sum(distGt));
          else
            valid = 0; distGt = 0;
          end
          indF1 = [indF1; featIndBB1{g} repmat(valid,lenFtObj,1) repmat(distGt,lenFtObj,1)];
        end
        gtImg.indF1 = indF1;
      end
    case 11 
      gtPath = sprintf('%s/%s/groundtruth.mat',imDirData,dataset);
      gt = load(gtPath); groundtruth1 = gt.groundtruth{imgno1}; groundtruth2 = gt.groundtruth{imgno2};
      if ~(isempty(groundtruth1) | isempty(groundtruth2))
        dilVal=10; indF1=[];
        [~,~,gtAll1, featByBB1, featIndBB1, gtObjId1] = getFgBBkine(f1,dataset, imgnoStr1, dilVal,'',imSize);
        [~,~,gtAll2, featByBB2, featIndBB2, gtObjId2] = getFgBBkine(f2,dataset, imgnoStr2, dilVal,'',imSize);
        indF1=[];
        for g=1:length(featIndBB1)
          lenFtObj = size(featIndBB1{g},1);
          indGt2 = find(gtObjId2 ==gtObjId1(g));
          if ~isempty(indGt2)
            valid = 1;
            distGt = abs(gtAll1{g}(5:6) - gtAll2{indGt2}(5:6));
            distGt = (sum(distGt));
          else
            valid = 0; distGt = 0;
          end
          indF1 = [indF1; featIndBB1{g} repmat(valid,lenFtObj,1) repmat(distGt,lenFtObj,1)];
        end
        gtImg.indF1 = indF1;
      end
    case 1
      gtImg=[];
  end
  
  
  
  tic; %getSSDBlock
  if ~exist(matchesSavePath,'file'); %convert to parfor by sending in index aa to
    [featMatch1, featMatch2] = matchDescriptorsSSDSol(f1,f2,regions,maskSzs,boundarys,scs,topLefts,....
      detType,desType,imgPath1,imgPath2,matchesSavePath,distThresh,descPath1,descPath2,gtImg,dSetNo); %matches{pNo}
  end
  tMatch=toc; fprintf('is %f',tMatch);
  
  if 0
    %disp detected pts
    figure, imshow(imgPath1),hold on;showellipticfeaturesSPL(f1);
    figure, imshow(imgPath2),hold on;showellipticfeaturesSPL(f2);
    
    %         disp corres gt points
    figure(num1), imshow(imgPath1),
    for obj=1:length(gtAll1)
      rectangle('Position', [gtAll1{obj}(1) gtAll1{obj}(2) gtAll1{obj}(3) gtAll1{obj}(4)],'LineWidth',2);
    end
    %disp matches
    color = rand(size(featMatch1,1),3); colorF = color;
    img1 = imread(imgPath1); img2 = imread(imgPath2);
    figure,imshow(imgPath1); hold on; showellipticfeaturesSPL(featMatch1,colorF,5,0,1,img1);
    figure,imshow(imgPath2); hold on; showellipticfeaturesSPL(featMatch2,colorF,5,0,1,img2);
    
    %             debugNonMatchingPts(f1,f2,detPtsNoDupDes1,detPtsNoDupDes2,imgPath1,imgPath2)
  end
end
end

function [feat nb dim]=loadFeatures(file)
fid = fopen(file, 'r');
dim=fscanf(fid, '%f',1);
if dim==1
  dim=0;
end
nb=fscanf(fid, '%d',1);
feat = fscanf(fid, '%f', [5+dim, inf]);
fclose(fid);
end


function oldcode

if 0 %nonRedRep
  gauss = 3.3;flag = 0;trunc = 0.83; %2.83 % 1.83 % 14.142 % gauss = 3.3;
  [h,w] = size(rgb2gray(im2double(imread(imgPath1))));  %all coordinates are relative to image 1
  rk  = sprintf('%s/%s/img%d.rep.%s.txt', ptDirData, dataset, imgno1-1,detType);
  if size(feat1Rep,1)>0
    writeToFileTest(rk,feat1Rep',1,w,h,0,1,1);
    com = sprintf('./methods/map_ellipses %s %i %i %f %f label %i ', rk, w, h, trunc, gauss, flag);
    [st, res] = system(com); g = textscan(res, '%f %f %f %f');
    correspNonRed = g{2}(1); repeatNonRed = 100*correspNonRed/sf; %sum_sum = g{1}(1);% no need
  else, repeatNonRed = 0; correspNonRed=0; end
  
  rk  = sprintf('%s/%s/img%d.sift.rep.%s.txt', ptDirData, dataset, imgno1-1,detType);
  if size(feat1Mat,1)>0
    writeToFileTest(rk,feat1Mat(:,1:5),1,w,h,0,1,1);
    com = sprintf('./methods/map_ellipses %s %i %i %f %f label %i ', rk, w, h, trunc, gauss, flag);
    [st, res] = system(com); g = textscan(res, '%f %f %f %f');
    matNonRed = g{2}(1); msNonRed = 100*matNonRed/sf; %sum_sum = g{1}(1);% no need
  else, msNonRed =0; matNonRed=0; end
end

end
