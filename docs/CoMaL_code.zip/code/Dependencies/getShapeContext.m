function [BH1,mean_dist_1] = getShapeContext(boundaryPts)

mean_dist_global=[]; % use [] to estimate scale from the data
nbins_theta=6;
nbins_r=3;
nsamp1=size(boundaryPts,1);
ndum1=0;
eps_dum=0.15;
r_inner=5/8;
r_outer=2;
n_iter=5;
r=1; % annealing rate
beta_init=1;  % initial regularization parameter (normalized)
out_vec_1=zeros(1,nsamp1); 

[BH1,mean_dist_1]=sc_compute(boundaryPts',zeros(1,nsamp1),mean_dist_global,nbins_theta,nbins_r,r_inner,r_outer,out_vec_1);


end