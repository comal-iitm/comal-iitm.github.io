function [cornersFinal, boundaryFinal, maskFinal, scFinal, topLeftFinal, roi_image] = getCOMIC(imageFile, ROI, numCores)
%function [cornersFinal, boundaryFinal, scFinal, topLeftFinal, roi_image] = getCOMIC(imageFile, ROI, numCores) 
  initialClock=tic;
  loopOver=1; ifInit=1;
  nonLcsBasedOverErr = 35; overErrMser=40;%nonLcsBasedOverErr = 10; overErrMser=15;
  delta = 5;
  dupRem = 1;
  expandAmt = 50; coordFg = cell(1,3); detectedPts=[];
  commonVar  = globalVariables(1);
  imgnoInt = 1;
  fprintf('\n Processing %s:', imageFile);
  imgPath = imageFile; %Path of the image file
  imgPath_temp = 'temp.mat'; %Path of the smoothed image we are going to store
  img = (imread(imgPath)); %give initial image a little smoothing

%   fig1 = figure(1);
%   imshow(img);
%   h = imrect();
%   bbox = getPosition(h);
  
  roi = {};
  roi.x = round(ROI(1));
  roi.y = round(ROI(2));
  roi.width = round(ROI(3));
  roi.height = round(ROI(4));
  
%   roi.x = round(bbox(1));
%   roi.y = round(bbox(2));
%   roi.width = round(bbox(3));
%   roi.height = round(bbox(4));
%   close(fig1);
  roi_image = img;%(roi.y:(roi.y+roi.height), roi.x:(roi.x+roi.width),:);
  img = rgb2gray(img);
  img = uint32(img);
  sizeIm  = size(img);
  ysize = sizeIm(1) ; xsize = sizeIm(2);

  i = 1;
  fprintf(' Scale number %d, ',i);
  
  iSz = commonVar.sigSmin(i);
  img = BoundaryGaussianSmoothing_2D(img,2); %iSz/3 %Smooth the image
  save(imgPath_temp, 'img');    %Save the image, this will be loaded in runMatasMser
  
  [imBlocks indBlock indBlockSz] = getBlocksInROI(img,imgnoInt,roi); %Obtains the different image blocks, indices and sizes
  coordFg = getPixelsInBB(roi); %Obtain the "valid" blocks acc. to the FG data
  
  %%
  if ifInit
    
    szCellBl = length(imBlocks); theta = 0;iter=0;
    coordFgObj = coordFg; dummy=0;
    fprintf('InitialClock: %f\n', toc(initialClock)/60);
    
    %mserClock = tic;
    mserCount = 0;
    cornerCount = 0;
    parfor iBl =1:szCellBl 
      %Obtain the regions using the runMatasMser function
      %mserClock = tic;
      [~, regionsDecInit(iBl), variationNThreshInit(iBl), plusOrMinusInit(iBl)] = runMatasMser(imgPath_temp,theta,delta-5,iter,imgnoInt,dummy,indBlock(iBl),indBlockSz(iBl)); %imBlocksCell{split}
      
      %mserCount = mserCount + toc(mserClock)/60;
      %cornerClock = tic;
      [initCornersCell0{iBl}, maskCornerAll(iBl), boundaryPartAll(iBl), scAll(iBl),~, topLeftImAll(iBl)] = getCornersCOMIC(regionsDecInit(iBl), indBlock(iBl), indBlockSz(iBl), iBl, variationNThreshInit(iBl), iSz, plusOrMinusInit(iBl), imgnoInt, coordFgObj);
      %cornerCount = cornerCount + toc(cornerClock)/60;
      
    end
    
    %fprintf('MserClock: %f\n', toc(mserClock)/60);
    %fprintf('MserClock: %f\n', mserCount);
    %fprintf('CornerClock: %f\n', cornerCount);
    
    %duplicateClock = tic;
    maskCornerMat = []; boundaryPartMat = []; scMat=[]; topLeftImMat=[];
 
    for iBl =1:szCellBl
      maskCornerMat = [maskCornerMat ; maskCornerAll{iBl}];
      boundaryPartMat = [boundaryPartMat; boundaryPartAll{iBl}]; scMat = [scMat; scAll{iBl}];
      topLeftImMat = [topLeftImMat; topLeftImAll{iBl}];
    end
    
    %             regionsDec = regionsDecInit';
    initCornersMat = cell2mat(initCornersCell0');
    
    %duplicate removal by looking at underlying MSER
    for fC=1:2
      floorOrCeil = 1-mod(fC,2);
      numDup = 1;
      if floorOrCeil
        [aa,indUniquePM1,indUniquePM2] = unique(floor(initCornersMat(:,1:2)/3.5)*3.5,'rows');
      else
        [aa,indUniquePM1,indUniquePM2] = unique(round(initCornersMat(:,1:2)/3.5)*3.5,'rows'); %increase this
      end
      countPM = accumarray(indUniquePM2,1); % Gives a histogram
      indDup0 = find(countPM>numDup); % If number of pixels > duplicate 
      indInValid0 = collectParallel(indDup0,indUniquePM2,initCornersMat,scMat,boundaryPartMat,numCores); %Make for for dSetRest
      if 0
        figure, imshow(img,[]), hold on, plot(initCornersMat(:,1),initCornersMat(:,2),'*');
        initCornersMat0 = initCornersMat; initCornersMat0(indInValid0,:)=[];
        figure, imshow(img,[]), hold on, plot(initCornersMat0(:,1),initCornersMat0(:,2),'*');
      end
      initCornersMat(indInValid0,:)=[]; %if you use indValid, you have to take into account points that don't have duplicates
      boundaryPartMat(indInValid0,:)=[]; maskCornerMat(indInValid0,:)=[]; scMat(indInValid0,:)=[];
      topLeftImMat(indInValid0,:)=[];
    end
    
    clear initCorners initCornerBlocks initCornersMatSortd indInitUnique indOutofBdry;
  end
  %% Loop over Init
  %fprintf('DuplicateClock: %f\n', toc(duplicateClock)/60);
  %loopClock = tic;
  if loopOver
    numCorners = size(initCornersMat,1);
    numDiv = ceil(numCorners/numCores);
    indDiv = 1:numDiv:numCorners; indDiv(end+1) = numCorners;
    %initCornersCell = cell(1, length(indDiv)-1);
    %boundaryPartCell = cell(1, length(indDiv)-1);
    %maskCornerCell = cell(1, length(indDiv)-1);
    %scCell = cell(1, length(indDiv)-1);
    %topLeftImCell = cell(1, length(indDiv)-1);
    
    for a = 2:length(indDiv)
      initCornersCell{a-1} = initCornersMat(indDiv(a-1):indDiv(a),:);
      boundaryPartCell{a-1} = boundaryPartMat(indDiv(a-1):indDiv(a));
      maskCornerCell{a-1} = maskCornerMat(indDiv(a-1):indDiv(a));
      scCell{a-1} = scMat(indDiv(a-1):indDiv(a));
      topLeftImCell{a-1} = topLeftImMat(indDiv(a-1):indDiv(a));
    end
    
    for split= 1:length(scCell)%parfor, make for for rest
      [cornersConv0{split}, maskConvSz0{split}, regionConv0{split}, scConv0{split}, boundaryConv0{split}, topLeftConv0{split}, maskConv0{split}] = getConvergedCorner2(initCornersCell{split},...
        boundaryPartCell{split},maskCornerCell{split}, scCell{split},topLeftImCell{split}, img,indBlock,imgnoInt,delta,split);
      %pass plusorminus and surrounding region area into getmAtas code.
    end
    
    cornersConv =cell2mat(cornersConv0');
    regionConv=[]; maskConvSz=[]; scConv=[];boundaryConv=[];topLeftConv=[];maskConv_={};
    
    rter = 0;
    for split=1:size(scConv0,2)
      regionConv = [regionConv regionConv0{split}]; maskConvSz = [maskConvSz maskConvSz0{split}];
      for i = 1:size(maskConv0{split},2),
        rter = rter+1;
        maskConv_{rter} = maskConv0{split}{i};
      end;
      scConv = [scConv scConv0{split}]; boundaryConv = [boundaryConv boundaryConv0{split}]; topLeftConv = [topLeftConv topLeftConv0{split}];
    end
    
    %need regions and block size for rep checking.
    [cornersConvSortd, indSorted] = sortrows(cornersConv,[1 2 13]); %is one with least strength better or least toggle dist better?
    [~,indUnique]= unique(round(cornersConvSortd(:,1:3).*100)./100,'rows'); %pick one with least variation
    %             fprintf('\n number of points before: %d and after unique: %d',size(cornersBlockMat,1),length(indUnique));
    indF = indSorted(indUnique);
    cornersConv = cornersConv(indF,:); regionConv = regionConv(indF); maskConvSz = maskConvSz(indF);
    scConv = scConv(indF); boundaryConv = boundaryConv(indF); topLeftConv = topLeftConv(indF);
    maskConv = {};
    
    for ind_ = 1:size(indF,1),
      maskConv{ind_} = maskConv_{indF(ind_)};
    end;
    
    %if 1               figure, imshow(img,[]), hold on, plot(cornersConv(:,1),cornersConv(:,2),'r*');
    %end
    %fprintf('Here\n');
  else
    cornersConv = initCornersMat;
    scConv = scMat;
    boundaryConv = boundaryPartMat;
    topLeftConv = topLeftImMat;
  end
  %fprintf('LoopClock: %f\n', toc(loopClock)/60);
  %restClock = tic;
  %% Overlap checking
  if dupRem
    if loopOver==0 & ifInit==0
      cornersBlockMat=[]; scConv=[]; boundaryConv=[]; regionConv=[]; maskConvSz=[];
    end
    [indFinal cornersFinal boundaryFinal maskFinal scFinal topLeftFinal] = overlapCheck(cornersConv,[ysize,xsize],nonLcsBasedOverErr,overErrMser,scConv,boundaryConv,regionConv,maskConvSz, maskConv, topLeftConv);%gets descriptor also
%    [indFinal cornersFinal boundaryFinal scFinal topLeftFinal] = overlapCheck2(cornersConv,[ysize,xsize],nonLcsBasedOverErr,overErrMser,scConv,boundaryConv,topLeftConv);%gets descriptor also
  end
  if 0
    hold on, plot(cornersFinal(1,:)',cornersFinal(2,:)','k*');
  end
  %fprintf('RestClock Profusely : %f\n',toc(restClock)/60.0);
end

