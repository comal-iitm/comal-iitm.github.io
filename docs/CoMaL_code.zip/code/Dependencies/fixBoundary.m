function fixBoundary

numFrames = 388;
pairsInit = reshape(1:2*numFrames,2,numFrames)';
indStereo = 1:2:numFrames;
pairs = pairsInit(indStereo,:); pairs(:,2) = pairs(:,2)+1;

for i=1:length(pairs)
    boundaryName = sprintf('../images/flow/boundary/boundary%d_%d.png',pairs(i,1),pairs(i,2));
    boundaryParts0 = im2bw(imread(boundaryName));
    outerBoundary = bwconvhull(boundaryParts0);
    seBig1 = strel('disk',10);    outerBoundary = imerode(outerBoundary,seBig1);
    boundaryParts = (boundaryParts0 & outerBoundary);
    if 0
        figure, imshow(boundaryParts)
    end
    imwrite(boundaryParts,boundaryName);
end
