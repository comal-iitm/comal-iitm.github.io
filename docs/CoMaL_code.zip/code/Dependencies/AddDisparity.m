function [f1New ysize xsize] = AddDisparity(file1,file2,i,harronmser)

resizefactor=1; whitePixelVal=1; %255; 
%change for cones
cones=1;
if cones
dispDivFactor = 4;
windSz=4; %1 and 4;
disparity = double(imread('./stereo/groundtruth.png')); %double(imread('./stereo/groundtruth.png')); %png and gif
    
else
dispDivFactor = 16;
windSz=1; %1 and 4;
disparity = double(imread('./stereo/groundtruth.gif')); %double(imread('./stereo/groundtruth.png')); %png and gif
end

%%%%%

% disparity = imresize(disparity,resizefactor);
occ = imread('./stereo/occ-depthdisc.png');
occ = imresize(occ,resizefactor);
[ysize,xsize] = size(occ);
boundaryParts = imread('./stereo/boundary2.png');%imread('./stereo/boundary2.png');
boundaryParts = im2bw(boundaryParts);
% boundaryParts = imresize(boundaryParts,resizefactor);
if 0 %cones
se = strel('disk',4);
boundaryParts = imdilate(boundaryParts,se);
end


if 0 %~mod(i,2)
    boundaryParts2 = zeros(ysize,xsize);
    [row col] = find(boundaryParts==whitePixelVal);
    for i1=1:length(row)
        colNew = round(col(i1) - (disparity(row(i1),col(i1))/dispDivFactor)); 
        if colNew>0
        boundaryParts2(row(i1),colNew) = whitePixelVal;
        
        end
    end
    
    %     se = strel('disk',3);
    %     boundaryParts2 = imdilate(boundaryParts2,se);
    %     se = strel('disk',6);
    %     boundaryParts2 = imerode(boundaryParts2,se);
    %
else
    boundaryParts2 = imread('./stereo/boundary22.png');%imread('./stereo/boundary2.png');
    boundaryParts2 = im2bw(boundaryParts2);
end

if cones
% se = strel('disk',1);
% boundaryParts = imerode(boundaryParts,se);
% se = strel('disk',2);
% boundaryParts2 = imerode(boundaryParts2,se);
end

f1 =loadFeatures(file1);
f2 =loadFeatures(file2);
if 1
    if harronmser
        f1 = [f1(1:2,:)./2; f1(3:5,:).*4; f1(6:7,:)];
        f1=f1';
        
        f2 = [f2(1:2,:)./2; f2(3:5,:).*4; f2(6:7,:)];
        f2=f2';
    else
        f1 = [f1(1:2,:)./2; f1(3:5,:).*4];
        f1=f1';
        
        f2 = [f2(1:2,:)./2; f2(3:5,:).*4];
        f2=f2';
    end
else
    f1=f1'; f2=f2';
end


f1New=[];
f1Round = floor(f1(:,1:2));

for j=1:size(f1Round,1)
    if mod(i,2)
        if boundaryParts(f1Round(j,2),f1Round(j,1))==whitePixelVal
            
            if 0
                %                 x = round(f1(j,2)/2); y= round(f1(j,1)/2);
                toadd = -disparity(f1Round(j,2),f1Round(j,1))/dispDivFactor; 
                f1disp = [f1(j,1)+toadd f1(j,2:end)];
                %     f1dispRound = round(f1disp(:,1:2));
            else
                xlim1 = max(1,f1Round(j,2)-windSz); ylim1 = max(1,f1Round(j,1)-windSz);
                xlim2 = min(f1Round(j,2)+windSz,ysize); ylim2 = min(f1Round(j,1)+windSz,xsize);
                try
                disparity_neigh = disparity(xlim1:xlim2,ylim1:ylim2);
                catch
                    aa=1;
                end
                disparity_neigh = unique(disparity_neigh);
                minvalLeast=1000; bestPt=[];
                for n=1:length(disparity_neigh)
                    toadd = -disparity_neigh(n)/dispDivFactor; 
                    f1disp = [f1(j,1)+toadd f1(j,2:end)];
                    
                    scale = sqrt(1/f1(1,3));
                    scaleArray = repmat(scale,4,size(f2,1));
                    feat1=[f1disp(1:5)'; scale; scale; scale; scale];
                    feat2=[f2(:,1:5)'; scaleArray];
                    [wout, twoutFull, dout, tdout]=c_eoverlap(feat1,feat2,1);
                    
                    minval = min(wout);
                    if minval<minvalLeast
                        minvalLeast = minval;
                        bestPt = f1disp;
                    end
                end
                
                
            end
            f1New = [f1New; bestPt];
        end
    else
        if boundaryParts2(f1Round(j,2),f1Round(j,1))==whitePixelVal
            
            toadd=0;
            f1disp = [f1(j,1)+toadd f1(j,2:end)];
            f1New = [f1New; f1disp];
        end
    end
end







if 0 %harronmser
    f1New=f1New';
    ptSize = size(f1New,2);
    sizeFeat = sqrt(1/f1New(3,1)).*ones(1,ptSize);
    [detPtsNoDup detPtsOrig]  = overlapCheck([f1New(1:2,:); sizeFeat; zeros(1,ptSize); sizeFeat; zeros(4,ptSize); f1New(7,:); zeros(2,ptSize); f1New(6,:)],[ysize,xsize],10,0); %some extra value
    %                 figure, imshow(imgPath);
    %                 [detPtsNoDup detPtsOrig]  = overlapCheck(detPtsOrig,[ysize,xsize],20,25); %some extra value
    detPtsNoDup = [detPtsNoDup; detPtsOrig(10,:)];
    
    f1New = detPtsNoDup';
    %     writeToFileTest(file1,detPtsNoDup',1,xsize,ysize,0);
    
end