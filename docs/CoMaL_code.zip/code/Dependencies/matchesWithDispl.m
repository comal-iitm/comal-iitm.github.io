function [matchingScore, numMatches, ...
          isValid, recall, prec, vidObj] = matchesWithDispl(dataset, detType, ...
                                                            desType, frameTuple, ...
                                                            delta, fgTypeCompB, ...
                                                            thresh, imSize, dSetNo, ...
                                                            fgBound, vidObj)

makeVideo=0;

switch desType
    case 'ssd', numIndex = 3;
    case 'sol', numIndex = 4;
    case 'sift', numIndex = 3;
end

%% Checking if groundtruth car even exists in the frame

imgDirPath = sprintf('../Images/%s', dataset);
matchesSavePath0 = sprintf('../data/results/matches-delta%d/%s', delta, dataset);
matchesSavePath = sprintf('%s/match%s_%d_%d_displ_full_%s.mat', ...
                          matchesSavePath0, detType, frameTuple(1), ...
                          frameTuple(2), desType);

gtPath = sprintf('%s/groundtruth.mat', imgDirPath);
gt = load(gtPath); 

B = 3; isValid = 1; 
if dSetNo == 6
    
    groundtruth1 = gt.tracklets{frameTuple(1)};
    groundtruth2 = gt.tracklets{frameTuple(2)};
    
    B = 1;
    if isempty(groundtruth1) | isempty(groundtruth2)
        isValid = 0;
    else
        isValid = 1; 
    end

end

if dSetNo == 10
    
    groundtruth1 = gt.groundtruth{frameTuple(1)-147};
    groundtruth2 = gt.groundtruth{frameTuple(2)-147};
    
    B = 3;
    if isempty(groundtruth1) | isempty(groundtruth2)
        isValid = 0;
    else
        isValid = 1; 
    end

end

if dSetNo == 11
    
    groundtruth1 = gt.groundtruth{frameTuple(1)};
    groundtruth2 = gt.groundtruth{frameTuple(2)};
    
    B = 3;
    if isempty(groundtruth1) | isempty(groundtruth2)
        isValid = 0;
    else
        isValid = 1; 
    end

end

matchingScore = zeros(B, 1);
numMatches = zeros(B, 1);
recall = zeros(B, 1); 
prec = zeros(B, 1);

%% open matches and get points coordinates from indices
if 1, %~exist(strcat(matchesSavePath),'file') % condition for running things fresh
    matchDisplStr = ''; dilVal = 4; deltaDisp = 15; %for 2 frames
    [featMatch1, ...
     featMatch2, ...
     matchesFull, ...
     flagFileFault, ...
     feat1, feat2] = getFeatFromMatch(dataset, detType, ...
                                                     desType, frameTuple, ...
                                                     delta, matchDisplStr, ...
                                                     fgTypeCompB, thresh, numIndex);
  
    if ~flagFileFault,
        
        if dSetNo == 6,
            
            [matchFinal0, totValidPts] = compareDispl(featMatch1, featMatch2, ...
                                                     matchesFull, frameTuple, ...
                                                     dataset, dilVal, ...
                                                     deltaDisp, imSize);
            matchFinal{1} = matchFinal0;
        
        elseif dSetNo == 10 || dSetNo == 11
            
            
            %deltaDisp = 10; 
            [matchFinal, totValidPts] = compareDisplKine(featMatch1, featMatch2, ...
                                                          matchesFull, frameTuple, ...
                                                          dataset, dilVal, fgBound, ...
                                                          deltaDisp, imSize);
        else
            
            %deltaDisp = 10; 
            [matchFinal, totValidPts] = compareDisplCoMiC(featMatch1, featMatch2, ...
                                                          matchesFull, gt.gt, ...
                                                          frameTuple, fgBound, ...
                                                          deltaDisp, dataset);
        
        end
        % scores
        % numMatches = size(matchFinal,1); matchingScore = (numMatches / size(feat2,2))*100; %check correctness
        for b=1:B,
            
            numMatches(b, 1) = length(unique(matchFinal{b}(:, 2:end), 'rows'));
            matchingScore(b, 1) = (numMatches(b) / size(feat2, 2))*100; %check correctness

            %  save(matchesSavePath,'matchFinal'); % for tsuk don't save
            if ~isempty(totValidPts) & totValidPts ~= 0,
                
                recall(b, 1) = numMatches(b)/ size(feat1, 2); 
                prec(b, 1) = numMatches(b)/totValidPts(b); %make recall more precise
            
            else
                
                recall(b, 1) = 0; prec(b, 1) = 0; %this happens only for dsetno=6 case
            
            end
            
        end
        
    end
    
else
    m = load(matchesSavePath);
  
    dSetNo = getParamsAndDataset(dataset);
    dilVal= 10; matchDisplStr = '_displ';
    [featMatch1, featMatch2, matchesFull, ...
    flagFileFault, feat1, feat2] = getFeatFromMatch(dataset, detType, ...
                                                     desType, frameTuple, ...
                                                     delta, matchDisplStr, ...
                                                     fgTypeCompB, thresh, numIndex);
  
    imgnoStr1 = getImgnoInStrOrInt(frameTuple(1), dSetNo);
  
    % numMatches = size(m.matchFinal,1); matchingScore = (numMatches / size(feat2,2))*100; %check correctness
    numMatches = length(unique(m.matchFinal(:, 2:end), 'rows'));
    matchingScore = (numMatches / size(feat2, 2))*100; %check correctness
  
    if ~isempty(featMatch2)
        
        recall = numMatches/size(feat1, 2);
        prec = numMatches/size(featMatch2, 2); %make recall more precise
    
    else
        recall = 0; prec=0;
    end
end

if 0,
    
    dSetNo = getParamsAndDataset(dataset);
    imgnoStr1 = getImgnoInStrOrInt(frameTuple(1), dSetNo);
    imgnoStr2 = getImgnoInStrOrInt(frameTuple(2), dSetNo);
  
    imgPath = sprintf('../images/%s/img%s.ppm', dataset, imgnoStr1);
    img1 = imread(imgPath);
    imgPath = sprintf('../images/%s/img%s.ppm', dataset, imgnoStr2);
    img2 = imread(imgPath);
    color = rand(size(matchFinal, 1), 3); colorF = color;
  
    figure,imshow(img1); hold on;
    showellipticfeaturesSPL(feat1(:, matchFinal(:, 1))', colorF, 5, 0, 1, img1);
    figure,imshow(img2); hold on;
    showellipticfeaturesSPL(feat2(:,matchFinal(:,2))', colorF, 5, 0, 1, img2);
  
end
%% separating detections at boundary
% if dSetNo==1
%   if featFG(frameTuple(1))>0
%     indFeatPres=1;
%     delta=5;dilvalCompB=4;
%     [~, numMatchesNFrames(1), numMatchesNFrames(2), numMatchesNFrames(3)] = boundNonMatches2(frameTuple(end),dataset,delta,dilvalCompB,detType,together(:,end));
%     [~, numInit(1), numInit(2), numInit(3)] = boundNonMatches2(frameTuple(1),dataset,delta,dilvalCompB,detType,[]);
%
%     matchingScoreNFrames = (numMatchesNFrames./numInit)*100;%size(f1,2)*100; %could divide by initial detected points (before matching)
%
%   else
%     indFeatPres=0;
%   end
%
% else
%   ptFile = sprintf('../data/results/feat-delta%d/%s/img%d.%s.txt',delta,dataset,frameTuple(fr),detType);
%   try    feat = loadFeatures(ptFile); %subtraction has to be done here before display
%   catch
%     return;
%   end
%   matchingScoreNFrames = (numMatchesNFrames./size(feat,2))*100;
%   indFeatPres=1;
% end

%% Recording video - can be cut down
if makeVideo
    
    savePath = sprintf('../data/figs-delta%d/%s', delta, dataset);
    if ~exist(savePath,'dir') mkdir(savePath);  end
    close all; %color = rand(size(200,1),3);  %   color = rand(size(featMatch1,2),3); colorF = color;
    
    switch desType
        
        case 'ssd', desTypeStr = 'ssd';
        case 'sol', desTypeStr = 'nsd';
        case 'sift', desTypeStr = 'sift';
    
    end

    switch detType
        
        case 'harronmser',
            detTypeStr = 'CoMiC';
        case 'har',
            detTypeStr = 'Harris';
        case 'hes',
            detTypeStr = 'Hessian';
        case 'msr',
            detTypeStr = 'MSER';
        case 'fas',
            detTypeStr = 'FAST';
    
    end

    movName = sprintf('%s/matches_%s_%s.avi', savePath, detTypeStr, desTypeStr);%fgTypeCompB);
    if isempty(vidObj) vidObj = VideoWriter(movName);open(vidObj); end
  
    [~,indUnique] = unique(matchesFull(:, 2:end), 'rows');
  
    if frameTuple(1) == 1
        
        featMatch1Uniq = featMatch1(:, indUnique);
        imfr = getFeatPlotOnImage(frameTuple(1), dataset, featMatch1Uniq);
        imfr = imresize(imfr, 0.25);
        writeVideo(vidObj, imfr);
    
    end
  
    featMatch2Uniq = featMatch2(:, indUnique);
    imfr = getFeatPlotOnImage(frameTuple(2), dataset, featMatch2Uniq);
    imfr = imresize(imfr, 0.25);
    writeVideo(vidObj, imfr);
    %mpgwrite(mov,C,movName,[1, 0, 1, 0, 10, 1, 1, 1]);winopen(movName.avi)
  
end
end

function imfr = getFeatPlotOnImage(frameTuple, dataset, featMatch)
dSetNo = getParamsAndDataset(dataset);
imgnoStr = getImgnoInStrOrInt(frameTuple, dSetNo);
imgPath = sprintf('../images/%s/img%s.ppm', dataset, imgnoStr);
img = imread(imgPath);

if ~isempty(featMatch)
    
    colorF = repmat([0 0.85 0.85], size(featMatch, 2), 1);
    imfr  = showellipticfeaturesSPL(featMatch', colorF, 5, 0, 0, img);
    [szX, szY, dummy] = size(img);
    imfr = imfr(1:szX, 1:szY, :);

else
    
    imfr = img;

end
end