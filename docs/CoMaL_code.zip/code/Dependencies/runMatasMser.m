function [boundaryVals, regionsDec, strength, plusOrMinus] = runMatasMser(subBlockOrImPath,theta,delta,iter,t,plusOrMinus,indBlockAll,indBlockSzAll) %resizefactor

commonVar  = globalVariables(t);
boundaryVals=[];

if iter
    subBlock = subBlockOrImPath;
    sizeImg = size(subBlock);
    imgFormatd = uint8(subBlock)'; sizeImg(3) = 1;
    
    [regions strength] = extremaExptIter(imgFormatd,sizeImg,theta,delta,plusOrMinus); %boundaryValsPlus boundaryValsMinus 
        
    if ~isempty(regions)
        %regionsDec  = decodeRLE(regions);
        regionsDec = regions;
    else
        regionsDec = [];
    end
    
    for ind=1:length(regionsDec) % This loop eliminates the region points which have negative or 0 entries
        %[~,colNo] = find(regionsDec{ind}<=0);
        %regionsDec{ind}(:,colNo) = [];
        sel = uint32(sub2ind(sizeImg, regionsDec{ind}(1,:), regionsDec{ind}(2,:)));
        
        if 0 %some testing of packing into regions is happening right
            mask = zeros(149,149); mask(sel)=1;
            sel = uint32(sub2ind([51 51], regionsDec{ind}(1,:), regionsDec{ind}(2,:)));
            %         sel = uint32(sub2ind([51 51], regionsDec{ind}(1,:)+1, regionsDec{ind}(2,:)+1));
            %         sel = uint32(sub2ind([50 50], regionsDec{ind}(1,:), regionsDec{ind}(2,:)));
            for ii=1:size(regionsDec{ind},2)
                mask(regionsDec{ind}(1,ii),regionsDec{ind}(2,ii)) = 1;
            end
        end
        regionsDec{ind} = sel;
    end
    
else
    boundaryVals={}; regionsDec=cell(size(indBlockAll,1)); strength=cell(size(indBlockAll,1)); plusOrMinus =cell(size(indBlockAll,1));
    %boundaryVals={}; regionsDec={}; strength={}; plusOrMinus ={};
    imgPath = subBlockOrImPath;
%     subBlockCell = subBlockOrImPath;
    %img = imread(imgPath);
    load(imgPath); %Load the image which was stored earlier
    %if ~strcmp(imgPath(end-2:end),'pgm')
    %    img = rgb2gray(img);
    %end
    
    %img = uint32(img);
    %img = BoundaryGaussianSmoothing_2D(img,2); %scale/3
%     img = imresize(img,resizefactor);
    
    for i1=1:size(indBlockAll,1)
%           subBlock = subBlockCell{i1};
        indBlock = indBlockAll{i1}; %The location of the image block
        indBlockSz = indBlockSzAll{i1}; %The size of the image block
        topIm = indBlock(2); bottomIm= indBlock(2)+indBlockSz(2)-1;
        leftIm= indBlock(1); rightIm= indBlock(1)+indBlockSz(2)-1;
        subBlock = img(topIm:bottomIm,leftIm:rightIm); %Obtain the image block
        sizeImg = size(subBlock); 
        imgFormatd = uint8(subBlock)'; sizeImg(3) = 1; %Some formatted image? 
        
        %strength has 1st var as the margin and 2nd var as the threshold
        
        %{
        [regionsPlus regionsMinus strengthPlus strengthMinus] = extremaExpt(imgFormatd,sizeImg,delta); %boundaryValsPlus boundaryValsMinus 
%         boundaryVals{i1} = [boundaryValsPlus boundaryValsMinus];
        %The regions are in the RLE format
        regions = [regionsPlus regionsMinus]; %Concatenate the plus and minus regions
        strength{i1} = [strengthPlus strengthMinus]; 
        plusOrMinus{i1} = [ones(size(regionsPlus,2),1); zeros(size(regionsMinus,2),1)];
        %}
        [regions, strength_, plusOrMinus_] = extremaExpt(imgFormatd,sizeImg,delta); %boundaryValsPlus boundaryValsMinus
        strength{i1} = strength_;
        plusOrMinus{i1} = plusOrMinus_;
        if ~isempty(regions)
             %regionsDec1  = decodeRLE(regions_temp); %This decode the RLE to another normal format of regions specification
             regionsDec0 = regions;
        else
            regionsDec0 = [];
        end
        
        for ind=1:length(regionsDec0)
            %[~,colNo] = find(regionsDec0{ind}<=0);
            %regionsDec0{ind}(:,colNo) = [];
           
            sel = uint32(sub2ind(sizeImg, regionsDec0{ind}(1,:), regionsDec0{ind}(2,:)));
            
            regionsDec0{ind} = sel;
            
        end
        regionsDec{i1} = regionsDec0;
        
    end
    
end
%%

commonVar.displayflag=0;
if commonVar.displayflag
    if 1 %some testing of packing into regions is happening right
        sz0 =  round(commonVar.sigSminInit*commonVar.iterBlockFactor/5)*5;
        sz = round(sz0*commonVar.blockMultFactor);%block size
        
        indTest = 8;
        mask = zeros(sz+1,sz+1); mask(regionsDec{indTest})=1; figure, imshow(mask);
        %         mask = zeros(sz,sz); mask(regionsMinus{indTest})=1;figure, imshow(mask);
        
        sel = uint32(sub2ind([51 51], regionsDec{ind}(1,:), regionsDec{ind}(2,:)));
        %
    end
    figure, imshow(img,[]), hold on,
    for i=1:length(boundaryVals)
        plot(boundaryVals{i}(2,:), boundaryVals{i}(1,:),'.');
    end
end
commonVar.displayflag=0;

% extremaExpt(img);