function PIP2 = FindMinCorner(a, circflag,t)

commonVar = globalVariables(t);
%smoothing

MomScaleFactor = 1;
sxl2 = 1; %constant changed
%for scale change
sxi2 = sxl2;
szpt=15; %window size
%end

x= a(:,2);
y= a(:,1);

sxM2 = MomScaleFactor*sxl2;
indices=[];   corval=[];
% compute scale-normalised second order matrix
x0=BoundaryGaussianSmoothing(x,1*sxl2,circflag,t);
y0=BoundaryGaussianSmoothing(y,1*sxl2,circflag,t);

xMean=BoundaryGaussianSmoothing(x0,sxi2,circflag,t);
yMean=BoundaryGaussianSmoothing(y0,sxi2,circflag,t);

% x1=x0-xMean(idx);
% y1=y0-yMean(idx);

x02=(x0.*x0);
y02=(y0.*y0);
x0y=(x0.*y0);

x02weighted=BoundaryGaussianSmoothing(x02,sxi2,circflag,t);
y02weighted=BoundaryGaussianSmoothing(y02,sxi2,circflag,t);
x0yweighted=BoundaryGaussianSmoothing(x0y,sxi2,circflag,t);

xm2weighted=(x02weighted-(xMean.^2));
ym2weighted=(y02weighted-(yMean.^2));
xmyweighted=(x0yweighted-(xMean.*yMean));

% more smoothing for the moment matrix computation

xMeanM=BoundaryGaussianSmoothing(x0,sxM2,circflag,t);
yMeanM=BoundaryGaussianSmoothing(y0,sxM2,circflag,t);

% x1=x0-xMean(idx);
% y1=y0-yMean(idx);

x02M=(x0.*x0);
y02M=(y0.*y0);
x0yM=(x0.*y0);

x02weightedM=BoundaryGaussianSmoothing(x02M,sxM2,circflag,t);
y02weightedM=BoundaryGaussianSmoothing(y02M,sxM2,circflag,t);
x0yweightedM=BoundaryGaussianSmoothing(x0yM,sxM2,circflag,t);

xm2weightedM=(x02weightedM-(xMeanM.^2));
ym2weightedM=(y02weightedM-(yMeanM.^2));
xmyweightedM=(x0yweightedM-(xMeanM.*yMeanM));


detC=(xm2weighted.*ym2weighted)-(xmyweighted.^2);
trace2C=(xm2weighted+ym2weighted).^2;

cimg=detC./trace2C;


cor_xy_sig =(abs(cimg))';


% above code copied from intpointdet


szpt=(szpt-1)/2; aa=[]; pt=size(cor_xy_sig,2);
if circflag
    cor_xy_sig=[cor_xy_sig(:,end-szpt+1:end) cor_xy_sig cor_xy_sig(:,1:szpt)]; %appending
%     cor_xy_sig = round(cor_xy_sig.*(10^10))./(10^10);
    pt=size(cor_xy_sig,2);
end

for j=szpt+1:pt-szpt
    if min(cor_xy_sig(j-szpt:j+szpt))==cor_xy_sig(j) %checking if point is a local minima in the window
        aa=[aa; j cor_xy_sig(1,j)];%%%%%%
    end
end

[minCorVal,minInd] = min(aa(:,2));
if minCorVal==0
    indZero = find(aa(:,2)==0);
    midInd = round(length(indZero)/2);
    minInd = indZero(midInd);
end
aa = aa(minInd,:);

%collecting points in aa (from cor_xy_sig) that have cor<0.5
PIP2=[];
if circflag
    diffSize = -szpt;
else
    diffSize = (length(x) - length(cimg))/2;
end
for i=1:size(aa,1)
    if 1%aa(i,3)<0.06
        ind=aa(i,1);
        %In the case when source in unCut but corxysig is larger in size due to szpt padding~Swarna
        indAdj= ind + diffSize;
        %            covMatInv = inv([cor_xy(m,3,aa(i,1)) cor_xy(m,4,aa(i,1)); cor_xy_M(m,4,aa(i,1)) cor_xy_M(m,5,aa(i,1))]);
        PIP1=[a(indAdj,2) a(indAdj,1) indAdj];% sigSmat(aa(i,1)) covMatInv(1,1) covMatInv(1,2) covMatInv(1,2) covMatInv(2,2) m]; %aa(i,3) has cor valu for that point
        PIP2=[PIP2; PIP1];
    end
end
if isempty(PIP2)
    PIP2=[0 0];
else
    PIP=[PIP2(:,2),PIP2(:,1)];
    
    if commonVar.displayflag
        I=double(dilated); %Warning: not passed anymore
        Size_PI=size(PIP,1);
        for r=1: Size_PI
            a = round(PIP(r,1));
            b = round(PIP(r,2));
            I(a-2:a+2,b-2)=0.5;
            I(a-2:a+2,b+2)=0.5;
            I(a-2,b-2:b+2)=0.5;
            I(a+2,b-2:b+2)=0.5;
        end
        
        figure, imshow(I);
    end
end
