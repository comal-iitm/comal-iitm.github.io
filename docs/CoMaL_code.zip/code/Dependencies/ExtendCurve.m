function [xExt yExt] = ExtendCurve(x,y,ifstart,numExtPts)

ws = warning('off','all'); 
[polyNew] = polyfit(x,y,2); %change one and end %,S,mu
warning(ws);

if ~all(isfinite(polyNew))
    polyNew = polyfit(x,y,1);
end

% ws = warning('off','all');  % Turn off warning
% P = polyfit(x,y,N);
% warning(ws)  % Turn it back on.
 

if all(isfinite(polyNew))    
    
    slopeNew = polyNew(1); interceptNew = polyNew(2);
    if ifstart
        diffValSign = sign(x(1) - x(end));
    else
        diffValSign = sign(x(end) - x(1));
    end
    
    if abs(slopeNew) < 100
        fac = 1/ceil(abs(slopeNew)^2);
    else
        fac = 1;
    end

    if ifstart
        xExt = x(1):diffValSign*fac:x(1)+(diffValSign*fac*numExtPts);
    else
        xExt = x(end):diffValSign*fac:x(end)+(diffValSign*fac*numExtPts);
    end
    
    % yExt = polyval([slopeNew,interceptNew],xExt);
    yExt = polyval(polyNew,xExt); %S,mu
    
else
    xExt = []; yExt=[];
end