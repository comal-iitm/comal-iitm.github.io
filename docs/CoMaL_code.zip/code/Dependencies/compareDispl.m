function [matchFinal totValidPts] = compareDispl(featMatch1,featMatch2,matchesFull,frameTuple,dataset,dilVal,deltaDisp,imSize)

ifExact=0;matchFinal=[];matchFinalExact=[]; totValidPts=0;
deltaDispBy2 = deltaDisp/2; 

dSetNo = getParamsAndDataset(dataset); 
imgnoStr1= getImgnoInStrOrInt(frameTuple(1),dSetNo);

if dSetNo == 10
    [~,~,gtAll1, featByBB1, featIndBB1, gtObjId1] = getFgBBkine(featMatch1', dataset, imgnoStr1, dilVal,'',imSize);
else
    [~,~,gtAll1, featByBB1, featIndBB1, gtObjId1] = getFgBB(featMatch1', dataset, imgnoStr1, dilVal,'',imSize);
end

imgnoStr2 = getImgnoInStrOrInt(frameTuple(2),dSetNo);

if dSetNo == 10
    [~,~,gtAll2, featByBB2, featIndBB2, gtObjId2] = getFgBBkine(featMatch2', dataset, imgnoStr2, dilVal,'',imSize);
else
    [~,~,gtAll2, featByBB2, featIndBB2, gtObjId2] = getFgBB(featMatch2', dataset, imgnoStr2, dilVal,'',imSize);
end

if 0 %display
  imgPath = sprintf('../images/%s/img%s.ppm',dataset,imgnoStr1);  img1 = imread(imgPath);
  imgPath = sprintf('../images/%s/img%s.ppm',dataset,imgnoStr2);  img2 = imread(imgPath);
  color = rand(size(featMatch1,2),3); colorF = color;
  figure,imshow(img1); hold on; showellipticfeaturesSPL(featMatch1',colorF,5,0,1,img1);
  figure,imshow(img2); hold on; showellipticfeaturesSPL(featMatch2',colorF,5,0,1,img2);
  
  text(featMatch(1,:)+3,featMatch(2,:)+3,num2str(m2.matchFinal(:,frD-1)),'FontSize',10,'Color','w')
end

[commonId commonIdInd1 commonIdInd2]= intersect(gtObjId1,gtObjId2);
for cId=1:length(commonId)
  numObj1 = commonIdInd1(cId); numObj2 = commonIdInd2(cId);
  
  if gtObjId1(numObj1) == gtObjId2(numObj2)
    [indCommonBB] = intersect(featIndBB1{numObj1},featIndBB2{numObj2}); %check what these are. Maybe it must go to feat.
    totValidPts = length(indCommonBB) + totValidPts;
    if ~ifExact
      dispPts = abs(featMatch1(1:2,indCommonBB) - featMatch2(1:2,indCommonBB));
      %     mean(dispPts,2); std(dispPts(:,1)); std(dispPts(:,2)) %get some
      %     statistics as additional checking
      dispGt = abs(gtAll1{numObj1}(5:6) - gtAll2{numObj2}(5:6));%/2;
      indMatch = find(dispPts(1,:) <= (dispGt(1)+deltaDisp) & dispPts(2,:) <= (dispGt(2)+deltaDisp)); %only these are matches
      
      matchFinal=[matchFinal; matchesFull(indCommonBB(indMatch),:)]; % indMatchExact
      [matchFinal indUnique] = unique(matchFinal,'rows');
      %     if numObj1>1 && length(indCommonBB(indMatch)) >10 aaaa=1; end % checking
    else
      dispPtsExact = featMatch1(1:2,indCommonBB) - featMatch2(1:2,indCommonBB);
      dispGtExact = (gtAll1{numObj1}(5:6) - gtAll2{numObj2}(5:6))/2;
      indMatchExact = find(dispPtsExact(1,:) <= (dispGtExact(1)+deltaDispBy2) & dispPtsExact(1,:) >= (dispGtExact(1)-deltaDispBy2) ...
        & dispPtsExact(2,:) <= (dispGtExact(2)+deltaDispBy2) & dispPtsExact(2,:) >= (dispGtExact(2)-deltaDispBy2)); %only these are matches
      matchFinalExact=[matchFinalExact; matchesFull(indCommonBB(indMatchExact),:)];
      [matchFinalExact indUnique] = unique(matchFinalExact,'rows');
      matchFinal = matchFinalExact;
    end
    
  end
  
  if 0 %display
  imgPath = sprintf('../images/%s/img%s.ppm',dataset,imgnoStr1);  img1 = imread(imgPath);
  imgPath = sprintf('../images/%s/img%s.ppm',dataset,imgnoStr2);  img2 = imread(imgPath);
  color = rand(size(featMatch1,2),3); colorF = color;
  figure,imshow(img1); hold on; showellipticfeaturesSPL(featMatch1(:,indCommonBB(indMatch))',colorF,5,0,1,img1);
  figure,imshow(img2); hold on; showellipticfeaturesSPL(featMatch2(:,indCommonBB(indMatch))',colorF,5,0,1,img2);
  
  if 0 %iccv fig      
        figure,imshow(img1); hold on; showellipticfeaturesSPL(featMatch1(:,indCommonBB(indMatch))',colorF,5,0,1,img1);
        numPt = 2; [x y] = ginput(numPt);
        featM1 = featMatch1(:,indCommonBB(indMatch));
        featM2 = featMatch2(:,indCommonBB(indMatch));
        for i=1:numPt
            [~,indRem(i)] = closestPt([x(i) y(i)],featM1(1:2,:)',1);
        end
        featM1= featM1(:,indRem); featM2 = featM2(:,indRem);
%         featM1(:,indRem)=[]; featM2(:,indRem)=[];
        color = rand(numPt,3); colorF = color;
        fig1 = showellipticfeaturesSPL(featM1',colorF,5,0,0,img1);
        fig2 =showellipticfeaturesSPL(featM2',colorF,5,0,0,img2);
        figure,imshow(fig1); figure,imshow(fig2); 
  end
  
  figure,imshow(img1); hold on; showellipticfeaturesSPL(featMatch1(:,indCommonBB(indMatchExact))',colorF,5,0,1,img1);
  figure,imshow(img2); hold on; showellipticfeaturesSPL(featMatch2(:,indCommonBB(indMatchExact))',colorF,5,0,1,img2);
  
  %checking
  figure,imshow(img1); hold on; showellipticfeaturesSPL(feat1(:,matchFinal(:,1))',colorF,5,0,1,img1);
  figure,imshow(img2); hold on; showellipticfeaturesSPL(feat2(:,matchFinal(:,2))',colorF,5,0,1,img2);
  
  end

end




end