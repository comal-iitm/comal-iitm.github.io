function [matchMat featMatch1 featMatch2 match] = matchDescriptors(des1,des2,mean_dist_1, mean_dist_2,boundaryPtsAll1,boundaryPtsAll2,f1,f2,img1,img2)

featMatch1=[]; featMatch2=[];
debug = 0;
r=1; k=1; % annealing rate
beta_init=1;  % initial regularization parameter (normalized)
match=[];
distThresh = 50;
matchMat = 10000*ones(size(des1,2),size(des2,2));

%Use this if you are searching for a match in a neighbourhood
% f1=f1'; f2=f2'; Gaussian weighting
for i = 1 : size(des1,2)
    [distVals ,indClose] = closestPt(f1(i,:), f2,1,60);
    ind0 = find(distVals < distThresh);
    indClose = indClose(ind0);
    des2Close = des2(indClose);
    sc_cost = getbestMatch(des1{i},des2Close);
    [minSc1 minInd1] = min(sc_cost);
    [sc_costSorted indBest] = sort(sc_cost);
    
%     sc_cost1 = getbestMatch(des2Close{minInd1},des1);
%     [minSc2 minInd2] = min(sc_cost1);
%     costmat=hist_cost_2(des1{i},des2{minInd}); % compute pairwise cost between all shape contexts
        
    if minSc1 < 0.05 %& minInd2==i
%         indBest(1:10)
%         matchMat(i,minInd) = minSc; %check range of dot prods
        matchCell{i} = indClose(minInd1);
        featMatch1 = [featMatch1; f1(i,:)];
        featMatch2 = [featMatch2; f2(indClose(minInd1),:)];
    else
        matchCell{i} = 0;
    end
    
    if 0 %debug
        idx1 = i; %i;
        idx2 = indClose(indBest(2)); 4;%minInd1; indBest(3);%minInd1; %201
        
        image1 = rgb2gray(imread(img1));
        image2 = rgb2gray(imread(img2));
        figure, imshow(image1), hold on, plot(boundaryPtsAll1{idx1}(:,2),boundaryPtsAll1{idx1}(:,1));
        figure, imshow(image2), hold on,
        plot(boundaryPtsAll2{idx2}(:,2),boundaryPtsAll2{idx2}(:,1));
        
    end
    
end

matchMat = cell2mat(matchCell);
indMatch1 = find(matchMat);
match(2,:)  = matchMat(indMatch1);
match(1,:) = indMatch1;

if 0
    matchMatFinal = zeros(size(des1,1),size(des2,1));
    minVal = 0;
    while 1
        minValNew  = min(min(matchMat));
        if minValNew > 100
            break;
        end
        [mini minj] = find(matchMat==minValNew);
        matchMat(mini,:) = 10000;
        matchMat(:,minj) = 10000;
        matchMatFinal(mini(1),minj(1)) = minValNew;
        minVal = minValNew;
        featMatch1 = [featMatch1; f1(mini(1),:)];
        featMatch2 = [featMatch2; f2(minj(1),:)];
        
    end
end

end


function sc_cost = getbestMatch(des1Eg,des2)

for j=1:size(des2,2)
        %     diff = sqrt(sum((repmat(des1(i,:),size(des2,1),1) - des2).^2,2));        % Computes vector of dot products
        costmat=hist_cost_2(des1Eg,des2{j}); % compute pairwise cost between all shape contexts
        % calculate shape context cost
        [a1,b1]=min(costmat,[],1);
        [a2,b2]=min(costmat,[],2);
        sc_cost(j) =max(mean(a1),mean(a2));        
end
    
end