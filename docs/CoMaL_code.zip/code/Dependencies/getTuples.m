function Tuples = getTuples(dirPath, fmt)


dirData = dir(dirPath);
Tuples = [];
for i=1:size(dirData,1),
    if (regexpi(dirData(i).name, strcat('img(?:[0-9])+.', fmt)) ~= 0)
        Tuples = [Tuples; dirData(i).name];
    end;
end;
