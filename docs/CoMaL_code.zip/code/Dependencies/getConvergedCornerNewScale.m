function [cornersAll cornersAllOrig boundaryNewTransAll regionsFinal blockSzFinal topLeftFinal plusOrMinusFinal] = getConvergedCornerNewScale(cornersInitAll,regionDecAll,plusOrMinusAll,imgPath,boundaryAll,circFlagList,t,resizefactor,splitNo,MaxOrMinScaleFlag) %boundaryAll not in parfor method1 method2, as op imgPath


commonVar = globalVariables(t);
cornersAll = []; cornersAllOrig=[]; boundaryNewTrans=[]; regionsFinal=[]; blockSzFinal=[]; topLeftFinal=[]; plusOrMinusFinal=[];boundaryNewTransAll={};
iter=1; maxIterPt=10; maxIterScale=10; numConv=1;

if ~isempty(cornersInitAll)
    scale = cornersInitAll(1,3)/commonVar.smoothingFactor;
    img = imread(imgPath);
    if ~strcmp(imgPath(end-2:end),'pgm')
        img = rgb2gray(img);
    end
    
    img = uint32(img);
    img = BoundaryGaussianSmoothing_2D(img,2); %scale/3
    img = imresize(img,resizefactor);
    
    [imBlocksAll,indBlockAll,indBlockSzAll] = getAllblocks(img,scale,t);
    
    corRows = size(cornersInitAll,1);
    totalLoop=0;
    
    for cornerIdx = 1:corRows
        %     fprintf('\n\n\n  %d %d\n\n\n\n\n',cornerIdx,splitNo);
        times=0; %for debugging
        cornerOld = cornersInitAll(cornerIdx,:);
        blockNo = cornersInitAll(cornerIdx,11);
        indNo = cornersInitAll(cornerIdx,12);
        thresh = cornersInitAll(cornerIdx,14);
        variationMetric = cornersInitAll(cornerIdx,13); %not needed as of now
        bNo = cornersInitAll(cornerIdx,15);
        octaveIdx = cornersInitAll(cornerIdx,17); %store in corner and bring in from there in future
        
        imBlock = imBlocksAll{blockNo};
        indBlock = indBlockAll{blockNo};
        indBlockSz = indBlockSzAll{blockNo};
        %     boundaryOld = boundaryOld';
        if 0
            regionCur = regionDecAll{blockNo}{indNo};
            plusOrMinus = plusOrMinusAll{blockNo}(indNo);
        else
            regionCur = regionDecAll{cornerIdx};
            plusOrMinus = plusOrMinusAll(cornerIdx);
            circflag = circFlagList(cornerIdx);
            
        end
        if 1 %~commonVar.isparfor
            boundaryOld = boundaryAll{cornerIdx}; %{blockNo}{indNo}{bNo};
            boundaryOld(:,1:2) =  boundaryOld(:,1:2)+ repmat([indBlock(2)-1 indBlock(1)-1],size(boundaryOld,1),1) ;
        end
        
        cornerOld(:,1:2) =  cornerOld(:,1:2); %- (indBlock - 1);
        
        maskPrev = zeros(indBlockSz(1),indBlockSz(2)); maskPrev(regionCur) =1; %mask must also be changed
        %     if plusOrMinus==0
        %         maskPrev = 1 - maskPrev;
        %     end
        topPrev = indBlock(2); leftPrev = indBlock(1);
        corLeftPrev=[]; corRightPrev=[];corLeft=[]; corRight=[];
        
        numIter = 0; corMovt= 50; cornerNewTrans=[]; numLoop=0; sxi2Init = cornerOld(3);
        regionsCloseAllIter=[];cornerNewTransAllIter=[]; corMovtAllIter=[];variationAllIter=[];minMserDistAllIter=[];threshAllIter=[];
        boundaryNewTransAllIter=[]; bNoNewAllIter=[];topLeftFinalAllIter=[];szSubBlockAllIter=[];
        scaleIter=0;bestScaleMultiplier=0.1;
        
        numIter = 0; corMovt= 50; cornerNewTrans=[];
        iSz = cornerOld(3)/commonVar.smoothingFactor; %commonVar.sigSmin(octaveIdx);
        
        % 1.3*scale is the maximum limit to set of scales compared at
        % laplacian computation. 3*sigma is amount of smoothing required to
        % find the above.
        %          rangeVal = round(cornerOld(3)/commonVar.smoothingFactor*commonVar.iterBlockFactor/5)*5;
        
        while corMovt > 0 && numIter < maxIterPt
            cornerNew = []; cornerNewTrans = [];
            
            [~, regionsClose, variation, top, left, minMserDist,thresh,~,szSubBlock] = getCorCentBlockAndMserInd(cornerOld,boundaryOld,circflag,imBlock,maskPrev,plusOrMinus,img,indBlock,[topPrev leftPrev],t);%[subBlock, regionsClose, variation, top, left, minMserDist,thresh,maskBlock];
            regionsCloseCell = {regionsClose};
            regionsCloseAllIter = [regionsCloseAllIter; regionsCloseCell];
            variationAllIter = [variationAllIter; variation];
            minMserDistAllIter = [minMserDistAllIter; minMserDist];
            threshAllIter = [threshAllIter; thresh];
            szSubBlockAllIter = [szSubBlockAllIter;szSubBlock];
            topLeftFinalAllIter = [topLeftFinalAllIter; top left];
            
            if ~isempty(regionsClose)
                regionCurCell{1}{1} = regionsClose;
                indBlockCell{1} = indBlock;
                szSubBlockCell{1} = szSubBlock;
                blockNoCell = blockNo;
                octaveIdxCell = octaveIdx;
                iterCell = iter;
                variationNThreshCell{1} = [variation; thresh];
                iSzCell = iSz;
                plusOrMinusCell{1} = plusOrMinus;
                tCell = t;
                
                [cornerNew boundaryNew maskNew circflag]= getCorners(regionCurCell,indBlockCell,szSubBlockCell,blockNoCell,octaveIdxCell,iterCell,variationNThreshCell,iSzCell,plusOrMinusCell,tCell,cornerOld(1:2) - [left-1 top-1]); %maskAll boundaryAll
                if ~isempty(cornerNew)
                    boundaryNew = boundaryNew{1};
                    circflag = circflag{1};
                end
                
                %                commonVar.displayflag=0;
                if commonVar.displayflag & ~isempty(cornerNew)
                    figure, imshow(maskNew), hold on,
                    for aa=1:size(cornerNew,1)
                        plot(cornerNew(aa,1),cornerNew(aa,2),'*g','LineWidth',2);
                    end
                end
                %                 commonVar.displayflag=0;
                
                boundaryNewTrans=[];
                szCorNew = size(cornerNew,1);
                cornerNewTrans = cornerNew;
                
                if ~isempty(cornerNew)
                    
                    %                 cornerNewTrans(:,1:2) =  cornerNew(:,1:2).*(iSz/commonVar.sigSminInit) + repmat([left-1 top-1],szCorNew,1) ;
                    cornerNewTrans(:,1:2) =  cornerNew(:,1:2) + repmat([left-1 top-1],szCorNew,1) ;
                    cornerNewTransAll = cornerNewTrans;
                    corMovt = repmat(cornerOld(:,1:2),szCorNew,1)  - cornerNewTrans(:,1:2);
                    corMovt = sqrt(corMovt(:,1).^2 + corMovt(:,2).^2);
                    [minCornVal,minCloseInd] = min(corMovt);
                    corMovt = corMovt(minCloseInd);
                    cornerNewAll = cornerNew;
                    cornerNew = cornerNew(minCloseInd,:);
                    %                 if minCornVal < minCornerThresh
                    
                    if corMovt > 2.85*iSz % use this when using history of points to converge 0.85*iSz
                        %                     disp('Corner moving out of block'); %happens for non standard sizes of blocks
                        %                         commonVar.displayflag=0;
                        break;
                    end
                    
                    cornerNewTrans = cornerNewTrans(minCloseInd,:); %to map to closest corner, also to  determine end point of loop
                    
                    bNoNew = cornerNew(15); %bNoNewVals = cornerNew(:,16); bNoNew = bNoNewVals(minCloseInd,:); but this needs conditions in case cornerNew is empty
                    boundaryNewTrans(:,1:2) =  boundaryNew{1}{bNoNew}(:,1:2)+ repmat([top-1 left-1],size(boundaryNew{1}{bNoNew},1),1) ;
                    %                 boundaryNewTrans(:,1:2) =  boundaryNew{1}{bNoNew}(:,1:2).*(iSz/commonVar.sigSminInit) + repmat([top-1 left-1],size(boundaryNew{1}{bNoNew},1),1) ;
                    %                     if cornerNew(8) > round(1.3*3.1*cornerNew(3)) & cornerNew(8) < size(boundaryNewTrans,1) - round(1.3*3.1*cornerNew(3))
                    boundaryNewTransCell = {boundaryNewTrans};
                    cornerNewTransAllIter = [cornerNewTransAllIter; cornerNewTrans ];
                    corMovtAllIter = [corMovtAllIter; corMovt ];
                    boundaryNewTransAllIter = [boundaryNewTransAllIter; boundaryNewTransCell];
                    bNoNewAllIter = [bNoNewAllIter ;bNoNew];
                    [scaleCorner corRight corLeft] = getScale(cornerNewTransAll,minCloseInd,circflag,size(boundaryNewTrans,1));
            
                    if (commonVar.displayflag || 0 ) && (times<=15) %& corMovt > 2
                        figure, imshow(img,[]), hold on, plot(boundaryOld(:,2), boundaryOld(:,1),'m','LineWidth',2);
                        showellipticfeaturesSPL(cornerOld,[0 0 1],1,0,1);
                        %                         plot(cornerOld(1,1),cornerOld(1,2),'*r','LineWidth',2);
                        plot(boundaryNewTrans(:,2), boundaryNewTrans(:,1),'y','LineWidth',2);
                        showellipticfeaturesSPL(cornerNewTrans,[1 1 0],1,0,1);
                        %                         plot(cornerNewTrans(1,1),cornerNewTrans(1,2),'*g','LineWidth',2);
                        
                        rectangle('Position', [left top szSubBlock(2) szSubBlock(1)],'LineWidth',2);
                        rectangle('Position', [indBlock(1) indBlock(2) indBlockSz(2) indBlockSz(1)],'LineWidth',2);
                        %                         hold off;
                        %                         pause;
                        %%%%%%%%%%%%%%
                        times = times + 1;
                    end
                    %                     commonVar.displayflag = 0;
                    if commonVar.displayflag
                        figure, imshow(subBlock,[]), hold on, plot(cornerNew(1,1), cornerNew(1,2), '*g');
                        bNo = cornerNew(15);
                        plot(boundaryNew{1}{bNo}(:,2), boundaryNew{1}{bNo}(:,1));
                        plot(cornerOld(:,1),cornerOld(:,2),'*r','LineWidth',4);
                    end
                    numLoop = 1;
                    
                    cornerOld  = cornerNewTrans; %update
                    topPrev = top; leftPrev = left;
                    maskPrev = maskNew;
                    corRightPrev = corRight;
                    corLeftPrev = corLeft;
                  
                    if 1 %~commonVar.isparfor
                        boundaryOld = boundaryNewTrans;
                    end
                    
                    
                    numIter = numIter +1;
                    %                 topPrev = top; leftPrev = left;
                    %                 bottomPrev = top + rangeVal; rightPrev = left + rangeVal;
                    %                     else
                    %                         corMovt = -1;
                    %                     end
                else
                    corMovt = -1; %movement becomes invalid.
                end
            else
                corMovt = -1;
            end
            
        end
        
        totalLoop =  totalLoop + numLoop;
        [minCorMovt minInd] = min(corMovtAllIter);
        
        labelRP = isempty(corRightPrev);
        labelR = isempty(corRight);
        labelLP = isempty(corLeftPrev);
        labelL = isempty(corLeft);
        labelRs = num2str([labelRP labelR]);
        labelLs = num2str([labelLP labelL]);
        
        switch labelRs
            case '1  1'
                distRight = 0;
            case '1  0'
                distRight = 500;
            case '0  1'
                distRight = 500;
            case '0  0'
                distRight = sqrt(sum((corRightPrev(1:2) - corRight(1:2)).^2));
        end
           
        switch labelLs
            case '1  1'
                distLeft = 0;
            case '1  0'
                distLeft = 500;
            case '0  1'
                distLeft = 500;
            case '0  0'
                distLeft = sqrt(sum((corLeftPrev(1:2) - corLeft(1:2)).^2));
        end
        

        if ((numIter==maxIterPt && (corMovt <= 2.1) && variation < 5000) || (corMovt == 0)) && (distRight<=2.1 & distLeft <=2.1) % minCorMovt<=2.1 & scaleConv==0 & ~isempty(cornerNewTrans) Empty corner condition ensures that only toggle case comes in, otherwise corner not found means that the er was not stable; not checking divergenceFlag, not bothered if it didn't converge in the end.
            
            %Incorporate getting points from loop for toggle case here also
            if commonVar.displayflag
                selCur0 = find(subBlock<thresh);
                %                 regionsDecCur{1} = selCur0; %termporatily turned off for parfor. Uncomment if this figure needs to be displayed
                [cornerNew boundaryNew maskNew]= getCorners(regionsDecCur,indBlock,size(subBlock),blockNo,octaveIdx,iter,[variation; thresh],iSz,plusOrMinus,cornerOld(1:2) - [left-1 top-1]); %maskAll boundaryAll
                figure, imshow(imBlock,[]), hold on,
                plot(boundaryNewTrans(:,2), boundaryNewTrans(:,1),'y','LineWidth',2);
                showellipticfeatures(cornerNewTrans,[1 1 0]);
                
                plot(boundaryNew{1}{1}(:,2), boundaryNew{1}{1}(:,1),'m','LineWidth',2);
                showellipticfeatures(cornerNew);
                
                rectangle('Position', [left top size(subBlock,2) size(subBlock,1)],'LineWidth',2);
            end
            
            [scaleCorner corRight corLeft] = getScale(cornerNewTransAll,minCloseInd,circflag,size(boundaryNewTrans,1));
            
            if scaleCorner ~= 0
                cornerNewTrans = cornerNewTransAllIter(minInd,:);
                
                if commonVar.displayflag
                    hold on;
                    plot(boundaryNewTrans(:,2), boundaryNewTrans(:,1),'y','LineWidth',2);
                    showellipticfeaturesSPL(cornerNewTrans,[1 1 0],1,0,1);
                    if ~isempty(corRight)
                        plot(corRight(1),corRight(2),'*r');
                    end
                    if ~isempty(corLeft)
                        plot(corLeft(1),corLeft(2),'*r');
                    end
                end
                
                
                cornerNewTrans(3) = scaleCorner;
                cornerNewTrans(11) = blockNo;
                cornerNewTrans(12) = indNo; %determines which mser now
                cornerNewTrans(13) = variationAllIter(minInd);
                cornerNewTrans(14) = threshAllIter(minInd);
                cornerNewTrans(15) = bNoNewAllIter(minInd); %do you even need bNo, if so make it 15, and this 16?
                cornerNewTrans(16) = minMserDistAllIter(minInd);
                cornerNewTrans(17) = octaveIdx;
                cornerNewTrans(20) = plusOrMinus;
                cornerNewTrans(21) = minCorMovt; %make this distance from centre for one shot calculation
                
                cornersAllOrig = [cornersAllOrig; cornerNewTrans];
                %         cornerNewTrans(1:2) =  cornerNewTrans(1:2) + (indBlock-1);
                
                %                 subplot(1,3,3), imshow(img,[]), hold on, plot(cornerNewTrans(1,1),cornerNewTrans(1,2),'*g','LineWidth',5);
                cornersAll = [cornersAll; cornerNewTrans];
                regionsFinal{numConv} = regionsCloseAllIter{minInd};
                blockSzFinal(numConv,:) = szSubBlockAllIter(minInd,:);
                topLeftFinal(numConv,:) = topLeftFinalAllIter(minInd,:);
                plusOrMinusFinal(numConv,1) = plusOrMinus;
                
                boundaryNewTransAll{numConv} = boundaryNewTransAllIter{minInd};
                numConv = numConv+1;
            end
        end
    end
end
commonVar.displayflag=0;
if commonVar.displayflag
    figure, imshow('../images/bike/img1.ppm'), hold on, showellipticfeaturesSPL(cornersAll,[1 1 0],1,0,1);
    for i=1:size(cornersAll,1)
        text(cornersAll(i,1)+2,cornersAll(i,2)+2,num2str(cornersAll(i,13)),'BackgroundColor',[.9 .5 .5]);
    end
end

if 0
    fprintf('\nNo of corners entering the loop: %d out of %d\n',totalLoop,corRows);
end
