function [regions regionLen regionsBoundary] = decodeRLE(regionsRLE)

regions = cell(1, size(regionsRLE,2));
for i =1:size(regionsRLE,2)
    
    size1 = 0;
    for j=1:size(regionsRLE{i},2)
        size1 = size1 + regionsRLE{i}(3,j) - regionsRLE{i}(2,j) + 1;
    end;
    
    runLenTot = 0; xVals=zeros(1, size1); yVals=zeros(1, size1); xValsBound=zeros(1,size(regionsRLE{i},2)*2); yValsBound=zeros(1,size1);
    iter_beg = 1;
    for j=1:size(regionsRLE{i},2)
        runLen = regionsRLE{i}(3,j) - regionsRLE{i}(2,j) + 1;
        iter_end = iter_beg + runLen - 1;
        xVals(1,iter_beg:iter_end) = repmat(regionsRLE{i}(1,j),1,runLen);
        %xValsBound(1, j:j+1) = repmat(regionsRLE{i}(1,j),1,2);
        yVals(1, iter_beg:iter_end) = regionsRLE{i}(2,j):regionsRLE{i}(3,j);
        %yValsBound(1, iter_beg:iter_end) = [regionsRLE{i}(2,j) regionsRLE{i}(3,j)];
        iter_beg = iter_end+1;
        runLenTot = runLenTot + runLen;
    end
    
    regions{i}(1,:) = xVals + 1;
    regions{i}(2,:) = yVals + 1;
    %regionLen{i} = runLenTot;
    
    %regionsBoundary{i}(1,:) = xValsBound;
    %regionsBoundary{i}(2,:) = yValsBound;
end