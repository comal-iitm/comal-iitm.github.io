function thresh = SubtractAndGetSiftDescriptor(imTuple,ifDesc,detType,desType,sxi2,threshInit,dSetNo,dilVal,fgTypeComp,delta,imgnoBase,thresh)

ptDirData = sprintf('../data/results/feat-delta%d',delta);
descDirData = sprintf('../data/results/desc-delta%d',delta);
imDirData = '../Images';

%% Detector - others
dataset = imTuple{1};
imgInd = regexp(imTuple{2}, '[0-9]');
imgnoStr =  imTuple{2}(imgInd); % needs adjusting for non-single digit img nos
imgnoInt = str2double(imgnoStr);

imgPath = sprintf('%s/%s/%s',imDirData,dataset,imTuple{2});
ptFile = sprintf('%s/%s/img%d.%s.txt',ptDirData,dataset,imgnoInt-1,detType);
ptFileCoMIC = sprintf('%s/%s/img%d.%s.txt',ptDirData,dataset,imgnoInt-1,'harronmser');
try
  fComic = loadFeatures(ptFileCoMIC); sxi2 = sqrt(1/fComic(3,1));
catch
  disp('problem here in sub'); disp(imgnoInt); %happens when ther is no car in the frame
end

fgType{1}=fgTypeComp;
if ~ifDesc %if only running descriptor and not points also simulataneously
  [feat thresh] = OtherDetectors(imgPath,ptFile,dataset,imgnoInt,detType,sxi2,threshInit,dSetNo,thresh,imgnoBase,ptFileCoMIC,dilVal,fgType);
else thresh=[]; end %some random initialisation to be sent out


if ifDesc
  switch desType
    case 'sol'
      nsdopt = nsd.opts(); nsdopt.descriptor.verbose=0;
      [imref,~, scaleFact] = nsd.preprocess(imgPath, nsdopt.pp);
      feat = loadFeatures(ptFile);
      featResz = round(feat(1:2,:).*scaleFact);
      scales = sqrt(1./feat(3,:)).*scaleFact;
      
      if 0
        figure, imshow(imgPath), hold on, plot(feat(1,:),feat(2,:),'*');
        figure, imshow(imref), hold on, plot(featResz(1,:),featResz(2,:),'*');
      end
      
      fr = [featResz(2,:); featResz(1,:); scales; zeros(1,size(feat,2))];
      [d_ref,di_ref,fr_ref,f_ref] = nsd.descriptor(imref, nsdopt.descriptor,fr);
      desc.d = d_ref; desc.di = di_ref; %desc.fr = fr_ref; desc.f =f_ref;
      savePath = sprintf('%s/%s/solDesc%d_%s.mat',descDirData,dataset,imgnoInt-1,detType);
      save(savePath,'desc');
    case 'sift'
      ptDesFile = sprintf('%s/%s/img%d.%s.sift.txt',descDirData,dataset,imgnoInt-1,detType);
      if ~exist(ptDesFile,'file')
        runSift = sprintf('./compute_descriptors.ln -sift -i %s -p1 %s -o1 %s > out.log',imgPath,ptFile,ptDesFile);
        system(runSift);
      end
  end
end

%% Getting SSD patch outside, not used
if 0% dSetNo==1 || dSetNo==2 || dSetNo==6 %the subtracting image part might go out in the future, to make one subtraction for all types of detectors, or detector loop might come inside
  %     [indValidFg coordFg] = getValidIndInFgBB(feat(1:2,:)',dataset,imgnoInt,dSetNo,dilVal,fgType);
  %     feat = feat(:,indValidFg{1});
  
  %Descriptor:
  radiusForSSD=11;
  img = imread(imgPath);
  ifSc = 0;
  detPtsNoDupDes = getSSDDescriptor(img,feat,radiusForSSD,ifSc);
  ptDesFile = sprintf('%s/%s/detPtsNoDupDes%d_%s.mat',descDirData,dataset,imgnoInt,detType);
  save(ptDesFile,'detPtsNoDupDes');
end

%% Descriptor - sift
if dSetNo==3 || dSetNo==7 %|| dSetNo==4
  ptDesFile = sprintf('%s/%s/img%d.%s.sift.txt',ptDirData,dataset,imgnoInt-1,detType);
  runSift = sprintf('./compute_descriptors.ln -sift -i %s -p1 %s -o1 %s',imgPath,ptFile,ptDesFile);
  system(runSift);
end

%% Following code used if stuff is run from outside
if 0
  img = rgb2gray(img);
  S      =  3 ;
  omin   = -1 ;
  O      = floor(log2(min(M,N)))-omin-3 ; % up to 8x8 images
  sigma0 = 1.6*2^(1/S) ;                  % smooth lev. -1 at 1.6
  sigman = 0.5 ;
  NBP    = 4 ;
  NBO    = 8 ;
  magnif = 3.0 ;
  gss = gaussianss(img,sigman,O,S,omin,-1,S+1,sigma0) ;
  octaveIdx =1;
  numPts = size(f1,2);
  
  % radius = maginf * sigma * NBP / 2
  % radius = 6sigma = factor*6*(sigma0 * 2^(s/S)), where factor = 2 here coz image
  % is blown up by that factor
  s = 0; %1.2;
  cornerMat = [2.*f1(1:2,:); s*ones(1,numPts);zeros(1,numPts) ];
  featDesc = siftdescriptor(gss.octave{octaveIdx}, cornerMat,gss.sigma0,gss.S, gss.smin, ...
    'Magnif', magnif, 'NumSpatialBins', NBP, 'NumOrientBins', NBO) ;
  descr = uint8(512*featDesc) ;
  featFinal = [f1; double(descr)];
  
  ptDes = sprintf('../data/results/%s/featFinal%d_%s',dataset,str2num(imgnoStr)-1,detType);
  save(ptDes,'featFinal');
end
