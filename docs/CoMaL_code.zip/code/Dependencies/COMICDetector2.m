function [cornersFinal, ...
    boundaryFinal, ...
    maskFinal] = COMICDetector2(Tuples, dSetNo, dilValComp, ...
    fgTypeComp, delta, numCores)


loopOver=1; ifInit=1;dupRem = 1;
nonLcsBasedOverErr = 35; overErrMser=40; %nonLcsBasedOverErr = 10; overErrMser=15;
dirData = '../Images'; %The image datasets directory

expandAmt = 50; coordFg = cell(1,3); detectedPts=[];
%Warning: Adjust scaleFactor inside globalVariables function
imgInd = regexp(Tuples{2}, '[0-9]');% Returns the indices in Tuples with the detected regex
imgno =  Tuples{2}(imgInd); % needs adjusting for non-single digit img nos
imgnoInt = str2num(imgno); % Obtain the image file number
commonVar  = globalVariables(imgnoInt);

fprintf('\n Processing %s:',Tuples{2});
imgPath = fullfile(dirData,Tuples{1},Tuples{2}); %Path of the image file
imgPath_temp = fullfile(dirData,Tuples{1},'temp_.mat'); %Path of the smoothed image we are going to store
img = (imread(imgPath)); %give initial image a little smoothing

img = uint32(img);
sizeIm  = size(img); ysize = sizeIm(1) ; xsize = sizeIm(2);

%%
for i=1, %2:size(commonVar.sigSmin,2)
    
    fprintf(' Scale number %d, ', i);
    iSz = commonVar.sigSmin(i);
    img = BoundaryGaussianSmoothing_2D(img, 2); %iSz/3 %Smooth the image
    save(imgPath_temp, 'img');    %Save the image, this will be loaded in runMatasMser
    
    %Obtains the different image blocks, indices and sizes
    [imBlocks indBlock indBlockSz] = getAllblocks(img, iSz, imgnoInt);
    
    dilVal = [expandAmt; 4; dilValComp];
    fgType{1} = 'full'; fgType{2} = 'bound'; fgType{3} = fgTypeComp; % fgTypeComp controls what regions of fg is used in comparison, rest in fgType have to be full
    
    %Obtain the "valid" blocks acc. to the FG data
    [indValidFg coordFg] = getValidIndInFgBB(indBlock, Tuples{1}, imgno, ...
        dSetNo, dilVal, fgType);
    imBlocks = imBlocks(indValidFg{1}, :);
    indBlock = indBlock(indValidFg{1}, :);
    indBlockSz = indBlockSz(indValidFg{1}, :);
    
    
    %%
    if size(imBlocks,1) >= 1,
        if ifInit,
            
            szCellBl = length(imBlocks); theta = 0;iter=0;
            coordFgObj = coordFg{2}; dummy=0;
            initCornersCell0 = {};
            
            parfor iBl =1:szCellBl 

                [~, regionsDecInit(iBl), ...
                    variationNThreshInit(iBl), ...
                    plusOrMinusInit(iBl)] = runMatasMser(imgPath_temp, theta, ...
                    delta-5, iter, ...
                    imgnoInt, dummy, ...
                    indBlock(iBl), ...
                    indBlockSz(iBl)); %imBlocksCell{split}
                %fprintf('Crossed\n\n');
                [initCornersCell0{iBl}, ...
                    maskCornerAll(iBl), ...
                    boundaryPartAll(iBl), ...
                    scAll(iBl), ~, ...
                    topLeftImAll(iBl)] = getCornersTest(regionsDecInit(iBl), indBlock(iBl), ...
                    indBlockSz(iBl), iBl, ...
                    variationNThreshInit(iBl), iSz, ...
                    plusOrMinusInit(iBl), imgnoInt, ...
                    dSetNo, coordFgObj);
            end
            
            maskCornerMat = []; boundaryPartMat = []; scMat=[]; topLeftImMat=[];
            
            for iBl =1:szCellBl
                
                maskCornerMat = [maskCornerMat ; maskCornerAll{iBl}];
                boundaryPartMat = [boundaryPartMat; boundaryPartAll{iBl}];
                scMat = [scMat; scAll{iBl}];
                topLeftImMat = [topLeftImMat; topLeftImAll{iBl}];
                
            end
            
            initCornersMat = cell2mat(initCornersCell0');
            if dSetNo==8
                
                indNotUseful = find(initCornersMat(:, 2) < 120);
                boundaryPartMat(indNotUseful, :) = [];
                maskCornerMat(indNotUseful, :) = [];
                scMat(indNotUseful, :) = [];
                topLeftImMat(indNotUseful, :) = [];
                initCornersMat(indNotUseful, :) = [];
            end
            
            %duplicate removal by looking at underlying MSER
            for fC=1:2
                
                floorOrCeil = 1-mod(fC,2);
                numDup = 1;
                if floorOrCeil
                    
                    [aa, indUniquePM1, indUniquePM2] = unique(floor(initCornersMat(:,1:2)/3.5)*3.5,'rows');
                else
                    [aa, indUniquePM1, indUniquePM2] = unique(round(initCornersMat(:,1:2)/3.5)*3.5,'rows'); %increase this
                end
                countPM = accumarray(indUniquePM2, 1);
                indDup0 = find(countPM > numDup);
                indInValid0 = collectParallel(indDup0, indUniquePM2, initCornersMat, ...
                    scMat, boundaryPartMat, numCores); %Make for for dSetRest
                if 0
                    figure, imshow(img,[]), hold on, plot(initCornersMat(:,1),initCornersMat(:,2),'*');
                    initCornersMat0 = initCornersMat; initCornersMat0(indInValid0,:)=[];
                    figure, imshow(img,[]), hold on, plot(initCornersMat0(:,1),initCornersMat0(:,2),'*');
                end
                
                initCornersMat(indInValid0, :) = [];
                boundaryPartMat(indInValid0, :) = [];
                maskCornerMat(indInValid0, :) = [];
                scMat(indInValid0, :) = [];
                topLeftImMat(indInValid0, :) = [];
                
            end
            
            clear initCorners initCornerBlocks initCornersMatSortd indInitUnique indOutofBdry;
        end
        
        %% Loop over Init
        if loopOver,
            
            numCorners = size(initCornersMat, 1);
            numDiv = ceil(numCorners/numCores);
            indDiv = 1:numDiv:numCorners;
            indDiv(end+1) = numCorners;
            
            for a = 2:length(indDiv)
                
                initCornersCell{a-1} = initCornersMat(indDiv(a-1):indDiv(a), :);
                boundaryPartCell{a-1} = boundaryPartMat(indDiv(a-1):indDiv(a));
                maskCornerCell{a-1} = maskCornerMat(indDiv(a-1):indDiv(a));
                scCell{a-1} = scMat(indDiv(a-1):indDiv(a));
                topLeftImCell{a-1} = topLeftImMat(indDiv(a-1):indDiv(a));
                
            end
            
            parfor split= 1:length(scCell)
                
                [cornersConv0{split}, ...
                    maskConvSz0{split}, ...
                    regionConv0{split}, ...
                    scConv0{split}, ...
                    boundaryConv0{split}, ...
                    topLeftConv0{split}, ...
                    maskConv0{split}] = getConvergedCorner2(initCornersCell{split}, ...
                    boundaryPartCell{split}, ...
                    maskCornerCell{split}, ...
                    scCell{split}, ...
                    topLeftImCell{split}, ...
                    img, indBlock, imgnoInt, ...
                    delta, split);
            end
            
            cornersConv =cell2mat(cornersConv0');
            regionConv=[]; maskConvSz=[]; scConv=[];boundaryConv=[];
            topLeftConv=[];maskConv_={};
            
            rter = 0;
            
            for split=1:size(scConv0, 2),
                
                regionConv = [regionConv regionConv0{split}];
                maskConvSz = [maskConvSz maskConvSz0{split}];
                
                for i = 1:size(maskConv0{split}, 2),
                    rter = rter+1;
                    maskConv_{rter} = maskConv0{split}{i};
                end;
                
                scConv = [scConv scConv0{split}];
                boundaryConv = [boundaryConv boundaryConv0{split}];
                topLeftConv = [topLeftConv topLeftConv0{split}];
                
            end
            
            %need regions and block size for rep checking.
            [cornersConvSortd, indSorted] = sortrows(cornersConv, [1 2 13]);
            [~, indUnique]= unique(round(cornersConvSortd(:, 1:3).*100)./100, 'rows'); %pick one with least variation
            % fprintf('\n number of points before: %d and after unique: %d',size(cornersBlockMat,1),length(indUnique));
            indF = indSorted(indUnique);
            cornersConv = cornersConv(indF, :);
            regionConv = regionConv(indF);
            maskConvSz = maskConvSz(indF);
            
            scConv = scConv(indF);
            boundaryConv = boundaryConv(indF);
            topLeftConv = topLeftConv(indF);
            maskConv = {};
            
            for ind_ = 1:size(indF, 1),
                maskConv{ind_} = maskConv_{indF(ind_)};
            end;
            
            if 0,
                
                figure, imshow(uint8(img)), hold on, plot(cornersConv(:,1),cornersConv(:,2),'*');
                
            end
        else
            cornersConv = initCornersMat;
        end
        
        %% Overlap checking
        if dupRem,
            
            if loopOver == 0 & ifInit == 0,
                
                cornersBlockMat=[]; scConv=[]; boundaryConv=[];
                regionConv=[]; maskConvSz=[];
            end
            [indFinal cornersFinal ...
                boundaryFinal maskFinal, ~, ~] = overlapCheck(cornersConv, [ysize, xsize], ...
                nonLcsBasedOverErr, overErrMser, ...
                scConv, boundaryConv, ...
                regionConv, maskConvSz, maskConv, topLeftConv);%gets descriptor also
        end
        
        %% Saving and writing
        
        cornersConv = cornersConv(indFinal,:); regionConv = regionConv(indFinal);
        maskConvSz = maskConvSz(indFinal); scConv = scConv(indFinal);
        boundaryConv = boundaryConv(indFinal); topLeftConv = topLeftConv(indFinal);
        
        basicPath=fullfile('..','data','results',sprintf('feat-delta%d',delta),sprintf('%s',Tuples{1}));
        if ~exist(basicPath), mkdir(basicPath); end
        imgnoInt = str2num(imgno);isFiveCols=1;
        detPtsFile = fullfile(basicPath, sprintf('img%d.harronmser.txt',imgnoInt-1));
        writeToFileTest(detPtsFile,cornersFinal',1,xsize,ysize,0,imgnoInt,isFiveCols);
        
        basicPath0 = sprintf('../data/results/orig-delta%d/%s/',delta,Tuples{1});
        if ~exist(basicPath0), mkdir(basicPath0); end
        save(sprintf('%s/cornersConv%d.mat',basicPath0,imgnoInt),'cornersConv');
        save(sprintf('%s/regionConv%d.mat',basicPath0,imgnoInt),'regionConv');
        save(sprintf('%s/maskConvSz%d.mat',basicPath0,imgnoInt),'maskConvSz');
        save(sprintf('%s/boundaryConv%d.mat',basicPath0,imgnoInt),'boundaryConv');
        save(sprintf('%s/scConv%d.mat',basicPath0,imgnoInt),'scConv');
        save(sprintf('%s/topLeftConv%d.mat',basicPath0,imgnoInt),'topLeftConv');
        
        %run sift descriptor
        if dSetNo == 3 || dSetNo==4 || dSetNo==7
            detType = 'harronmser';
            ptDesFile = sprintf('../data/results/feat-delta%d/%s/img%d.%s.sift.txt',delta,Tuples{1},imgnoInt-1,detType);
            runSift = sprintf('./compute_descriptors.ln -sift -i %s -p1 %s -o1 %s',imgPath,detPtsFile,ptDesFile);
            system(runSift);
        end
        %}
    else
        
        cornersFinal = [];
        boundaryFinal = {};
        maskFinal = {};
        
    end;
    
end