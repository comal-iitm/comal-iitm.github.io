function VehicleGroundtruthConversion()

dirData ='../images';
Tuples = getTuples(dirData);
[datasets indUnique] = unique(Tuples(:,1));

for d=18:length(datasets)
    dSet = datasets{d};
    dSetNo = getParamsAndDataset(dSet);
    if dSetNo==6
        imgDirPath = sprintf('%s/%s',dirData,dSet);
        gtPath = sprintf('%s/%s/groundtruth.txt',dirData,dSet);
        tracklets = readLabels(gtPath);
        gtSavePath = sprintf('%s/groundtruth.mat',imgDirPath);
        save(gtSavePath,'tracklets');
    end
end

