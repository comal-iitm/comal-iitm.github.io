function debugNonMatchingPts(f1,f2,des1,des2,img1,img2)

detType = 'harronmser';

imgs{1} = imread(img1); imgs{2} = imread(img2);
feats{1} = f1; feats{2} = f2;
descriptors{1} = des1; descriptors{2} = des2;

indCloseBothSides=[];szBlock=23; % 23;
for i=1:2
    img = imgs{i};
    f = feats{i};
    des = descriptors{i};
    figure, imshow(img,[]), hold on, showellipticfeaturesSPL(f);
    hold on, [x,y] = ginput(1);
    [vals,indClose] = closestPt([x y],f,1,1); %
    if strcmp(detType,'harronmser')
        indCloseBothSides =[indCloseBothSides; 2*indClose-1; 2*indClose];
        block = uint8(reshape(des(2*indClose-1,:),[szBlock szBlock 3]));
        figure, imshow(block);
        block = uint8(reshape(des(2*indClose,:),[szBlock szBlock 3]));
        figure, imshow(block);
        
    else
        indCloseBothSides =[indCloseBothSides; indClose];
        block = uint8(reshape(des(indClose,:),[szBlock szBlock 3]));
        figure, imshow(block);
        
    end
    disp(indCloseBothSides);
end

end

