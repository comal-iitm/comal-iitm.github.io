function indInValid = checkDupMSER(cornersDup,scSet,boundaryPartSet)

numCorners = size(cornersDup,1);
% pairs = nchoosek(1:numCorners,2); 
valid = ones(numCorners,1);
scCostThresh = 0.18;

for i=1:numCorners
    if valid(i)
        indDup = setdiff(find(valid>0),1:i);
        for j=1:length(indDup)
            sc_cost = getbestMatch(scSet{i},scSet{indDup(j)});
            if sc_cost < scCostThresh %qtyCompare > 0.15 && qtyCompare < qtyThresh %
                if 0 %display
                    figure, plot(boundaryPartSet{i}(:,2),boundaryPartSet{i}(:,1),'g'), hold on;
                    plot(boundaryPartSet{indDup(j)}(:,2),boundaryPartSet{indDup(j)}(:,1),'r')
                    close all;
                end
                areaPerSet1 = cornersDup(i,16); areaPerSet2 = cornersDup(indDup(j),16);
                if abs(areaPerSet1 - areaPerSet2) > 0.1 %when the difference in area is too large, pick the smaller one at this stage. This subsumes the plusOrMinus checking.
                    if areaPerSet1 > areaPerSet2 % the larger one is biased to have a larger strength
                        valid(i)=0;
                    else
                        valid(indDup(j))=0;
                    end
                else
                    if cornersDup(i,13) <= cornersDup(indDup(j),13) % strengths
                        valid(i)=0;
                    else
                        valid(indDup(j))=0;
                    end
                end
                
            else
                aa=1; %show same fig as in the beginning
            end
        end
    end
    
end

indInValid = find(valid==0);

end