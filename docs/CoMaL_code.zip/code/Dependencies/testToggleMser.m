function testToggleMser

numClose=25; numPts=1;
load('matlab.mat');

%     myDisplayDetPtsOuter([imgNoinFullList])
% figure, imshow(img,[]), hold on,
% plot(initCornersMat(:,1),initCornersMat(:,2),'*g');
myDisplayDetPtsOuter('bike',1,'harronmser')
hold on, [x,y] = ginput(1);
[vals,ind] = closestPt([x y],initCornersMat,1,numClose); %
ind = ind(vals<10);
ptsToCompareClose = initCornersMat(ind,:);

boundaryPartCell = boundaryPartMat(ind);
maskCornerCell = maskCornerMat(ind);
scCell = scMat(ind);
topLeftImCell = topLeftImMat(ind);

[cornersConv0 maskConvSz0 regionConv0 scConv0 boundaryConv0] = getConvergedCorner2(ptsToCompareClose,...
    boundaryPartCell ,maskCornerCell , scCell, topLeftImCell, img,indBlock,imgnoInt,delta,1);

