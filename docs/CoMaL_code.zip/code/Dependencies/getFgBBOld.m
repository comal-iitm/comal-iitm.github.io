function [indValid coordFg] = getFgBB(xyCoord, dataset, imgnoStr, dilVal,fgType) %fgType will be used later

groundtruth = csvread(sprintf('../images/%s/groundtruth.txt',dataset));
%     convertGt(dataset,dataset); %convert for PROST dataset
sizeOrig = dlmread(sprintf('../images/%s/original_size.txt',dataset));
scaleFac = 700./sizeOrig(2); %sizeOrig;
%get gt values
if sth
    get all the left and tops. Run a for loop over every one of them.
end

leftGtInit = groundtruth(str2num(imgnoStr),1); topGtInit = groundtruth(str2num(imgnoStr),2);
widInit = groundtruth(str2num(imgnoStr),3); htInit = groundtruth(str2num(imgnoStr),4);
if 0
    aa = imresize(img,[sizeOrig(2) sizeOrig(1)]);
    figure, imshow(aa,[])
    rectangle('Position', [leftGtInit topGtInit widInit htInit],'LineWidth',2);
end

%adjust for scale
topLeftGt = [topGtInit-1 leftGtInit-1].*scaleFac + 1;
topGt = topLeftGt(1); leftGt = topLeftGt(2);
widHtGt = [htInit widInit].*scaleFac;
wid = widHtGt(2); ht = widHtGt(1);
if 0
    figure, imshow(img,[])
    rectangle('Position', [leftGt topGt wid ht],'LineWidth',2);
    rectangle('Position', [leftBox topBox wid+80 ht+80],'LineWidth',2);
end
%dilate/expand to fit in block indices
img = imread(sprintf('../images/%s/img%s.ppm',dataset,imgnoStr));
sizeIm  = size(img);
ysize = sizeIm(1) ; xsize = sizeIm(2);

for numDil=1:length(dilVal)
    botGt = topGt + ht; rightGt = leftGt + wid;
    topBox = max(topGt - dilVal(numDil),1);
    leftBox = max(leftGt - dilVal(numDil),1);
    botBox = min(botGt + dilVal(numDil),ysize);
    rightBox = min(rightGt + dilVal(numDil),xsize);
    indValid{numDil} = find(xyCoord(:,1)>=leftBox & xyCoord(:,1)<=rightBox & xyCoord(:,2)>=topBox & xyCoord(:,2)<=botBox);
    
    [col row] = meshgrid(round(leftBox:rightBox), round(topBox:botBox));
    [szCoord1 szCoord2] = size(col);
    colReshape = reshape(col,szCoord1*szCoord2,1);
    rowReshape = reshape(row,szCoord1*szCoord2,1);
    coordFg{numDil} = [colReshape  rowReshape];
end

if 0
    img = imread(sprintf('../images/%s/img%s.ppm',dataset,imgnoStr));
    figure, imshow(img,[]), hold on,
    plot(indBlockMat(indValid,1),indBlockMat(indValid,2),'*');
    figure, imshow(img,[]), hold on,
    plot(coordFg{2}(:,1),coordFg{2}(:,2),'*');
end

end