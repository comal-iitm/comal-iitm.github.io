function RepeatabilityAllImageMatchingScale(datastring) %For Image matching experiments

switch datastring
    case 'bike'
        xlabelString = 'Increasing blur';
    case 'uubc'
        xlabelString = 'JPEG compression %';
    case 'luvn'
        xlabelString = 'Decreasing light';
end

overErr= 4; legendFontSize = 20; %45 
lineSize = 3; %10
labelSize = 20; %40

getPtsOtherDets = 0;
if getPtsOtherDets
    OtherDetectorsScale(datastring,'hr3'); % 'hr1'also possible
    OtherDetectorsScale(datastring,'hs2'); % 'hs1'
    OtherDetectorsScale(datastring,'fas');
%     OtherDetectors(datastring,'fer');
    OtherDetectorsScale(datastring,'msr'); %check this
    ChangeScaleFromFile(datastring);
end

% ChangeScaleFromFile(datastring);

if 0
    Select; %choose threshold for overlap check
end

%% Running repeatability

[repeatHom, correspHom, ~,~,repeatMultMatchesHom,correspMultMatchesHom] = testMserSimple(datastring,'harronmser',overErr,0); %testMserSimple(detType,desciptor,firsttime)
[~,~, matching_scoreHom,nb_of_matchesHom] = testMserSimple(datastring,'harronmser',overErr,1);

[repeatHr3, correspHr3, ~,~,repeatMultMatchesHr3,correspMultMatchesHr3] = testMserSimple(datastring,'hr3',overErr,0);
[~,~, matching_scoreHr3,nb_of_matchesHr3] = testMserSimple(datastring,'hr3',overErr,1);

[repeatHs2, correspHs2, ~,~,repeatMultMatchesHs2,correspMultMatchesHs2] = testMserSimple(datastring,'hs2',overErr,0);
[~,~, matching_scoreHs2,nb_of_matchesHs2] = testMserSimple(datastring,'hs2',overErr,1);

[repeatFas, correspFas, ~,~,repeatMultMatchesFas,correspMultMatchesFas] = testMserSimple(datastring,'fas',overErr,0); %testMserSimple('fas',overErr,0,2,4);
[~,~, matching_scoreFas,nb_of_matchesFas] = testMserSimple(datastring,'fas',overErr,1); %testMserSimple('fas',overErr,1,2,4); for bikes


% [repeatFer, correspFer, ~,~,repeatMultMatchesFer,correspMultMatchesFer] = testMserSimple(datastring,'fer',overErr,0); %testMserSimple('fas',overErr,0,2,3);
% [~,~, matching_scoreFer,nb_of_matchesFer] = testMserSimple(datastring,'fer',overErr,1); %testMserSimple('fas',overErr,1,2,3); for bikes

[repeatMsr, correspMsr, ~,~,repeatMultMatchesMsr,correspMultMatchesMsr] = testMserSimple(datastring,'msr',overErr,0);
[~,~, matching_scoreMsr,nb_of_matchesMsr] = testMserSimple(datastring,'msr',overErr,1);


%% Getting figures
mark=['-cv';'-gs';'-m+';'-bp';'-rd';'-kx';];

hFig1 = figure;clf;
grid on;
ylabel('Repeatability %','FontSize',labelSize,'FontWeight','bold')

figure(hFig1); axis([1.8 6 0 102]);
xAxis = 2:6;
xlabel(xlabelString,'FontSize',labelSize,'FontWeight','bold');
hold on;

hFig2 = figure;clf;
grid on;
ylabel('Number of Correspondences','FontSize',labelSize,'FontWeight','bold')
xlabel(xlabelString,'FontSize',labelSize,'FontWeight','bold');
hold on;


figure(hFig1);  plot(xAxis,repeatHom,mark(6,:),'Linewidth',lineSize,'MarkerSize',24);
% figure(hFig1);  plot(xAxis,repeatHr1,mark(1,:),'Linewidth',2,'MarkerSize',14);
figure(hFig1);  plot(xAxis,repeatHr3,mark(2,:),'Linewidth',lineSize,'MarkerSize',24);
% figure(hFig1);  plot(xAxis,repeatHs1,mark(3,:),'Linewidth',2,'MarkerSize',14);
figure(hFig1);  plot(xAxis,repeatHs2,mark(4,:),'Linewidth',lineSize,'MarkerSize',24);
figure(hFig1);  plot(xAxis,repeatFas,mark(5,:),'Linewidth',lineSize,'MarkerSize',24);
% figure(hFig1);  plot(xAxis,repeatFer,mark(1,:),'Linewidth',lineSize,'MarkerSize',24);
figure(hFig1);  plot(xAxis,repeatMsr,'-d','Color',[1 0.6 0],'Linewidth',lineSize,'MarkerSize',24);
figure(hFig1);  plot(xAxis,repeatHom,mark(6,:),'Linewidth',lineSize,'MarkerSize',24);

figure(hFig2);  plot(xAxis,correspHom,mark(6,:),'Linewidth',lineSize,'MarkerSize',24);
% figure(hFig2);  plot(xAxis,correspHr1,mark(1,:),'Linewidth',2,'MarkerSize',14);
figure(hFig2);  plot(xAxis,correspHr3,mark(2,:),'Linewidth',lineSize,'MarkerSize',24);
% figure(hFig2);  plot(xAxis,correspHs1,mark(3,:),'Linewidth',2,'MarkerSize',14);
figure(hFig2);  plot(xAxis,correspHs2,mark(4,:),'Linewidth',lineSize,'MarkerSize',24);
figure(hFig2);  plot(xAxis,correspFas,mark(5,:),'Linewidth',lineSize,'MarkerSize',24);
% figure(hFig2);  plot(xAxis,correspFer,mark(1,:),'Linewidth',lineSize,'MarkerSize',24);
figure(hFig2);  plot(xAxis,correspMsr,'-d','Color',[1 0.6 0],'Linewidth',lineSize,'MarkerSize',24);
figure(hFig2);  plot(xAxis,correspHom,mark(6,:),'Linewidth',lineSize,'MarkerSize',24);

figure(hFig1);set(gca,'FontWeight','bold');
h_legend= legend('CoMIC','Harris','Hessian','Fast-9','Mser','Location','SouthEast'); %legend('ProfuseMser','Harris1','Harris2','Hessian1','Hessian2','Fast-9','Location','SouthEast');
set(gca,'FontWeight','bold');
set(h_legend, 'FontSize',legendFontSize)
set(gca,'FontWeight','bold','LineWidth',lineSize,'FontSize',labelSize);


figure(hFig2);set(gca,'FontWeight','bold');
h_legend = legend('CoMIC','Harris','Hessian','Fast-9','Mser','Location','SouthEast');
%     set(gca,'FontWeight','bold');
set(h_legend, 'FontSize',legendFontSize)
set(gca,'FontWeight','bold','LineWidth',lineSize,'FontSize',labelSize);

hFig3 = figure;clf;
grid on;
ylabel('Matching Score%','FontSize',labelSize,'FontWeight','bold')

figure(hFig3); axis([1.8 6 0 102]);
xAxis = 2:6;
xlabel(xlabelString,'FontSize',labelSize,'FontWeight','bold');

hold on;
hFig4 = figure;clf;
grid on;
ylabel('Number of matches','FontSize',labelSize,'FontWeight','bold')
xlabel(xlabelString,'FontSize',labelSize,'FontWeight','bold');
hold on;


figure(hFig3);  plot(xAxis,matching_scoreHom,mark(6,:),'Linewidth',lineSize,'MarkerSize',24);
% figure(hFig3);  plot(xAxis,matching_scoreHr1,mark(1,:),'Linewidth',2,'MarkerSize',14);
figure(hFig3);  plot(xAxis,matching_scoreHr3,mark(2,:),'Linewidth',lineSize,'MarkerSize',24);
% figure(hFig3);  plot(xAxis,matching_scoreHs1,mark(3,:),'Linewidth',2,'MarkerSize',14);
figure(hFig3);  plot(xAxis,matching_scoreHs2,mark(4,:),'Linewidth',lineSize,'MarkerSize',24);
figure(hFig3);  plot(xAxis,matching_scoreFas,mark(5,:),'Linewidth',lineSize,'MarkerSize',24);
% figure(hFig3);  plot(xAxis,matching_scoreFer,mark(1,:),'Linewidth',lineSize,'MarkerSize',24);
figure(hFig3);  plot(xAxis,matching_scoreMsr,'-d','Color',[1 0.6 0],'Linewidth',lineSize,'MarkerSize',24);
figure(hFig3);  plot(xAxis,matching_scoreHom,mark(6,:),'Linewidth',lineSize,'MarkerSize',24);

figure(hFig4);  plot(xAxis,nb_of_matchesHom,mark(6,:),'Linewidth',lineSize,'MarkerSize',24);
% figure(hFig4);  plot(xAxis,nb_of_matchesHr1,mark(1,:),'Linewidth',2,'MarkerSize',14);
figure(hFig4);  plot(xAxis,nb_of_matchesHr3,mark(2,:),'Linewidth',lineSize,'MarkerSize',24);
% figure(hFig4);  plot(xAxis,nb_of_matchesHs1,mark(3,:),'Linewidth',2,'MarkerSize',14);
figure(hFig4);  plot(xAxis,nb_of_matchesHs2,mark(4,:),'Linewidth',lineSize,'MarkerSize',24);
figure(hFig4);  plot(xAxis,nb_of_matchesFas,mark(5,:),'Linewidth',lineSize,'MarkerSize',24);
% figure(hFig4);  plot(xAxis,nb_of_matchesFer,mark(1,:),'Linewidth',lineSize,'MarkerSize',24);
figure(hFig4);  plot(xAxis,nb_of_matchesMsr,'-d','Color',[1 0.6 0],'Linewidth',lineSize,'MarkerSize',24);
figure(hFig4);  plot(xAxis,nb_of_matchesHom,mark(6,:),'Linewidth',lineSize,'MarkerSize',24);

figure(hFig3);set(gca,'FontWeight','bold');
h_legend=legend('CoMic','Harris','Hessian','Fast-9','Mser','Location','SouthEast');
%     set(gca,'FontWeight','bold','FontSize',30);
set(h_legend, 'FontSize',legendFontSize)
set(gca,'FontWeight','bold','LineWidth',lineSize,'FontSize',labelSize);

figure(hFig4);set(gca,'FontWeight','bold');
h_legend=legend('CoMic','Harris','Hessian','Fast-9','Mser','Location','NorthEast');
%     set(gca,'FontWeight','bold','FontSize',30);
set(h_legend, 'FontSize',legendFontSize)
set(gca,'FontWeight','bold','LineWidth',lineSize,'FontSize',labelSize);


hFig5 = figure;clf;
grid on;
ylabel('Repeatability %','FontSize',labelSize,'FontWeight','bold')

figure(hFig5); axis([1.8 6 0 102]);
xAxis = 2:6;
xlabel(xlabelString,'FontSize',labelSize,'FontWeight','bold');

hold on;
hFig6 = figure;clf;
grid on;
ylabel('Number of Correspondences','FontSize',labelSize,'FontWeight','bold')
xlabel(xlabelString,'FontSize',labelSize,'FontWeight','bold');
hold on;


figure(hFig5);  plot(xAxis,repeatMultMatchesHom,mark(6,:),'Linewidth',lineSize,'MarkerSize',24);
% figure(hFig1);  plot(xAxis,repeatHr1,mark(1,:),'Linewidth',2,'MarkerSize',14);
figure(hFig5);  plot(xAxis,repeatMultMatchesHr3,mark(2,:),'Linewidth',lineSize,'MarkerSize',24);
% figure(hFig1);  plot(xAxis,repeatHs1,mark(3,:),'Linewidth',2,'MarkerSize',14);
figure(hFig5);  plot(xAxis,repeatMultMatchesHs2,mark(4,:),'Linewidth',lineSize,'MarkerSize',24);
figure(hFig5);  plot(xAxis,repeatMultMatchesFas,mark(5,:),'Linewidth',lineSize,'MarkerSize',24);
% figure(hFig5);  plot(xAxis,repeatMultMatchesFer,mark(1,:),'Linewidth',lineSize,'MarkerSize',24);
figure(hFig5);  plot(xAxis,repeatMultMatchesMsr,'-d','Color',[1 0.6 0],'Linewidth',lineSize,'MarkerSize',24);
figure(hFig5);  plot(xAxis,repeatMultMatchesHom,mark(6,:),'Linewidth',lineSize,'MarkerSize',24);

% figure(hFig2);  plot(xAxis,correspHr1,mark(1,:),'Linewidth',2,'MarkerSize',14);
figure(hFig6);  plot(xAxis,correspMultMatchesHom,mark(6,:),'Linewidth',lineSize,'MarkerSize',24);
figure(hFig6);  plot(xAxis,correspMultMatchesHr3,mark(2,:),'Linewidth',lineSize,'MarkerSize',24);
% figure(hFig2);  plot(xAxis,correspHs1,mark(3,:),'Linewidth',2,'MarkerSize',14);
figure(hFig6);  plot(xAxis,correspMultMatchesHs2,mark(4,:),'Linewidth',lineSize,'MarkerSize',24);
figure(hFig6);  plot(xAxis,correspMultMatchesFas,mark(5,:),'Linewidth',lineSize,'MarkerSize',24);
% figure(hFig6);  plot(xAxis,correspMultMatchesFer,mark(1,:),'Linewidth',lineSize,'MarkerSize',24);
figure(hFig6);  plot(xAxis,correspMultMatchesMsr,'-d','Color',[1 0.6 0],'Linewidth',lineSize,'MarkerSize',24);
figure(hFig5);  plot(xAxis,repeatMultMatchesHom,mark(6,:),'Linewidth',lineSize,'MarkerSize',24);

figure(hFig5);set(gca,'FontWeight','bold');
h_legend= legend('CoMIC','Harris','Hessian','Fast-9','Mser','Location','SouthEast'); %legend('ProfuseMser','Harris1','Harris2','Hessian1','Hessian2','Fast-9','Location','SouthEast');
% set(gca,'FontWeight','bold');
set(h_legend, 'FontSize',legendFontSize)
set(gca,'FontWeight','bold','LineWidth',lineSize,'FontSize',labelSize);


figure(hFig6);set(gca,'FontWeight','bold');
h_legend = legend('CoMIC','Harris','Hessian','Fast-9','Mser','Location','SouthEast');
% set(gca,'FontWeight','bold');
set(h_legend, 'FontSize',legendFontSize)
set(gca,'FontWeight','bold','LineWidth',lineSize,'FontSize',labelSize);

detPtsFileRep=fullfile('..','data','results',sprintf('%s',datastring),'Repeatability.png');
detPtsFileRepMany2One=fullfile('..','data','results',sprintf('%s',datastring),'RepeatabilityMany2One.png');
detPtsFileCorres=fullfile('..','data','results',sprintf('%s',datastring),'Correspondences.png');
detPtsFileCorresMany2One=fullfile('..','data','results',sprintf('%s',datastring),'CorrespondencesMany2One.png');
detPtsFileMatchingScore=fullfile('..','data','results',sprintf('%s',datastring),'MatchingScore.png');
detPtsFileNumMatches=fullfile('..','data','results',sprintf('%s',datastring),'NumMatches.png');

figure(hFig1); saveas(hFig1,detPtsFileRep);
figure(hFig2); saveas(hFig2,detPtsFileCorres);
figure(hFig3); saveas(hFig3,detPtsFileMatchingScore);
figure(hFig4); saveas(hFig4,detPtsFileNumMatches);
figure(hFig5); saveas(hFig5,detPtsFileRepMany2One);
figure(hFig6); saveas(hFig6,detPtsFileCorresMany2One);

end