function result=extend2(data,ny,nx)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This routine pads 'nx' columns to the left and right of the 'data' matrix
% by propagating the entries of the left and rightmost columns of the data
% matrix to those columns. It also pads 'ny' rows to the top and bottom
% of the 'data' matrix by propagating its top and bottom values to those
% rows.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs
%   data - the data matrix to be padded
%   nx, ny - no of cols and rows of padding to be added to the left and
%            right & top and bottom respectively of the 'data' matrix.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% pad nx extra columns of 'zeros' on each side of the 'data' matrix and ny 
% extra rows of 'zeros' to the top and bottom of the matrix.
[ysize,xsize]=size(data);
newxsize=xsize+2*nx;
newysize=ysize+2*ny;
result=zeros(newysize,newxsize);
result(ny+1:ysize+ny,nx+1:xsize+nx)=data;

% the zero paddings to the left and right of the 'data' matrix are replaced
% by propagating the values from the left-most and right-most columns of
% 'data' to all the padded columns. 
for x=1:nx result(:,x)=result(:,nx+1); end
for x=xsize+nx+1:newxsize result(:,x)=result(:,xsize+nx); end

% the zero paddings to the top and bottom of the 'data' matrix are replaced
% by propagating the values from the top and bottom columns of 'data' to 
% all the padded rows. 
for y=1:ny result(y,:)=result(ny+1,:); end
for y=ysize+ny+1:newysize result(y,:)=result(ysize+ny,:); end
