function [coordFg coordFgBound] = BGSubtraction(bgPath,imgPath,dilVal)
%give one pixwl leeway

detPtsFinal = [];
thresh = 10; numLarge=3;
background = imread(bgPath);
background = double((background));

% for i=1:length(imgnoList)
imageMain = imread(imgPath);
image = double((imageMain));
%subtraction
fgInit = abs(image - background);
szFG = size(fgInit);
fgFinal = zeros(szFG(1),szFG(2));
imgFinalOneDim = zeros(szFG(1),szFG(2));
imgFinal = zeros(szFG(1),szFG(2),3);
imgFinal0 = zeros(szFG(1),szFG(2),3);

%threshold to find connectd component in all 3 image parts
for numDim=1:3
    fg = fgInit(:,:,numDim);
    fg = uint8(fg);
    fgBinary = im2bw(fg,thresh/255); % "graythresh(I)" is Otsu's method for finding the optimal intensity level for performing an image threshold.
    check2 = 1;
    largeComponents = largestConnComp(fgBinary,numLarge,check2,fg);
    fg0 = zeros(szFG(1),szFG(2));
    fg0(largeComponents) = 1;
    fgFinal = fgFinal + fg0;
    %         figure, imshow(fg0);
end

%getting indices, coordinate values of valid foreground points
indFg = find(fgFinal);
nColors=2;
for numDim=1:3
    imgOneDim = imageMain(:,:,numDim);
    imgFinalOneDim(indFg) = imgOneDim(indFg);
    imgFinal0(:,:,numDim) = imgFinalOneDim;
end
imgFinal0 = uint8(imgFinal0);
cluster_idx = ColourSeg_temp(imgFinal0,indFg,nColors);
handTemplate = load('handTemplate');
% figure, imshow(imgFinal0);

for k = 1:nColors
    color1 = zeros(szFG(1),szFG(2));
    seg_ind{k} = indFg(cluster_idx == k);
    for i=1:3
        tempImg = imageMain(:,:,i);
        colorVals = tempImg(seg_ind{k});
        color1(seg_ind{k}) = colorVals;
        color(:,:,i) = color1;
        histColor(:,i) = hist(colorVals,1:10:255);
    end
    
    %     figure, imshow(uint8(color));
    %     save('handTemplate','histColor');
    corrValF = corr(histColor,handTemplate.histColor);
    corrVal(k) = mean(diag(corrValF));
    %     figure,imshow(uint8(color));
end

[maxCorrVal maxCorrInd] = max(corrVal);
maskHand = zeros(szFG(1),szFG(2));
maskHand(seg_ind{maxCorrInd}) = 1;
indHand = largestConnComp(maskHand,1);
indHand = indHand{1};
indFg = setdiff(indFg,indHand);

segMask = zeros(szFG(1),szFG(2));
segMask(indFg)=1;
indFg = largestConnComp(segMask,1);
indFg = indFg{1};

fgFinal0 = zeros(szFG(1),szFG(2));
fgFinal0(indFg) = 1;
se = strel('disk',dilVal);
fgFinal = imdilate(fgFinal0,se); %can use bwmorph also but it dilates too much
%     figure, imshow(fgFinal);
%     figure, imshow(fgFinal1);

indFg = find(fgFinal);
[rowFg colFg] = find(fgFinal);
coordFg = [colFg rowFg];
boundFg = bwboundaries(fgFinal0);
fgBoundary = zeros(szFG(1),szFG(2));

for b=1:size(boundFg,1)
    if size(boundFg{b},1) > 100      
        boundPixels = (boundFg{b}(:,2)-1).*szFG(1) + boundFg{b}(:,1);
        fgBoundary(boundPixels) = 1; 
    end
end

% se1 = strel('disk',2*dilVal);
fgBoundary = imdilate(fgBoundary,se); %can use bwmorph also but it dilates too much
[rowFgBound colFgBound] = find(fgBoundary);
coordFgBound = [colFgBound rowFgBound];

imgFinalOneDim = zeros(szFG(1),szFG(2));
% coordFg = [colFg rowFg];
for numDim=1:3
    imgOneDim = imageMain(:,:,numDim);
    imgFinalOneDim(indFg) = imgOneDim(indFg);
    imgFinal(:,:,numDim) = imgFinalOneDim;
end
imgFinal = uint8(imgFinal); %background subtracted image, for checking

% figure, imshow(imgFinal);
end


function largeComponents = largestConnComp(mask,numLarge,check2,fg)
if ~exist('check2')
    check2 = 0;
end

connected = bwconncomp(mask);
maxSizeComp = 0;
for conn=1:connected.NumObjects
    sizeComp = length(connected.PixelIdxList{1,conn});
    maxSizeComp(conn) = sizeComp;
end
[~, indLarge] = sort(maxSizeComp,'descend');
largeComponents = connected.PixelIdxList(1,indLarge(1:numLarge));

if check2
    for indL=1:numLarge
        diffVal(indL) = mean(fg(largeComponents{indL}));
    end
    [~,indMaxRegion] = max(diffVal);
    biggestConn = indLarge(indMaxRegion);
    
    largeComponents  = connected.PixelIdxList{1,biggestConn};
end

end