function [repeat,corresp, match_score,matches]=repeatability(file1,file2,Hom,imf1,imf2,imgNo,origSizeFile,dSetNo,dataset,dispPath)
overErr = 4;
imDirData = '../images';
match_score=[]; matches=[];
%
%Computes repeatability and overlap score between two lists of features
%detected in two images.
%   [erro,repeat,corresp,matched,matchedp]=repeatability('file1','file2','H4to1','imf1','imf2','-ko');
%
%IN:
%    file1 - file 1 with detected features
%    file2 - file 2 with detected features
%    H - file with 3x3 Homography matrix from image 1 to 2, x2=H*x1
%        Assumes that image coordiantes are 0..width.
%    imf1 - image file  1
%    imf2 - image file  2
%    common_part - flag should be set to 1 for repeatability and 0 for descriptor performance
%
%OUT :    erro - overlap %
%         repeat - repeatability %
%         corresp - nb of correspondences
%         match_score  - matching score
%         matches - number of correct nearest neighbour matches
%         twi - matrix with overlap errors<50\%
%
%  region file format :
%--------------------
%descriptor_size
%nbr_of_regions
%x1 y1 a1 b1 c1 d1 d2 d3 ...
%x2 y2 a2 b2 c2 d1 d2 d3 ...
%....
%....
%---------------------
%x, y - center coordinates
%a, b, c - ellipse parameters ax^2+2bxy+cy^2=1
%d1 d2 d3 ... - descriptor invariants
%if descriptor_size<=1 the descriptor is ignored

%% Reading input files
feat1Rep=[]; feat2Rep=[]; feat1Mat=[]; feat2Mat=[];
addCheck = 1;
[f1 s1 dimdesc1]=loadFeatures(file1);
[f2 s2 dimdesc2]=loadFeatures(file2);
H=load(Hom);
imCut = 0; %0.7*blocksizeMax/2; %imCut is not used at all in this function
[commonVar,repVar] = globalVariables(imgNo);
im1=imread(imf1); im2=imread(imf2);
im1x=size(im1) - imCut; %im1x=round(size(im1)./3.33);
im1y=im1x(1); im1x=im1x(2);
im2x=size(im2) - imCut; %im2x=round(size(im2)./3.33);
im2y=im2x(1); im2x=im2x(2);

if dSetNo~=8
  origSize = csvread(origSizeFile);
  resizeFactorPts = origSize./[im1y im1x];
  scaleFact = sqrt((resizeFactorPts(1)^2 + resizeFactorPts(2)^2)/2);   %more accurate than scaleFac = 700./origSize(1); Detection of features is done at the standard size of 700X1000, points are resized to the value specified in the groundtruth
  scaleMax = sqrt(1/max(f1(3,:)./(scaleFact*scaleFact)))/commonVar.smoothingFactor;
  blocksizeMax = round(scaleMax*commonVar.iterBlockFactor/5)*5*commonVar.blockMultFactor;
end

if 0
  fprintf(1,'nb of regions in file1 %d - descriptor dimension %d.\n',s1,dimdesc1);
  fprintf(1,'nb of regions in file2 %d - descriptor dimension %d.\n',s2,dimdesc2);
end
if size(f1,1)==5 & size(f1,1)==size(f2,1)
  %     fprintf(1,'%s looks like file with affine regions...\n',file1);
  if  size(f1,1)~= 5 | size(f1,1) ~= 5
    error('Wrong ascii format of %s or %s files.',file1,file2);
  end
elseif dimdesc1>1 & dimdesc1==dimdesc2
  %     fprintf(1,'%s, %s look like files with descriptors...\n',file1,file2);
else
  error('Different descriptor dimension in %s or %s files.',file1,file2);
end

dimdesc=dimdesc1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% allocate vectors for the features
feat1=zeros(9+dimdesc,s1);
feat2=zeros(9+dimdesc,s2);
feat1(1:5,1:s1)=f1(1:5,1:s1);
feat2(1:5,1:s2)=f2(1:5,1:s2);

if dSetNo~=8
  feat1 = ResizePts(feat1,resizeFactorPts);
  feat2 = ResizePts(feat2,resizeFactorPts);
end

if size(f1,1)>1
  feat1(10:9+dimdesc,1:s1)=f1(6:5+dimdesc,1:s1);
  feat2(10:9+dimdesc,1:s2)=f2(6:5+dimdesc,1:s2);
end

%% Project and Resize regions
HI=H(:, 1:3);
% HI = HI*[resizeFactorPts(1) 0 0; 0 resizeFactorPts(2) 0; 0 0 1];

if dSetNo==7
  HI=inv(H);
else
  H=inv(HI);
end

% fprintf(1,'Projecting 1 to 2...');
if dSetNo==8
  s1 = sqrt(1/feat1(3,1)); s2 = sqrt(1/feat1(3,1));  %s1 = 5.5; s2 = 5.5;
  scales1 = repmat(s1,4,size(feat1,2)); scales2 = repmat(s2,4,size(feat2,2));
  feat1(6:9,:) = scales1; feat2(6:9,:) = scales2;
  feat1 = feat1'; feat1t = feat1; scales1 = scales1(1,:);
  feat2 = feat2'; feat2t = feat2; scales2 = scales2(1,:);
else
  [feat1 feat1t scales1]=project_regions(feat1',HI);
  % fprintf(1,'and 2 to 1...\n');
  [feat2 feat2t scales2]=project_regions(feat2',H);
end

if 0
  imOrig = imresize(imread(imf2),scaleFact);
  figure, imshow(imOrig);showellipticfeaturesSPL(feat2);
  figure, imshow(imOrig);showellipticfeaturesSPL(feat1t);
  
  imOrig = imresize(imread(imf1),scaleFact);
  figure, imshow(imOrig);showellipticfeaturesSPL(feat1);
  figure, imshow(imOrig);showellipticfeaturesSPL(feat2t);
end

if dSetNo~=8
  feat1 = ResizePts(feat1',1./resizeFactorPts);
  feat2 = ResizePts(feat2',1./resizeFactorPts);
  feat1t = ResizePts(feat1t',1./resizeFactorPts);
  feat2t = ResizePts(feat2t',1./resizeFactorPts);
  feat1 = feat1'; feat1t = feat1t'; feat2 = feat2'; feat2t = feat2t';
end

if 0
  figure, imshow(imf2); hold on; showellipticfeaturesSPL(feat2,[1 1 0]);
  figure, imshow(imf2); hold on; showellipticfeaturesSPL(feat1t',[1 0 0]);
  
  hFig0 = figure, imshow(imf1); hold on; showellipticfeaturesSPL(feat1',[1 1 0]);
  figure, imshow(imf1); hold on; showellipticfeaturesSPL(feat2t',[1 0 0]);
  saveas(hFig0,'Hessian-initOverlap')
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if 1 %common_part==1
  %     fprintf(1,'Removing features from outside of the common image part...\n');
  ind=find((feat1(:,1)+feat1(:,8))<im1x & (feat1(:,1)-feat1(:,8))>0+imCut & (feat1(:,2)+feat1(:,9))<im1y & (feat1(:,2)-feat1(:,9))>0+imCut);
  feat1=feat1(ind,:);
  feat1t=feat1t(ind,:);
  ind01 = ind;
  ind=find((feat1t(:,1)+feat1t(:,8))<im2x & (feat1t(:,1)-feat1t(:,8))>0+imCut & (feat1t(:,2)+feat1t(:,9))<im2y & (feat1t(:,2)-feat1t(:,9))>0+imCut);
  feat1=feat1(ind,:);
  feat1t=feat1t(ind,:);
  ind02 = ind;
  ind1 = ind01(ind02);
  scales1=scales1(ind);
  
  ind=find((feat2(:,1)+feat2(:,8))<im2x & (feat2(:,1)-feat2(:,8))>0+imCut & (feat2(:,2)+feat2(:,9))<im2y & (feat2(:,2)-feat2(:,9))>0+imCut);
  feat2t=feat2t(ind,:);
  feat2=feat2(ind,:);
  ind01 = ind;
  ind=find((feat2t(:,1)+feat2t(:,8))<im1x & (feat2t(:,1)-feat2t(:,8))>0+imCut & (feat2t(:,2)+feat2t(:,9))<im1y & (feat2t(:,2)-feat2t(:,9))>0+imCut);
  feat2t=feat2t(ind,:);
  feat2=feat2(ind,:);
  ind02 = ind;
  ind2 = ind01(ind02);
  scales2=scales2(ind);
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  if 0
    fprintf(1,'nb of regions in common part in image1 %d.\n',size(feat1,1));
    fprintf(1,'nb of regions in common part in image2 %d.\n',size(feat2t,1));
  end
end
% if changeRepFormula, sf=max([size(feat1,1) size(feat2t,1)]);


feat1=feat1';
feat1t=feat1t';
feat2t=feat2t';
feat2=feat2';

szFeat = size(feat1,1);
if 0 %for i = 1 : szFeat
  %     numMaxOverlap = round((pi*overRad*overRad)/4);
  %     distVals0 = closestPt(f1(1:2,i)', f1',1,min(numMaxOverlap,size(f1,2)));
  %     indOvrLap = find(distVals0 <= overRad);
  %     overlapPerF(i) = length(indOvrLap);
end
% overlapPer = mean(overlapPerF);
if 0
  fprintf(1,'Computing overlap error & selecting one-to-one correspondences: ');
end
%c_eoverlap is a C implementation to compute the overlap error.
%% Get shifted points at bound, non bound, for Middlebury
switch dSetNo
  case 4
    disparity = double(imread(sprintf('%s/%s/groundtruth.pgm',imDirData,dataset)));
    boundaryPartsPlus = imread(sprintf('%s/%s/occ_and_discont.png',imDirData,dataset));
    feat1Res = ResizePts(feat1,resizeFactorPts); feat2Res = ResizePts(feat2,resizeFactorPts);
    feat2tAll = AddDisparityNDisplay2(feat1Res',disparity,boundaryPartsPlus,dataset,imf1,imf2,feat2Res',resizeFactorPts);%imf1); %holds for desciptor vectors too
    feat1 = feat2;
    
  case 8
    feat2tAll = stereoKITTI(feat1',feat2',dispPath,imf1,imf2);
    feat1 = feat2;
    
  otherwise
    feat2tAll{1} = feat2t;
end
%         Match using SSD right here and compare the disparities

%% Repeatability calculation
erro=[10:10:60];
for fT=1:size(feat2tAll,1) %Introduce a plugin and get a graph %
  feat2t = feat2tAll{fT};
  sf=min([size(feat1,2) size(feat2t,2)]);
  common_part=1;
  if ~isempty(feat2t)
    tic; [wout, twout, dout, tdout]=c_eoverlap(feat1,feat2t,common_part); %feat1 has been changed to feat2 for dSset=4
    %     t=toc; fprintf(1,' %.1f sec.\n',t);
    corresp0=zeros(1,6);
    for i=1:6,
      wi=(wout<erro(i));
      corresp0(i)=sum(sum(wi));
      if i==overErr
        [indF2 indF1] = find(wi==1);
        feat1Rep = feat1(1:5,indF1); feat2Rep = feat2t(1:5,indF2);
      end
    end
    repeat0=100*corresp0/sf;
    repeat(fT) = repeat0(overErr); corresp(fT) = corresp0(overErr);
  else
    repeat(fT) = 0; corresp(fT) = 0;
  end
  
  if 0
    fprintf(1,'\noverlap error: ');
    fprintf(1,'%.1f ',erro);
    fprintf(1,'\nrepeatability: ');
    fprintf(1,'%.1f ',repeat);
    fprintf(1,'\nnb of correspondences: ');
    fprintf(1,'%.0f ',corresp);
    fprintf(1,'\n');
  end
  %% Matching score
  if dSetNo~=8
    if 0 %get desc directly from test
      des1 = getSiftDescriptor(rgb2gray(im1),feat1(1:5,:)); feat1 = [feat1(1:9,:); double(des1)];
      des2 = getSiftDescriptor(rgb2gray(im2),feat2(1:5,:)); feat2t = [feat2t(1:9,:); double(des2)];
    end
    
    common_part=0;
    [wout, twout, dout, tdout]=c_eoverlap(feat1,feat2t,common_part);
    match_overlap=50;
    %     fprintf(1,'Matching with the descriptor for the overlap error < %d\%\n',match_overlap);
    if common_part==0
      twi=(twout<match_overlap);
    else
      twi=(wout<match_overlap);
    end
    
    
    detInd1 = regexp(file1,'0.');
    detInd2 = regexp(file1,'.sift');
    detType = file1(detInd1+2:detInd2-1);
    
    if 0 %strcmp(detType,'harronmser') && addCheck %can get screwed up for scale invariance
      shapeCheck=1;
      qtyThresh = 0.18; % show the point
      
      matchMatFinal = 1000000*ones(size(feat2,2),size(feat1,2));
      color = rand(size(feat2,2),3);
      for fNo = 1:size(feat2,2)
        disp(fNo);
        imgInd = regexp(imf2, '[0-9]'); imgno2 =  imf2(imgInd);
        centerM(1,:) = round(feat2(1:2,fNo)); sxi2 = feat2(6,fNo);
        sc2 = getBlAroundPt(pathToLoad,str2double(imgno2),fNo,shapeCheck,ind2);%block1 =(..,centerM,sxi2);
        %         selCutDes{2} = find(block1);
        [val, closeInds] = sort(tdout(fNo,:));
        bestPtNotFound = 1; numClose = 1;
        qtyValPrev = qtyThresh;
        while numClose <= 4 %bestPtNotFound
          closeFeat = closeInds(numClose);
          centerM(1,:) = round(feat1(1:2,closeFeat));
          sc1 = getBlAroundPt(pathToLoad,1,closeFeat,shapeCheck,ind1);%block2 =(..,centerM,sxi2);
          %             selCutDes{1} = find(block2);
          if shapeCheck
            sc_cost = getbestMatch(sc1,sc2);
            qtyVal = sc_cost;
          else
            areaDiff = setxor(selCutDes{1}, selCutDes{2});
            areaDiffWtd = length(areaDiff);
            if length(selCutDes{1}) < length(selCutDes{2});
              weightsSum = length(selCutDes{2});
            else
              weightsSum = length(selCutDes{1});
            end
            qtyVal = areaDiffWtd;
            qtyThresh = 0.35*weightsSum;
          end
          if qtyVal < qtyThresh && qtyVal < qtyValPrev %switch off the bad ones
            %                 bestPtNotFound = 0;
            qtyValPrev = qtyVal;
            matchMatFinal(fNo,closeFeat) = tdout(fNo,closeFeat);
            if 1
              figure, imshow(imf1); hold on; showellipticfeaturesSPL(feat1(:,closeFeat)',color(fNo,:),1,0,1);
              showellipticfeaturesSPL(feat1(:,closeInds(1))',[1 0 0],1,0,1);
              figure, imshow(imf2); hold on; showellipticfeaturesSPL(feat2(:,fNo)',color(fNo,:),1,0,1);
              close all;
            end
          end
          numClose = numClose + 1;
        end
        if bestPtNotFound
          numClose=1;
          %             matchMatFinal(fNo,closeInds(1:5)) = tdout(fNo,closeInds(1:5));
        end
        matchMatFinal(fNo,closeInds(numClose:5)) = tdout(fNo,closeInds(numClose:5));
      end
      
      %     one-to-one matching
      matchMat = matchMatFinal;
      minVal = 0;
      matchMatFinal0 = zeros(size(feat2,2),size(feat1,2));
      while 1
        minValNew  = min(min(matchMat));
        if minValNew == 1000000
          break;
        end
        [mini minj] = find(matchMat==minValNew);
        matchMat(mini(1),:) = 1000000;
        matchMat(:,minj(1)) = 1000000;
        matchMatFinal0(mini(1),minj(1)) = minValNew;
        minVal = minValNew;
        %         featMatch1 = [featMatch1; f1(mini(1),:)];
        %         featMatch2 = [featMatch2; f2(minj(1),:)];
      end
      dx=(matchMatFinal0>0).*(twi);
    else
      dx=(dout<1000000).*(twi);
    end
    if 0
      hFig1 = figure; imshow(im1); hold on;
      [x2 x1] = find(dx==1);
      color = rand(length(x1),3);
      showellipticfeaturesSPL(feat1(:,x1)',color);
      showellipticfeaturesSPL(feat2t(:,x2)',color);
      
      x2NotThere = setdiff(1:size(dx,1),x2);
      %     hFig1 = figure; imshow(im1); hold on;
      %     showellipticfeaturesSPL(feat2t(:,x2NotThere)','r');
      %     showellipticfeaturesSPL(feat1','g');
      %     %Gap:
      woutNotThere = wout(x2NotThere,:);
      [~,indNotThere] = find(woutNotThere<40); %display curves for all these
      hFig1 = figure; imshow(im1); hold on;
      showellipticfeaturesSPL(feat2t(:,x2NotThere)','r');
      showellipticfeaturesSPL(feat1(:,indNotThere)','g');
      
      shapeCheck=1; imgInd = regexp(imf2, '[0-9]'); imgno2 =  imf2(imgInd);
      for aa=1:length(indNotThere)
        sc2 = getBlAroundPt(pathToLoad,str2double(imgno2),x2NotThere(aa),shapeCheck,ind2);%block1 =(..,centerM,sxi2);
        sc1 = getBlAroundPt(pathToLoad,1,indNotThere(aa),shapeCheck,ind1);%block2 =(..,centerM,sxi2);
      end
      saveas(hFig1,'Hessian-matches');
    end
    % dx=(dout<10000).*(twi);
    [pt2 pt1] = find(dx);    feat1Mat = feat1(:,pt1)';    feat2Mat = feat2t(:,pt2)';
    
    if 0
      featA = feat1t(:,pt1)';
      featB = feat2(:,pt2)';
      num1 = round(rand(1)*200); num2 = round(rand(1)*200)
      figure(num1), imshow(imf2), figure(num2), imshow(imf2),
      for i=1:size(featA,1)
        color = rand(1,3);
        figure(num1), hold on; showellipticfeaturesSPL(featA(i,:),color);
        figure(num2), hold on; showellipticfeaturesSPL(featB(i,:),color);
      end
      pt2NonMatch = setdiff(1:size(dx,1),pt2);
      featB_NM = feat2(:,pt2NonMatch)';
      figure, imshow(imf2), hold on; showellipticfeaturesSPL(featB_NM,color);
      
      [pt2R pt1R] = find(wi);
      pt2NonMatch = intersect(pt2R,pt2NonMatch); %color =  0.5469    0.9575    0.9649, good for matching
      featB_NM = feat2(:,pt2NonMatch)';
      figure, imshow(imf2), hold on; showellipticfeaturesSPL(featB_NM,color);
      
      figure, imshow(imf2), hold on, showellipticfeaturesSPL(feat1t',color);
      figure, imshow(imf2), hold on, showellipticfeaturesSPL(feat2',color);
    end
    
    matches(fT)=sum(sum(dx));
    match_score(fT)=100*matches/sf;
  end
end
% fprintf(1,'Matching score  %0.1f, nb of correct matches %.1f.\n',match_score,matches);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [feat,featp,scales]=project_regions(feat,H)

s=size(feat);
s1=s(1);

featp=feat;
scales=zeros(1,s1);

for c1=1:s1,%%%%%%%%%%%%%%%%%
  %feat(c1,3:5)=(1/25)*feat(c1,3:5);
  Mi1=[feat(c1,3) feat(c1,4);feat(c1,4) feat(c1,5)];
  
  %compute affine transformation
  [v1 e1]=eig(Mi1);
  d1=(1/sqrt(e1(1)));
  d2=(1/sqrt(e1(4)));
  sc1=sqrt(d1*d2);
  feat(c1,6)=d1;
  feat(c1,7)=d2;
  scales(c1)=sqrt(feat(c1,6)*feat(c1,7));
  
  %bounding box
  feat(c1,8) = sqrt(feat(c1,5)/(feat(c1,3)*feat(c1,5) - feat(c1,4)^2));
  feat(c1,9) = sqrt(feat(c1,3)/(feat(c1,3)*feat(c1,5) - feat(c1,4)^2));
  
  
  Aff=getAff(feat(c1,1),feat(c1,2),sc1, H);
  
  %project to image 2
  l1=[feat(c1,1),feat(c1,2),1];
  l1_2=H*l1';
  l1_2=l1_2/l1_2(3);
  featp(c1,1)=l1_2(1);
  featp(c1,2)=l1_2(2);
  BMB=inv(Aff*inv(Mi1)*Aff');
  [v1 e1]=eig(BMB);
  featp(c1,6)=(1/sqrt(e1(1)));
  featp(c1,7)=(1/sqrt(e1(4)));
  featp(c1,3:5)=[BMB(1) BMB(2) BMB(4)];
  %bounding box in image 2
  featp(c1,8) = sqrt(featp(c1,5)/(featp(c1,3)*featp(c1,5) - featp(c1,4)^2));
  featp(c1,9) = sqrt(featp(c1,3)/(featp(c1,3)*featp(c1,5) - featp(c1,4)^2));
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function Aff=getAff(x,y,sc,H)
h11=H(1);
h12=H(4);
h13=H(7);
h21=H(2);
h22=H(5);
h23=H(8);
h31=H(3);
h32=H(6);
h33=H(9);
fxdx=h11/(h31*x + h32*y +h33) - (h11*x + h12*y +h13)*h31/(h31*x + h32*y +h33)^2;
fxdy=h12/(h31*x + h32*y +h33) - (h11*x + h12*y +h13)*h32/(h31*x + h32*y +h33)^2;

fydx=h21/(h31*x + h32*y +h33) - (h21*x + h22*y +h23)*h31/(h31*x + h32*y +h33)^2;
fydy=h22/(h31*x + h32*y +h33) - (h21*x + h22*y +h23)*h32/(h31*x + h32*y +h33)^2;

Aff=[fxdx fxdy;fydx fydy];
end


function [feat nb dim]=loadFeatures(file)
fid = fopen(file, 'r');
dim=fscanf(fid, '%f',1);
if dim==1
  dim=0;
end
nb=fscanf(fid, '%d',1);
feat = fscanf(fid, '%f', [5+dim, inf]);
fclose(fid);
end

