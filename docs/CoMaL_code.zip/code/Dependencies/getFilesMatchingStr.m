function [filesMatch imgIndCell] = getFilesMatchingStr(datastring,str)

dirData = dir(sprintf('../data/results/%s',datastring));
fileList = {dirData.name}';
imgIndCell = regexp(fileList , str);
matchValid = cellfun(@isempty,imgIndCell);
filesMatch = fileList(~matchValid);
imgIndCell = imgIndCell(~matchValid);

% getFilesMatchingStr(datastring,definingStr);
% definingStr can be mor than one string, loop over all of it
% num = regexp(filesMatch,'[0-9]');
%if not contiguous, get them as seperate numbers
