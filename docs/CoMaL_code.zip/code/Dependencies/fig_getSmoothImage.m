function [imGraySmooth szIm] = fig_getSmoothImage(imgName)

im = imread(imgName);
szIm = size(im);
imGray = rgb2gray(im);  H = fspecial('disk',25); imGraySmooth = imfilter(imGray,H,'replicate');

end