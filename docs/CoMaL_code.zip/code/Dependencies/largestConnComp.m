function [largeComponents diffVal largeComponents0] = largestConnComp(mask,numLarge,ifDense,check2,fg)
if ~exist('ifDense')
    check2 = 0;
    ifDense = 0;
end

if ~exist('check2')
    check2 = 0;
end

connected = bwconncomp(mask);
maxSizeComp = 0;
for conn=1:connected.NumObjects
    sizeComp = length(connected.PixelIdxList{1,conn});
    maxSizeComp(conn) = sizeComp;
end
[~, indLarge] = sort(maxSizeComp,'descend');
numLarge  = min(numLarge,connected.NumObjects);
largeComponents = connected.PixelIdxList(1,indLarge(1:numLarge));

if ifDense
    szMask = size(mask);
    for i=1:numLarge
        mask = zeros(szMask(1),szMask(2));
        mask(largeComponents{i}) = 1;
        areaComp(i) = bwarea(mask);
    end
    
    density = areaComp./maxSizeComp(indLarge(1:numLarge));
    indDense = find(density<1.03);
    largeComponents = largeComponents(indDense);
end

if check2
    [sz1 sz2 sz3] = size(fg);
    for indL=1:numLarge
        for dim=1:sz3
            fgTemp = fg(:,:,dim);
            diffVal(indL,dim) = mean(fgTemp(largeComponents{indL}));
        end
    end
    [~,indMaxRegion] = max(diffVal);
    %     biggestConn = indLarge(indMaxRegion);
    largeComponents0 = largeComponents;
    largeComponents  = largeComponents{1,indMaxRegion};
end

end