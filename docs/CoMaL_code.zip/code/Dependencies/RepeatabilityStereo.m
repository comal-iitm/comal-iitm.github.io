function RepeatabilityStereo

detectorTypes = ['har';'hes'];
stereoType = ['L'; 'R'];
firsttime=1; resizefactor=1;

if 0
occ = imread('./stereo/occ-depthdisc.png');
% occ = imresize(occ,2);
disparity = double(imread('./stereo/groundtruth.gif'));
% disparity = imresize(disparity,2);
disparity = disparity./4;
[ysize,xsize] = size(occ);
% [ygrid xgrid]= meshgrid(1:xsize,1:ysize);
% xgrid2 = round(xgrid - disparity);   

occ2 = zeros(ysize,xsize);
[row col] = find(occ2==0);
for i=1:length(row)
    colNew = round(col(i) - disparity(row(i),col(i)));
    occ2(row(i),colNew) = 1;
end


if 0
for i=1:ysize
    for j=1:xsize
        
        jnew = round(j-(disparity(i,j)));
%        try
        occ2(i,jnew) = occ(i,j);
%          catch
%             aa=1;
%         end
        
        
    end
end
end
% for i=1:ysize*xsize
%     
%  occ2(xgrid2(i),ygrid(i)) = occ(xgrid(i),ygrid(i));
%     
% end

% occ22=reshape(occ2,ysize,xsize);
end

if firsttime %Add disparity
for i=1:2
    %     im=imread(sprintf('./stereo/im%s.png',stereoType(i,:)));
    %     figure,imshow(occ);figure,imshow(im);
    file1 = sprintf('./stereo/%s.harronmser.txt',stereoType(i,:)); % harronmser
    file2 = sprintf('./stereo/%s.harronmser.txt',stereoType(mod(2*i,3),:)); % harronmser
    harronmser=1;
    [f1New ysize xsize]= AddDisparity(file1,file2,i,harronmser);
    writeToFileTest(file1,f1New,1,xsize,ysize,0);
    
    if 1
    for pointtype=1:2
        file1 = sprintf('./stereo/%s.%s.txt',stereoType(i,:),detectorTypes(pointtype,:)); % harronmser
        file2 = sprintf('./stereo/%s.%s.txt',stereoType(mod(2*i,3),:),detectorTypes(pointtype,:)); % harronmser
        harronmser=0;
        [f1New ysize xsize]= AddDisparity(file1,file2,i,harronmser);
        writeToFile(file1,f1New,1,xsize,ysize,0);
        
    end
    end
    
end
end

commonVar = globalVariables;
showCorresFig = 1;

repFigFile = './stereo/repeatability.fig';
corrFigFile = './stereo/correspondence.fig';

repJpgFile  = './stereo/repeatability.jpg';
corrJpgFile = './stereo/correspondence.jpg';


hFig1 = figure;clf;
grid on;
ylabel('Repeatability %','FontSize',30,'FontWeight','bold')
xlabelString = 'Cones stereo pair';
figure(hFig1); axis([0.99 2 0 102]);
xAxis = 1:2;
xlabel(xlabelString,'FontSize',30,'FontWeight','bold');

hold on;
if showCorresFig
    hFig2 = figure;clf;
    grid on;
    ylabel('Number of Correspondences','FontSize',40,'FontWeight','bold')
    xlabel(xlabelString,'FontSize',40,'FontWeight','bold');
    hold on;
end

% mark=['-kx';'-rv';'-gs';'-m+';'-bp';'-yo'];
mark=['-kx';'-rx';'-kd';'-bx';'-yx';'-gx'];
markHar=['-ks';'-rs';'-rx';'-bs';'-ys';'-gs'];
markHes=['-kv';'-rv';'-bo';'-bv';'-yv';'-gv'];
% markMsr=['-kv';'-rv';'-gv';'-gp';'-bv';'-yv'];

seqrepeat=[]; seqrepeatHar=[]; seqrepeatHes=[]; seqrepeatMsr=[];
seqcorresp=[]; seqcorrespHar=[]; seqcorrespHes=[]; seqcorrespMsr=[];
seqViewPt=[];

img1 = 1;
viewPtAngle = 10;
imf1 = sprintf('./stereo/imL.png');
file1 = sprintf('./stereo/L.harronmser.txt'); % harronmser
fileHar1 = sprintf('./stereo/L.har.txt'); % harronmser
fileHes1 = sprintf('./stereo/L.hes.txt'); % harronmser
% fileMsr1 =fullfile('..','data','results',sprintf('%s',datastring),sprintf('img0.msr.txt'));

if exist(file1,'file') && exist(fileHar1,'file') && exist(fileHes1,'file') 
    
    imf2 = sprintf('./stereo/imR.png');
    file2 = sprintf('./stereo/R.harronmser.txt'); % harronmser
    fileHar2 = sprintf('./stereo/R.har.txt'); % harronmser
    fileHes2 = sprintf('./stereo/R.hes.txt'); % harronmser
    Hom = './stereo/Hunity';
    if exist(file2,'file') && exist(fileHar2,'file') && exist(fileHes2,'file') %&& exist(fileMsr2,'file')
        [erro,repeat,corresp, match_score,matches, twi]=repeatabilityHarrOnMser(file1,file2,Hom,imf1,imf2,1,resizefactor);
        [erro,repeatHar,correspHar, ~,~, ~]=repeatabilityHarrOnMser(fileHar1,fileHar2,Hom,imf1,imf2,1,resizefactor);
        [erro,repeatHes,correspHes, ~,~, ~]=repeatabilityHarrOnMser(fileHes1,fileHes2,Hom,imf1,imf2,1,resizefactor);
%         [erro,repeatMsr,correspMsr, ~,~, ~]=repeatabilityHarrOnMser(fileMsr1,fileMsr2,Hom,imf1,imf2,1);
        
        viewPtAngle = viewPtAngle+10;
        
        seqrepeat=[seqrepeat; repeat];
        seqrepeatHar=[seqrepeatHar; repeatHar];
        seqrepeatHes=[seqrepeatHes; repeatHes];
        %             seqrepeatMsr=[seqrepeatMsr; repeatMsr];
        
        seqcorresp=[seqcorresp; corresp]; % not used now
        seqcorrespHar=[seqcorrespHar; correspHar];
        seqcorrespHes=[seqcorrespHes; correspHes];
        %             seqcorrespMsr=[seqcorrespMsr; correspMsr];
        seqViewPt = [seqViewPt viewPtAngle];
        
    end
    
    
    for ovlErrIdx=3%:ovErJump:size(erro,2)
        
%         xAxis = xAxis(startimgno:endimgno-1);
        figure(hFig1);  plot(xAxis,[seqrepeat(:,ovlErrIdx) seqrepeat(:,ovlErrIdx)],mark(ovlErrIdx,:),'Linewidth',5,'MarkerSize',20);
        if showCorresFig
            
            figure(hFig2);  plot(xAxis,[seqcorresp(:,ovlErrIdx) seqcorresp(:,ovlErrIdx)],mark(ovlErrIdx,:),'Linewidth',5,'MarkerSize',20);
        end
        if commonVar.dispAllDetectors
            figure(hFig1);  plot(xAxis,[seqrepeatHar(:,ovlErrIdx) seqrepeatHar(:,ovlErrIdx)],markHar(ovlErrIdx,:),'Linewidth',5,'MarkerSize',20);
%             figure(hFig1);  plot(xAxis,[seqrepeatHes(:,ovlErrIdx) seqrepeatHes(:,ovlErrIdx)],markHes(ovlErrIdx,:),'Linewidth',5,'MarkerSize',20);
            %             figure(hFig1);  plot(xAxis,seqrepeatMsr(:,ovlErrIdx),markMsr(ovlErrIdx,:),'Linewidth',5,'MarkerSize',20);
            if showCorresFig
                figure(hFig2);  plot(xAxis,[seqcorrespHar(:,ovlErrIdx) seqcorrespHar(:,ovlErrIdx)],markHar(ovlErrIdx,:),'Linewidth',5,'MarkerSize',20);
%                 figure(hFig2);  plot(xAxis,[seqcorrespHes(:,ovlErrIdx) seqcorrespHes(:,ovlErrIdx)],markHes(ovlErrIdx,:),'Linewidth',5,'MarkerSize',20);
                %                 figure(hFig2);  plot(xAxis,seqcorrespMsr(:,ovlErrIdx),markMsr(ovlErrIdx,:),'Linewidth',5,'MarkerSize',20);
                
            end
        end
        %                 figure(hFig2);  plot(seqViewPt,seqcorresp(:,ovlErrIdx),mark(ovlErrIdx,:));
    end
    
    if 1
        %                 axis([10 70 0 100]);
        %                 figure(hFig1); axis([2 6 10 110]);
        figure(hFig1);set(gca,'FontWeight','bold');
        h_legend=legend('ProfuseMser','Harris','Hessian','MSER','Location','SouthEast');
        set(gca,'XTick',1:1:2); set(gca,'YTick',0:10:102)
        set(gca,'FontSize',40,'FontWeight','bold');
        set(h_legend, 'FontSize',40)
        %         h_legend=legend('HarrOnMser 10% o.e','Harris 10% o.e','Hessian 10% o.e','HarrOnMser 40% o.e','Harris 40% o.e','Hessian 40% o.e');
        %         set(h_legend, 'FontSize',20)
        if showCorresFig
            figure(hFig2); h_legend=legend('ProfuseMser','Harris','Hessian','MSER');%'Location','North' %%h_legend=legend('HarrOnMser 10% o.e','Harris 10% o.e','Hessian 10% o.e','HarrOnMser 40% o.e','Harris 40% o.e','Hessian 40% o.e');
            axis([0.99 2 0 300]); 
            set(gca,'XTick',1:1:2); 
            set(gca,'FontSize',40,'FontWeight','bold');
            set(h_legend, 'FontSize',40) %axis([58 100 0 2700]);
        end
    else
        
        figure(hFig1);legend(det_suffix(1,:),det_suffix(2,:),det_suffix(3,:),det_suffix(4,:),det_suffix(5,:),det_suffix(6,:),'FontSize',20);
        if showCorresFig
            figure(hFig2);legend(det_suffix(1,:),det_suffix(2,:),det_suffix(3,:),det_suffix(4,:),det_suffix(5,:),det_suffix(6,:),'FontSize',20);
        end
    end
    
end


% figure(hFig2);legend(det_suffix(1,:),det_suffix(2,:),det_suffix(3,:),det_suffix(4,:),det_suffix(5,:),det_suffix(6,:));

saveas(hFig1,repFigFile);
if showCorresFig
    saveas(hFig2,corrFigFile);
end
saveas(hFig1,repJpgFile);
if showCorresFig
    saveas(hFig2,corrJpgFile);
end


end