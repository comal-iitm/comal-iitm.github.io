function [cornerpoints cornervalues numberofpoints]= localminima_block(cornernessvals,windowszby2,padded)
% stack=dbstack;
% Timing('localmaxima_block',1,stack(2).name);

% ANKITA: divide the cornernessvals into blocks of equal size
% windowsize/3 then find the max of each of them and then successively
% take three adjacent three and find their max .if it comes out to be
% the second value then it is a good point


sizecornernessvals = size(cornernessvals,2);
blocksize=2*windowszby2/3;
k=floor(sizecornernessvals/blocksize);

%ANKITA: the number of points may not be a multiple of 3 hence remain1
%takes care of the remainder 

remain1=sizecornernessvals-blocksize*k;
% number of maximas we get = k
pt=zeros(2,k);
for i=0:k-1
    [a,b]=min(cornernessvals(blocksize*i+1:(i+1)*blocksize));
    pt(1,i+1)=a(end);
    pt(2,i+1)=b(end)+i*blocksize;
end
if (remain1>0)
    [a,b]=min(cornernessvals(sizecornernessvals-remain1+1:end));
    pt(1,k+1)=a(end);
    pt(2,k+1)=b(end)+k*blocksize;
end

k = size(pt,2);

maxpts=zeros(2,1000);
numberofpoints=0;
mx = [];
mxind=1;
i=1;
while (i+2) <= k
    [mx mxind]=min(pt(1,i:i+2));
    if mxind == 2
        numberofpoints=numberofpoints+1;
        maxpts(1,numberofpoints)=mx;
        maxpts(2,numberofpoints)=pt(2,i+1);
    end
    i=i+1;
end

maxpts=maxpts(:,1:numberofpoints);
% this is only to make it faster

% if cornerness was padded then we have some extra points choose
% only the valid points 
if(padded)
valid=find(maxpts(2,:)>windowszby2 & maxpts(2,:)<sizecornernessvals-windowszby2);
maxpts=maxpts(:,valid);
numberofpoints=size(maxpts,2);
maxpts(2,:)=maxpts(2,:)-windowszby2;
end

% 
% z=[];
% % % % if (number > 2*blocksize)
% % %     [z(1,1) z(2,1)]=max(points(:,1:(2*blocksize)),[],2);
% % %     
% % %     if(z(2,1)<=(blocksize) && z(2,1)>=(blocksize/2+3))
% % %         numberofpoints=numberofpoints+1;
% % %         t=[z t];
% % %     end
% % % end
% 
% if (number > remain1+blocksize)
%     [z(1,1) z(2,1)]=max(points(:,end-double(remain1)-double(blocksize)+1:end),[],2);
%     
%     if(z(2,1) > blocksize && z(2,1) < 2*blocksize)
%         numberofpoints=numberofpoints+1;
%         z(2,1)=z(2,1)+(k-3)*blocksize;
%         t=[t z ];
%     end
% end
% 
% 
%     
cornerpoints=(maxpts(2,:))';
cornervalues=(maxpts(1,:))';
% Timing('localmaxima_block',0,stack(2).name);
end
