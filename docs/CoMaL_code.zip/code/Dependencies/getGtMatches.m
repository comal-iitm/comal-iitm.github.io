function [mScore,numMatches,isValid,recall, prec] = getGtMatches(dataset,detType,desType,pair,delta,matchDisplStr,fgTypeCompB,thresh,resizeFactorPts)
isValid=1; mScore = zeros(3,1); numMatches = zeros(3,1); recall=zeros(3,1); prec=zeros(3,1);
switch desType
  case 'ssd', numIndex = 3;
  case 'sol', numIndex = 4;
  case 'sift', numIndex = 3;
end

[featMatch1 featMatch2 matchesFull flagFileFault feat1 feat2] = getFeatFromMatch(dataset,detType,desType,pair,delta,matchDisplStr,fgTypeCompB,thresh,numIndex);
dSetNo = getParamsAndDataset(dataset); imgnoStr1= getImgnoInStrOrInt(pair(1),dSetNo); imgnoStr2 = getImgnoInStrOrInt(pair(2),dSetNo);
imf1 = sprintf('../images/%s/img%s.ppm',dataset,imgnoStr1);
imf2 = sprintf('../images/%s/img%s.ppm',dataset,imgnoStr2);
if flagFileFault==1;
  isValid=0;
end

if ~flagFileFault & ~isempty(featMatch1)
  imDirData = '../images';overErr=2;
  H = [1 0 0; 0 1 0; 0 0 1];erro=[10:10:60];
  s1 = sqrt(1/featMatch1(3,1)); scale1 = repmat(s1,4,size(featMatch1,2));
  featMatch1 = [featMatch1; scale1]';
  s2 = sqrt(1/featMatch2(3,1)); scale2 = repmat(s2,4,size(featMatch2,2));
  featMatch2 = [featMatch2; scale2]';
  
  % [featMatch1 featMatch1t scales1]=project_regions(featMatch1',H);
  % [featMatch2 featMatch2t scales2]=project_regions(featMatch2',H);
  
  switch dSetNo
    case 4
      feat1Res = ResizePts(featMatch1',resizeFactorPts); feat2Res = ResizePts(featMatch2',resizeFactorPts);
      disparity = double(imread(sprintf('%s/%s/groundtruth.pgm',imDirData,dataset)));
      boundaryPartsPlus = imread(sprintf('%s/%s/occ_and_discont.png',imDirData,dataset));
      [featMatch1tAll feat1All]= AddDisparityNDisplay2(feat1Res',disparity,boundaryPartsPlus,dataset,imf1,imf2,feat2Res',resizeFactorPts);%imf1); %holds for desciptor vectors too
    case 8
      dispPath = sprintf('%s/%s/disp/disp%d_%d.png',imDirData ,dataset,pair(1),pair(2));
      [featMatch1tAll,featA,featWrong] = stereoKITTI(featMatch1,featMatch2,dispPath,pair,imf1,imf2);
      feat1tAll = stereoKITTI(feat1',feat2',dispPath,pair,imf1,imf2);
     case 9
      [featMatch1tAll,featA,featWrong] = flowKITTI(featMatch1,featMatch2,pair,imf1,imf2);      
      feat1tAll = flowKITTI(feat1',feat2',pair,imf1,imf2);%(f1,f2,flowPath,imf1,imf2);
  end
  
  for fT=1:3
    feat1t = featMatch1tAll{fT};
    if ~isempty(feat1t)
      tic; [wout, twout, dout, tdout]=c_eoverlap(featMatch2',feat1t,1); %feat1 has been changed to feat2 for dSset=4
      
      if 0
        color = rand(size(featMatch1,1),3); colorF = color;
        figure,imshow(imf1); hold on; showellipticfeaturesSPL(featMatch1,colorF,5,0,1,imf1);
        figure,imshow(imf2); hold on; showellipticfeaturesSPL(featMatch2,colorF,5,0,1,imf2);
        
        
        figure, imshow(imf2); hold on; showellipticfeaturesSPL(feat1t');
        figure, imshow(imf2); hold on; showellipticfeaturesSPL(featMatch2); showellipticfeaturesSPL(feat1t',[1 0 0]);
        showellipticfeaturesSPL(feat1t(:,indF2)',[0 1 0]);
        
        
        
      end
      %     t=toc; fprintf(1,' %.1f sec.\n',t);
      corresp0=zeros(1,6);
      for i=1:6,
        wi=(wout<erro(i));
        corresp0(i)=sum(sum(wi));
        if i==overErr
          [indF2 indF1] = find(wi==1);
          
        end
      end
      
      if fT==2% || fT==2
        color = rand(size(indF2,1),3); colorF = color;
%         figure,imshow(imf2); hold on; showellipticfeaturesSPL(featMatch2(indF1,:),colorF,5,0,1,imf2);
%         figure,imshow(imf1); hold on; showellipticfeaturesSPL(featA{fT}(:,indF2)',colorF,5,0,1,imf1);
%         mkdir(sprintf('../data/figs-delta%d/%s',delta,dataset));
        imname1 = sprintf('../data/figs-delta%d/%s/im%d_%s_%s_%d.jpg',delta,dataset,pair(1),detType,desType,fT);
        imname2 = sprintf('../data/figs-delta%d/%s/im%d_%s_%s_%d.jpg',delta,dataset,pair(2),detType,desType,fT);
        img1 = imread(imf1); img2 = imread(imf2);
        imfr1 = showellipticfeaturesSPL(featMatch2(indF1,1:5),colorF,4,0,0,img2);
        imwrite(imfr1,imname1);
        imfr2 = showellipticfeaturesSPL(featA{fT}(1:5,indF2)',colorF,4,0,0,img1);
        imwrite(imfr2,imname2);
      end
      
      %     repeat0=100*corresp0/sf;
      totPts = size(feat1tAll{fT},2);
      numMatches(fT) = corresp0(overErr);
      mScore(fT) = (numMatches(fT) /totPts)*100;%min(size(f1,2),size(feat1t,2)))*100;
      TP = numMatches(fT); TN = size(featWrong{fT},2); %true negative
      FN = totPts - size(feat1t,2);
      recall(fT) = TP/(TP + FN); %TP/(TP+FN), FN = missed points
      prec(fT) = TP/(size(feat1t,2)); %TP/(TP+FP)
    else
      numMatches(fT) = 0;  mScore(fT) = 0;%min(size(f1,2),size(feat1t,2)))*100;
      recall(fT) = 0; prec(fT) = 0;
    end
  end
end

end


function [feat,featp,scales]=project_regions(feat,H)

s=size(feat);
s1=s(1);

featp=feat;
scales=zeros(1,s1);

for c1=1:s1,%%%%%%%%%%%%%%%%%
  %feat(c1,3:5)=(1/25)*feat(c1,3:5);
  Mi1=[feat(c1,3) feat(c1,4);feat(c1,4) feat(c1,5)];
  
  %compute affine transformation
  [v1 e1]=eig(Mi1);
  d1=(1/sqrt(e1(1)));
  d2=(1/sqrt(e1(4)));
  sc1=sqrt(d1*d2);
  feat(c1,6)=d1;
  feat(c1,7)=d2;
  scales(c1)=sqrt(feat(c1,6)*feat(c1,7));
  
  %bounding box
  feat(c1,8) = sqrt(feat(c1,5)/(feat(c1,3)*feat(c1,5) - feat(c1,4)^2));
  feat(c1,9) = sqrt(feat(c1,3)/(feat(c1,3)*feat(c1,5) - feat(c1,4)^2));
  
  
  Aff=getAff(feat(c1,1),feat(c1,2),sc1, H);
  
  %project to image 2
  l1=[feat(c1,1),feat(c1,2),1];
  l1_2=H*l1';
  l1_2=l1_2/l1_2(3);
  featp(c1,1)=l1_2(1);
  featp(c1,2)=l1_2(2);
  BMB=inv(Aff*inv(Mi1)*Aff');
  [v1 e1]=eig(BMB);
  featp(c1,6)=(1/sqrt(e1(1)));
  featp(c1,7)=(1/sqrt(e1(4)));
  featp(c1,3:5)=[BMB(1) BMB(2) BMB(4)];
  %bounding box in image 2
  featp(c1,8) = sqrt(featp(c1,5)/(featp(c1,3)*featp(c1,5) - featp(c1,4)^2));
  featp(c1,9) = sqrt(featp(c1,3)/(featp(c1,3)*featp(c1,5) - featp(c1,4)^2));
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function Aff=getAff(x,y,sc,H)
h11=H(1);
h12=H(4);
h13=H(7);
h21=H(2);
h22=H(5);
h23=H(8);
h31=H(3);
h32=H(6);
h33=H(9);
fxdx=h11/(h31*x + h32*y +h33) - (h11*x + h12*y +h13)*h31/(h31*x + h32*y +h33)^2;
fxdy=h12/(h31*x + h32*y +h33) - (h11*x + h12*y +h13)*h32/(h31*x + h32*y +h33)^2;

fydx=h21/(h31*x + h32*y +h33) - (h21*x + h22*y +h23)*h31/(h31*x + h32*y +h33)^2;
fydy=h22/(h31*x + h32*y +h33) - (h21*x + h22*y +h23)*h32/(h31*x + h32*y +h33)^2;

Aff=[fxdx fxdy;fydx fydy];
end


function [feat nb dim]=loadFeatures(file)
fid = fopen(file, 'r');
dim=fscanf(fid, '%f',1);
if dim==1
  dim=0;
end
nb=fscanf(fid, '%d',1);
feat = fscanf(fid, '%f', [5+dim, inf]);
fclose(fid);
end


%
% matching_score=[];nb_of_matches=[];featMatch1RC=[]; featMatch2RC=[];
% featMatch1R = round(featMatch1(:,1:2)); featMatch2R = round(featMatch2(:,1:2));
% feat2Corres = feat1tAll{3}(); feat1Corres = feat1All{3};
% indValid0 = ismember([featMatch1R featMatch2R],[feat1Corres feat2Corres],'rows');
% featMatch1RC = featMatch1R(indValid0); featMatch2RC = featMatch2R(indValid0);
% size(featMatch2RC,1)/min(size(feat2Corres),size(feat1Corres,1));
%
% for i=1:2
%     feat2Set = feat1tAll{i};
%     feat2SetR = round(feat2Set);
%     indValid0 = ismember(featMatch2R,feat2SetR,'rows');
%     indValid = find(indValid0);
%     featMatch2R(indValid);
% end