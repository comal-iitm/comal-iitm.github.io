function fig_gaussianweighting1(imName0,threshI)

imgName = sprintf('../imagesFigure/%s',imName0);
im = imread(imgName);
szIm = size(im);

gaussICS = zeros(szIm(1),szIm(2));
gauss2D = fspecial('gaussian', [szIm(1) szIm(2)], 2);

for thresh = threshI - delta: threshI + delta
    maskICS = (im > thresh);
    bICS = bwboundaries(maskICS);
    gauss2dSamp = diag(gauss2D(bICS{1}(:,2),bICS{1}(:,1)));
    D = bwdist(~bw); %for other points
    gaussICS(bICS{1}(:,2),bICS{1}(:,1))) = gauss2dSamp;
    
end

figure, imshow(gaussICS); 

for thresh = threshI - delta: threshI + delta
    maskICS = (im > thresh);
    
    bICS = bwboundaries(maskICS);
    gauss2dSamp = diag(gauss2D(bICS{1}(:,2),bICS{1}(:,1)));
    D = bwdist(~bw); %for other points
    gaussICS(bICS{1}(:,2),bICS{1}(:,1))) = gauss2dSamp;
    
end