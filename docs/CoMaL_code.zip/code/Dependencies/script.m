%Use tuples when everything is run at least once

datasetsAll{1} = ['boxx';'doll';'hero';'hous';'jtoo';'pens';'race';'stnd'];
datasetsAll{2} = ['bord';'boxz';'cann';'cupp';'cycl';'dino';'lemm'];
detTypes{1} = 'harronmser'; detTypes{2} = 'har'; detTypes{3} = 'hes';
ifOtherDetectors = [0 1];

runDetDes = [0 0 0];
twoframeMatch=0; matchAllFrames = 1;
% Select2(0); % should be 0 and 1 together later.z

for dSetNo = 2%1:2
    datasets = datasetsAll{dSetNo};
    for i=1%:size(datasets,1) %run from dino harris (little done)
        dset = datasets(i,:); disp(dset);
        for det=1:3
            detType = detTypes{det};
            [matching_scoreNFrames{det},nb_of_matchesNFrames{det}] = RepeatabilityAllImageMatching(dset,detType,0,runDetDes(det),ifOtherDetectors(dSetNo),twoframeMatch, matchAllFrames);
        end
        
        if matchAllFrames
            savePath = sprintf('../data/graphs/%s',dset);
            if ~exist(savePath,'dir')
                mkdir(savePath);
            end
            matches = matching_scoreNFrames{1};
            save(sprintf('%s/harronmser',savePath),'matches');
            
            numFrames = size(matching_scoreNFrames{1},2);
            getFigure2(dset,sprintf('Matching Score for %d frames%',numFrames),'Number of matches',matching_scoreNFrames,nb_of_matchesNFrames);
        end
    end
end