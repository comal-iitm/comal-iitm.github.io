function [indFinal featFinal boundaryFinal scFinal topLeftFinal] = overlapCheck(f1Init,szImage,nonLcsBasedOverErr,lcsBasedOverErr,scSet,boundarySet,topLeftSet)
% Send dc inside. Get sc and more things out.

if ~exist('lcsBasedOverErr','var')
    lcsBasedOverErr = 0;
end
scThresh = 0.25;

s1 = size(f1Init,1);sizeCol = 1./(f1Init(:,3).^2);
feat1 = [f1Init(:,1:2) sizeCol zeros(s1,1) sizeCol repmat(f1Init(:,3),1,4)];
strengthMetric = f1Init(:,13); areaPer = f1Init(:,16); plusOrMinus = f1Init(:,20);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

im1x=szImage;im1y=im1x(1);im1x=im1x(2);
feat1(:,10) = feat1(:,1)+feat1(:,8);feat1(:,11) = feat1(:,1)-feat1(:,8);
feat1(:,12) = feat1(:,2)+feat1(:,9);feat1(:,13) = feat1(:,2)-feat1(:,9);

ind=find((feat1(:,1)+feat1(:,8))<im1x & (feat1(:,1)-feat1(:,8))>0 & (feat1(:,2)+feat1(:,9))<im1y & (feat1(:,2)-feat1(:,9))>0);
feat1=feat1(ind,:)'; %f1Init = f1Init(ind,:);
s1 = size(feat1,1);
strengthMetric = strengthMetric(ind); areaPer = areaPer(ind); plusOrMinus = plusOrMinus(ind);
scSet = scSet(ind); boundarySet = boundarySet(ind); topLeftSet = topLeftSet(ind);

valid = ones(1,length(ind));
for partIdx = 1:s1
    if partIdx <= size(valid,1)
    if valid(partIdx) % for useAverage they wud all be the same
        feat1Part = feat1(:,partIdx);
        feat1Rest = feat1;
        common_part = 1; [~, twout, ~, ~]=c_eoverlap(feat1Part,feat1Rest,common_part);
        twout(partIdx) = 100;
        dupIdx = find(twout<=lcsBasedOverErr & twout>=0);
        if ~isempty(dupIdx)
            for i=1:size(dupIdx,1)
                if lcsBasedOverErr
                    sc_cost = getbestMatch(scSet{partIdx},scSet{dupIdx(i)});
                    if  sc_cost < scThresh
                        if abs(areaPer(partIdx)-areaPer(dupIdx(i)))<0.2
                            if (strengthMetric(partIdx) >= strengthMetric(dupIdx(i))) %(strengthMetric(partIdx) >= strengthMetric(dupIdx(i))) %also try area instead of strength
                                valid(dupIdx(i)) = 0; else valid(partIdx) = 0;
                            end
                        else
                            if (areaPer(partIdx) < areaPer(dupIdx(i))) %(strengthMetric(partIdx) >= strengthMetric(dupIdx(i))) %also try area instead of strength
                                valid(dupIdx(i)) = 0; else valid(partIdx) = 0;
                            end
                            
                        end
                        if 0
                            mask1 = zeros(maskSzSet{partIdx}(1),maskSzSet{partIdx}(2)); mask1(regionSet{partIdx})=1;
                            mask2 = zeros(maskSzSet{dupIdx(i)}(1),maskSzSet{dupIdx(i)}(2)); mask2(regionSet{dupIdx(i)})=1;
                            figure, subplot(1,2,1), imshow(mask1), subplot(1,2,2), imshow(mask2);
                            figure, plot(boundarySet{dupIdx(i)}(:,2),boundarySet{dupIdx(i)}(:,1),'r');
                            hold on, plot(boundarySet{partIdx}(:,2),boundarySet{partIdx}(:,1),'r'); hold on;
                        end
                    else
                        
                    end
                else
                    if twout(dupIdx(i)) < nonLcsBasedOverErr
                        if (strengthMetric(partIdx) >= strengthMetric(dupIdx(i))) %(strengthMetric(partIdx) >= strengthMetric(dupIdx(i))) %also try area instead of strength
                            valid(dupIdx(i)) = 0; else valid(partIdx) = 0;
                        end
                        
                    end
                end
            end
        end
    end
    end;
end

select = find(valid == 1); indFinal = ind(select); featFinal = feat1(1:5,select); 
kter = 0;
scFinal = {};
topLeftFinal = {};

for i = 1:size(valid, 2),
    if valid(1,i) == 1,
        kter = kter + 1;
        scFinal{kter} = scSet{i};
        topLeftFinal{kter} = topLeftSet{i};
        boundaryFinal{kter} = [boundarySet{i}(:,2), boundarySet{i}(:,1)];
    end;
end;

end
