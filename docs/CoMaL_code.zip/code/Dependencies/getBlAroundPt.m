function boundOrBlock = getBlAroundPt(pathToLoad,imgno,featNo,shapeCheck,ind,centerM,sxi2)

regionPath = sprintf('%s/regionsFinalAll%d',pathToLoad,imgno);
boundaryPath = sprintf('%s/boundaryFinalAll%d',pathToLoad,imgno);
sizeBlPath = sprintf('%s/blockSzFinalAll%d',pathToLoad,imgno);
topLeftPath = sprintf('%s/topLeftFinalAll%d',pathToLoad,imgno);
region = load(regionPath); bound = load(boundaryPath); sizeBlA = load(sizeBlPath); tL = load(topLeftPath); 

sizeBl = sizeBlA.blockSzFinalAll(ind,:); sizeBl = sizeBl(featNo,:);
selCut = region.regionsFinalAll(ind); selCut = selCut{featNo};
boundary = bound.boundaryFinalAll(ind); boundary = boundary{featNo};    
topLeft = tL.topLeftFinalAll(ind,:); topLeft = topLeft(featNo,:);
    
mask = zeros(sizeBl(1),sizeBl(2));  mask(selCut) = 1;
if 1
    figure, imshow(mask), hold on;
    boundary = boundary - repmat([topLeft(1)-1 topLeft(2)-1],size(boundary,1),1);
    plot(boundary(:,2),boundary(:,1),'r');
end

if shapeCheck
    sc = getShapeContext(boundary);
    boundOrBlock = sc;
else %cutting out block
    szBlockBy2 = round(3*sxi2/2);
    center(1,:) = centerM - (fliplr(topLeft) - 1);
    TempPos1(1,1) = max(1,center(1,2) - szBlockBy2); TempPos1(1,2) = min(sizeBl(1),center(1,2) + szBlockBy2);
    TempPos1(2,1) = max(1,center(1,1) - szBlockBy2); TempPos1(2,2) = min(sizeBl(2),center(1,1) + szBlockBy2);
    block = mask(TempPos1(1,1):TempPos1(1,2),TempPos1(2,1):TempPos1(2,2),:);
    addPre1 = (center(1,2) - szBlockBy2 -1); addPost1 = sizeBl(1) - (center(1,2) + szBlockBy2);
    addPre2 = (center(1,1) - szBlockBy2 -1); addPost2 = sizeBl(2) - (center(1,1) + szBlockBy2);
    if addPre1 < 0 | addPre2 < 0
        if addPre1>0; addPre1 = 0; end
        if addPre2>0; addPre2 = 0; end
        block = padarray(templates,[abs(addPre1) abs(addPre2) 0],'pre');
    end
    if addPost1 < 0 | addPost2 < 0
        if addPost1>0; addPost1 = 0; end
        if addPost2>0; addPost2 = 0; end
        block = padarray(templates,[abs(addPost1) abs(addPost2) 0],'post');
    end
    boundOrBlock = block;
end

end