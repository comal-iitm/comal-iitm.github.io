% BoundaryGaussianSmoothing_2D : Returns a matrix smoothed with a Gaussian 
% kernel of standard deviation sigma.
% 
% Input Arguments : coords - Input Matrix (Image)
%                   sigma - Std. dev. of the Gaussian
%
% Output : The smoothed matrix filteredResult.
% NOTE : The size of the kernel (kernelLength) is computed from sigma.
% ~Documented by Ramkumar

function filteredResult = BoundaryGaussianSmoothing_2D(coords,sigma,shorterLength)
global granularity

if nargin < 3
    shorterLength=0;
end
% stack=dbstack;
%  Timing('BoundaryGaussianSmoothing_2D',1,stack(2).name);
if shorterLength
    kernelLength = floor((sigma)/2)*2+1;
else
kernelLength = floor((6*sigma)/2)*2+1;
end
smoothingKernel = fspecial('gaussian',[kernelLength kernelLength],sigma);

%     filteredResult = imfilter(coords,smoothingKernel,'circular','conv');
filteredResult = imfilter(coords,smoothingKernel,'same','conv','replicate');
%     filteredResult = conv(coords,smoothingKernel,'valid');
%     filteredResult = [granularity*ones(floor(size(smoothingKernel,1)/2),1); filteredResult ;granularity*ones(floor(size(smoothingKernel,1)/2),1)];

%
%  Timing('BoundaryGaussianSmoothing_2D',0,stack(2).name);
end
