function [erro,repeat,corresp, match_score,matches, twi] = RepeatabilityTest(startimgno, endimgno, datastring,sz)

commonVar = globalVariables;
showCorresFig = 1;

repFigFile = fullfile('..','data','results',sprintf('%s',datastring),sprintf('repeatability_%d_%d.fig',startimgno,endimgno));
corrFigFile = fullfile('..','data','results',sprintf('%s',datastring),sprintf('correspondence_%d_%d.fig',startimgno,endimgno));
repCmdOutFile = fullfile('..','data','results',sprintf('%s',datastring),sprintf('repeatability_cmdOutput_%d_%d.txt',startimgno,endimgno));

if 1 %singleScaleRep
    if 0 %otherDetectors
        repJpgFile = fullfile('..','data','results',sprintf('%s',datastring),'MainObsns',sprintf('repeatabilityOther_SZ%d.jpg',sz));
        corrJpgFile = fullfile('..','data','results',sprintf('%s',datastring),'MainObsns',sprintf('correspondenceOther_SZ%d.jpg',sz));
    else
        repJpgFile = fullfile('..','data','results',sprintf('%s',datastring),sprintf('repeatabilityProfuse_%s.jpg',datastring));
        corrJpgFile = fullfile('..','data','results',sprintf('%s',datastring),sprintf('correspondenceProfuse_%s.jpg',datastring));
    end
end

hFig1 = figure;clf;
grid on;
ylabel('Repeatability %','FontSize',14,'FontWeight','bold')
switch (datastring)
    case 'bike'
        xlabelString = 'Increasing blur';
        figure(hFig1); axis([1.8 6 0 102]);
        xAxis = 2:6;
        case 'tree'
        xlabelString = 'Increasing blur';
        figure(hFig1); axis([1.8 6 0 102]);
        xAxis = 2:6;
    case 'luvn'
        xlabelString = 'Decreasing light';
        figure(hFig1); axis([1.8 6 0 102]);
        xAxis = 2:6;
    case 'uubc'
        xlabelString = 'JPEG compression %';
        figure(hFig1); axis([58 100 0 102]);
        xAxis = [60 80 90 95 97.5];
        case 'boat'
        xlabelString = 'Scale changes';
        figure(hFig1); axis([0 3 0 102]);
        xAxis = [0.8 1.3 1.9 2.35 2.8];
end

xlabel(xlabelString,'FontSize',14,'FontWeight','bold');

hold on;
if showCorresFig
    hFig2 = figure;clf;
    grid on;
    ylabel('Number of Correspondences','FontSize',14,'FontWeight','bold')
    xlabel(xlabelString,'FontSize',14,'FontWeight','bold');
    hold on;
end

% mark=['-kx';'-rv';'-gs';'-m+';'-bp';'-yo'];
mark=['-kx';'-rx';'-gx';'-gd';'-bx';'-yx'];
markHar=['-ks';'-rs';'-gs';'-rx';'-bs';'-ys'];
markHes=['-kv';'-rv';'-gv';'-bo';'-bv';'-yv'];
markMsr=['-kv';'-rv';'-gv';'-kp';'-bv';'-yv'];

seqrepeat=[]; seqrepeatHar=[]; seqrepeatHes=[]; seqrepeatMsr=[];
seqcorresp=[]; seqcorrespHar=[]; seqcorrespHes=[]; seqcorrespMsr=[];
seqViewPt=[];

% command window output can be written to 'file' or 'stdout'.
outputDevice = 'file';

% command window output device is chosen
switch outputDevice
    case 'file'
        repCmdOutFid = fopen(repCmdOutFile,'a');
        disp('Warning: Command window output being saved to file. No output on Command Window');
    case 'stdout'
        repCmdOutFid = 1;
    case 'stderr'
        repCmdOutFid = 2;
end

img1 = 1;
viewPtAngle = 10;
if ~strcmp(datastring,'boat')
    imf1 = fullfile('../images',datastring,'img1.ppm');
else
    imf1 = fullfile('../images',datastring,'img1.pgm');
end


file1 =fullfile('..','data','results',sprintf('%s',datastring),sprintf('img0.harronmser.txt'));
fileHar1 =fullfile('..','data','results',sprintf('%s',datastring),sprintf('img0.har.txt'));
fileHes1 =fullfile('..','data','results',sprintf('%s',datastring),sprintf('img0.hes.txt'));
fileMsr1 =fullfile('..','data','results',sprintf('%s',datastring),sprintf('img0.msr.txt'));

if exist(file1,'file') && exist(fileHar1,'file') && exist(fileHes1,'file') && exist(fileMsr1,'file') && endimgno>1
    for img2 = max(startimgno,2):endimgno
        if ~strcmp(datastring,'boat')
            imf2 = fullfile('../images',datastring,sprintf('img%d.ppm',img2));
        else
            imf2 = fullfile('../images',datastring,sprintf('img%d.pgm',img2));
        end
        
        Hom = fullfile('..','images',sprintf('%s',datastring),sprintf('H%sto%sp',num2str(img1),num2str(img2)));
        file2 = fullfile('..','data','results',sprintf('%s',datastring),sprintf('img%d.harronmser.txt',img2-1));
        fileHar2 =fullfile('..','data','results',sprintf('%s',datastring),sprintf('img%d.har.txt',img2-1));
        fileHes2 =fullfile('..','data','results',sprintf('%s',datastring),sprintf('img%d.hes.txt',img2-1));
        fileMsr2 =fullfile('..','data','results',sprintf('%s',datastring),sprintf('img%d.msr.txt',img2-1));
        
        if exist(file2,'file') && exist(fileHar2,'file') && exist(fileHes2,'file') && exist(fileMsr2,'file') 
            [erro,repeat,corresp, match_score,matches, twi]=repeatability(file1,file2,Hom,imf1,imf2,1,repCmdOutFid,sz);
            [erro,repeatHar,correspHar, ~,~, ~]=repeatability(fileHar1,fileHar2,Hom,imf1,imf2,1,repCmdOutFid,sz);
            [erro,repeatHes,correspHes, ~,~, ~]=repeatability(fileHes1,fileHes2,Hom,imf1,imf2,1,repCmdOutFid,sz);
            [erro,repeatMsr,correspMsr, ~,~, ~]=repeatability(fileMsr1,fileMsr2,Hom,imf1,imf2,1,repCmdOutFid,sz);
            
            viewPtAngle = viewPtAngle+10;
            
            seqrepeat=[seqrepeat; repeat];
            seqrepeatHar=[seqrepeatHar; repeatHar];
            seqrepeatHes=[seqrepeatHes; repeatHes];
            seqrepeatMsr=[seqrepeatMsr; repeatMsr];
            
            seqcorresp=[seqcorresp; corresp]; % not used now
            seqcorrespHar=[seqcorrespHar; correspHar];
            seqcorrespHes=[seqcorrespHes; correspHes];
            seqcorrespMsr=[seqcorrespMsr; correspMsr];
            seqViewPt = [seqViewPt viewPtAngle];
            
        end
    end
    
    if commonVar.dispAllDetectors
        ovErJump=3;
        det_suffix=['40'];%         det_suffix=['10';'40'];
        
    else
        ovErJump=1;
        det_suffix=['10';'20';'30';'40';'50';'60'];
        
    end
    
    for ovlErrIdx=4%:ovErJump:size(erro,2)
%         figure(hFig1); axis([1.8 6 10 110]);
        figure(hFig1);  plot(xAxis,seqrepeat(:,ovlErrIdx),mark(ovlErrIdx,:),'Linewidth',2,'MarkerSize',14);
        if showCorresFig
%             figure(hFig2); axis([1.8 6 10 900]);
            figure(hFig2);  plot(xAxis,seqcorresp(:,ovlErrIdx),mark(ovlErrIdx,:),'Linewidth',2,'MarkerSize',14);
        end
        if commonVar.dispAllDetectors
            figure(hFig1);  plot(xAxis,seqrepeatHar(:,ovlErrIdx),markHar(ovlErrIdx,:),'Linewidth',2,'MarkerSize',14);
            figure(hFig1);  plot(xAxis,seqrepeatHes(:,ovlErrIdx),markHes(ovlErrIdx,:),'Linewidth',2,'MarkerSize',14);
            figure(hFig1);  plot(xAxis,seqrepeatMsr(:,ovlErrIdx),markMsr(ovlErrIdx,:),'Linewidth',2,'MarkerSize',14);
            if showCorresFig
                figure(hFig2);  plot(xAxis,seqcorrespHar(:,ovlErrIdx),markHar(ovlErrIdx,:),'Linewidth',2,'MarkerSize',14);
                figure(hFig2);  plot(xAxis,seqcorrespHes(:,ovlErrIdx),markHes(ovlErrIdx,:),'Linewidth',2,'MarkerSize',14);
                figure(hFig2);  plot(xAxis,seqcorrespMsr(:,ovlErrIdx),markMsr(ovlErrIdx,:),'Linewidth',2,'MarkerSize',14);
                
            end
        end
        %         figure(hFig2);  plot(seqViewPt,seqcorresp(:,ovlErrIdx),mark(ovlErrIdx,:));
    end
    
    if commonVar.dispAllDetectors
%                 axis([10 70 0 100]);
%                 figure(hFig1); axis([2 6 10 110]);
                figure(hFig1);set(gca,'FontWeight','bold');
                h_legend=legend('ProfuseMser','Harris','Hessian','MSER','Location','SouthEast'); 
                set(h_legend, 'FontSize',15)
                set(gca,'FontWeight','bold');
        %         h_legend=legend('HarrOnMser 10% o.e','Harris 10% o.e','Hessian 10% o.e','HarrOnMser 40% o.e','Harris 40% o.e','Hessian 40% o.e');
        %         set(h_legend, 'FontSize',14)
        if showCorresFig
            figure(hFig2); h_legend=legend('ProfuseMser','Harris','Hessian','MSER');%'Location','North' %%h_legend=legend('HarrOnMser 10% o.e','Harris 10% o.e','Hessian 10% o.e','HarrOnMser 40% o.e','Harris 40% o.e','Hessian 40% o.e');
            set(h_legend, 'FontSize',15)
            set(gca,'FontWeight','bold');
        end
    else
        
        figure(hFig1);legend(det_suffix(1,:),det_suffix(2,:),det_suffix(3,:),det_suffix(4,:),det_suffix(5,:),det_suffix(6,:),'FontSize',14);
        if showCorresFig
            figure(hFig2);legend(det_suffix(1,:),det_suffix(2,:),det_suffix(3,:),det_suffix(4,:),det_suffix(5,:),det_suffix(6,:),'FontSize',14);
        end
    end
    
end


% figure(hFig2);legend(det_suffix(1,:),det_suffix(2,:),det_suffix(3,:),det_suffix(4,:),det_suffix(5,:),det_suffix(6,:));

saveas(hFig1,repFigFile);
if showCorresFig
    saveas(hFig2,corrFigFile);
end
% saveas(hFig2,corrFigFile);
if 1%singleScaleRep
    saveas(hFig1,repJpgFile);
    if showCorresFig
        saveas(hFig2,corrJpgFile);
    end
end

if strcmp(outputDevice,'file')
    fclose(repCmdOutFid);
end

end