function [boundaryVals regionsDec strength plusOrMinus] = runMatasMserOld(img,theta,iter,t)


commonVar  = globalVariables(t);

sizeImg = size(img);
imgFormatd = uint8(img)'; sizeImg(3) = 1;

if iter
    [boundaryValsPlus boundaryValsMinus regionsPlus regionsMinus strengthPlus strengthMinus] = extremaExptIter(imgFormatd,sizeImg,theta); %may need to feed in iter info to remove duplicates
    boundaryVals = [boundaryValsPlus boundaryValsMinus];
    regions = [regionsPlus regionsMinus];
    strength = [strengthPlus strengthMinus];
    plusOrMinus = [ones(size(regionsPlus,2),1); zeros(size(regionsMinus,2),1)];
    
else
    [boundaryValsPlus boundaryValsMinus regionsPlus regionsMinus strengthPlus strengthMinus] = extremaExpt(imgFormatd,sizeImg); %theta not needed in this case
    boundaryVals = [boundaryValsPlus boundaryValsMinus];
    regions = [regionsPlus regionsMinus];
    strength = [strengthPlus strengthMinus];
    plusOrMinus = [ones(size(regionsPlus,2),1); zeros(size(regionsMinus,2),1)];
    
end
%%
if ~isempty(regions)
    regionsDec  = decodeRLE(regions);
else
    regionsDec = [];
end

for ind=1:length(regionsDec)
    [~,colNo] = find(regionsDec{ind}<=0);
    regionsDec{ind}(:,colNo) = [];
    sel = uint32(sub2ind(sizeImg, regionsDec{ind}(1,:), regionsDec{ind}(2,:)));
    
    if 0 %some testing of packing into regions is happening right
        mask = zeros(149,149); mask(sel)=1;
        sel = uint32(sub2ind([51 51], regionsDec{ind}(1,:), regionsDec{ind}(2,:)));
        %         sel = uint32(sub2ind([51 51], regionsDec{ind}(1,:)+1, regionsDec{ind}(2,:)+1));
        %         sel = uint32(sub2ind([50 50], regionsDec{ind}(1,:), regionsDec{ind}(2,:)));
        for ii=1:size(regionsDec{ind},2)
            mask(regionsDec{ind}(1,ii),regionsDec{ind}(2,ii)) = 1;
        end
    end
    regionsDec{ind} = sel;
end

commonVar.displayflag=0;
if commonVar.displayflag
    if 1 %some testing of packing into regions is happening right
        sz0 =  round(commonVar.sigSminInit*commonVar.iterBlockFactor/5)*5;
        sz = round(sz0*commonVar.blockMultFactor);%block size 
        
        indTest = 8;
        mask = zeros(sz+1,sz+1); mask(regionsDec{indTest})=1; figure, imshow(mask);
%         mask = zeros(sz,sz); mask(regionsMinus{indTest})=1;figure, imshow(mask);
        
        sel = uint32(sub2ind([51 51], regionsDec{ind}(1,:), regionsDec{ind}(2,:)));
        %
    end
    figure, imshow(img,[]), hold on,
    for i=1:length(boundaryVals)
        plot(boundaryVals{i}(2,:), boundaryVals{i}(1,:),'.');
    end
end
commonVar.displayflag=0;

% extremaExpt(img);