function [dSetNo decVal] = getParamsAndDataset(dsetOrNo)

warning('Folder Naming conventions defined in getParamsAndDataset');

if ischar(dsetOrNo)
    dset = dsetOrNo;
    
    datasetOurs = ['boxx';'doll';'hero';'hous';'jtoo';'pens';'race';'stnd'];
    datasetTrack = ['bord';'boxz';'cann';'cupp';'cycl';'dino';'lemm'];
    datasetOxford = ['bike';'luvn';'uubc';'tree';'biks']; %'boat'; 'bark'
    datasetMiddleBury = ['tsuk';'cone';'tedy'];
    datasetCaltech = ['bask';'jeep';'covr';'chip';'cnch';'desk';'dogg';'fram';'jack';'lamp';'motr';'mous';'spng';'tcyc'];
    datasetKITTI = [repmat('car',21,1) ('a':'u')'];
    datasetAdobe = ['crml';'dome';'fish';'gate';'offc';'riod';'shng';'yard'];
    datasetKittiStereo = ['kstr'];
    datasetKittiFlow = ['flow'];
    datasetKinect = ['kine'];
    datasetKinectUT = ['ut01';'ut02';'ut03';'ut04';'ut05';'ut06';'ut07';'ut08';'ut09';'ut10']; 
    
    numOurs = size(datasetOurs,1); datasetOursCell = mat2cell(datasetOurs,ones(1,numOurs),4);
    numTrack = size(datasetTrack,1); datasetTrackCell = mat2cell(datasetTrack,ones(1,numTrack),4);
    numOxford = size(datasetOxford,1); datasetOxfordCell = mat2cell(datasetOxford,ones(1,numOxford),4);
    numMiddleBury = size(datasetMiddleBury,1); datasetMiddleBuryCell = mat2cell(datasetMiddleBury,ones(1,numMiddleBury),4);
    numCaltech = size(datasetCaltech,1); datasetCaltechCell = mat2cell(datasetCaltech,ones(1,numCaltech),4);
    numVehicle = size(datasetKITTI,1); datasetVehicleCell = mat2cell(datasetKITTI,ones(1,numVehicle),4);
    numAdobe = size(datasetAdobe,1); datasetAdobeCell = mat2cell(datasetAdobe,ones(1,numAdobe),4);
    numKittiStereo = size(datasetKittiStereo,1); datasetKittiStereoCell = mat2cell(datasetKittiStereo,ones(1,numKittiStereo),4);
    numKittiFlow = size(datasetKittiFlow,1); datasetKittiFlowCell = mat2cell(datasetKittiFlow,ones(1,numKittiFlow),4);
    numKinect = size(datasetKinect,1); datasetKinectCell = mat2cell(datasetKinect,ones(1,numKinect),4);
    numKinectUT = size(datasetKinectUT,1); datasetKinectCellUT = mat2cell(datasetKinectUT,ones(1,numKinectUT),4);
    
    if any(strcmp(dset,datasetOursCell)), dSetNo = 1; end
    if any(strcmp(dset,datasetTrackCell)), dSetNo = 2; end
    if any(strcmp(dset,datasetOxfordCell)), dSetNo = 3; end
    if any(strcmp(dset,datasetMiddleBuryCell)), dSetNo = 4; end
    if any(strcmp(dset,datasetCaltechCell)), dSetNo = 5; end
    if any(strcmp(dset,datasetVehicleCell)), dSetNo = 6; end
    if any(strcmp(dset,datasetAdobeCell)), dSetNo = 7; end
    if any(strcmp(dset,datasetKittiStereoCell)), dSetNo = 8; end
    if any(strcmp(dset,datasetKittiFlowCell)), dSetNo = 9; end
    if any(strcmp(dset,datasetKinectCell)), dSetNo = 10; end
    if any(strcmp(dset,datasetKinectCellUT)), dSetNo = 11; end
    
else
    dSetNo = dsetOrNo;
    
    switch dSetNo
        case {3,4}
            decVal=1;
        case {2,6,10,11}
            decVal=4;
        case {1,8,9}
            decVal=3;
        case {5,7}
            decVal=2;
    end
end
end