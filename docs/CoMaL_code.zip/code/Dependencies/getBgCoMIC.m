function getBgCoMIC

dirData ='../images';
dilVal = 4;
Tuples = getTuples(dirData);
[datasets indUnique] = unique(Tuples(:,1));
indUnique = [0; indUnique];
numImagesAll = indUnique(2:end) - indUnique(1:end-1); %add here if sth is not right

for d=1:length(datasets)
  dset = datasets{d};
  dSetNo = getParamsAndDataset(dset);
  if dSetNo == 1
    bgPath = fullfile('../bg',dset,sprintf('imgB.ppm')); %this might have to be changed for some images
    numFrames = numImagesAll(d); %indUnique(d+1) - indUnique(d);
    imToRun = (1:numFrames)' ;
    gtCell={};
    parfor iR =1:length(imToRun)
      imgnoStr = getImgnoInStrOrInt(iR,dSetNo);
      imgPath = fullfile(dirData,dset,sprintf('img%s.ppm',imgnoStr));
      [coordFg coordFgBound] = BGSubtraction(bgPath,imgPath,dilVal,dset,sprintf('img%s.ppm',imgnoStr));
      gtCell{iR} = mean(coordFg{1});
      
      if 0
        figure, imshow(imgPath), hold on, plot(coordFg{1}(:,1),coordFg{1}(:,2));
        plot(gtCell{iR}(1,1),gtCell{iR}(1,2),'*r');
      end
    end
    gt = cell2mat(gtCell');
    savePath = sprintf('%s/%s/groundtruth.mat',dirData,dset);
    save(savePath,'gt');
  end
end
