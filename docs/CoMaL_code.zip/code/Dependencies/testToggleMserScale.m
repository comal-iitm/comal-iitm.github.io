function testToggleMserScale(imgNo)

datastring = ['bike';'luvn';'uubc'];
numClose=25; dataInd=1;numPts=1;
% file1 =fullfile('..','data','results',sprintf('%s',datastring(dataInd,:)),sprintf('img%d.harronmser.txt',imgNo));
% img2Pts = loadFeatures(file1);
% img2Pts = img2Pts';


%checking which one to load
if 0
    load('cornersBlockMat2_6.mat');
    figure, imshow('../images/boat/img2.pgm'), hold on,
    showellipticfeaturesSPL(cornersBlockMat');
end
%%%%%%%%%%%%%
% [~,initCornersCleaned]= overlapCheck(initCornersMat',[ysize,xsize],5,0);
% initCornersMat = initCornersCleaned';
ptFile = sprintf('../data/results/bike/img%d.harronmser.txt',imgNo-1);
[feat s1 dimdesc1]=loadFeatures(ptFile);
commonVar = globalVariables(imgNo);

imgFile = sprintf('../images/bike/img%d.ppm',imgNo);
figure, imshow(imgFile), hold on,
showellipticfeaturesSPL(feat');
hold on, [x,y] = ginput(1);
[vals,ind] = closestPt([x y],feat',1,numClose); %
ind = ind(vals<10);
points = feat(:,ind);
for i=1:size(points,2)
    point  = points(:,i);
    pointScale = sqrt(1./point(3));
    %     [~,scaleNo] = min(abs(commonVar.sigSmin - pointScale));
    for scaleNo = 3:4
        load(sprintf('matlab%d_%d.mat',imgNo,scaleNo));
        
        ptsToCompare = initCornersMat;
        [vals,ind] = closestPt(point',ptsToCompare,1,numClose); %
        ind = ind(vals<10);
        ptsToCompareClose = ptsToCompare(ind,:);
        
        for split0=1:size(ptsToCompareClose,1)
            blockNo = ptsToCompareClose(split0,11);
            indNo = ptsToCompareClose(split0,12);
            bNo = ptsToCompareClose(split0,15);
            regionDec0{split0} = regionsDec{blockNo}{indNo};
            plusOrMinus0(split0,1) = plusOrMinus{blockNo}(indNo);
            boundaryAll0{split0} = boundaryAll{blockNo}{indNo}{bNo};
            circFlagListSplit0(split0,1) = circFlagList{blockNo}(indNo);
        end
        MaxOrMinScaleFlag = 1;
        [cornersBlock,~,~,regionsFinal0, blockSzFinal0, topLeftFinal0 plusOrMinusFinal0] = getConvergedCorner(ptsToCompareClose,regionDec0,plusOrMinus0,imgPath,boundaryAll0,circFlagListSplit0,imgNo,resizefactor,1,MaxOrMinScaleFlag);   %boundaryAll not sent during parfor %imBlocks must be uint32; method1,method2 as op
    end
end
