function [feat nb dim numFields]=loadFeaturesOld(file,other)

if nargin<2
    other=0;
end

fid = fopen(file, 'r');
dim=fscanf(fid, '%f',1);
if dim==1
    dim=0;
end

if ~other
    nb=fscanf(fid, '%d',1);
    numFields = fscanf(fid, '%d',1);
else
    numFields=12;
    nb = dim;
    dim = fscanf(fid, '%f',1);
end

if numFields<=7 | numFields ==12
    feat = fscanf(fid, '%f', [numFields+dim, nb]);
    fclose(fid);
else
    [feat nb dim] = loadFeaturesMSER(file);
end

% From 'displaydetpts.m'
%
% function [feat nb dim]=loadFeatures(file)
% fid = fopen(file, 'r');
% dim=fscanf(fid, '%f',1);
% if dim==1
% dim=0;
% end
% nb=fscanf(fid, '%d',1);
% feat = fscanf(fid, '%f', [5+dim, inf]);
% fclose(fid);
% %end
