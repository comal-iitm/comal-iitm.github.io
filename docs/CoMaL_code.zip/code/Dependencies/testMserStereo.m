function testMserStereo %(dataset,overErr)
%% INIT PARAMS

% close all;
dataset='boat'; overErr=15; compareWithOtherMethod=0;
firstTime=0;%this area disadvantages areas below 7-10

if strcmp(dataset,'boat');
    ext='pgm';
    isboat=1;
else
    ext='ppm';
    isboat=0;
end
if 0
load('matlab1.mat');
blockNo = cornersBlockMatOrigForm(11,:);
indNo = cornerNewTrcornersBlockMatOrigForm(12,:); %determines which mser now
for a=1:size(cornersBlockMatOrigForm,2)
    plusOrMinus(a) = plusOrMinusAll{blockNo(a)}(indNo(a));
end
cornersBlockMatOrigForm(:,18) = plusOrMinus;
end
% myDisplayDetPtsOuter([1 6]);
img1 = './stereo/imL.png';
pt1= './stereo/L.harronmser.txt';
feat1=loadFeatures(pt1); %strength1 = feat1(6,:);
% if compareWithOtherMethod
%     ptOther1= sprintf('../data/results (2)/%s/img0.harronmser.txt',dataset);
%     featOther1=loadFeatures(ptOther1); strengthOther1 = featOther1(6,:);
%     count=0;closestOtherpt=[];strengthDiff=[];closestOtherptNonMatch=[];strengthDiffNonMatch=[];
%     for i=1:size(feat1,2)
%         [closeval,indOther] = closestPt(feat1(:,i)',featOther1');
%         if closeval<5
%             closestOtherpt = [closestOtherpt; feat1(:,i)'; featOther1(:,indOther)'];
%             strengthDiff = [strengthDiff;strength1(i) - strengthOther1(indOther)];
%             count=count+1;
%         else
%             closestOtherptNonMatch = [closestOtherptNonMatch; feat1(:,i)'];
%             strengthDiffNonMatch = [strengthDiffNonMatch;strength1(i)];
%         end
%     end
%     indDiff = find(abs(strengthDiff)>20);
%     figure; imshow(img1); hold on, showellipticfeaturesSPL(closestOtherpt(2.*indDiff,:),[1 1 0]);
%     for ii=1:length(indDiff)
%         text(closestOtherpt(2*indDiff(ii),1)+3,closestOtherpt(2*indDiff(ii),2)+3,num2str(strengthDiff(indDiff(ii),1)));
%     end
%     
%     figure; imshow(img1); hold on, showellipticfeaturesSPL(closestOtherptNonMatch,[1 1 0]);
%     for ii=1:size(closestOtherptNonMatch,1)
%         text(closestOtherptNonMatch((ii),1)+3,closestOtherptNonMatch((ii),2)+3,num2str(strengthDiffNonMatch((ii),1)));
%     end
% end
for imgNo=5
    
    pt2= './stereo/R.harronmser.txt';
    img2 = './stereo/imR.png';
    Hom = './stereo/Hunity';
    %     feat2=loadFeatures(pt2); strength2 = feat2(6,:);
    
    [~,~,~,~,~,~,twout,wout,featTest1,featTest2,strength1,strength2,cornerness1,cornerness2]= repeatabilityHarronMser(pt1,pt2,Hom,img1,img2,1,1); %numMserTot(1),numMserTot(imgNo)
    [match2,matchOther] = find(wout<=20);% ((wout<=10 | wout>=40) & wout<100); % find (wout>=10 & wout<=40) ;
    nonMatch2 = setdiff(1:size(wout,1),match2);
    
    strengthCorCombo1 = [strength1' cornerness1'];
    strengthCorComboMatch2 = [strength2(match2)' cornerness2(match2)'];
    strengthCorComboNonMatch2 = [strength2(nonMatch2)' cornerness2(nonMatch2)'];
    if 0
        indlowstrength = find(strengthCorComboMatch2(:,1)<20);
        weakMatch2 = match2(indlowstrength);
        figure; imshow(img2); hold on, showellipticfeaturesSPL(featTest2(:,weakMatch2)',[1 1 0]);
        for ii=1:length(weakMatch2)
            text(featTest2(1,weakMatch2(ii))+3,featTest2(2,weakMatch2(ii))+3,num2str(strengthCorComboMatch2(indlowstrength(ii),1)));
        end
        
        indlowstrength = find(strengthCorComboNonMatch2(:,1)<20);
        weakNonMatch2 = nonMatch2(indlowstrength);
        figure; imshow(img2); hold on, showellipticfeaturesSPL(featTest2(:,weakNonMatch2)',[1 1 0]);
        for ii=1:length(weakNonMatch2)
            text(featTest2(1,weakNonMatch2(ii))+3,featTest2(2,weakNonMatch2(ii))+3,num2str(strengthCorComboNonMatch2(indlowstrength(ii),1)));
        end
    end
    
    figure; imshow(img2); hold on, showellipticfeaturesSPL(featTest1(:,matchOther)',[0 0 0]);
    showellipticfeaturesSPL(featTest2(:,match2)',[1 1 0]);
    
    figure; imshow(img2); hold on, showellipticfeaturesSPL(featTest2(:,nonMatch2)',[1 1 0]); %match2 for other conditions
    for ii=1:size(nonMatch2,2)
        text(featTest2(1,nonMatch2(ii))+1,featTest2(2,nonMatch2(ii))+1,num2str(strength2(nonMatch2(ii))));
    end
    figure; imshow(img1); hold on, showellipticfeaturesSPL(featTest1',[1 1 0]);
    figure; imshow(img2); hold on, showellipticfeaturesSPL(featTest2',[1 1 0]);
    for ii=1:size(featTest2,2)
        text(featTest2(1,ii)+1,featTest2(2,ii)+1,num2str(strength2(ii)));
    end
    
    hFig1 = figure; imshow(img1);
    hFig2 = figure; imshow(img2);
    figure(hFig2); hold on, showellipticfeaturesSPL(featTest2',[1 1 0]);
    
    for times=1:1 %testing for 15 points
        figure(hFig2); hold on, [x,y] = ginput(1);
        [~,ind] = closestPt([x y],featTest2');
        [~, f1] = find(twout(ind,:)<overErr);
        [~, f1Match] = find(wout(ind,:)<overErr);
        if isempty(f1)
            fprintf('\n No match');
        end
        featFin1 = featTest1(:,f1)';
        
        figure(hFig1); hold on, showellipticfeaturesSPL(featFin1,[1 1 0]);
        figure(hFig1); hold on, showellipticfeaturesSPL(featTest1(:,f1Match)',[1 0 0]);
        
        for i=1:length(f1)
            %             strength = strength1(f1(i));
            strength = twout(ind,f1(i));
            text(featTest1(1,f1(i))+3,featTest1(2,f1(i))+3,num2str(strength));
        end
        %         strengthMatch = strength1(f1(i));
        strengthMatch = wout(ind,f1(i));
        text(featTest1(1,f1Match)+6,featTest1(2,f1Match)+6,num2str(strengthMatch),'BackgroundColor',[.9 .5 .5]);
        %     [f2 f1] =find(wout<overErr); %make the 15 an input
        %     featFin1 = featTest1(:,f1)'; featFin2 = featTest2(:,f2)';
    end
    
end