function template = getTemplate(image,center,szBlock0,numShifts)
template=[];
szBlockBy2 = (szBlock0-1)/2 + numShifts;szImg = size(image);

TempPos1(1,1) = max(1,round(center(2) - szBlockBy2)); TempPos1(1,2) = min(szImg(1),round(center(2) + szBlockBy2));
TempPos1(2,1) = max(1,round(center(1) - szBlockBy2)); TempPos1(2,2) = min(szImg(2),round(center(1) + szBlockBy2));
template = image(TempPos1(1,1):TempPos1(1,2),TempPos1(2,1):TempPos1(2,2),:);

addPre1 = round(center(2) - szBlockBy2 -1); addPost1 = szImg(1) - round(center(2) + szBlockBy2);
addPre2 = round(center(1) - szBlockBy2 -1); addPost2 = szImg(2) - round(center(1) + szBlockBy2);
if addPre1 < 0 | addPre2 < 0
    if addPre1 <0
        [M N dim] = size(template);
        padded = zeros(abs(addPre1),N,dim);
        template = [padded; template];
    end
    if addPre2 <0
        [M N dim] = size(template);
        padded = zeros(M,abs(addPre2),dim);
        template = [padded template];
    end
end
if addPost1 < 0 | addPost2 < 0
    szBlock = szBlock0 + 2*numShifts;
    if addPost1<0
        [M N dim] = size(template);
        padded = zeros(abs(addPost1),N,dim);
        try
        template(M+1:szBlock,:,:) = padded;
        catch, aa=1; end
    end
    if addPost2<0
        [M N dim] = size(template);
        padded = zeros(M,abs(addPost2),dim);
        try
        template(:,N+1:szBlock,:) = padded;        
        catch return; end
    end    
end
%     template_common = zeros(szBlock,szBlock,3);
%     template_common(selDilated) = I_template(selDilated);
%     templates1{imgno} = template_common;
