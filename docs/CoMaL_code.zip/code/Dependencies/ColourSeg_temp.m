function [cluster_idx largeComponentsAll cluster_mean ab] = ColourSeg_temp(he,indFg,threshColorSeg,handColor)

% he = imread('../images/jtoy/img001.ppm');
% imshow(he), title('H&E image');
% text(size(he,2),size(he,1)+15,...
%     'Image courtesy of Alan Partin, Johns Hopkins University', ...
%     'FontSize',7,'HorizontalAlignment','right');
numLarge = 5;
cform = makecform('srgb2lab');
lab_he = applycform(he,cform);
ab = double(lab_he(:,:,2:3));
nrows = size(ab,1);
ncols = size(ab,2);

for i=1:2
    temp_ab = ab(:,:,i);
    abResize(:,i) = temp_ab(indFg);
end

ab = abResize; %reshape(ab,nrows*ncols,2);
cluster_idx0 = [];

if 1

% handColor(2,:)=[131 141];
% handColor(3,:)=[135 155];

thresh1 = threshColorSeg(1);
thresh2Up = threshColorSeg(2);
thresh2Dn = threshColorSeg(3);
abLen = size(abResize,1);
for i=1%:3
diffVal = ab - repmat(handColor(i,:),abLen,1); %sum(,2)
idx0 = find(abs(diffVal(:,1))<thresh1 & diffVal(:,2)<thresh2Up & diffVal(:,2)>-thresh2Dn); 
cluster_idx0 = [cluster_idx0; idx0];
end

indHand = indFg(cluster_idx0);
hand = zeros(nrows,ncols);
hand(indHand) = 1;
largeComponents  = largestConnComp(hand,numLarge);
cluster_idx = largeComponents;
% hand = imfill(hand);
% figure, imshow(he), figure, imshow(hand);

cluster_mean = 0;
else

% repeat the clustering 3 times to avoid local minima
[cluster_idx, cluster_center] = kmeans(ab,nColors,'distance','sqEuclidean', ...
    'Replicates',3);
for k=1:nColors
    seg_ind = indFg(cluster_idx == k);
    for i=1:3
        tempImg = he(:,:,i);
        cluster_mean(k,i) = mean(tempImg(seg_ind));
    end
end
end

if 0
    pixel_labels = cluster_idx; %reshape(cluster_idx,nrows,ncols);
    % imshow(pixel_labels,[]), title('image labeled by cluster index');
    segmented_images = cell(1,nColors);
    rgb_label = pixel_labels; %repmat(pixel_labels,[1 1 nColors]);
    
    for k = 1:nColors
        color1 = zeros(nrows,ncols);
        seg_ind = indFg(rgb_label == k);
        for i=1:3
            tempImg = he(:,:,i);
            color1(seg_ind) = tempImg(seg_ind);
            color(:,:,i) = color1;
        end
        segmented_images{k} = uint8(color);
        figure,imshow(segmented_images{k});
    end
    
   end