function [cornersAll mask boundary] = getERBoundCor(mserIndAll,blockOrImPath,octaveIdx,iter,indBlock,blockNo,variationMetric) %maskAll boundaryAll

dataset = ['graf';'luvn'; 'bike';'uubc';'boat'];

if ischar(blockOrImPath)
    img = uint32(imread(blockOrImPath));
    for i=1:5 %find which dataset
        present = regexp(blockOrImPath,dataset(i,:));
        if present
            dataInd = i;
        end
    end
    
    datastring = dataset(dataInd,:);
    if ~strcmp(datastring,'boat')
        img = rgb2gray(img); %make sure all changes to the orig image are made on this too
    end
    imBlock = img;
else
    imBlock =  blockOrImPath;
end

cornersAll=[]; %boundaryAll={}; boundaryAll0={};
% indCor =1; %finds all corners in a particular mask
for ind = 1:size(mserIndAll,2)
    
    mserInd = mserIndAll(1,ind); %will work from init and other. neverthless, bad design
    corners0 = []; mask=[]; boundary=[]; corners = [];
    commonVar = globalVariables;
    sigSmin = 6; longBound=0; remsxl2 = 1; extraLen=1; %for existence of maximality % fprintf('\n momScaleFactor in getERBoundCor is %f',commonVar.momScaleFactor); to check for global vars
    sxi2 = sigSmin*(commonVar.smoothingFactor^(octaveIdx-1));
    sel = erfill_mex_general(imBlock,mserInd);
    % if ispc
    %     sel = erfill_mex_win(imBlock, double(mserInd)) ; %imBlock must be uint32
    % else
    %     sel = erfill_mex(imBlock, double(mserInd)) ; %imBlock must be uint32
    % end
    
    [sz1 sz2] = size(imBlock);
    
    if length(sel) > 40
        mask = zeros(sz1,sz2) ; mask(sel) =1 ;
        
        if find(mask)
            [boundary,~,circflag] = CalculateERBoundary(mask,iter);
            if ~isempty(boundary)
                %                                             if length(boundary)>1
                %                                                 aa=1;
                %                                             end
                %             sxi2 = sigSmin;
                for bNo =  1:length(boundary)
                    if  2*(1 + ceil(commonVar.momScaleFactor*sxi2) + extraLen) <length(boundary{bNo}) % while --- && octaveIdx<numOctaves; must be made 3*(ceil(remsxl2max) + max(ceil(sxi2max), ceil(sxM2max))); must changed when accomodating diff segments in same ER
                        %             sxl2 = smoothingFactor * sxi2;                        
                        corners0 = intpointdetom(boundary{bNo}(:,2), boundary{bNo}(:,1),remsxl2,sxi2,sz2,sz1,-1,circflag,bNo,iter);
                                                
                        if ~isempty(corners0)
                            szCorners0 = size(corners0,1);
                            if exist('blockNo','var')
                                corners0(:,11) = blockNo;
                            else
                                corners0(:,11) = ones(szCorners0,1); %in this case coz it's only on the entire image
                            end
                            corners0(:,12) = repmat(mserInd,szCorners0,1);
                            corners0(:,17) = repmat(mserIndAll(2,ind),szCorners0,1); %cellNo
                            corners = [corners; corners0];
                            
                        end
                        %                     octaveIdx = octaveIdx +1;
                        %                     sxi2 = sigSmin*(1.4^(octaveIdx-1));
                        if commonVar.displayflag
                            szBoundary = length(boundary{bNo});
                            boundary{bNo}(:,1) =  boundary{bNo}(:,1) + repmat(indBlock(2),szBoundary,1);
                            boundary{bNo}(:,2) =  boundary{bNo}(:,2) + repmat(indBlock(1),szBoundary,1);
                            plot(boundary{bNo}(:,2), boundary{bNo}(:,1),'r');
                        end
                    end
                end
            end
        end
    end
    
    if exist('indBlock','var') & ~isempty(corners)
        szCorners = size(corners,1);
        corners(:,1:2) =  corners(:,1:2) + repmat(indBlock,szCorners,1);
        corners(:,13) = variationMetric(1,ind);
               
    end
    cornersAll = [cornersAll; corners];
    %         cornersAll{indCor} = corners;
    %         boundaryAll{indCor,:} = boundary; Too heavy to store values
    %         before hand
    %         maskAll{indCor} = mask;
    %         indCor = indCor +1;
end
end