function coordFg = getPixelsInBB(roi) %fgType will be used later

  [col row] = meshgrid(round(roi.x:roi.x+roi.width), round(roi.y:roi.y+roi.height));
  [szCoord1 szCoord2] = size(col);
  colReshape = reshape(col,szCoord1*szCoord2,1);
  rowReshape = reshape(row,szCoord1*szCoord2,1);
  coordFg = [colReshape  rowReshape];
  