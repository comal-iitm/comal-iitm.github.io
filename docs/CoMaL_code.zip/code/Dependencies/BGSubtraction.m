function [coordFg coordFgBound] = BGSubtraction(bgPath,imgPath,dilVal,datastring,imgName)

switch datastring
    case {'boxx','doll','hous','pens','stnd','jto2','jtoy','hero','jtoo'}
        threshBGInit = 14; %dec color thresh for some in boxx, one doll, skin gone,
        dilValInit = 4;
        threshColorSeg = [10 10 20];
        handColor(1,:)=[135 155];
        ifsetdiff = 1;
    case {'race'}
        threshBGInit = 25;
        dilValInit = 3;
        threshColorSeg = [10 10 20];
        handColor(1,:)=[135 155];
        ifsetdiff = 1;
        
    case {'elph'}
        threshBGInit = 14; %dec color thresh for some in boxx, one doll, skin gone,
        dilValInit = 4;
        threshColorSeg = [10 10 10];
        handColor(1,:)=[125 135]; %this is actually the elephant body color.1111111
        ifsetdiff = 0;
    
    case {'kine'}
        threshBGInit = 25; %dec color thresh for some in boxx, one doll, skin gone,
        dilValInit = 4;
            
    case {'ut01', 'ut02', 'ut03', 'ut04', 'ut05', 'ut06', 'ut07', 'ut08', 'ut09', 'ut10'}
        threshBGInit = 25; %dec color thresh for some in boxx, one doll, skin gone,
        dilValInit = 4;
end

numLarge=7;

background = imread(bgPath);
background = double((background));

imageMain = imread(imgPath);
image = double((imageMain));

%% subtraction
fgInit = abs(image - background);
szFG = size(fgInit);
fgFinal = zeros(szFG(1),szFG(2));
fgObjFinal0 = zeros(szFG(1),szFG(2));

%threshold to find connectd component in all 3 image parts
% for thresh = threshMin:threshMax
for numDim=1:3
    fg = fgInit(:,:,numDim);
    fg = uint8(fg);
    fgBinary = fg>threshBGInit;
    %     fgBinary = im2bw(fg,thresh/255); % "graythresh(I)" is Otsu's method for finding the optimal intensity level for performing an image threshold.
    fgFinal = or(fgFinal, fgBinary);
end
% end
indFg = find(fgFinal);
imgFinal0  = getColorImgFromMask(indFg,imageMain);

switch datastring

    case 'kine'
        fgObjFinal0(indFg) = 1;
    otherwise
        
    %% hand seg

    handPrim  = ColourSeg_temp(imgFinal0,indFg,threshColorSeg,handColor);
    if ifsetdiff
        indFgObj = setdiff(indFg,handPrim{1});
    else
        indFgObj = cell2mat(handPrim'); %In the case of a homogenous obj with bad background, color of obj is returned in handprim
    end
    fgObjFinal0(indFgObj) = 1;

end

%% get largest few components
ifDense = 1;
largeComponentsObj = largestConnComp(fgObjFinal0,numLarge,ifDense); %check2,fg
fgObjFinal0 = zeros(szFG(1),szFG(2));
largeComponentsObjAll = cell2mat(largeComponentsObj');
fgObjFinal0(largeComponentsObjAll) = 1;

%% dilate, erode
seInit = strel('disk',dilValInit);
fgObjFinal0 = imdilate(fgObjFinal0,seInit);
fgObjFinal0 = imerode(fgObjFinal0,seInit);

fgObjFinalMain = zeros(szFG(1),szFG(2));
largeComponents = largestConnComp(fgObjFinal0,1); %
fgObjFinalMain(largeComponents{1}) = 1;
indFgObjA = find(fgObjFinalMain);
imgObjFinalA = getColorImgFromMask(indFgObjA,imageMain);

for numDil=1:length(dilVal)
    se = strel('disk',dilVal(numDil));
    fgObjFinal = imdilate(fgObjFinalMain,se);
    [rowFg colFg] = find(fgObjFinal);
    coordFg{numDil} = [colFg rowFg];
end

indFgObj = find(fgObjFinal);
imgObjFinal = getColorImgFromMask(indFgObj,imageMain);

if 0
    imgObjDisp = imresize(imgObjFinal,600/700);
    %imwriteSwarna(imgObjDisp,sprintf('../bg/%s/_%s',datastring,imgName));
    imwrite(imgObjDisp,sprintf('../bg/%s/_%s',datastring,imgName));
end
%%

if 0
    handColor = [150 140 75];
    diffVals = mean(abs(cluster_mean - repmat(handColor,nColors,1)),2);
    [~,colorDiff] = sort(diffVals,'descend');
    handPrim = indFg(cluster_idx == colorDiff(end));
end

%% boundary

boundFg = bwboundaries(fgObjFinalMain);

for numDil=1:length(dilVal)
    fgBoundary = zeros(szFG(1),szFG(2));
    for b=1:size(boundFg,1)
        if size(boundFg{b},1) > 100
            boundPixels = (boundFg{b}(:,2)-1).*szFG(1) + boundFg{b}(:,1);
            fgBoundary(boundPixels) = 1;
        end
    end
    se = strel('disk',dilVal(numDil));
    fgBoundary = imdilate(fgBoundary,se); %can use bwmorph also but it dilates too much
    [rowFgBound colFgBound] = find(fgBoundary);
    coordFgBound{numDil} = [colFgBound rowFgBound];
    if numDil == 2
        aaaa = 1;
    end
end

end

function [imgFinal0 fgFinal] = getColorImgFromMask(indFg,imageMain)

szFG = size(imageMain);
fgFinal = zeros(szFG(1),szFG(2));
imgFinalOneDim = zeros(szFG(1),szFG(2));
imgFinal0 = zeros(szFG(1),szFG(2),3);

for numDim=1:3
    imgOneDim = imageMain(:,:,numDim);
    imgFinalOneDim(indFg) = imgOneDim(indFg);
    imgFinal0(:,:,numDim) = imgFinalOneDim;
end
imgFinal0 = uint8(imgFinal0);

fgFinal(indFg) = 1;
end