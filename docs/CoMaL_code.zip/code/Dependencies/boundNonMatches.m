function [featNos matchFinal] = boundNonMatches(im,dset,delta,dilvalCompB,fgTypeB,getFgOnly)

featNos = zeros(1,5);
detTypes{1} = 'harronmser'; detTypes{2} = 'har'; detTypes{3} = 'hes'; detTypes{4} = 'msr'; detTypes{5} = 'fas'; %detTypes{6} = 'rnd'; %detTypes{7} = 'fer';
dSetNo = getParamsAndDataset(dset);
imgnoStr1 = getImgnoInStrOrInt(im,dSetNo); %imgnoStr2 = getImgnoInStrOrInt(im+1,dSetNo);

[~,coordFg1 coordFgBound1] = getBgSubtractedFeat([], dset, imgnoStr1,dilvalCompB,fgTypeB);

for det=1:length(detTypes)
    detType = detTypes{det};
    ptFile1 = sprintf('../data/results/feat-delta%d/%s/img%d.%s.txt',delta,dset,im-1,detType);
    %                         ptFile2 = sprintf('../data/results/feat-delta%d/%s/img%d.%s.txt',delta,dset,im,detType);
    try f1 = loadFeatures(ptFile1); 
    catch
      return ;
    end
      f1 = f1';%  f2 = loadFeatures(ptFile2);
    xyCoord0 = round(f1(:,1:2));
    
    switch fgTypeB
        case 'full'
            indValid0 = ismember(xyCoord0,coordFg1{1},'rows');
            indValid = find(indValid0);
            featNos(det) = length(indValid);
        case 'bound'
            indValid0 = ismember(xyCoord0,coordFgBound1{1},'rows');%this will not work for dSet=2 for now
            indValid = find(indValid0);
            
        case 'nonBound'
            indValid0Full = ismember(xyCoord0,coordFg1{1},'rows');
            indValidFull = find(indValid0Full);
            
            indValid0Bound = ismember(xyCoord0,coordFgBound1{1},'rows');
            indValidBound = find(indValid0Bound);
            
            indValid = setdiff(indValidFull,indValidBound);
    end
    
    if 0
        imgPath = sprintf('../images/%s/img%s.ppm',dset,imgnoStr1);
        figure, imshow(imgPath), hold on, plot(xyCoord0(:,1),xyCoord0(:,2),'*g');
        figure, imshow(imgPath), hold on, plot(coordFgBound1{1}(:,1),coordFgBound1{1}(:,2),'*b');
        figure, imshow(imgPath), hold on, plot(xyCoord0(indValid,1),xyCoord0(indValid,2),'*g');
        figure, imshow(imgPath), hold on, plot(coordFg{1}(:,1),coordFg{1}(:,2),'*b');
    end
    
    if ~getFgOnly
    matchesSavePath = sprintf('../data/results/matches-delta%d/%s/match%s_%d_%d',delta,dset,detType,im,im+1);
    matchesSavePathFull = sprintf('%s_full',matchesSavePath);
    if exist(strcat(matchesSavePathFull,'.mat'),'file')
        matchesTwoFr = load(matchesSavePathFull);
        
        %                         indValidF2  = getBgSubtractedFeat(f2(fx,:), dataset, imgnoStr2,dilvalCompB(b),fgTypeCompB{b});
        if  all(size(matchesTwoFr.matchFinal))~=0
            [~,fgInd] = intersect(matchesTwoFr.matchFinal(:,1),indValid);
            matchFinal = matchesTwoFr.matchFinal(fgInd,:);
        else
            matchFinal = [];
        end
    else
        matchFinal = [];
    end
    save(sprintf('%s_%s',matchesSavePath,fgTypeB),'matchFinal');
    end
end
end

%written this way to save time in computing the boundary for every image
%multiple times, for each dataset. Doing it inside also is good.