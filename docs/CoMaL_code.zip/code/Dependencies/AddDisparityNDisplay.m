function [fBound fNonBound fTotal ysize xsize] = AddDisparityNDisplay(file1,file2,datapath,file1b,file1nb,file1full,file2full,file1bDes,file1nbDes,file1fullDes,file2fullDes)

resizefactor=1; 

%for cones [9/10 75/70]; %[4.5/10 37.5/70]; %for each method, get a resizeFactor set
displayflag=0;
otherDetectors = 1;
cones=1;
if cones
    dispDivFactor = 2; %is mentioned in the website
    windSz=4; %1 and 4;
    whitePixelVal=1; %1
    resizeFactorPts = [9/10 75/70]; 
else
    dispDivFactor = 16;
    windSz=1; %1 and 4;
    whitePixelVal=255; %1
    midPixelVal = 128; %2
    resizeFactorPts =  [384/1000 288/700]; 
end

indices = strfind(file2,'.');
imgno = str2num(file2(indices(end-1)-1));
detType = file2(indices(end-1)+1:indices(end)-1);

disparity = double(imread(sprintf('%s/groundtruth.pgm',datapath)));
[ysize,xsize] = size(disparity);
boundaryPartsPlus = imread(sprintf('%s/occ_and_discont.png',datapath));

if cones
    if 1
        boundaryPartsPlus(boundaryPartsPlus ==1) = 0;
        se = strel('disk',4);
        se2 = strel('disk',1);
        boundaryPartsPlus = imdilate(boundaryPartsPlus,se);
        boundaryParts1 = imerode(boundaryPartsPlus,se2);
        boundaryParts1(boundaryParts1 ==2) = 1;
    else
        boundaryParts1 = boundaryPartsPlus;
    end
else
    if 1
        
        boundaryPartsPlus(boundaryPartsPlus ==midPixelVal) = 0;
        se = strel('disk',3);
        se2 = strel('disk',1);
        boundaryPartsPlus = imdilate(boundaryPartsPlus,se);
        boundaryParts1 = imerode(boundaryPartsPlus,se2);
% %         boundaryParts1(boundaryParts1 ==whitePixelVal) = whitePixelVal;
    else
        boundaryParts1 = boundaryPartsPlus;
    end
    
end
if 0
    boundaryParts2 = zeros(ysize,xsize);
    [row col] = find(boundaryParts1==whitePixelVal);
    for i1=1:length(row)
        colNew = round(col(i1) - (disparity(row(i1),col(i1))/dispDivFactor));
        if colNew>0
            boundaryParts2(row(i1),colNew) = whitePixelVal;
        end
    end
    boundaryParts2 = imdilate(boundaryParts2,se);
end

if displayflag
    figure, imshow(boundaryParts1,[]);
    figure, imshow(boundaryParts2,[]);
end


f1Orig =loadFeatures(file1); f1=f1Orig';
f2Orig =loadFeatures(file2); f2=f2Orig';

scaleFact = sqrt((resizeFactorPts(1)^2 + resizeFactorPts(2)^2));   %Detection of features is done at the standard size of 700X1000, points are resized to the value specified in the groundtruth
f1(:,1)=f1(:,1).*resizeFactorPts(1); f1(:,2)=f1(:,2).*resizeFactorPts(2);
f1(:,3:5)=f1(:,3:5)./(scaleFact*scaleFact);
f2(:,1)=f2(:,1).*resizeFactorPts(1); f2(:,2)=f2(:,2).*resizeFactorPts(2);
f2(:,3:5)=f2(:,3:5)./(scaleFact*scaleFact);

fBound=[]; fNonBound=[]; fTotal=[];
f1Round = floor(f1(:,1:2));
indZero = find(f1Round(:,1)==0 | f1Round(:,2)==0);
f1Round(indZero,:)=[];f1(indZero,:)=[];

for j=1:size(f1Round,1)

    if boundaryParts1(f1Round(j,2),f1Round(j,1))== whitePixelVal %midPixelValchange this also!
        bestPt=[];
        if 1 %too rigid
            %                 x = round(f1(j,2)/2); y= round(f1(j,1)/2);
            toadd = -disparity(f1Round(j,2),f1Round(j,1))/dispDivFactor;
            bestPt = [f1(j,1)+toadd f1(j,2:end)];
            %     f1dispRound = round(f1disp(:,1:2));
        else
            xlim1 = max(1,f1Round(j,2)-windSz); ylim1 = max(1,f1Round(j,1)-windSz);
            xlim2 = min(f1Round(j,2)+windSz,ysize); ylim2 = min(f1Round(j,1)+windSz,xsize);
            try
                disparity_neigh = disparity(xlim1:xlim2,ylim1:ylim2);
            catch
                disp('Disparity access to invalid point')
            end
            
            disparity_neigh = unique(disparity_neigh);
            minvalLeast=1000; bestPt=[];feat1Collect=[];
            for n=1:length(disparity_neigh)
                toadd = -disparity_neigh(n)/dispDivFactor;
                f1disp = [f1(j,1)+toadd f1(j,2:end)];
                
                scale = sqrt(1/f1(1,3));
                scaleArray = repmat(scale,4,size(f2,1));
                feat1=[f1disp(1:5)'; scale; scale; scale; scale];
                feat2=[f2(:,1:5)'; scaleArray];
                [wout, twoutFull, dout, tdout]=c_eoverlap(feat1,feat2,1);
                
                
                
                minval = min(wout);
                if minval<minvalLeast
                    minvalLeast = minval;
                    bestPt = f1disp;
                end
                feat1Collect = [feat1Collect feat1] ;
            end
            if 0
                figure, imshow('../images/cone/img1.ppm');
                showellipticfeaturesSPL(f1(j,:));
                
                figure, imshow('../images/cone/img2.ppm');
                showellipticfeaturesSPL(feat1Collect',[1 1 0]);
                showellipticfeaturesSPL(bestPt,[1 0 0]);
                
            end
        end
        
        fBound = [fBound; bestPt];
        
    else
        toadd = -disparity(f1Round(j,2),f1Round(j,1))/dispDivFactor;
        bestPt = [f1(j,1)+toadd f1(j,2:end)];
        fNonBound = [fNonBound; bestPt];
    end
end

fTotal = [fBound; fNonBound];

if strcmp(detType,'harronmser')
    otherDetectors = 0;
end

writeToFileTest(file2full,f2,1,xsize,ysize,0,1,otherDetectors );
writeToFileTest(file1b,fBound,1,xsize,ysize,0,imgno,otherDetectors );
writeToFileTest(file1nb,fNonBound,1,xsize,ysize,0,imgno,otherDetectors );
writeToFileTest(file1full,fTotal,1,xsize,ysize,0,imgno,otherDetectors );


writeToFileTestForDesc(file2fullDes,f2,1,xsize,ysize,0,1,otherDetectors );
writeToFileTestForDesc(file1bDes,fBound,1,xsize,ysize,0,imgno,otherDetectors );
writeToFileTestForDesc(file1nbDes,fNonBound,1,xsize,ysize,0,imgno,otherDetectors );
writeToFileTestForDesc(file1fullDes,fTotal,1,xsize,ysize,0,imgno,otherDetectors );


if displayflag
    
    %%%% %checking if the disparity file works correctly
    f1disp=[];
    f1Round = round(f1(:,1:2));
    for j=1:size(f1,1)
        toadd = -disparity(f1Round(j,2),f1Round(j,1))/dispDivFactor;
        f1disp = [f1disp; f1(j,1)+toadd f1(j,2:end)];
        
    end
    
    %     figure, imshow('../data/results/cone/imL.png');
    figure, imshow('../data/results/tsuk/imL.png'); %figure, imshow('../data/results/cone/im2.ppm');
    showellipticfeaturesSPL(f1);
    
    figure,  imshow('../data/results/cone/im6.ppm');
    showellipticfeaturesSPL(f2);
    
    figure,  imshow('../data/results/tsuk/img1.png'); %imshow('../images/cone/img1.ppm');
    showellipticfeaturesSPL(f1Orig');
    
    figure, imshow('../images/cone/img2.ppm');
    showellipticfeaturesSPL(f2Orig');
    
    %     figure, imshow('../data/results/cone/imR.png');
    figure, imshow('../data/results/tsuk/imR.png');%imshow('../data/results/cone/im6.ppm');
    showellipticfeaturesSPL(f1disp);
    
    %%%% Points along boundary
    f1disp =[];
    f1Round = round(f1(:,1:2));
    for j=1:size(f1Round,1)
        if boundaryParts1(f1Round(j,2),f1Round(j,1))==whitePixelVal
            f1disp = [f1disp ; f1(j,:)];
        end
    end
    figure, imshow('../data/results/tsuk/imL.png'); %imshow('../data/results/cone/im2.ppm');
    showellipticfeaturesSPL(f1disp);
    showellipticfeaturesSPL(f1disp,'k',4)
    showellipticfeaturesSPL(f1disp,'w',1.5)
    
    
    figure, imshow('../data/results/tsuk/imL.png'); %imshow('../data/results/cone/im6.ppm');
    showellipticfeaturesSPL(fNew);
    
    f2disp =[];
    f2Round = round(f2(:,1:2));
    for j=1:size(f2Round,1)
        if boundaryParts2(f2Round(j,2),f2Round(j,1))==whitePixelVal
            f2disp = [f2disp ; f2(j,:)];
        end
    end
    figure, imshow('../data/results/tsuk/imL.png'); %imshow('../data/results/cone/im6.ppm');
    showellipticfeaturesSPL(f2disp);
    showellipticfeaturesSPL(f2disp,'k',4)
    showellipticfeaturesSPL(f2disp,'w',1.5)
    
    
    %%%%%
    if 0
        fNew=fNew';
        ptSize = size(fNew,2);
        sizeFeat = sqrt(1/fNew(3,1)).*ones(1,ptSize);
        [detPtsNoDup detPtsOrig]  = overlapCheck([fNew(1:2,:); sizeFeat; zeros(1,ptSize); sizeFeat; zeros(4,ptSize); fNew(7,:); zeros(2,ptSize); fNew(6,:)],[ysize,xsize],10,0); %some extra value
        %                 figure, imshow(imgPath);
        %                 [detPtsNoDup detPtsOrig]  = overlapCheck(detPtsOrig,[ysize,xsize],20,25); %some extra value
        detPtsNoDup = [detPtsNoDup; detPtsOrig(10,:)];
        
        fNew = detPtsNoDup';
        %     writeToFileTest(file1,detPtsNoDup',1,xsize,ysize,0);
    end
    
end