gt=csvread('../images/bord/rectangles'); %for cann, dino
% gt=csvread('../images/bord/board_gt.txt'); %for box, lemming and board of PROST
% gt=csvread('groundthruth.txt'); %for cycle and cup of vot

imfiles = dir('../images/bord/*.ppm');
imfilenames = cat(1,imfiles(:).name);
reqgt = gt( str2num(imfilenames(:,1:end-4)) , 1:4 );
save('gt.mat','reqgt');