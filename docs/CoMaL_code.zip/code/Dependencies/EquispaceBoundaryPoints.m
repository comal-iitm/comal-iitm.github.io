function [x y idxCorrected indmap]  = EquispaceBoundaryPoints(x,y,idx,circflag)

global granularity2    

    % Granularize the contours. ~Ramkumar
    xNorm = x .* granularity2;
    yNorm = y .* granularity2;

    iterResample = 0;
    indmap = 1:1:size(xNorm,1); % Number of contour points? ~Ramkumar
    
    [xNormResampled yNormResampled idxCorrected indmap resampledBasisDistNorm] = ...
        ResampleAffineContour(xNorm,yNorm,idx,indmap,circflag);
    
    while (max(resampledBasisDistNorm)>1.02 || min(resampledBasisDistNorm)<0.98) && iterResample < 10
        [xNormResampled yNormResampled idxCorrected indmap resampledBasisDistNorm] = ...
            ResampleAffineContour(xNormResampled,yNormResampled,idxCorrected,indmap,circflag);
        iterResample = iterResample+1;
    end
    
    x = xNormResampled ./ granularity2;
    y = yNormResampled ./ granularity2;
        
end
