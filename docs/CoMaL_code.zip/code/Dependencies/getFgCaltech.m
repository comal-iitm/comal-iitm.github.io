function getFgCaltech()

%cut the bottom layer out and do this.
%run bw boundary on this.
dirData='../images'; imext='.ppm';
Tuples = getTuples(dirData);
[datasets indUnique] = unique(Tuples(:,1));
indUnique = [0; indUnique];
numImagesAll = indUnique(2:end) - indUnique(1:end-1); %add here if sth is not right
bbInit = [180 90 520 565];

for d=14:length(datasets)
    dset = datasets{d};
    dSetNo = getParamsAndDataset(dset);
    if dSetNo==5
        startImgNo = 1 ; endImgNo = numImagesAll(d);
        for imgno = startImgNo:endImgNo
            imgnoStr = getImgnoInStrOrInt(imgno,dSetNo);
            imgPath = fullfile(dirData,dset,sprintf('img%s.ppm',imgnoStr));
            img=imread(imgPath);
            [imX,imY,third] = size(img);
            imBinary = zeros(imX,imY);
            
            left = bbInit(1); top = bbInit(2); wid = bbInit(3); ht = bbInit(4);
            if 0
                hFig = figure; imshow(img);
                rectangle('Position',bbInit);
                imgSave1 = sprintf('../bb/%s',dset);
                imgSave = sprintf('../bb/%s/img%s.ppm',dset,imgnoStr);
                if ~exist('imgSave1','dir')
                    mkdir(imgSave1);
                end
                saveas(hFig,imgSave);
                close all;
            end
            if 1
                imgGray = rgb2gray(img); szImg = size(imgGray);
                if 0
                    imgBinary = zeros(szImg(1),szImg(2));
                    indValid = find(imgGray<170 & imgGray>100);
                    imgBinary(indValid)=1;
                    %                 imgBinary = 1-imgBinary;
                    figure, imshow(imgBinary);
                    imgBinaryCut(top:top+ht,left:left+wid,:) = imgBinary(top:top+ht,left:left+wid,:);
                    figure, imshow(imgBinary);
                end
                thresh = graythresh(imgGray);
                fgBinary1 = im2bw(imgGray,thresh);
                figure, imshow(fgBinary1);
                imgBinary = 1 - imgBinary;
                imgBinaryCut(top:top+ht,left:left+wid,:) = imgBinary(top:top+ht,left:left+wid,:);
                figure, imshow(imgBinary);
                
                %             imgGray = 255-imgGray;
                %             thresh = graythresh(imgGray);
                %             fgBinary2 = im2bw(imgGray,thresh);
                %             figure, imshow(fgBinary2);
                %             fgBinary = 1 - fgBinary;
                
                se = strel('disk',40); fgBinaryDil = imdilate(imgBinaryCut,se);
                figure, imshow(fgBinaryDil);
            end
        end
    end
end