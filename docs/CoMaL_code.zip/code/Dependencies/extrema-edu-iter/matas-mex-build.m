%%
pwd = '/home/swarna/Downloads/extrema-edu/extrema';
cd(pwd);
%%
% This is the command used to get the static libraries compiled from within
% MATLAB (the .out is also ready but we won't be using that)
system('make clean');
system('make all');
%%
% This is the command that compiles the mex after the libraries are
% available using the usual makefile supplied with the Matas code.
mex -v -I../LL -I../utls -I../imageutls -I../optionGM libExtrema.a ../LL/libLL.a ../utls/libutls.a ../optionGM/libOptionGM.a -lrt extremaExpt.cpp
%%
% mex driver for Matas' code (mex)
img = imread('img1.ppm');
extremaExpt(img);