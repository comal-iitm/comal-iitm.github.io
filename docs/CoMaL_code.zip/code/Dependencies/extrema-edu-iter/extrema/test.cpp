/*--------------------------------------------------------------------------*/
/* Copyright 2006, Jiri Matas & Michal Perdoch       matas@cmp.felk.cvut.cz */
/*--------------------------------------------------------------------------*/

// #include<mexutils.c>
#include <mex.h>
#include "libExtrema.h"
#include <../optionGM/optionGM.h>
#include <../optionGM/optionPriv.h>
#include <../imageutls/imageread.h>
#include <../utls/timeutls.h>
#include "boundary.h"
#include "preprocess.h"
#include "suballoc.h"
#include "sortPixels.h"
#include "optThresh.h"
#include "getExtrema.h"

#include <stdio.h>
#define MAX_PATH_LEN 1024

#ifdef WIN32

#define snprintf _snprintf

#endif

using namespace extrema;

void
        mexFunction(int nout, mxArray *out1[],
        int nin, const mxArray *in[])
{
    enum {IN_I=0, IN_PARAMS} ;
    enum {OUT_IP=0, OUT_REGIONS, OUT_VARIATION} ;
    
    ExtremaParams p; int rep_count,i;    
    int bi,bj;
    /*  replace by default values */
    char *output_fname = "mex_test_image.mser"; //OptionStr("o", NULL, "output file");
    char *image_fname = "img1.ppm";
    double scale_factor = 1.0; //OptionDouble("es", 1.0, "ellipse scale, (output types 2 and 4)");
    scale_factor = scale_factor * 2; /* compensate covariance matrix */
    p.preprocess = 0; //OptionInt("pre", 0, "image preprocessing type");
    p.max_area = 0.01; //OptionDouble("per", 0.01, "maximum relative area");
    p.min_size = 30; //OptionInt("ms", 30, "minimum size of output region");
    p.min_margin = 10; //OptionInt("mm", 10, "minimum margin");
    p.relative = 0; //OptionToggle("rel", 0, "use relative margins")!=0;
    p.verbose = 0; //OptionToggle("v", 0, "verbose output");
    p.debug = 0; //OptionInt("d", 0, "debug outputs");
    rep_count = 1; //OptionInt("r", 1, "number of runs (for timing purposes)");
    int output_type = 1; //OptionInt("t", 0, "output file type 0 - RLE, 1 - ExtBound., 2 - Ellipse, 3 - GF, 4 - Aff.\n");
    vector <BoundaryRegion> boundary_vector;
    
    unsigned char * I_pt; //input has to be in the following format: R G B values of each pixel picked column-wise in the img array- after imread
    double * imgdim;
    mxArray    *boundFinal;
    int bdims[1], bndims, nel, dims[2];
    const char *classcheck;
    double* pt;
//     classcheck = mxGetClassName(in[IN_I]);
//     printf("Class of I is %s \n",classcheck);
//     
//     classcheck = mxGetClassName(in[IN_PARAMS]);
//     printf("Class of dims is %s \n",classcheck);
//     
    I_pt  = (unsigned char *)mxGetData(in[IN_I]) ;
    imgdim = mxGetPr(in[IN_PARAMS]) ;
    for(i=0; i<3; ++i) {
     dims[i] = *imgdim++;   
    }
//     printf("No of imputs %d:\n", nin);
//     printf("The dimensions: %d, %d %d\n", dims[0],dims[1],dims[2]);
//     nel = dims[0]*dims[1]*dims[2];

//     out1[OUT_IP] = mxCreateDoubleMatrix(nel, 2, mxREAL);
//     pt =  mxGetPr(out1[OUT_IP]);
//     for(i = 0 ; i < nel ; ++i) {
//         *pt++ = *I_pt++;
//     }
    
    ExtremaImage im;
    ExtremaImage imComp;
    // if (p.verbose)
//       printf("Processing %s\n", image_fname);
    size_t w, h, c;
//     int ret = read_image(image_fname, imComp.data, w, h, c);
//      printf("Reading done");
//     for(i = 0 ; i < nel ; ++i) {
//         *pt++ = *im.data++;
//     }
//     delete[] imComp.data;
    
//       free(image_fname);
    
    im.data = I_pt;
     printf("The dimensions again: %d, %d %d\n", w,h,c);
//          im.width = w; im.height = h;        
//     im.channels = c; 
    im.width = dims[1];
    im.height = dims[0];        
    im.channels = dims[2];     
//     printf("Image width %d, height %d, channels %d and some value%d.\n",
//             im.width, im.height, im.channels,im.data[50,600]);
    if (!p.preprocess)
    {
        
        if (im.channels<2)
            p.preprocess = PREPROCESS_CHANNEL_none; //must check how this behaves for grayscale image
        else
            p.preprocess = PREPROCESS_CHANNEL_intensity;
    }
//     if (p.verbose)
//         printf("Output file: %s\n", output_fname);
//     FILE *out = fopen(output_fname, "w+");
//     if (!out)
//     {
//         printf("Cannot open output file for writing.\n");
//         exit(0);
//     }
//     double t1 = get_time();
//
    BoundaryExtrema result;
    if (rep_count>1)
        printf("Number of runs: %d\n", rep_count);
    for (int i=0;i<rep_count;i++)
        result = getBoundaryExtrema(p, im);
//
    printf("Total MSER+ %d, MSER- %d detected\n",
            result.MSERplus.size(),
            result.MSERmin.size());
    
    
    boundary_vector = result.MSERplus; //cast?
    bndims = 2; bdims[0] = 1; bdims[1] = boundary_vector.size();
    out1[OUT_IP] = mxCreateCellArray(bndims, bdims);

    sort(boundary_vector.begin(), boundary_vector.end());
    for(bi=0; bi < boundary_vector.size(); bi++)
    {
        const BoundaryRegion *r = &boundary_vector[bi];
        boundFinal = mxCreateDoubleMatrix(2, r->boundary.size(), mxREAL);
        pt =  mxGetPr(boundFinal);
        for (bj=0; bj<r->boundary.size(); ++bj) {
            *pt++ = r->boundary[bj].col;
            *pt++ = r->boundary[bj].line;
        }
        mxSetCell(out1[OUT_IP], bi, mxDuplicateArray(boundFinal));

}
    
   
    
}
