/*--------------------------------------------------------------------------*/
/* Copyright 2006, Jiri Matas & Michal Perdoch       matas@cmp.felk.cvut.cz */
/*--------------------------------------------------------------------------*/

#ifndef __OPT_THRESH_H__
#define __OPT_THRESH_H__

#include "extremaTypes.h"

namespace extrema 
{

void FastSetOptThresholds4StableRegion(t_region *p_r);

}
#endif
