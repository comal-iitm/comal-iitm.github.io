#include "matrix.h"
#include <mex.h>



void
        mexFunction(int nout, mxArray *cell_array_ptr[],
        int nin, const mxArray *in[])
{
int      ndim=2, dims[]={2, 2}; 
int      index, nsubs=2, subs[2];
double   real_pr[] = {5.23, 7.45, 8.17, 9.79};
double   *pr;
mxArray  *string_array_ptr, *vector_ptr;

 /* Create a 2-by-2 cell array. */
   cell_array_ptr = mxCreateCellArray(ndim, dims);
   mxSetName(cell_array_ptr, "amoeba");

 /* Create a string array. */ 
   string_array_ptr = mxCreateString("Hello friends.");
 /* Place the string array into cell element (1,1). */
   subs[0]=0; subs[1]=0;
   index = mxCalcSingleSubscript(cell_array_ptr, nsubs, subs); 
   mxSetCell(cell_array_ptr, index, string_array_ptr);

 /* Create a 1-by-4 vector array of doubles. */ 
   vector_ptr = mxCreateDoubleMatrix(1, 4, mxREAL);
   pr = mxGetPr(vector_ptr);
   memcpy((void *)pr,(const void *)real_pr,4*sizeof(double));
 /* Place the vector array into cell element (2,2). */
   subs[0]=1; subs[1]=1;
   index = mxCalcSingleSubscript(cell_array_ptr, nsubs, subs); 
   mxSetCell(cell_array_ptr, index, vector_ptr);
}