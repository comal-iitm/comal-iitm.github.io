%%
clc;
clear all;
%%
% This is the command used to get the static libraries compiled from within
% MATLAB (the .out is also ready but we won't be using that)
system('make -f Makefile clean');
system('make -f Makefile all');
%%
% This is the command that compiles the mex after the libraries are
% available using the usual makefile supplied with the Matas code.
% mex -v -g -I../LL -I../utls -I../imageutls -I../optionGM libExtrema.a ../LL/libLL.a ../utls/libutls.a ../optionGM/libOptionGM.a -lrt test.cpp
mex -v -g -I../LL -I../utls -I../imageutls -I../optionGM libExtrema.a ../LL/libLL.a ../utls/libutls.a ../optionGM/libOptionGM.a -lrt extremaExpt.cpp
% mex -v -g -I../LL -I../utls -I../imageutls -I../optionGM libExtrema.a ../LL/libLL.a ../utls/libutls.a ../optionGM/libOptionGM.a -lrt extrema.cpp

%%
% dbmex on;
img = imread('img1.ppm'); % img = rgb2gray(img);
sizeImg = size(img);
for i=1:3
    imgTemp(:,:,i) = img(:,:,i)';
end
imgTemp = shiftdim(imgTemp,2);
imgFormatd = reshape(imgTemp,1,sizeImg(1)*sizeImg(2)*sizeImg(3));
%%
boundaryVals = extremaExpt(imgFormatd,sizeImg);
% extremaExpt(img);
    