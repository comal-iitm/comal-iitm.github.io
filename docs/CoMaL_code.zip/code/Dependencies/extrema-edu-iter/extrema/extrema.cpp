/*--------------------------------------------------------------------------*/
/* Copyright 2006, Jiri Matas & Michal Perdoch       matas@cmp.felk.cvut.cz */
/*--------------------------------------------------------------------------*/

#include "libExtrema.h"
#include <optionGM.h>
#include <optionPriv.h>
#include <imageread.h>
#include <timeutls.h>
#include <stdio.h>

#define MAX_PATH_LEN 1024

#ifdef WIN32

#define snprintf _snprintf

#endif

using namespace extrema;

int main(int argc, char *argv[])
{
   ExtremaParams p; int rep_count;
   OptionInit(argv,&argc);          /* analyse the command line */
   char *image_fname = OptionStr("i", NULL, "input image (png, tiff, jpg, ppm, pgm)");     
   char *output_fname = OptionStr("o", NULL, "output file");     
   double scale_factor = OptionDouble("es", 1.0, "ellipse scale, (output types 2 and 4)");
   scale_factor = scale_factor * 2; /* compensate covariance matrix */
   p.preprocess = OptionInt("pre", 0, "image preprocessing type");
   p.max_area = OptionDouble("per", 0.01, "maximum relative area");
   p.min_size = OptionInt("ms", 30, "minimum size of output region");
   p.min_margin = OptionInt("mm", 10, "minimum margin");
   p.relative = OptionToggle("rel", 0, "use relative margins")!=0;
   p.verbose = OptionToggle("v", 0, "verbose output");
   p.debug = OptionInt("d", 0, "debug outputs");
   rep_count = OptionInt("r", 1, "number of runs (for timing purposes)");
   int output_type = OptionInt("t", 0, "output file type 0 - RLE, 1 - ExtBound., 2 - Ellipse, 3 - GF, 4 - Aff.\n");
   //   p.stability_method=STABILITY_METHOD_SQRT_AREA;  // Michal Jancosek, stara extrema
   OptionCompulsory("i");
   OptionCheck();
   if (!output_fname)
   {      
      output_fname = (char *)malloc(MAX_PATH_LEN*sizeof(char));
      switch(output_type)
      {
      case 0: 
         snprintf(output_fname, MAX_PATH_LEN, "%s.rle", image_fname); break;
      case 1:
         snprintf(output_fname, MAX_PATH_LEN, "%s.extbound",image_fname);break;
      case 2:
         snprintf(output_fname, MAX_PATH_LEN, "%s.ell", image_fname); break;
      case 3:
         snprintf(output_fname, MAX_PATH_LEN, "%s.gf", image_fname); break;
      case 4:
         snprintf(output_fname, MAX_PATH_LEN, "%s.aff", image_fname); break;
      default:
         return -1;
      }
   }
   ExtremaImage im;
   if (p.verbose)
      printf("Processing %s\n", image_fname);
   size_t w, h, c; 
   int ret = read_image(image_fname, im.data, w, h, c);
   im.width = w; im.height = h; im.channels = c;
   if (ret)
   {
      printf("Error reading image %s, ", image_fname);
      switch(ret)
      {
      case -1:
         printf("cannot open file.\n"); break;
      case -2:
         printf("invalid file or unknown format.\n"); break;
      case -3:
         printf("unsupported format.\n"); break;
      case -4:
         printf("corrupted file?\n"); break;
      }
   } else {
      if (p.verbose)
         printf("Image width %d, height %d, channels %d.\n",
                im.width, im.height, im.channels);
      if (!p.preprocess)
      {
         if (im.channels<3)
            p.preprocess = PREPROCESS_CHANNEL_none;
         else
            p.preprocess = PREPROCESS_CHANNEL_intensity;
      }
      if (p.verbose)
         printf("Output file: %s\n", output_fname);
      FILE *out = fopen(output_fname, "w+");
      if (!out)
      {
         printf("Cannot open output file for writing.\n");
         exit(0);
      }
      double t1 = get_time();
      if (output_type!=1 && output_type!=3)
      {            
         RLEExtrema result;
         if (rep_count>1)
            printf("Number of runs: %d\n", rep_count);
         for (int i=0;i<rep_count;i++)
            result = getRLEExtrema(p, im);
         if (p.verbose)
            printf("Total MSER+ %d, MSER- %d detected in %.4f sec.\n",
                   result.MSERplus.size(),
                   result.MSERmin.size(),
                   get_time()-t1);
         switch (output_type)
         {
         case 0:
            exportRLEVector(out, result.MSERplus);
            exportRLEVector(out, result.MSERmin);
            break;
         case 2:
            /* output one header only */
            fprintf(out, "1.0\n");
            result.MSERplus.insert(result.MSERplus.end(),
                                   result.MSERmin.begin(),
                                   result.MSERmin.end());
            result.MSERmin.clear();
            fprintf(out, "%d\n", 
                    result.MSERplus.size());
            exportAffVector(out, result.MSERplus, scale_factor, 1);
            break;
         case 4:
            exportAffVector(out, result.MSERplus, scale_factor, 0);
            exportAffVector(out, result.MSERmin, scale_factor, 0);
            break;
         default:
            printf("Invalid output format.\n");               
         }
      } else {
         BoundaryExtrema result;
         if (rep_count>1)
            printf("Number of runs: %d\n", rep_count);
         for (int i=0;i<rep_count;i++)
            result = getBoundaryExtrema(p, im);
         if (p.verbose)
            printf("Total MSER+ %d, MSER- %d detected in %.4f sec.\n",
                   result.MSERplus.size(),
                   result.MSERmin.size(),
                   get_time()-t1);
         if (output_type==1)
         {
            exportBoundaryVector(out, result.MSERplus);
            exportBoundaryVector(out, result.MSERmin);
         } else {
            fprintf(out, "@Set MSERplus\n");
            exportBoundaryVectorGF(out, result.MSERplus);
            fprintf(out, "@Set MSERminus\n");
            exportBoundaryVectorGF(out, result.MSERmin);
         }
      }
      fclose(out);
      delete[] im.data;
   }
   free(image_fname);
   return 0;
}
