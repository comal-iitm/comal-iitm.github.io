/* ==========================================================================
 * phonebook.c
 * example for illustrating how to manipulate structure and cell array
 *
 * takes a (MxN) structure matrix and returns a new structure (1x1)
 * containing corresponding fields: for string input, it will be (MxN)
 * cell array; and for numeric (noncomplex, scalar) input, it will be (MxN)
 * vector of numbers with the same classID as input, such as int, double
 * etc..
 *
 * This is a MEX-file for MATLAB.
 * Copyright 1984-2006 The MathWorks, Inc.
 *==========================================================================*/
/* $Revision: 1.6.6.2 $ */

#include "mex.h"
#include "string.h"

#define MAXCHARS 80   /* max length of string contained in each field */

/*  the gateway routine.  */
void mexFunction( int nlhs, mxArray *plhs[],
        int nrhs, const mxArray *prhs[] )
{
    
    const mwSize *dims;
    mxArray    *tmp;
    int        i,i1;
    mwSize     ndim;
    double* pt, *dummy;
    
    ndim = mxGetNumberOfDimensions(prhs[0]);
    dims = mxGetDimensions(prhs[0]);
        
    dummy  = mxGetData(prhs[0]) ;
    /* create a 1x1 struct matrix for output  */
    tmp = mxCreateDoubleMatrix(1, dims[1], mxREAL);
    pt =  mxGetPr(tmp);
    for(i = 0 ; i < dims[1] ; ++i) {
        *pt++ = *dummy++;
    }
    
    plhs[0] = mxCreateCellArray(ndim, dims);
    
    for(i1=0; i1<dims[1]; ++i1) {
        mxSetCell(plhs[0], i1, mxDuplicateArray(tmp));
        
    }

    
    return;
}

