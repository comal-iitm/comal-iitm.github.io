/*--------------------------------------------------------------------------*/
/* Copyright 2006, Jiri Matas & Michal Perdoch       matas@cmp.felk.cvut.cz */
/*--------------------------------------------------------------------------*/

#ifndef __EXTREMA_CONFIG_H__
#define __EXTREMA_CONFIG_H__

/* measure time in libExtrema functions */
#define TIME_STATS                   1

#endif // __EXTREMA_CONFIG_H__
