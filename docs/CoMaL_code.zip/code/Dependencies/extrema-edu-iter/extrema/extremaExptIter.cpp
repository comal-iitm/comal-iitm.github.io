/*--------------------------------------------------------------------------*/
/* Copyright 2006, Jiri Matas & Michal Perdoch       matas@cmp.felk.cvut.cz */
/*--------------------------------------------------------------------------*/

// #include<mexutils.c>
#include <mex.h>
#include "libExtrema.h"
#include <../optionGM/optionGM.h>
#include <../optionGM/optionPriv.h>
#include <../imageutls/imageread.h>
#include <../utls/timeutls.h>
#include "boundary.h"
#include "preprocess.h"
#include "suballoc.h"
#include "sortPixels.h"
#include "optThresh.h"
#include "getExtrema.h"
#include <stdio.h>
#include <iostream>
#define MAX_PATH_LEN 1024

#ifdef WIN32
#define snprintf _snprintf
#endif

using namespace extrema;

void
        mexFunction(int nout, mxArray *out1[],
        int nin, const mxArray *in[])
{
    enum {IN_I=0, IN_PARAMS,IN_THETA,IN_DELTA,IN_PM} ;
    enum {OUT_REGIONS=0, OUT_VARIATION} ;//OUT_BOUND_P=0, OUT_BOUND_M
    
    ExtremaParams p; int rep_count,i;
    int bi,bj;
    double *iter_pt;
    double theta = mxGetScalar(in[IN_THETA]) ;
    int delta = mxGetScalar(in[IN_DELTA]) ;
    int plusOrMinus = mxGetScalar(in[IN_PM]);
    /*  replace by default values */
    int iter_val;
    char *image_fname = "img1.ppm";
    double scale_factor = 1.0; //OptionDouble("es", 1.0, "ellipse scale, (output types 2 and 4)");
    scale_factor = scale_factor * 2; /* compensate covariance matrix */
    p.preprocess = 0; //OptionInt("pre", 0, "image preprocessing type");
    //OptionInt("ms", 30, "minimum size of output region");
    p.max_area = 0.99; //OptionDouble("per", 0.01, "maximum relative area");
    p.min_margin = delta; //OptionInt("mm", 10, "minimum margin");
//            printf("delta: %f\n",p.min_margin);
//         p.theta = theta;
//         printf("angle: %f\n",p.theta);
    p.relative = 0; //OptionToggle("rel", 0, "use relative margins")!=0;
    p.verbose = 0; //OptionToggle("v", 0, "verbose output");
    p.debug = 0; //OptionInt("d", 0, "debug outputs");
    rep_count = 1; //OptionInt("r", 1, "number of runs (for timing purposes)");
    int output_type = 1; //OptionInt("t", 0, "output file type 0 - RLE, 1 - ExtBound., 2 - Ellipse, 3 - GF, 4 - Aff.\n");
//     vector <BoundaryRegion> boundary_vector_plus, boundary_vector_minus;
    vector <RLERegion> rle_vector ;
    
    unsigned char * I_pt; //input has to be in the following format: R G B values of each pixel picked column-wise in the img array- after imread
    double *imgdim, *pt, *ptstrength;
    mxArray *regionFinal, *strength;
    mxArray    *boundFinal;
    int bdims[2], bndims, nel, dims[3];
    const char *classcheck;
    
    I_pt  = (unsigned char *)mxGetData(in[IN_I]) ;
    imgdim = mxGetPr(in[IN_PARAMS]) ;
    for(i=0; i<3; ++i) {
        dims[i] = *imgdim++;
    }
    
    ExtremaImage im;
    im.data = I_pt;
    im.width = dims[1]; im.height = dims[0]; im.channels = dims[2];
    p.pwidth = dims[1]; p.pheight = dims[0];
    
    p.min_size = p.pwidth/3.5;//1.5;
//     std::cout << p.min_size;
    
    if (!p.preprocess)
    {
        if (im.channels<2)
            p.preprocess = PREPROCESS_CHANNEL_none; //must check how this behaves for grayscale image
        else
            p.preprocess = PREPROCESS_CHANNEL_intensity;
    }
    
    bndims = 2;
    
//regions
    RLEExtrema resultRLE;
    resultRLE = getRLEExtrema(p,im,plusOrMinus);
    if (plusOrMinus)
       rle_vector = resultRLE.MSERplus;
    else
        rle_vector = resultRLE.MSERmin;
    
    bdims[0] = 1; bdims[1] = rle_vector.size();
    out1[OUT_REGIONS] = mxCreateCellArray(bndims, bdims);
    out1[OUT_VARIATION] = mxCreateDoubleMatrix(2,rle_vector.size(),mxREAL);
    ptstrength = mxGetPr(out1[OUT_VARIATION]) ;
     
    for(bi=0; bi < rle_vector.size(); bi++)
    {
        const RLERegion *r = &rle_vector[bi];

		int size1 = 0;
		int iter_beg = 0, iter_end;
		double runLen;	
	    int count = 0;	
		for (bj=0; bj<r->rle.size(); bj++) {
			size1 += r->rle[bj].col2 - r->rle[bj].col1 + 1;
			runLen = r->rle[bj].col2 - r->rle[bj].col1 + 1;
			iter_end = iter_beg + runLen - 1;

			for(int jter=iter_beg; jter<=iter_end; jter++)
			{
				if(r->rle[bj].line+1 <= 0 || r->rle[bj].col1 + jter - iter_beg + 1 <=0)
				{
					count++;
				}
			}
			iter_beg = iter_end + 1;
		}
	
        regionFinal = mxCreateDoubleMatrix(2, size1-count, mxREAL);
        pt =  mxGetPr(regionFinal);

		iter_beg = 0; iter_end = 0;
        for (bj=0; bj<r->rle.size(); bj++) {
            //*pt++ = r->rle[bj].line;
            //*pt++ = r->rle[bj].col1;
            //*pt++ = r->rle[bj].col2;
			runLen = r->rle[bj].col2 - r->rle[bj].col1 + 1;
			iter_end = iter_beg + runLen - 1;

			for(int jter=iter_beg; jter<=iter_end; jter++)
			{
				if(!(r->rle[bj].line+1 <= 0 || r->rle[bj].col1 + jter - iter_beg + 1 <=0))
				{
					*pt++ = r->rle[bj].line + 1;
					*pt++ = r->rle[bj].col1 + jter - iter_beg + 1;
				}
			}
			iter_beg = iter_end + 1;
        }

        mxSetCell(out1[OUT_REGIONS], bi, mxDuplicateArray(regionFinal));
        *ptstrength++ = r->marginTemp;
        //*ptstrength++ = r->margin;
        *ptstrength++ = r->threshold;
    }
    
}
