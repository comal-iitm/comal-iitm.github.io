function [ssdVal shiftErrors] = AlignGetSSD3(selCutRGBMain,selCutRGB,img,center, szBlock0, numShifts)

szDilate = 4;

szBlockBy2 = (szBlock0-1)/2 + numShifts;

szBlock = szBlock0 + 2*(numShifts);
for imgno=1:2
    image = double((imread(img{imgno})))*(1/255);%
    szImg = size(image);
    TempPos1(1,1) = max(1,center(imgno,2) - szBlockBy2); TempPos1(1,2) = min(szImg(1),center(imgno,2) + szBlockBy2);
    TempPos1(2,1) = max(1,center(imgno,1) - szBlockBy2); TempPos1(2,2) = min(szImg(2),center(imgno,1) + szBlockBy2);
    templates{imgno} = image(TempPos1(1,1):TempPos1(1,2),TempPos1(2,1):TempPos1(2,2),:);
    
    addPre1 = (center(imgno,2) - szBlockBy2 -1); addPost1 = szImg(1) - (center(imgno,2) + szBlockBy2);
    addPre2 = (center(imgno,1) - szBlockBy2 -1); addPost2 = szImg(2) - (center(imgno,1) + szBlockBy2);
    if addPre1 < 0 | addPre2 < 0
        if addPre1>0; addPre1 = 0; end
        if addPre2>0; addPre2 = 0; end
        templates{imgno} = padarray(templates{imgno},[abs(addPre1) abs(addPre2) 0],'pre');
    end
    if addPost1 < 0 | addPost2 < 0
        if addPost1>0; addPost1 = 0; end
        if addPost2>0; addPost2 = 0; end
        templates{imgno} = padarray(templates{imgno},[abs(addPost1) abs(addPost2) 0],'post');
    end
    %     template_common = zeros(szBlock,szBlock,3);
    %     template_common(selDilated) = I_template(selDilated);
    %     templates1{imgno} = template_common;
end

% horizAdd = zeros(numShifts,szBlock,3);
% temp1 = [horizAdd; templates{1}; horizAdd]; %append extra
% temp2 = [horizAdd; templates{2}; horizAdd]; %append extra
% temp3 = [horizAdd; check1; horizAdd];
% verticalAdd = zeros(szBlock+2*numShifts,numShifts,3);
% templates{1} = [verticalAdd temp1 verticalAdd]; %append extra
% templates{2} = [verticalAdd temp2 verticalAdd]; %append extra
% check1 = [verticalAdd temp3 verticalAdd]; %append extra
[mask1 selApp1] = getDilMaskFromSel(selCutRGBMain,szBlock0,numShifts,szDilate);
[mask2 selApp2] = getDilMaskFromSel(selCutRGB,szBlock0,numShifts,szDilate);
% selCommon0 = intersect(selApp1,selApp2);

[Xshift,Yshift] = meshgrid(-numShifts:numShifts,-numShifts:numShifts);
XshiftN = Xshift(:); %reshape(Xshift,(2*numShifts+1)*(2*numShifts+1),1);
YshiftN = Yshift(:); %reshape(Yshift,(2*numShifts+1)*(2*numShifts+1),1);
shiftErrors = 5000000*ones(numel(Xshift),1);
for shift=1:numel(Xshift)
    [templateSh1 templateSh2] = imshiftMine([XshiftN(shift) YshiftN(shift)],templates{1},templates{2});
    [maskSh1 maskSh2] = imshiftMine([XshiftN(shift) YshiftN(shift)],mask1,mask2);
    I_error = imabsdiff(templateSh1,templateSh2);
    selApp1 = find(maskSh1); selApp2 = find(maskSh2);
    selAppCommon{shift} = intersect(selApp1,selApp2);
    I_errorSel = I_error(selAppCommon{shift});
    %     if length(selAppCommon{shift}) > (.8*length(selCommon0))
    shiftErrors(shift) = sum(I_errorSel);
    %     end
end
shiftErrors1 = reshape(shiftErrors,2*numShifts+1,2*numShifts+1);
%                         figure, surf(shiftErrors1), shading flat
%figure, imshow(templates{1}); figure, imshow(template_shifted);

[minSSD minSSDInd] = min(shiftErrors);
ssdVal = shiftErrors(minSSDInd)/length(selAppCommon{minSSDInd});
shiftErrors1(numShifts,numShifts);

if 0
    template_shifted = imshift([XshiftN(minSSDInd) YshiftN(minSSDInd)],templates{2});
    maskDisp = zeros(szBlock,szBlock,3);
    maskDisp(selAppDilCommon{minSSDInd})=1;
    
    %     maskDisp = zeros(szBlock,szBlock,3);
    %     maskDisp(selCommon0)=1;
    %
    boundary = bwboundaries(maskDisp(:,:,1));
    numParts = length(boundary);
    figure, imshow(template_shifted); hold on,
    for i=1:numParts
        plot(boundary{numParts}(:,2),boundary{numParts}(:,1));
    end
    figure, imshow(templates{1}); hold on,
    for i=1:numParts
        plot(boundary{numParts}(:,2),boundary{numParts}(:,1));
    end
    
end
end

function [maskFinal selApp] = getDilMaskFromSel(selCut,szBlock,numShifts,szDilate)
if 0
    mask = zeros(szBlock,szBlock,3);
    mask(selCut) = 1;
    horizAdd = zeros(numShifts,szBlock,3);
    temp = [horizAdd; mask; horizAdd];
    verticalAdd = zeros(szBlock+2*numShifts,numShifts,3);
    maskAdded = [verticalAdd temp verticalAdd]; %append extra
    
    % se = strel('disk',szDilate);
    % maskFinal = imdilate(maskAdded,se);
    maskFinal = maskAdded;
    selApp = find(maskFinal);
else
    [i1 i2 i3] = ind2sub([szBlock szBlock 3], selCut);
    i1 = i1 + numShifts;
    i2 = i2 + numShifts;
    selApp = sub2ind([szBlock+2*numShifts szBlock+2*numShifts 3], i1, i2, i3);
    maskFinal = zeros(szBlock+2*numShifts ,szBlock+2*numShifts,3);
    maskFinal(selApp) = 1;
    
end

end

function [imBlockSh1 imBlockSh2] = imshiftMine(shifts,imBlock1,imBlock2)
shXA = abs(shifts(1)); shYA = abs(shifts(2));
imBlockSh1 = imBlock1; imBlockSh2 = imBlock2;

switch sign(shifts(1))
    case -1
        imBlockSh1 = imBlockSh1(1:end-shXA,:,:);
        imBlockSh2 = imBlockSh2(1+shXA:end,:,:);
        
    case 1
        imBlockSh2 = imBlockSh2(1:end-shXA,:,:);
        imBlockSh1 = imBlockSh1(1+shXA:end,:,:);
end


switch sign(shifts(2))
    case -1
        imBlockSh1 = imBlockSh1(:,1:end-shYA,:);
        imBlockSh2 = imBlockSh2(:,1+shYA:end,:);
        
    case 1
        imBlockSh2 = imBlockSh2(:,1:end-shYA,:);
        imBlockSh1 = imBlockSh1(:,1+shYA:end,:);
end

end