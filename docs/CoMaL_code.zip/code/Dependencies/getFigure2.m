function [hFig1 hFig2 legendStr] = getFigure2(datastring,xlabelString, yLabelString1, yLabelString2,score,corres,delta,desTypeDet,hFig1,hFig2,des,legendStr)
markA{1}=['-kx';'-gs';'-bp';'-m+';'-rd';'-cv']; %Mser 'Color',[1 0.6 0]
markA{2}=['--kx';'--gs';'--bp';'--m+';'--rd';'--cv']; %Mser 'Color',[1 0.6 0]
markA{3} =['-.kx';'-.gs';'-.bp';'-.m+';'-.rd';'-.cv']; %Mser 'Color',[1 0.6 0]
mark = markA{des};
% mark=['-cv';'-gs';'-m+';'-bp';'-rd';'-kx']; % -- for dashed line
lineWidthVal = 4; MarkerSizeVal = 10; FontSizeVal = 40; %10, 24 and 40

numImages = max(size(score{1}));
xAxis = 1:(numImages);%/3);

if isempty(hFig1) & isempty(hFig2) 
hFig1 = figure;clf;
grid on;
title(datastring,'FontSize',FontSizeVal,'FontWeight','bold');
ylabel(yLabelString1,'FontSize',FontSizeVal,'FontWeight','bold')
xlabel(xlabelString,'FontSize',FontSizeVal,'FontWeight','bold');
figure(hFig1); axis([0.99 numImages 0.99 102]);
hold on;

hFig2 = figure;clf;
grid on;
title(datastring,'FontSize',FontSizeVal,'FontWeight','bold');
ylabel(yLabelString2,'FontSize',FontSizeVal,'FontWeight','bold')
xlabel(xlabelString,'FontSize',FontSizeVal,'FontWeight','bold');
hold on;
legendStr=[];
end


numDetectors = size(score,2);
for i=numDetectors:-1:1
figure(hFig1);  plot(xAxis,score{i},mark(i,:),'Linewidth',lineWidthVal,'MarkerSize',MarkerSizeVal,'MarkerEdgeColor','k'); %'MarkerFaceColor','g'
figure(hFig2);  plot(xAxis,corres{i},mark(i,:),'Linewidth',lineWidthVal,'MarkerSize',MarkerSizeVal,'MarkerEdgeColor','k');
end
% '-d','Color',[1 0.6 0], '-k'

figure(hFig1); 
legendStr = [legendStr ; sprintf('Fast-9  %s',desTypeDet{5});sprintf('Mser    %s',desTypeDet{4});sprintf('Hessian %s',desTypeDet{3});sprintf('Harris  %s',desTypeDet{2});sprintf('CoMiC   %s',desTypeDet{1})];
h_legend= legend(legendStr);%,'Random','Fast-9','Mser','Location','SouthEast'); %legend('CoMIC','Harris1','Harris2','Hessian1','Hessian2','Fast-9','Location','SouthEast');
set(h_legend, 'FontSize',15);%45)
set(gca,'FontWeight','bold','LineWidth',lineWidthVal,'FontSize',FontSizeVal);
savePath = sprintf('../data/graphs-delta%d/%s/',delta,datastring);
if ~exist(savePath,'dir')
  mkdir(savePath);
end

saveas(hFig1,sprintf('%s/%s_%s.jpg',savePath,xlabelString,yLabelString1));
saveas(hFig1,sprintf('%s/%s_%s.fig',savePath,xlabelString,yLabelString1));

figure(hFig2);
% h_legend1 = legend(sprintf('Fast-9 %s',desTypeDet{5}),sprintf('Mser %s',desTypeDet{4}),sprintf('Hessian %s',desTypeDet{3}),sprintf('Harris %s',desTypeDet{2}),sprintf('CoMIC %s',desTypeDet{1}));%,'Random','Fast-9','Mser','Location','SouthEast'); %legend('CoMIC','Harris1','Harris2','Hessian1','Hessian2','Fast-9','Location','SouthEast');
h_legend1 = legend(legendStr);
set(h_legend1, 'FontSize',15);%45)
set(gca,'FontWeight','bold','LineWidth',lineWidthVal,'FontSize',FontSizeVal);
% set(h_legend, 'FontSize',15);%45)
saveas(hFig2,sprintf('%s/%s_%s.jpg',savePath,xlabelString,yLabelString2));
saveas(hFig2,sprintf('%s/%s_%s.fig',savePath,xlabelString,yLabelString2));

end
