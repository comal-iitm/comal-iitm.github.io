function [thetaNormal thetaTangent xMinNew xMaxNew yMinNew yMaxNew] = CalculateDirNormAndTan(boundaryRight,boundaryLeft,getBlockDim,cornerInIter,maskBlock,boundary,xMin,xMax,yMin,yMax)

if nargin < 3
    getBlockDim  = 0;
end

endPt1 = mean(boundaryRight);
endPt2 = mean(boundaryLeft);

polyNew = polyfit([endPt1(2) endPt2(2)],[endPt1(1) endPt2(1)],1); %change one and end

slopeNew = polyNew(1); interceptNew = polyNew(2);

%fprintf('Slope: %f, Intercept: %f\n', slopeNew, interceptNew);

thetaNormal  = atand(slopeNew);
if thetaNormal<0
    thetaNormal=180+thetaNormal;
end
thetaTangent = thetaNormal+90;%theta1 + 90;


if getBlockDim
    sizeIm = size(img);
    figure, imshow(maskBlock,[]), hold on, plot(boundary(:,2),boundary(:,1));
    
    plot(endPt1(2),endPt1(1),'*g'); plot(endPt2(2),endPt2(1),'*g')
    plot(cornerInIter(1), cornerInIter(2),'*b');
    plot(cornerInIter(2), cornerInIter(1),'*b');
    
    multFactor = 2;
    sizeDelPlus1LCSs = 10;% delta is 4 now, so 5*2 pixels for each lcs
    slopeNormal = tand(thetaNormal);
    interceptNormal=cornerInIter(1,2)-slopeNormal*cornerInIter(1,1);
    
    xLeft = (1/multFactor)*xMin:cornerInIter(1); xRight = cornerInIter(1):multFactor*xMax;
    yLeft = polyval([slopeNormal,interceptNormal],xLeft);
    yRight = polyval([slopeNormal,interceptNormal],xRight);
        
    if any(yLeft<0) | any(yRight<0) | any(yLeft(end)>sizeIm(2)) | any(yRight>sizeIm(2)) %check this
        yLeft = (1/multFactor)*yMin:cornerInIter(2); yRight = cornerInIter(2):multFactor*yMax;
        xLeft = polyval([slopeNormal,interceptNormal],yLeft);
        xRight = polyval([slopeNormal,interceptNormal],yRight);
    end
    
    if any(xLeft<0) | any(xRight<0) | any(xLeft(end)>sizeIm(2)) | any(xRight>sizeIm(2)) %check this
        disp('Problemo');    
    end
    
    NormdistFromCorDir1 = [xLeft; yLeft] - repmat(cornerInIter(1:2),length(xLeft),1);
    NormdistFromCorDir2 = [xRight; yRight] - repmat(cornerInIter(1:2),length(xRight),1);
    indDir1 = find(NormdistFromCorDir1>sizeDelPlus1LCSs);
    indDir2 = find(NormdistFromCorDir2>sizeDelPlus1LCSs);
    
    yMax = yLeft(indDir1); yMin = yRight(indDir2); 
    plot([xMin xMax],yMinMax,'r');
    
    %Just include endpoints of the normal
    slopeTangent = tand(thetaTangent);
    interceptTangent=cornerInIter(1,2)-slopeTangent*cornerInIter(1,1);
    
    yMinMax = polyval([slopeTangent,interceptTangent],[xMin xMax]);
    yMin  = yMinMax(1); yMax = yMinMax(2);
    plot([xMin xMax],yMinMax,'r');
    
    yMaxNew = max(cornerInIter(2),yMax); 
    yMinNew = min(cornerInIter(2),yMin);
    xMaxNew = max(cornerInIter(1),xMin);
    xMinNew = min(cornerInIter(1),xMax);
    
end

end