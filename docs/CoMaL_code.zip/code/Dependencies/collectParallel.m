function indInValidMat  = collectParallel(indDup0,indUniquePM2,initCornersMat,scMat,boundaryPartMat,numCores)

% indDup0Div={};
numDiv = ceil(length(indDup0)/numCores);
%fprintf('numDiv: %f\n', numDiv);

indDiv = 1:numDiv:length(indDup0); indDiv(end+1) = length(indDup0);
for a = 2:length(indDiv)
    indDup0Div = indDup0(indDiv(a-1):indDiv(a));
    dupSet={};cornersDup={}; regionsDup={}; indBlockDup={}; boundaryDup={}; circFlagDup={};
    
    for iDup=1:length(indDup0Div)
        dupSet0 = find(indUniquePM2==indDup0Div(iDup));
        dupSet{iDup} = dupSet0 ;
        cornersDup{iDup} = initCornersMat(dupSet0,:);
        scDup{iDup} = scMat(dupSet0);
        boundaryPartDup{iDup} = boundaryPartMat(dupSet0);
    end
    dupSetDiv{a-1} = dupSet;
    cornersDupDiv{a-1} = cornersDup;
    scDupDiv{a-1} = scDup;
    boundaryPartDupDiv{a-1}  = boundaryPartDup; %display only take off later
end

for iD=1:min(numCores,length(cornersDupDiv)) %parfor
    cornersDup = cornersDupDiv{iD};
    indInValid0All =[];
    for i=1:length(cornersDup)
        indInValid0 = checkDupMSER(cornersDupDiv{iD}{i},scDupDiv{iD}{i},boundaryPartDupDiv{iD}{i});
        indInValid0All = [indInValid0All; dupSetDiv{iD}{i}(indInValid0)];
    end
    indInValid{iD} = indInValid0All;
end
indInValidMat = cell2mat(indInValid');
end
