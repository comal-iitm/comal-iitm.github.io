#include <cv.h>
#include <highgui.h>
#include <stdio.h>
#include <iostream>
#include <vector>
#include <list>
#include <algorithm>
#include <sstream>
#include <string>
#include <stdlib.h>
#include <math.h>
#include <map>

using namespace std;
using namespace cv;

class myPoint
{
  public:
	int x, y;
	myPoint();
	myPoint(int x1, int y1);
	void display();
	bool operator<(const myPoint &rhs) const
	{
		 if (y > rhs.y) return false;
		 if (y < rhs.y) return true;
		 if (x < rhs.x) return true;
		 return false;
	}
	void operator=(const myPoint &P)
	{
		x = P.x;
		y = P.y;
	}

	bool operator==(const myPoint &P)
	{
		return (x == P.x && y == P.y);
	}
};

int min(int a, int b);
int max(int a, int b);
int chessDistance(myPoint a, myPoint b);
int manhattanDistance(myPoint a, myPoint b);
