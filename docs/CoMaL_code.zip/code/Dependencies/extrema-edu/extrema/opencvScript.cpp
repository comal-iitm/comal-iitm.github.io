#include "opencvScript.h"

myPoint::myPoint()
{
	x = 0;
	y = 0;
}
myPoint::myPoint(int x1, int y1)
{
	x = x1;
	y = y1;
}

void myPoint::display()
{
	cout << "(" << x << ", " << y << ")" << endl;
}

int min(int a, int b)
{
	    return (a > b)? b:a;
}

int max(int a, int b)
{
	    return (a < b)? b:a;
}

int chessDistance(myPoint a, myPoint b)
{
	    int dx = abs(a.x - b.x);
		    int dy = abs(a.y - b.y);
			    
			    return max(dx, dy);
}

int manhattanDistance(myPoint a, myPoint b)
{
	return abs(a.x - b.x) +abs(a.y - b.y);
}
/*
int main()
{
	char buffer[30000];
	
	FILE* file = fopen("bufferno1078.jpg.extbound", "r");

	while (!(fgets(buffer, 30000, file) == NULL))
	{
		char* pch;
		pch = strtok(buffer, "\n");
		int count_iter = atoi(pch);
		cout << count_iter << endl;
		for(int i=0; i<count_iter; i++)
		{
			//cout << "Here 1" << endl;
			fgets(buffer, 30000, file);
			//cout << "Here 2" << endl;
			pch = strtok(buffer," \n");

			vector<myPoint> points(atoi(pch));
			//cout << "Here 3" << endl;
			cout << atoi(pch) << endl;
			bool isX = true;
			int count = 0;
			//cout << "Here 4" << endl;
			
			list<int> y_list;
			map<int,list<int> > dicto;

			while(pch != NULL)
			{
				//cout << "Here 5" << endl;
				pch = strtok(NULL, " \n");
				if(pch != NULL)
				{
					if(isX)
					{
						points[count].x = atoi(pch);
						isX = !isX;
					}
					else
					{
						points[count].y = atoi(pch);
						isX = !isX;
						points[count].display();
												
						if(dicto.find(points[count].y) == dicto.end())
						{
							list<int> temp;

							y_list.insert(y_list.end(), points[count].y);
							temp.insert(temp.end(), points[count].x);
							dicto[points[count].y] = temp;
						}
						else
						{
							dicto[points[count].y].insert(dicto[points[count].y].end(), points[count].x);
						}
					
						count ++;
					}
				}
					//cout << atoi(pch) << ' ';
			}
			
			for(list<int>::iterator it = y_list.begin(); it != y_list.end(); ++it)
			{
				cout << *it << ": ";
				for(list<int>::iterator it2 = dicto[*it].begin(); it2 != dicto[*it].end(); ++it2)
				{
					cout << *it2 << ' ';
				}
				cout << endl;
			}	
			
			vector<myPoint> new_pts;
			
			myPoint p1, p2[3];
			int dx = 1, dy = 0;
			int j = 0;
			vector<myPoint> histogram_dirs(8);
			vector<int> bestDetails1(8);
			vector<int> bestDetails2(8);
			list<int>::iterator it_begin = y_list.begin();

			while( j >= 0)
			{
				cout << j << endl;
				int start_idx;
				if(-dx == 0 && -dy == -1)
					start_idx = 0;
				else if(-dx == 1 && -dy == -1)
					start_idx = 1;
				else if(-dx == 1 && -dy == 0)
					start_idx = 2;
				else if(-dx == 1 && -dy == 1)
					start_idx = 3;
				else if(-dx == 0 && -dy == 1)
					start_idx = 4;
				else if(-dx == -1 && -dy == 1)
					start_idx = 5;
				else if(-dx == -1 && -dy == 0)
					start_idx = 6;
				else if(-dx == -1 && -dy == -1)
					start_idx = 7;
				
				if(j > 0)
				{
					list<int>::iterator it_prev = it_begin + j - 1;
					for(list<int>::iterator it2 = dicto[*it_prev].begin(); it2 != dicto[*it_prev].end(); ++it2)
					{


				}
				break;
			}
			//cout << endl;
		}
		break;

		//cout << buffer;
	}

	fclose(file);
	return 0;
}
*/
