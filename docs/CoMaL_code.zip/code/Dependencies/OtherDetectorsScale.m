function OtherDetectorsScale(dataset,detType,numPts)
%This file hasn't been tested. Check it the first time.

%Harris
% MSER
%Hessian
% SUSAN
% Shi Tomasi
%DOG
% FAST
%AST?

detectorTypes = ['hr1';'hr2';'hr3';'msr';'hs1';'hs2';'sus';'shi';'dog';'fas';'msr';];
% thresholds = [3.8 0 100];
resizefactor = 1;detectedPtsOther=[];
overErr = 10; scaleMinLim = 3; scaleMaxLim = 8; sxi2 = 13.5;
i=1;
while i<7
    marker = strcmp(detType,detectorTypes(i,:));
    if marker ==1
        detNo = i;
        %         thresh = thresholds(i);
        break;
    end
    i=i+1;
end

dirData = '../images';
if strcmp(dataset,'bike') | strcmp(dataset,'luvn') | strcmp(dataset,'uubc')
    endImgNo = 6;
    ext = 'ppm';
else
    endImgNo = 2;
    ext = 'ppm';
end

for imgno=1:endImgNo
    feat=[];featNew=[];
    commonVar = globalVariables(imgno);
    detectedPtsOther{1} = [];
    
    
    %     imgInd = regexp(Tuples{t,2}, '[0-9]');
    %     imgno =  Tuples{t,2}(imgInd);
    iSz = commonVar.sigSmin(1);
    imgPath = sprintf('%s/%s/img%d.%s',dirData,dataset,imgno,ext);
        
    threshWithPtsFile = 1;
    if str2double(imgno)==1
        useThresh=0; threshHar=0; threshHes=0;
    else
        useThresh=1;
    end
    
    if threshWithPtsFile
        file1=fullfile('..','data','results',sprintf('%s',dataset),sprintf('img%d.harronmser.txt',imgno-1));
        detPts = loadfeatures(file1); numPtsHarrOnMser= size(detPts,2)-450;
    else
        numPtsHarrOnMser = numPts;
    end
    
    detPtsFileOther=fullfile('..','data','results',sprintf('%s',dataset),sprintf('img%d.%s.txt',(imgno)-1,detType));
    detPtsFileOtherDes=fullfile('..','data','results',sprintf('%s',dataset),sprintf('img%d.%sDes.txt',(imgno)-1,detType));
    
    switch detType
        case 'hr3'
            opHarFile = sprintf('../data/results/%s/img%d.%s.txt',dataset,(imgno)-1,detType);
            harFile = sprintf('./detect_points.ln -i %s -mhar -thres 1 -lap -o %s -DR',imgPath,opHarFile); %-lap
            system(harFile);
            
            feat =loadFeatures(opHarFile,1);
            indScaleCommon = find(feat(4,:)<scaleMaxLim & feat(4,:)>scaleMinLim);
            feat = feat(:,indScaleCommon);
            [~,indSort] = sort(-feat(3,:));
            feat = feat(:,indSort);
            if (imgno)==1
                feat = feat(:,1:numPtsHarrOnMser);
                thresh = feat(3,end);                
            else
                indOverThresh = find(feat(3,:)>=thresh);
                feat = feat(:,1:indOverThresh(end));
            end
                        
            sizeFeat = size(feat,2);
            scale = (feat(4,:).*2)';            
            featF = [feat(1:2,:)' scale zeros(sizeFeat,1) scale];
            detectedPtsOther{1} = featF;
            
        case 'hs2'
            opHesFile = sprintf('../data/results/%s/img%d.%s.txt',dataset,(imgno)-1,detType);
            hesFile = sprintf('./detect_points.ln -i %s -mhes -thres 5 -lap -o %s -DR',imgPath,opHesFile); %use some threshold
            system(hesFile);
            feat =loadFeatures(opHesFile,1);            
            indScaleCommon = find(feat(4,:)<scaleMaxLim & feat(4,:)>scaleMinLim);
            feat = feat(:,indScaleCommon);
            [~,indSort] = sort(-feat(3,:));
            feat = feat(:,indSort);
            if (imgno)==1
                feat = feat(:,1:numPtsHarrOnMser);
                thresh = feat(3,end);
                
            else
                indOverThresh = find(feat(3,:)>=thresh);
                feat = feat(:,1:indOverThresh(end));
            end
            
            sizeFeat = size(feat,2);
            scale = (feat(4,:).*2)';            
            featF = [feat(1:2,:)' scale zeros(sizeFeat,1) scale];
            detectedPtsOther{1} = featF;
            
            if 0
                I = imread(imgPath);
                szImage = size(I);
                [FinalFeat f1Init ind select] = overlapCheckOther([featF feat(4,:)'],szImage,overErr);
                detectedPtsOther{1} = FinalFeat;
            end
            
        case 'msr'
            if imgno==1
                numPtsMsr = 0; numPtsIter=0; numPtsWindow = 25; delta=14;
                while (numPtsMsr < numPtsHarrOnMser - numPtsWindow | numPtsMsr > numPtsHarrOnMser + numPtsWindow) & numPtsIter<6
                    mserFile = sprintf('./mser.ln -i %s -mm %d -o %s -t %d',imgPath,delta,detPtsFileOtherDes,2);
                    system(mserFile);
                    feat = loadFeatures(detPtsFileOtherDes);
                    numPtsMsr = size(feat,2);
                    delta = delta - 1;
                    numPtsIter = numPtsIter + 1;                    
                end
                mserFile = sprintf('./mser.ln -i %s -mm %d -o %s -t %d',imgPath,delta,detPtsFileOther,2);
                system(mserFile);                    
                detectedPtsOther{1} = [];
            else
                mserFile = sprintf('./mser.ln -i %s -mm %d -o %s -t %d',imgPath,delta,detPtsFileOtherDes,2);
                system(mserFile);
                mserFile = sprintf('./mser.ln -i %s -mm %d -o %s -t %d',imgPath,delta,detPtsFileOther,2);
                system(mserFile);                
                detectedPtsOther{1} = [];
            end
            
        case 'dog'
            opDogFile = sprintf('../data/results/%s/img%d.%s.txt',dataset,(imgno)-1,detType);
            dogFile = sprintf('./detect_points.ln -i %s -dog -o %s -DR',imgPath,opDogFile);
            system(dogFile);
            feat =loadFeatures(opDogFile,1);
            [~,indSort] = sort(-feat(3,:));
            feat = feat(:,indSort);
            if (imgno)==1
                feat = feat(:,1:numPtsHarrOnMser);
                thresh = feat(3,end);
                
            else
                indOverThresh = find(feat(3,:)>=thresh);
                feat = feat(:,1:indOverThresh(end));
            end
            
            sizeFeat = size(feat,2);
            scale = repmat(sxi2,sizeFeat,1); %feat(1,3)
            featF = [feat(1:2,:)' scale zeros(sizeFeat,1) scale];
            detectedPtsOther{1} = featF;
            
        case 'fas'
            I = imread(imgPath);
            I = rgb2gray(I);
            
            [feat strength] = fast9(I, 20,1); %fast9(I, 30,1);
            [strengthSortd,indSort] = sort(-strength);
            strengthSortd = abs(strengthSortd);
            feat = feat(indSort,:);
            if (imgno)==1
                featNew = feat(1:numPtsHarrOnMser,:);
                thresh = strengthSortd(numPtsHarrOnMser);
            else
                indOverThresh = find(strengthSortd>=thresh);
                if ~isempty(indOverThresh)
                    featNew = feat(1:indOverThresh(end),:);
                end
            end
            
            if ~isempty(featNew)
                sizeFeat = size(featNew,1);
                scale = repmat(sxi2,sizeFeat,1); %feat(1,3)
                featF = [featNew(:,1:2) scale zeros(sizeFeat,1) scale];
                detectedPtsOther{1} = featF;
            end
            
            %needs jpg image as input
            if 0
                opFastFile = sprintf('../data/results/%s/img%d.%s.txt',dataset,(imgno)-1,detType);
                imgPathJpg = sprintf('%s/%s/img%s.jpg',dirData,dataset,imgno);
                fastFile = sprintf('./fast -lst %s %s',imgPathJpg,opFastFile);
                system(fastFile);
                feat =loadFeatures(opFastFile,1);
            end
        case 'fer'
            %result gotten from c code outside
            featNew = dlmread(detPtsFileOther);
            sizeFeat = size(featNew,1);
            scale = repmat(sxi2,sizeFeat,1); %feat(1,3)
            featF = [featNew(:,1:2) scale zeros(sizeFeat,1) scale];
            detectedPtsOther{1} = featF;            
    end
    
    %needed?
    if 0
        if ~isempty(detectedPtsOther{1})
            detectedPtsOtherCleaned = overlapCheckOther(detectedPtsOther{1}',[ysize,xsize],0);
        else
            detectedPtsOtherCleaned =[];
        end
    end
    %                 figure, imshow(imgPath), showellipticfeaturesSPL(detectedPtsOtherCleaned');
    
    if ~isempty(detectedPtsOther{1})
        s1 = size(detectedPtsOther{1},1);
        sizeCol = (1./(detectedPtsOther{1}(:,3).^2)); % works only for single scale: No reason for duplicates to exist for more.        
        detectedPtsOtherFinal = [detectedPtsOther{1}(:,1) detectedPtsOther{1}(:,2) sizeCol zeros(s1,1) sizeCol];
        %     figure, imshow(imgPath), showellipticfeaturesSPL(points);
        I = rgb2gray(imread(imgPath));
        [ysize xsize]  = size(I);
        writeToFileTest(detPtsFileOther,detectedPtsOtherFinal,1,xsize,ysize,0,(imgno),1);
        writeToFileTestForDesc(detPtsFileOtherDes,detectedPtsOtherFinal,1,xsize,ysize,0,(imgno),1);
    else
        fprintf('No point detected');
    end
    
    %The other detector: the executable
    if 0
        system(sprintf('./detect_points.ln -%s -s %d -thres %d -i %s -o %s',detType,iSz/2,thresh(pointtype),imgPath,detPtsFileOther)); %
        system(sprintf('./detect_points.ln -%s -s %d -thres %d -i %s -o %s',detType,iSz/2,threshImg1(pointtype),imgPath,detPtsFileOther)); %
        %to get a certain number of points: sort the third column which has cornerness vals
    end
end

end
