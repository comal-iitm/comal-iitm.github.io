function ThresholdingFromFile

datasets =['bike';'luvn';'uubc'];

for d=1:3
    for imgNo=1:6
        file1 =fullfile('..','data','results',sprintf('%s',datasets{d}),sprintf('img%d.harronmser.txt',imgNo-1));
        detPts = loadfeatures(file1);
        
        combinedStrength = detPts(6,:).*detPts(7,:);
        indFinal = find(combinedStrength>THRESH);
        detectedPts = detPts(:,indFinal);
                
        detPtsFile=fullfile('..','data','results',sprintf('%s',datasets{d}),sprintf('img%d.harronmser.txt',str2num(imgNo)-1));        
        writeToFileTest(detPtsFile,detectedPts,1,xsize,ysize,0);
    end
end

end

%After this just run Repeatability from MAIN with detectors turned off;