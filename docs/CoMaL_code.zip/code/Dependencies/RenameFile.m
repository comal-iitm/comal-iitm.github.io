function RenameFile()

alphabets='a':'z';

for i=1:21
    alph = alphabets(i);
    decVal = 4;
    imgnoStr = getImgnoInStrOrInt(i-1,decVal);
        command = sprintf('mv /media/swarna_nfs/imagesOrigSize/label_02/%s.txt /media/swarna_nfs/imagesOrigSize/car%s/groundtruth.txt',imgnoStr,alph);
%     command = sprintf('mv /media/swarna_nfs/imagesOrigSize/%s /media/swarna_nfs/imagesOrigSize/car%s',imgnoStr,alph);
    system(command);
end