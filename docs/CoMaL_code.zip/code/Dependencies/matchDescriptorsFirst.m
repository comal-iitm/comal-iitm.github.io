function [featMatch1Final featMatch2Final matchFinal overlapPer] = matchDescriptorsFirst(des1,des2,f1,f2,detType,img1,img2,matchesSavePath,overRad)

distThresh = 20; %100
threshSSD = 0.05; %0.05
largeNum = 5000;
des1 = double(des1); des2 = double(des2);
img{1} = img1; img{2} = img2;
szFeat = size(des1,1);
ssdVals = cell(szFeat,1);
match = cell(szFeat,1);
szBlock = sqrt(size(des1,2)/3);
ssdVals =  largeNum*ones(szFeat,1);
matchMat = 100*ones(size(des1,1),size(des2,1));
matchFinal=[];
featMatch1Final=[]; featMatch2Final=[];
for i = 1 : szFeat
    indCloseSSD=[];ssdVal=[];
    idxF1 = IndDetType(detType,i);
    [distVals ,indClose] = closestPt(f1(idxF1,:), f2,1,min(60,size(f2,1)));
    
    numMaxOverlap = round((pi*overRad*overRad)/4);
    distVals0 = closestPt(f1(idxF1,:), f1,1,min(numMaxOverlap,size(f1,1)));
    indOvrLap = find(distVals0 <= overRad);
    overlapPerF(i) = length(indOvrLap)-1;
    
    ind0 = find(distVals < distThresh);
    indClose = indClose(ind0);
    
    if strcmp(detType,'harronmser')
        indCloseBothSides =[2*indClose-1; 2*indClose];
    else
        indCloseBothSides = indClose;
    end
    
    idxF2 = IndDetType(detType,indCloseBothSides);
    try %the detector prolly didn't run correctly. Ignore this error
    des2Close = des2(indCloseBothSides,:);
    catch
        disp(size(des2));
        disp(img2);
    end
    selCutRGBMain = find(des1(i,:));
    
    ssdVal = largeNum*ones(length(indCloseBothSides),1);
    areaDiff = largeNum*ones(length(indCloseBothSides),1);
    if strcmp(detType,'harronmser')
        for des2Ind=1:length(indCloseBothSides)
            selCutRGB = find(des2Close(des2Ind,:));
            minLengthRegion = max(length(selCutRGBMain),length(selCutRGB));
            areaDiffSamp = length(setxor(selCutRGBMain,selCutRGB));
            if areaDiffSamp < 0.6*minLengthRegion
                areaDiff(des2Ind) = areaDiffSamp;
            end
        end
        [areaLeastVal areaLeastInd] = sort(areaDiff); %mean(areaDiff);
        numShifts = 2;
        %         tic;
        for des2LeastInd=1:min(4,length(indCloseBothSides))%
            if areaLeastVal(des2LeastInd) < largeNum %areaLeastVal
                des2Ind = areaLeastInd(des2LeastInd);
                %             des2Ind = areaLeastInd;
                selCutRGB = find(des2Close(des2Ind,:));
                if 1
                    %                     tic;
                    center = [round(f1(idxF1,:)); round(f2(idxF2(des2Ind),:))];
                    ssdVal(des2Ind) = AlignGetSSD3(selCutRGBMain,selCutRGB,img,center, szBlock,numShifts);
                    %                     if ssdVal(des2Ind) < threshSSD %Remove this in final version, results without this is better
                    %                         break;
                    %                     end
                    %                     tt1 = toc;
                    
                else
                    getSSDBlock;
                    %                    tic;
                    [minShiftError minInd]= AlignGetSSD2(des1(i,:),des2Close(des2Ind,:),szBlock,numShifts);
                    %                     selUnion = union(selCutRGBMain,selCutRGB);
                    ssdVal(des2Ind) = minShiftError/size(des1,2); %length(selUnion);
                    %                     t1=toc;
                    if 0 %minInd~=5 %ssdVal(des2Ind) >0.1 && ssdVal(des2Ind) < 0.12 %To determine threshold
                        AlignGetSSD2(des1(i,:),des2Close(des2Ind,:),szBlock,numShifts,1);
                    end
                end
                
                %                 if ssdVal(des2Ind) < threshSSD %Remove this in final version, results without this is better
                %                     break;
                %                                     else
                %                     aa=1;
                %                 end
            end
        end
        %         tt=toc;
        
    else
        %         selCutCommon = 1:numel(selCutRGBMain);
        numShifts = 1;
        for des2Ind=1:length(indCloseBothSides)
            if 0
                center = [round(f1(idxF1,:)); round(f2(idxF2(des2Ind),:))];
                ssdVal(des2Ind)  = AlignGetSSD(selCutCommon,selCutCommon,img,center, szBlock,numShifts); %[ssdVal(des2Ind) shiftErrors]
                %             mid = round(length(shiftErrors)-1)/2 + 1;
                %             ssdVal(des2Ind)  = shiftErrors(mid)/length(selCutCommon);
            else
                minShiftError = AlignGetSSD2(des1(i,:),des2Close(des2Ind,:),szBlock,numShifts);
                %                 I_error = double(imabsdiff(des1(i,:),des2Close(des2Ind,:)))./255;
                ssdVal(des2Ind) = minShiftError/length(selCutRGBMain); %sum(I_error)
                
            end
        end
    end
    
    if 0
        
        des1Emp = zeros(1,szBlock*szBlock*3);
        des2Emp = zeros(1,szBlock*szBlock*3);
        des1Emp(selCutCommon)=des1(i,selCutCommon);
        des2Emp(selCutCommon)=des2Close(des2Ind,selCutCommon);
        
        des1Emp = des1(i,:);
        des2Emp = des2Close(des2Ind,:);
        
        block10 = uint8(reshape(des1Emp,[szBlock szBlock 3]));
        block20 = uint8(reshape(des2Emp,[szBlock szBlock 3]));
        figure, imshow(block10); figure, imshow(block20);
        block1 = rgb2gray(block10); block2 = rgb2gray(block20);
        figure, imshow(block1); figure, imshow(block2);
        %                     [block1 block2] = Align(block1,block2);
        histBlock1 = imhist(block1,nBins);
        histBlock2 = imhist(block2,nBins);
        histDiff = sum(abs(histBlock1 - histBlock2));
        ssdVal(des2Ind) = histDiff;
        %         figure, imshow(img1),showellipticfeaturesSPL(featMatch1);
        %                     figure, imshow(block1); figure, imshow(block2);
    end
    
    
    [ssdVal indCloseSSD] = sort(ssdVal);
    
    if ~isempty(ssdVal)
        if ssdVal(1) < threshSSD %& minInd==i
            indMatch = idxF2(indCloseSSD(1));
            ssdVals(i) = ssdVal(1);
            match{i} = [idxF1 indMatch];
            if ~strcmp(detType,'harronmser')
                matchMat(idxF1,indMatch) = ssdVals(i);
            end
        end
    end
    
    if strcmp(detType,'harronmser')
        if mod(i,2)==0
            if ssdVals(i) < largeNum || ssdVals(i-1) < largeNum
                if ssdVals(i)  >  ssdVals(i-1)
                    matchSide = [match{i-1} 0];
                    minSSD = ssdVals(i-1);
                else
                    matchSide = [match{i} 1];
                    minSSD = ssdVals(i);
                end
                matchFinal = [matchFinal; matchSide];
                matchMat(matchSide(1),matchSide(2)) = minSSD;
            end
        end
    end
end
overlapPer = mean(overlapPerF);

if ~strcmp(detType,'harronmser')
    matchFinal = [cell2mat(match) ssdVals(ssdVals<5000)];
end

if 0 %~isempty(matchFinal)
    matchMatF = zeros(size(des1,1),size(des2,1));
    minVal = 0;
    while 1
        minValNew  = min(min(matchMat));
        if minValNew >= 100
            break;
        end
        [mini minj] = find(matchMat==minValNew);
        matchMat(mini,:) = 100;
        matchMat(:,minj) = 100;
        matchMatF(mini(1),minj(1)) = minValNew;
        minVal = minValNew;
    end
    [fx fy] = find(matchMatF>0);
    [~, del] = setdiff(matchFinal(:,1:2),[fx fy],'rows');
    matchFinal(del,:)=[];
    
    featMatch1Final = f1(matchFinal(:,1),:);
    featMatch2Final = f2(matchFinal(:,2),:);
end

featMatch1Final = f1(matchFinal(:,1),:);
featMatch2Final = f2(matchFinal(:,2),:);
save(matchesSavePath,'matchFinal');

if 0
    figure, imshow(img1), showellipticfeaturesSPL(featMatch1Final);
    figure, imshow(img2), showellipticfeaturesSPL(featMatch2Final);
end

% featAvgMovtOld = 10; featAvgMovtNew = 5;
if 0
    % while featAvgMovtNew > wind*featAvgMovtOld || featAvgMovtNew < (1/wind)*featAvgMovtOld
    featMovt = sum((featMatch1Final(:,1:2) - featMatch2Final(:,1:2)).^2,2);
    %     featAvgMovtOld = featAvgMovtNew;
    featAvgMovt = mean(featMovt);
    featFg  = find(featMovt > 1); % wind = 0.09; wind*featAvgMovt
    featMatch1Final = featMatch1Final(featFg,:);
    featMatch2Final = featMatch2Final(featFg,:);
    matchFinal = matchFinal(featFg,:);
    %     featAvgMovtNew = featAvgMovt;
    % end
end

end


function sc_cost = getbestMatch(des1Eg,des2)

for j=1:size(des2,2)
    %     diff = sqrt(sum((repmat(des1(i,:),size(des2,1),1) - des2).^2,2));        % Computes vector of dot products
    costmat=hist_cost_2(des1Eg,des2{j}); % compute pairwise cost between all shape contexts
    % calculate shape context cost
    [a1,b1]=min(costmat,[],1);
    [a2,b2]=min(costmat,[],2);
    sc_cost(j) =max(mean(a1),mean(a2));
end

end

function idxCorrected = IndDetType(detType,idx)
if strcmp(detType,'harronmser')
    idxCorrected = ceil(idx./2);
else
    idxCorrected = idx;
end

end