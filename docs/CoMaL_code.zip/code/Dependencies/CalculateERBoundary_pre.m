function [aout, fBoundary, circflag] = CalculateERBoundary_pre(extremal, iter, commonVar, corner)

aout = {};
sizeaout = 0;
fBoundary=0;
circflag =0; %bwboundaries gives out complete boundaries only
granularity2 = 1;

[xD, yD] = size(extremal);

% save('extremal.mat', 'extremal');
[boundaryPts, ~, numObjects] = mex_bwboundaries(extremal);

% [boundaryPts, ~, numObjects] = bwboundaries(extremal, 'noholes');

%Gives the boundary pixels and the number of objects

for boundaryParts=1:size(boundaryPts, 1),
    
    if size(boundaryPts{boundaryParts}, 1) > 15
        %fprintf('Boundary size: %d\n', size(boundaryPts{boundaryParts}, 1));

    boundaries={};
    aoutBoundaryPart={}; 
        
    a = boundaryPts{boundaryParts};
    
    if(size(a, 1) == 0)
        break;
    end;
    % For each of the extremal regions at threshold 'k',usually only one,
    % unless you do dilate and erode,a' contains boundary values
    
    numBoundaryPts=size(a,1);
    
    % a(:,1) = granularity2*a(:,1);
    % a(:,2) = granularity2*a(:,2);
    
    rowsEdge = find(a(:,1)==1 | a(:,1)==xD | a(:,2)==1 | a(:,2)==yD); % The border introduced by blocking is irrelevant, it needs to be removed. 
    %check which x and y coord are at the boundary
    
    if isempty(rowsEdge),
        
        circflag=1; %this is a whole MSER.
        boundaries{1} = a;
        
    else
        
        if length(rowsEdge) > 2*(xD+yD)-6,
            
            aa=1;
            
        end;
        
        if length(rowsEdge) < (2*(xD+yD)-6), %Discarding other side- check 2
            
            a = circshift(a, [(-1)*rowsEdge(end) 0]); % Brings the main part of the curve to the center
            rowsEdge = find(a(:,1)==1 | a(:,1)==xD | a(:,2)==1 | a(:,2)==yD);
            % Can also be done using size of initial rowEdge and checking
            % if they are consec vals
            
            if length(rowsEdge) > 1,
                
                rowsEdge = [1; rowsEdge; length(a)];
                validSections = diff(rowsEdge);
                indValidSec = find(validSections>1);
                
                % edgeVals =[];
                
                for iVS = 1:length(indValidSec),
                    
                    indBound = indValidSec(iVS);
                    boundaries{iVS,1} = a(rowsEdge(indBound):rowsEdge(indBound+1), :);
                    % edgeVals =  [edgeVals; a(rowsEdge(edge),:) bound 1; a(rowsEdge(edge+1),:) bound 2];
                
                end
                
            else
                
                a(rowsEdge,:) = [];
                boundaries{1} = a;
                numBoundaryPts = numBoundaryPts-1;
                % disp('Single pixel in boundary')
            
            end
            
        end
        
        circflag=0;
    
    end
    
    for ino=1:length(boundaries),
        
        boundary1 = boundaries{ino};
        numBoundaryPts = size(boundary1, 1);
        
        i=1;
        
        while i<length(boundary1) & (boundary1(i,:) == boundary1(numBoundaryPts,:)),
            % last few points same as first few, remove them
            
            boundary1(numBoundaryPts, :) = [];
            numBoundaryPts = numBoundaryPts-1;
            i = i+1;
        
        end
        
        checkBound = diff(boundary1, 1, 1);
        
        if ~isempty(checkBound),
            
            rowRem = find((checkBound(:, 1) | checkBound(:, 2)) == 0);
                        
            if ~isempty(rowRem),
                
                boundary1(rowRem, :) = [];
                % boundary1(rowRem+1,:) = []; also correct
            
            end;
            % Timing('FindMinCorner',1);
            
            if circflag,
                
                if ~iter,
                    
                    testPos = FindMinCorner_pre(boundary1, circflag, commonVar);
                    
                else
                    
                    [testVal, testPos] = mex_closestPt([corner(2) corner(1)], boundary1, 0);
                    %[testVal, testPos] = closestPt([corner(2) corner(1)], boundary1, 0);
                
                end;
                
                boundary1 = circshift(boundary1, [(-1)*testPos(1, end) 0]);
                % numCons = 5;
                % boundary1 = [boundary1(end-numCons:end,:); boundary1; boundary1(1:numCons,:)];
                % Timing('FindMinCorner',0);
            
            end;
            
            commonVar.displayflag = 0;
            
            if commonVar.displayflag,
                
                close all;
                figure, imshow(extremal), hold on, plot(boundary1(:, 2), boundary1(:, 1), 'g');
                cVal=1;
                
            end
            
            commonVar.displayflag = 0;
            
            %Resampling
            iterResample = 0;
            indmapdummy = 1:1:size(boundary1, 1);
            
            %tic;
            
            if size(boundary1, 1) <= 2
                %fprintf('Size of boundary: %d\n', size(boundary1, 1));
                axresampled = [];
                ayresampled = [];
            else

                [axresampled, ...
                 ayresampled , ...
                 ~, ...
                 indmapdummy, ...
                 resampledBasisDistNorm] = mex_ResampleAffineContour(boundary1(:, 1), ...
                                                                 boundary1(:, 2), ...
                                                                 1, indmapdummy, circflag);
                %fprintf('Exited ResampledAffineContour\n');
                axresampled(end+1) = boundary1(end, 1);
                ayresampled(end+1) = boundary1(end, 2);

                %tt=toc;

                if ~isempty(resampledBasisDistNorm),

                    while ((max(resampledBasisDistNorm)>1.02 || ...
                           min(resampledBasisDistNorm)<0.98) && ...
                           iterResample < 20),

                        %fprintf('Size of axboundary: %d\n', size(axresampled, 1));
                        [axresampled0, ...
                         ayresampled0, ...
                         ~, ...
                         indmapdummy, ...
                         resampledBasisDistNorm] = mex_ResampleAffineContour(axresampled, ...
                                                                         ayresampled, ...
                                                                         1, ...
                                                                         indmapdummy, ...
                                                                         circflag);
                        %fprintf('Exited ResampledAffineContour\n');

                        axresampled0(end+1) = axresampled(end);
                        ayresampled0(end+1) = ayresampled(end);

                        axresampled = axresampled0;
                        ayresampled = ayresampled0;

                        iterResample = iterResample+1;

                        commonVar.displayflag = 0;
                        if commonVar.displayflag,

                            figure, imshow(extremal), hold on,
                            color = rand(1,3);
                            % plot(ayresampled0,axresampled0,'Color',color);
                            % plot(ayresampled,axresampled,'*g');
                            plot(ayresampled, axresampled, 'Color', color);
                            plot(ayresampled(1), axresampled(1), '*', 'Color', color);

                        end

                        commonVar.displayflag = 0;

                    end

                else

                    axresampled=[];
                    ayresampled=[];

                end
            end

            %clear boundary1
            boundary1 = [axresampled ayresampled];
            
            sizeaout = sizeaout + 1;
            aoutBoundaryPart{sizeaout} = boundary1;
            
        end
        
    end
    % end
    
    if ~isempty(aoutBoundaryPart)
        
        aout = cat(2,aout, aoutBoundaryPart);
    
    end
    
    end
end
% granularity2 = oldgranularity2;
%  Timing('CalculateERBoundary',0,stack(2).name);
