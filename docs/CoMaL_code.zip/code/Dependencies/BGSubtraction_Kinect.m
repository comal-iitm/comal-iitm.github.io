function [coordFg coordFgBound] = BGSubtraction_Kinect(maskPath,imgPath,dilVal,imgName)

imageMain = imread(imgPath);
image = double((imageMain));

dilValInit = 3;
numLarge=7;

szFG = size(image);

fgObjFinal0 = imread(maskPath);
fgObjFinal0(fgObjFinal0 ~= 0) = 1;

%% get largest few components
ifDense = 1;
largeComponentsObj = largestConnComp(fgObjFinal0,numLarge,ifDense); %check2,fg
fgObjFinal0 = zeros(szFG(1),szFG(2));
largeComponentsObjAll = cell2mat(largeComponentsObj');
fgObjFinal0(largeComponentsObjAll) = 1;

%% dilate, erode
seInit = strel('disk',dilValInit);
fgObjFinal0 = imdilate(fgObjFinal0,seInit);
fgObjFinal0 = imerode(fgObjFinal0,seInit);

fgObjFinalMain = zeros(szFG(1),szFG(2));
largeComponents = largestConnComp(fgObjFinal0,1); %
fgObjFinalMain(largeComponents{1}) = 1;
indFgObjA = find(fgObjFinalMain);
imgObjFinalA = getColorImgFromMask(indFgObjA,imageMain);

for numDil=1:length(dilVal)
    se = strel('disk',dilVal(numDil));
    fgObjFinal = imdilate(fgObjFinalMain,se);
    [rowFg colFg] = find(fgObjFinal);
    coordFg{numDil} = [colFg rowFg];
end

indFgObj = find(fgObjFinal);
imgObjFinal = getColorImgFromMask(indFgObj,imageMain);
if 0
    imgObjDisp = imresize(imgObjFinal,300/700);
    imwriteSwarna(imgObjDisp,sprintf('../bg/%s/%s',datastring,imgName));
end
%%

if 0
    handColor = [150 140 75];
    diffVals = mean(abs(cluster_mean - repmat(handColor,nColors,1)),2);
    [~,colorDiff] = sort(diffVals,'descend');
    handPrim = indFg(cluster_idx == colorDiff(end));
end

%% boundary

boundFg = bwboundaries(fgObjFinalMain);
fgBoundary = zeros(szFG(1),szFG(2));
for b=1:size(boundFg,1)
    if size(boundFg{b},1) > 100
        boundPixels = (boundFg{b}(:,2)-1).*szFG(1) + boundFg{b}(:,1);
        fgBoundary(boundPixels) = 1;
    end
end

for numDil=1:length(dilVal)
    se = strel('disk',dilVal(numDil));
    fgBoundary = imdilate(fgBoundary,se); %can use bwmorph also but it dilates too much
    [rowFgBound colFgBound] = find(fgBoundary);
    coordFgBound{numDil} = [colFgBound rowFgBound];
end

end

function [imgFinal0 fgFinal] = getColorImgFromMask(indFg,imageMain)

szFG = size(imageMain);
fgFinal = zeros(szFG(1),szFG(2));
imgFinalOneDim = zeros(szFG(1),szFG(2));
imgFinal0 = zeros(szFG(1),szFG(2),3);

for numDim=1:3
    imgOneDim = imageMain(:,:,numDim);
    imgFinalOneDim(indFg) = imgOneDim(indFg);
    imgFinal0(:,:,numDim) = imgFinalOneDim;
end
imgFinal0 = uint8(imgFinal0);

fgFinal(indFg) = 1;
end