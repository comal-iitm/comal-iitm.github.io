function [f f1Corres fNotPres] = stereoKITTI(f1,f2,dispPath,pair,imf1,imf2)
%can be integrated with MiddleBury later

disparity = disparity_read(dispPath);
boundaryParts = im2bw(imread(sprintf('../images/kstr/boundary/boundary%d_%d.png',pair(1),pair(2))));

if 0
dispToSmooth = uint8(imread(dispPath));
dispSmooth = BoundaryGaussianSmoothing_2D(dispToSmooth,2);
dispBin = im2bw(dispToSmooth); outerBoundary = bwconvhull(dispBin);
seBig1 = strel('disk',10); seBig2 = strel('disk',5); seSmall = strel('disk',1);
outerBoundary = imerode(outerBoundary,seBig1);

boundaryParts0 = edge(dispToSmooth,'canny',0.62,1.9); %try some params
boundaryParts = (boundaryParts0 & outerBoundary);

boundaryParts = imdilate(boundaryParts,seBig2);
boundaryParts = imerode(boundaryParts,seSmall);

if 0 %checking
  figure, imshow(boundaryParts); figure, imshow(boundaryParts0); figure, imshow(dispSmooth);
  figure, imshow(imf1); hold on; showellipticfeaturesSPL(f1); figure, imshow(imf2); hold on; showellipticfeaturesSPL(f2);
  figure, imshow(imf1); [x y] = ginput(1);
  otherX = x  - disp(y,x);
  figure, imshow(imf2); hold on, plot(otherX,y,'*');
  
  %     figure, imshow(imf1); hold on; showellipticfeaturesSPL(f1(j,:)); figure, imshow(imf2); hold on; showellipticfeaturesSPL(f2Disp);
  
end
end

f=cell(3,1); f1Corres=cell(3,1); fNotPres=cell(3,1);
f1Round = floor(f1(:,1:2));
indZero = find(f1Round(:,1)==0 | f1Round(:,2)==0);
f1Round(indZero,:)=[];f1(indZero,:)=[];

for j=1:size(f1Round,1)
  toadd = disparity(f1Round(j,2),f1Round(j,1));
  if boundaryParts(f1Round(j,2),f1Round(j,1))== 1%whitePixelVal %midPixelValchange this also!
    if toadd ~=-1
      f2Disp = [f1(j,1) - toadd f1(j,2:end)];
      if f2Disp(1)>0 && f2Disp(2)>0
        f{2}= [f{2} f2Disp'];
        f1Corres{2} = [f1Corres{2} f1(j,:)'];
      else
        fNotPres{2} = [fNotPres{2} f1(j,:)'];
      end
    else
      fNotPres{2} = [fNotPres{2} f1(j,:)'];
    end
    
  else
    
    if toadd ~=-1
      f2Disp = [f1(j,1) - toadd f1(j,2:end)];
      if f2Disp(1)>0 && f2Disp(2)>0
        f{1}= [f{1} f2Disp'];
        f1Corres{1} = [f1Corres{1} f1(j,:)'];
      else
        fNotPres{1} = [fNotPres{1} f1(j,:)'];
      end
    else
      fNotPres{1} = [fNotPres{1} f1(j,:)'];
    end
    
  end
end


f{3} = [f{1} f{2}]; %non boundary, boundary, all
f1Corres{3} = [f1Corres{1} f1Corres{2}];
fNotPres{3} = [fNotPres{1} fNotPres{2}];

if 0
  figure, imshow(imf1), hold on; showellipticfeaturesSPL(f1Corres{3});
  figure, imshow(imf2), hold on; showellipticfeaturesSPL(f{3});
  
  figure, imshow(imf1), hold on; showellipticfeaturesSPL(f1Corres{2}');
  figure, imshow(imf2), hold on; showellipticfeaturesSPL(f{2}');
  figure, imshow(imf2), hold on; showellipticfeaturesSPL(f2);
end

end