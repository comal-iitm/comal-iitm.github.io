function [f f1Corres fNotPres] = fixBoundaryKITTI

imDirData ='../images' ; dataset = 'kstr';
numFrames = 388;
pairsInit = reshape(1:2*numFrames,2,numFrames)';
indStereo = 1:2:numFrames;
pairs = pairsInit(indStereo,:); %pairs(:,2) = pairs(:,2)+1;

for i=1:length(pairs)
    dispPath = sprintf('%s/%s/disp/disp%d_%d.png',imDirData ,dataset,pairs(i,1),pairs(i,2));
    disparity = disparity_read(dispPath);
    dispImg = uint8(imread(dispPath));    
    boundaryParts0 = edge(dispImg,'canny',0.62,1.9); %try some params

    dispBin = im2bw(dispImg);
    outerBoundary = bwconvhull(dispBin);
    seBig1 = strel('disk',10);    outerBoundary = imerode(outerBoundary,seBig1);
    boundaryParts = (boundaryParts0 & outerBoundary);
        
    seBig2 = strel('disk',5); seSmall = strel('disk',1);
    boundaryParts = imdilate(boundaryParts,seBig2);
    boundaryParts = imerode(boundaryParts,seSmall);

    if 0
        figure, imshow(boundaryParts)
    end
    
    if 1
    OImg = disparity;
    segImg=(bwconvhull(OImg)-imclose(edge(bwconvhull(OImg),'canny')|edge(OImg,'canny'),strel('square',10)));
    boundaryParts=boundaryParts - (boundaryParts & imdilate(segImg,strel('disk',4)));
    end
    
    boundaryName = sprintf('%s/%s/boundary/boundary%d_%d.png',imDirData,dataset,pairs(i,1),pairs(i,2));
    imwrite(boundaryParts,boundaryName);

end
