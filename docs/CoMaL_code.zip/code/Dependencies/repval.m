function [POS,IR]=repval(J)

%Initialize in case empty set
IR=[]; POS=[];

[Y,I]=sort(J);
I2=find(diff(Y)==0);
B2=unique([I2(:)',I2(:)'+1]);
[~,~,IR]=unique(Y(B2));

if ~isempty(IR)
    POS=I(B2);
    for i=1:IR(end)
       POS(IR==IR(i));
    end
    %         NR=hist(IR,IR(end));
    
    %         if all(size(v)>1)
    %             RV=B(B3,:); %matrix, sort by rows
    %         else
    %             RV=B(B3);
    %         end
end


%Turn output into column vector
% NR=NR(:);
IR=IR(:); POS=POS(:);
% if ~all(size(v)>1), RV=RV(:); end %Non-matrices

end


%Credit:
%Basic concept of code by J.S. on 7 Dec, 2001 for vectors
%http://www.mathworks.com/matlabcentral/newsreader/view_thread/30051
%Expanded code to include matrices, chars, and cell of strings