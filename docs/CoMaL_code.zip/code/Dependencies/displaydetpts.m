function imfr = displaydetpts(ptsFile,imgPath,resizefactor,ifFig,debug,showStrength) %ptsFile,imgPath,numPts,debug,showStrength
if nargin < 5
    debug=0;
    showStrength=0;
end
imfr =[];
img1 = imread(imgPath);
img1 = imresize(img1,resizefactor,'bilinear');

[f1 s1 dimdesc1]=loadFeatures(ptsFile); f1=f1';

if 0
    [vals,inds] = sort(f1(:,6),'descend');
    equalStrengthAtThresh = find(vals < vals(numPts));
    numPts = equalStrengthAtThresh(1)-1;
    numPts = min(numPts,size(f1,1));
    f1 = f1(inds(1:numPts),:);
end

if ~ifFig
    colorF = repmat([0.8,.3,0.3],size(f1,1),1);        
    imfr  = showellipticfeaturesSPL(f1,colorF,5,0,0,img1);
else
    figure; imshow(img1), hold on
    % plot(f1(:,1),f1(:,2),'*');
    showellipticfeaturesSPL(f1,'k',4)
    showellipticfeaturesSPL(f1,'w',1.5)
end
% showellipticfeaturesSPL(f1);

% showellipticfeaturesSPL(f1);

if showStrength
    f1(:,6) = round(f1(:,6).*100)./100;
    for ii=1:size(f1,1)
        text(f1((ii),1)+3,f1((ii),2)+3,num2str(f1((ii),6)));
    end
    
end

if debug
    file1 = PutImgNumInFileName(file1,'Duplicates',1);
    [f1 s1 dimdesc1]=loadFeatures(file1); f1=f1';
    figure; imshow(img1), hold on
    showellipticfeaturesSPL(f1);
end

if 0
    fname = PutImgNumInFileName(imgPath,no2);
    
    img2=imread(fname);
    img2 = imresize(img2,resizefactor,'bilinear');
    
    file2 = PutImgNumInFileName(ptsFile,no2-1);
    [f2 s2 dimdesc2]=loadFeatures(file2); f2=f2';
    
    figure; imshow(img2), hold on
    showellipticfeaturesSPL(f2);
    
    if debug
        file2 = PutImgNumInFileName(file2,'Duplicates',1);
        [f2 s2 dimdesc2]=loadFeatures(file2); f2=f2';
        figure; imshow(img2), hold on
        showellipticfeaturesSPL(f2);
    end
    
end
end

function [feat nb dim]=loadFeatures(file)
fid = fopen(file, 'r');
dim=fscanf(fid, '%f',1);
if dim==1
    dim=0;
end
nb=fscanf(fid, '%d',1);
feat = fscanf(fid, '%f', [5+dim, inf]);
fclose(fid);
end

%end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
