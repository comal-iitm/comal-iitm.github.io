function test_sfm(dataset)
dataset = 'herz';

commonVar  = globalVariables(1);
boundFilter = 1;
radius = 5;
resizeFactorPts = [3072/1000 2048/700]; 
standardSize = [1000 700];

%Is written only for 2 files as of now, which are img1 and img2
im1 = 'img1.png'; im2 = 'img2.png';
img1 = fullfile('..','images',dataset(1:4),im1); %can make this a param later
img2 = fullfile('..','images',dataset(1:4),im2);
Hom = fullfile('..','images',dataset(1:4),'H1to2p');

datapath = sprintf('../data/results/%s',dataset);

file1 =fullfile(datapath, 'img0.harronmser.txt');
file2 =fullfile(datapath, 'img1.harronmser.txt');
file3 =fullfile(datapath, 'img1from0.harronmser.txt');
file4 =fullfile(datapath, 'img0from1.harronmser.txt');
file5 =fullfile(datapath, 'imgBound1.harronmser.txt');
file6 =fullfile(datapath, 'imgBound0.harronmser.txt');


corresFile1to2 = sprintf('%s/%s.%s.flow.dat',datapath,im1,im2);
corresFile2to1 = sprintf('%s/%s.%s.flow.dat',datapath,im2,im1);

fileCorres1to2 = fopen(corresFile1to2);
fileCorres2to1 = fopen(corresFile2to1);

sizePt1 = fread(fileCorres1to2,4,'uint32');
corres1to2 = fread(fileCorres1to2,'float');
sizePt2 = fread(fileCorres2to1,4,'uint32');
corres2to1 = fread(fileCorres2to1,'float');

fclose(fileCorres1to2); fclose(fileCorres2to1);

corres1to2R = reshape(corres1to2,2,sizePt1(2)*sizePt1(3));
corres2to1R = reshape(corres2to1,2,sizePt2(2)*sizePt2(3));
corres1to2RF{1} = reshape(corres1to2R(1,:),sizePt1(3),sizePt1(2)); corres1to2RF{2} = reshape(corres1to2R(2,:),sizePt1(3),sizePt1(2));
corres2to1RF{1} = reshape(corres2to1R(1,:),sizePt2(3),sizePt2(2)); corres2to1RF{2} = reshape(corres2to1R(2,:),sizePt2(3),sizePt2(2));

%test correspondences
commonVar.displayflag=0;
if commonVar.displayflag;
    figure, imshow(img1);
    [x,y] = ginput(5);
    x = round(x); y = round(y);
    figure, imshow(img2); hold on;
    for i=1:5
        [xRad yRad] = GetPointsWithinRad(x(i),y(i),radius);
        colors = [(0:1/length(xRad):1)' zeros(length(xRad)+1,1) zeros(length(xRad)+1,1)];
        for j=1:length(xRad)
            x2(j) = corres1to2RF{1}(xRad(j),yRad(j));
            y2(j) = corres1to2RF{2}(xRad(j),yRad(j));
            plot(x2,y2,'*','Color',colors(j,:));
        end
    end
    
end

%%
feat1 = loadfeatures(file1);
feat2 = loadfeatures(file2);

scaleFact = sqrt((resizeFactorPts(1)^2 + resizeFactorPts(2)^2)/2);   %Detection of features is done at the standard size of 700X1000, points are resized to the value specified in the groundtruth
feat1(1,:)=feat1(1,:).*resizeFactorPts(1); feat1(2,:)=feat1(2,:).*resizeFactorPts(2);
% feat1(3:5,:)=feat1(3:5,:)./(scaleFact*scaleFact);
feat2(1,:)=feat2(1,:).*resizeFactorPts(1); feat2(2,:)=feat2(2,:).*resizeFactorPts(2);
% feat2(3:5,:)=feat2(3:5,:)./(scaleFact*scaleFact);

featR1(1:2,:) = round(feat1(1:2,:));
featR2(1:2,:) = round(feat2(1:2,:));

for i=1:size(feat1,2)
    featCorresp2(i,1) = corres1to2RF{1}(featR1(1,i),featR1(2,i));
    featCorresp2(i,2) = corres1to2RF{2}(featR1(1,i),featR1(2,i));
end

for i=1:size(feat2,2)
    featCorresp1(i,1) = corres2to1RF{1}(featR2(1,i),featR2(2,i));
    featCorresp1(i,2) = corres2to1RF{2}(featR2(1,i),featR2(2,i));
end

featCorresp1(:,1)=featCorresp1(:,1)./resizeFactorPts(1); featCorresp1(:,2)=featCorresp1(:,2)./resizeFactorPts(2);
featCorresp2(:,1)=featCorresp2(:,1)./resizeFactorPts(1); featCorresp2(:,2)=featCorresp2(:,2)./resizeFactorPts(2);
featCorresp2(:,3:7) = feat1(3:end,:)';
featCorresp1(:,3:7) = feat2(3:end,:)';
writeToFileTest(file3,featCorresp2,1,standardSize(1),standardSize(1),0,2); %last param is img number
writeToFileTest(file4,featCorresp1,1,standardSize(1),standardSize(1),0,1);

%%

% display
commonVar.displayflag=0;
if commonVar.displayflag;
    feat1Orig = loadfeatures(file1);
    feat2Orig = loadfeatures(file2);

    figure, imshow(imread(img1));
    showellipticfeaturesSPL(feat1Orig');
    
    figure, imshow(imread(img2));
    showellipticfeaturesSPL(feat2Orig');
    
    figure, imshow(imread(img2));
    showellipticfeaturesSPL(featCorresp2);
    
    figure, imshow(imread(img1));
    showellipticfeaturesSPL(featCorresp1);
end
%%
if 1
    imgNo=1; %used in globalVariables scaleFactor function
    
    %check the order to be used
    [~,~,~,~,~,~,twout,wout,featTest1,featTest2,strength1,strength2,cornerness1,cornerness2]= repeatabilityHarronMser(file2,file3,Hom,img1,img2, 1,1,imgNo,1);
    [~,~,~,~,~,~,twout,wout,featTest1,featTest2,strength1,strength2,cornerness1,cornerness2]= repeatabilityHarronMser(file1,file4,Hom,img1,img2, 1,1,imgNo,1);
    
    repeatability(file2,file3,Hom,img1,img2, 1);
end

if commonVar.displayflag;
    [match2,match1] = find(wout<=40);% ((wout<=10 | wout>=40) & wout<100); % find (wout>=10 & wout<=40) ;
    nonMatch2 = setdiff(1:size(wout,1),match2);
    figure; imshow(imresize(imread(img2),resizefactor)); hold on, showellipticfeaturesSPL(featTest2(:,nonMatch2)',[1 1 0]); %match2 for other conditions
    
    figure; imshow(imresize(imread(img2),resizefactor)); hold on, showellipticfeaturesSPL(featTest1(:,match1)',[1 1 0]);
    figure; imshow(imresize(imread(img2),resizefactor)); hold on, showellipticfeaturesSPL(featTest2(:,match2)',[1 1 0]);
    
    for ii=1:size(match2,1)
        text(featTest2(1,match2(ii))+3,featTest2(2,match2(ii))+3,num2str(wout(match2(ii),match1(ii))));
    end
    
    figure; imshow(imresize(imread(img2),resizefactor)); hold on, showellipticfeaturesSPL(featTest1',[1 1 0]);
    figure; imshow(imresize(imread(img2),resizefactor)); hold on, showellipticfeaturesSPL(featTest2',[1 1 0]);
end

%%
% Boundary filtering
if boundFilter
    boundPartFile1 = sprintf('%s/%s.%s.vis.png',datapath,im1,im2);
    boundPartFile2 = sprintf('%s/%s.%s.vis.png',datapath,im2,im1);
    imBound1 = imread(boundPartFile1);
    imBound2 = imread(boundPartFile2);
    
    featR1(3:7,:) = feat1(3:end,:); featR2(3:7,:) = feat2(3:end,:);
    [featCorrespBound2 featInRed1] = FeatOnBound(featR1,imBound1,corres1to2RF); %this just gives an empty file and is useless now
    [featCorrespBound1 featInRed2] = FeatOnBound(featR2,imBound2,corres2to1RF);
    
    commonVar.displayflag=0;
    if commonVar.displayflag;
        figure, imshow(imBound1);hold on;
        plot(featInRed1(:,1),featInRed1(:,2),'*');
        
        figure, imshow(imBound2);hold on;
        plot(featInRed2(:,1),featInRed2(:,2),'*');
    end
    
    imgToBeTransferred =  imBound1; imgTransferred = img2; correspondences = corres1to2RF;
    imBound2Dilated = MapBoundary(imgToBeTransferred,imgTransferred,correspondences);
    imBound1Dilated = MapBoundary(imBound2,img1,corres2to1RF);
    
    [featCorrespBound2 featInRed1] = FeatOnBound(featR1,imBound1Dilated,corres1to2RF);
    [featCorrespBound1 featInRed2] = FeatOnBound(featR2,imBound2Dilated,corres2to1RF);
    
    if commonVar.displayflag;
        figure, imshow(imBound2Dilated);hold on;
        plot(featInRed2(:,1),featInRed2(:,2),'*');
        figure, imshow(img1), hold on;
        showellipticfeaturesSPL(featCorrespBound1);
        
        figure, imshow(imBound1Dilated);hold on;
        plot(featInRed1(:,1),featInRed1(:,2),'*');
        figure, imshow(img2), hold on;
        showellipticfeaturesSPL(featCorrespBound2);
    end
    
    
    %Right now, the points in the boundary of one image is being compared to ALL those in the second. Another thing that can be done
    % is to compare it only with those on the corresponding boundary points of the second.
    
    %%
    %mapping boundary pixels to original img
    commonVar.displayflag=1;
    if commonVar.displayflag;
        countCorres = 0;
        ptsRad = GetPointsWithinRad(featCorrespBound2(:,1),featCorrespBound2(:,2),radius,featCorrespBound2(:,3:end));
        matchedPtsList = repeatabilityHarrOnMserSFM(featCorrespBound2,ptsRad,feat1,[sizePt1(3) sizePt1(2)],commonVar.overErr); %cornersBlockMatOrigForm if needed
        countCorres = countCorres + ifFound;
        rep = countCorres/size(featCorrespBound2,2);
        
        imgNo=2;
        writeToFileTest(file5,featCorrespBound2,1,sizePtR2(3),sizePtR2(2),0,2);
        %         writeToFileTest(file6,featCorrespBound1,1,sizePtR1(3),sizePtR1(2),0,1)
        
        %if any one of it is within 40% rep, then say cool, it's a correspondence
    end
    
    % display
    commonVar.displayflag=0;
    if commonVar.displayflag;
        figure, imshow(imresize(imread(img1),resizefactor));
        showellipticfeaturesSPL(feat1');
        
        figure, imshow(imresize(imread(img2),resizefactor));
        showellipticfeaturesSPL(feat2');
        
        figure, imshow(imBound2);showellipticfeaturesSPL(featCorrespBound2);
        figure, imshow(imBound1);showellipticfeaturesSPL(featCorrespBound1);
        
        figure, imshow(imBound2); hold on, plot(feat2InRed(:,1),feat2InRed(:,2),'*');
        figure, imshow(imBound1); hold on, plot(feat1InRed(:,1),feat1InRed(:,2),'*');
    end
    %%
    
    [~,~,~,~,~,~,twout,wout,featTest1,featTest2,strength1,strength2,cornerness1,cornerness2]= repeatabilityHarronMser(file2,file5,Hom,img1,img2, 1,resizeFactor,imgNo,1);
    [~,~,~,~,~,~,twout,wout,featTest1,featTest2,strength1,strength2,cornerness1,cornerness2]= repeatabilityHarronMser(file1,file6,Hom,img1,img2, 1,resizeFactor,imgNo,1);
end
end


function imgBoundTransferredDilated = MapBoundary(imgToBeTransferred,imgTransferred,correspondences)

featCorrespBoundX=[]; featCorrespBoundY=[];
imgBoundTransferred = imread(imgTransferred);
[szX szY dummy] = size(imgBoundTransferred);

se = strel('ball',10,10);
imgToBeTransferredDilated = imdilate(imgToBeTransferred,se);
[yBound xBound] = find(imgToBeTransferredDilated(:,:,1)==255);
%dilated
for i=1:length(xBound)
    featCorrespBoundY = correspondences{1}(xBound(i),yBound(i));
    featCorrespBoundX = correspondences{2}(xBound(i),yBound(i));
    featCorrespBoundY = round(featCorrespBoundY);
    featCorrespBoundX = round(featCorrespBoundX);
    if (featCorrespBoundX>0 & featCorrespBoundY>0 & featCorrespBoundX<szX & featCorrespBoundY<szY)
        imgBoundTransferred(featCorrespBoundX,featCorrespBoundY,1) = 255;
        imgBoundTransferred(featCorrespBoundX,featCorrespBoundY,2) = 0;
        imgBoundTransferred(featCorrespBoundX,featCorrespBoundY,3) = 0;
    end
end
imgBoundTransferredDilated = imdilate(imgBoundTransferred,se);
end


function [featCorrespBound featInRed] = FeatOnBound(feat2bTrans,imBound2bTrans,correspondences)

featCorrespBoundX=[]; featCorrespBoundY=[]; featInRed=[];
featCorrespBoundExtra = [];
for i=1:size(feat2bTrans,2)
    if imBound2bTrans(feat2bTrans(2,i),feat2bTrans(1,i),1)==255 %& imBound2bTrans(feat2bTrans(2,i),feat2bTrans(1,i),2)==0 & imBound2bTrans(feat2bTrans(2,i),feat2bTrans(1,i),3)==0
        featCorrespBoundX = [featCorrespBoundX correspondences{1}(feat2bTrans(1,i),feat2bTrans(2,i))];
        featCorrespBoundY = [featCorrespBoundY correspondences{2}(feat2bTrans(1,i),feat2bTrans(2,i))]; %points on boundary in corresponding image
        featCorrespBoundExtra = [featCorrespBoundExtra; feat2bTrans(3:end,i)'];
        featInRed = [featInRed; feat2bTrans(1:2,i)']; %points on boundary in that image
    end
end
indPositive = find(featCorrespBoundX>0 & featCorrespBoundY > 0);
featCorrespBoundX = featCorrespBoundX(indPositive); featCorrespBoundY = featCorrespBoundY(indPositive);
featCorrespBoundExtra = featCorrespBoundExtra(indPositive,:);
featCorrespBound = [featCorrespBoundX' featCorrespBoundY' featCorrespBoundExtra];
end
