function [matchingScoreNFrames numMatchesNFrames matching_score nb_of_matches isValid vidObj] = matchesOverNFrames(dataset,detType,numFrames,frameTuple,delta,ifmscore,matchTypeStr,fgTypeCompB,featFG,vidObj)

numMatchesNFrames=[0 0 0]; matchingScoreNFrames=[0 0 0]; nb_of_matches = zeros(1,numFrames-1); matching_score=zeros(1,numFrames-1);

%% Checking if groundtruth car even exists in the frame
imgDirPath = sprintf('../images/%s',dataset);
gtPath = sprintf('%s/groundtruth.mat',imgDirPath);
gt = load(gtPath); isValid=1;
for fr=1:length(frameTuple)
  groundtruth = gt.tracklets{frameTuple(1)};
  if isempty(groundtruth)
    isValid= isValid | 0;
  end
end
%% open file 1
ifgetFeat = [1 0];
[~,~,matchFinal, flagFileFault1, feat1] = getFeatFromMatch(dataset,detType,frameTuple(1:2),delta,matchTypeStr,fgTypeCompB,ifgetFeat);
if ~flagFileFault1
  matchP = matchFinal(:,2);
  together = matchFinal(:,1:2);
  
  if ifmscore
    %   set ifgetFeat = [1 1];
    nb_of_matches(1) = unique(matchP);%size(matchFinal,1);
    matching_score(1) = (nb_of_matches(1)/size(feat2,2))*100; %We check that given point in the first image, does it occur in the second. Different from calculation for mosaicing in oxford, where it is reverse
  end

%% some display
if 0
  color = rand(size(featMatch,2),3); colorF = color;
  for frD=2:3;
    ptFile = sprintf('../data/results/feat-delta%d/%s/img%d.%s.txt',delta,dataset,frameTuple(frD)-1,detType);
    dilVal = 4;    dSetNo = getParamsAndDataset(dataset); frStr = getImgnoInStrOrInt(frameTuple(frD),dSetNo);
    imgPath = sprintf('../images/%s/img%s.ppm',dataset,frStr);
    img = imread(imgPath); feat = loadFeatures(ptFile); %subtraction has to be done here before display
    featMatch = feat(:,m2.matchFinal(:,frD-1));
    figure,imshow(img); hold on; showellipticfeaturesSPL(featMatch',colorF,5,0,1,img);
    text(featMatch(1,:)+3,featMatch(2,:)+3,num2str(m2.matchFinal(:,frD-1)),'FontSize',10,'Color','w')
  end
end

%% main matching
for fr=2:numFrames-1
  if fr==numFrames-1
    ifgetFeat = [0 1];
  else
    ifgetFeat = [0 0];
  end
  [~,~,matchFinal, flagFileFault2,~,feat2] = getFeatFromMatch(dataset,detType,frameTuple(fr:fr+1),delta,matchTypeStr,fgTypeCompB,ifgetFeat);
  if ~flagFileFault2
    matchN = matchFinal(:,1);
    
    maxFeatNo = max([matchP; matchN]);
    withMissingInN = zeros(maxFeatNo,1); side = zeros(maxFeatNo,1); 
    withMissingInN(matchN) = matchFinal(:,2); %map from matchNext-matchesFrameNext with missing
        
    matchP1 = zeros(size(together,1),1); %matchP1 has zeros for elements that are not detected in the following images. It is to maintain the tracks.
    indPNonZero = find(matchP~=0);
    matchP = matchP(indPNonZero);
    matchP1(indPNonZero) = withMissingInN(matchP); %indices of matchP and matchN similar. Include stuff coming twice.
    together = [together matchP1];    
    
    if strcmp(detType,'harronmser')
      side(matchN) = matchFinal(:,3); 
      sideEnd = zeros(size(together,1),1);
      sideEnd(indPNonZero) = side(matchP); 
    end
    
    matchP = matchP1; %(matchP1~=0);
    if ifmscore
      %   set ifgetFeat = [1 1];
      nb_of_matches(fr) = unique(matchN);%size(matchFinal,1);
      matching_score(fr) = (nb_of_matches(fr)/size(feat2,2))*100; %We check that given point in the first image, does it occur in the second. Different from calculation for mosaicing in oxford, where it is reverse
    end
  end
end
if size(together,2)==numFrames
indTrack = find(together(:,end)~=0);
lastPt = together(indTrack,end);
firstPt = together(indTrack,1);
if strcmp(detType,'harronmser')
sideEnd =sideEnd(indTrack);
else
sideEnd =[];  
end
%% displacement check
if ~strcmp(matchTypeStr,'_displ')
  numMatchesNFrames(1) = length(unique(lastPt));%change this
  % matchingScoreNFrames = numMatchesNFrames/size(together,1)*100; %could divide by initial detected points (before matching)
else
  featMatch1 = feat1(:,firstPt); featMatch2 = feat2(:,lastPt);
  matchesFull = [firstPt lastPt sideEnd]; frameTuple2 = [frameTuple(1) frameTuple(end)]; 
  dilVal=10; deltaDisp = 25; %for 5 frames
  matchFinal = compareDispl(featMatch1,featMatch2,matchesFull,frameTuple2,dataset,dilVal,deltaDisp);
  numMatchesNFrames(1) = length(unique(matchFinal(:,2:end),'rows')); %incorporate 3rd side and make (2:3),'rows'
  %needs proper uniquing
end

%% score calculation
matchingScoreNFrames = (numMatchesNFrames./size(feat2,2))*100; %feat2 is the features in the last of the frame of the set
end
end
%% dunno what
if 0
  ptFile = sprintf('../data/results/feat-delta%d/%s/img%d.%s.txt',delta,dataset,frameTuple(1)-1,detType);
  f1= loadFeatures(ptFile); %subtraction has to be done here before display
  dSetNo = getParamsAndDataset(dataset);
  imgnoStr1 = getImgnoInStrOrInt(frameTuple(1),dSetNo); %imgnoStr2 = getImgnoInStrOrInt(im+1,dSetNo);
  fgTypeB = 'full';dilvalCompB=4;[~,coordFg1 coordFgBound1] = getBgSubtractedFeat([], dataset, imgnoStr1,dilvalCompB,fgTypeB);
  xyCoord0 = round(f1(1:2,:))';indValid0 = ismember(xyCoord0,coordFg1{1},'rows');featFG = find(indValid0);
end

dSetNo = getParamsAndDataset(dataset);

%% separating detections at boundary
if dSetNo==1
  if featFG(frameTuple(1))>0
    indFeatPres=1;
    delta=5;dilvalCompB=4;
    [~, numMatchesNFrames(1), numMatchesNFrames(2), numMatchesNFrames(3)] = boundNonMatches2(frameTuple(end),dataset,delta,dilvalCompB,detType,together(:,end));
    [~, numInit(1), numInit(2), numInit(3)] = boundNonMatches2(frameTuple(1),dataset,delta,dilvalCompB,detType,[]);
    
    matchingScoreNFrames = (numMatchesNFrames./numInit)*100;%size(f1,2)*100; %could divide by initial detected points (before matching)
    
  else
    indFeatPres=0;
  end
end

%% Recording video

if 0 %numFrames==5 %|| numFrames==20 %can look into tuning/refining this
  %check ones that are setdiff with this, together(indTrack)
  indTrackPassNFail{1} = find(together(:,end)~=0);
  indTrackPassNFail{2} = find(together(:,end)==0);
  savePath = sprintf('../data/figs-delta%d/%s',delta,dataset);
  if ~exist(savePath,'dir')
    mkdir(savePath);
  end
  for indType = 1%:2
    close all;
    indTrack = indTrackPassNFail{indType};
    togetherValid = together(indTrack,:);
    color = rand(size(togetherValid,1),3);
    movName = sprintf('%s/match%s_%s.avi',savePath,detType,fgTypeCompB); %movName = sprintf('%s/match%s_%s_%d_%d.avi',savePath,detType,fgTypeCompB,frameTuple(fr+1),indType);
    if isempty(vidObj)
      vidObj = VideoWriter(movName);
      open(vidObj);
    end
    
    for fr = 1:numFrames
      ptFile = sprintf('../data/results/feat-delta%d/%s/img%d.%s.txt',delta,dataset,frameTuple(fr)-1,detType);
      feat = loadFeatures(ptFile); %subtraction has to be done here before display
      dilVal = 4;
      %            [indValidFg coordFg] = getValidIndInFgBB(feat',dataset,imgno,dSetNo,dilVal,fgType);
      
      %             [feat indUnique1 indValid1] = getBgSubtractedFeat(dataset, detType,frameTuple(fr),decVal,feat,dilVal);
      
      %             if ~ifOtherDatasets
      %                 [featSub indUnique indValid] = getBgSubtractedFeat(dataset, detType,imgno,decVal,feat(1:2,:),dilVal);
      %                 feat = feat(:,indUnique);
      %             else
      %
      %                 [featSub indValid] = getFgBB(feat',imgnoStr,dataset,dilVal);
      %
      %             end
      dSetNo = getParamsAndDataset(dataset);
      frStr = getImgnoInStrOrInt(frameTuple(fr),dSetNo);
      imgPath = sprintf('../images/%s/img%s.ppm',dataset,frStr);
      img = imread(imgPath);
      indMatchesFr = togetherValid(:,fr);
      indValid = find(indMatchesFr);
      indMatchesFr = indMatchesFr(indValid);
      featMatch = feat(:,indMatchesFr);
      colorF = color(indValid,:);
      if 0
        hFig1 = figure; imshow(img), hold on, showellipticfeaturesSPL(featMatch',colorF);
        %                 if fr==1
        %                     text(40,40,'Detecting ...','FontSize',60,'Color','w','FontWeight','bold');
        %                 end
        imfr = getframe(gca); %# create movie
        %                 close(gcf);
        
      else
        if 0, figure, imshow(img); hold on; imfr  = showellipticfeaturesSPL(featMatch',colorF,5,0,1,img); end
        imfr  = showellipticfeaturesSPL(featMatch',colorF,5,0,0,img);
        if fr==1
          imfr(20:70,20:150,:)=255;
        end
      end
      if 1
        writeVideo(vidObj,imfr); % %         mpgwrite(mov,C,movName,[1, 0, 1, 0, 10, 1, 1, 1]);winopen(movName.avi)
      end
    end
    
  end
  %     myDisplayDetPtsOuter(dataset,frameTuple,detType);
end

end