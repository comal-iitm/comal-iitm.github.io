function imNew = GetBGFromVideo(dataset,numFrames,ifOtherDatasets)
dirData = '../images';
%manually determine widely separated images:
if ~exist('ifOtherDatasets','var')
    ifOtherDatasets = 0;
end

if ifOtherDatasets
    decVal =4;
else
    decVal =3; 
end

switch dataset
    case {'hous','pens','race','stnd'}
        frac1 = 0.5; frac2 = 0.5;
        imgnoStart=1;
        imgnoEnd = round(frac1*numFrames);
        
    case {'boxx'}
        frac2 = 0.65;
        imgnoStart=1;
        imgnoEnd = 170; %round(frac1*numFrames); 
        
    case {'jto2','jtoy','hero'}
        frac2 = 0.6;
        imgnoStart=1;
        imgnoEnd = 285; %round(frac1*numFrames); 
    
    case 'doll'
        frac2 = 0.5;
        imgnoStart = 400; %round(frac1*numFrames);
        imgnoEnd=1;
    case {'elph'}
        frac1 = 0.5; frac2 = 0.5;
        imgnoStart=1;
        imgnoEnd = 130; %round(frac1*numFrames);
end


imgnoStrStart = getImgnoInStrOrInt(imgnoStart,decVal);
imgnoStrEnd = getImgnoInStrOrInt(imgnoEnd,decVal);

im1 = imread(sprintf('%s/%s/img%s.ppm',dirData,dataset,imgnoStrStart));
im2 = imread(sprintf('%s/%s/img%s.ppm',dirData,dataset,imgnoStrEnd));
[imX imY dummy] = size(im1);
imCut = round(frac2*imY);
imNew = [im1(:,1:imCut,:) im2(:,imCut+1:end,:)];
% figure,imshow(imNew);
imwriteSwarna(imNew,sprintf('../bg/%s/imgB1.ppm',dataset));

end