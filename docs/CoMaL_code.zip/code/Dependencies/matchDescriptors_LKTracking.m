function [featMatch1Final featMatch2Final matchFinal featMatch1 featMatch2] = matchDescriptors(des1,des2,f1,f2,detType,img1,img2)

% featMatch1=[]; featMatch2=[];
debug = 0;
% match=[];
% ssdVals=[];
distThresh = 20;
nBins = 15;
ovThresh = 150; %85
ssd=1;
% matchMat = 10000*ones(size(des1,2),size(des2,2));
des1 = double(des1); des2 = double(des2);
matchMat=[];
%Use this if you are searching for a match in a neighbourhood
% f1=f1'; f2=f2'; Gaussian weighting

% debugNonMatchingPts(f1,f2,des1,des2,img1,img2)

for i = 1 : size(des1,1)
    indCloseSSD=[];ssdVal=[];
    if strcmp(detType,'harronmser')
        idxF1 =  ceil(i/2);
    else
        idxF1 = i;
    end
    [distVals ,indClose] = closestPt(f1(idxF1,:), f2,1,min(60,size(f2,1)));
    
    ind0 = find(distVals < distThresh);
    indClose = indClose(ind0);
    
    if strcmp(detType,'harronmser')
        threshSSD = 95;
        indCloseBothSides =[2*indClose-1; 2*indClose];
        des2Close = des2(indCloseBothSides,:);
        selCutRGBMain = find(des1(i,:));
        if 0
            %             aa(1) = find(indCloseBothSides==(2*indF2(1)-1)) ;
            %             aa(2) = find(indCloseBothSides==(2*indF2(1))) ;
        end
        ssdVal=[];
        for des2Ind=1:length(indCloseBothSides)
            selCutRGB = find(des2Close(des2Ind,:));
            selCutCommon = intersect(selCutRGBMain,selCutRGB);
            minLengthRegion = max(length(selCutRGBMain),length(selCutRGB));
            %first use histogram to prune out the best few and do grad
            %descent for those alone.
            if length(selCutCommon) > 0.5*minLengthRegion
                [ssdVal0,ind,distval] = closestPt(des1(i,selCutCommon), des2Close(des2Ind,selCutCommon),1,1,length(selCutCommon),ssd);
                szBlock = (sqrt(size(des1,2)/3)-1)/2;
                
                image1 = double(rgb2gray(imread(img1)))*(1/255);%
                image2 = double(rgb2gray(imread(img2)))*(1/255);%*(1/255)
%                 figure, imshow(image1);
                
                center1 = round(f1(idxF1,:));
                center2 = round(f2(ceil(indCloseBothSides(des2Ind)/2),:));
                TemplateData(1).p=[0 0 0 0 center2(2) center2(1)];
                TempPos1(1,1) = center1(2) - szBlock; TempPos1(1,2) = center1(2) + szBlock;
                TempPos1(2,1) = center1(1) - szBlock; TempPos1(2,2) = center1(1) + szBlock;
                TemplateData(1).image=image1(TempPos1(1,1):TempPos1(1,2),TempPos1(2,1):TempPos1(2,2),:);
                                
                % LK Tracking Options (other options default)
                Options.TranslationIterations=30;
                Options.AffineIterations=0;
                Options.RoughSigma=3;
                Options.FineSigma=1.5;
                
                selCutCommonGray = selCutCommon(selCutCommon<=(2*szBlock+1)*(2*szBlock+1));
%                 [TemplateData(1).p,ROIimage,T_error(i,1)]=LucasKanadeAffine(image2,TemplateData(1).p,TemplateData(1).image,Options,selCutCommonGray);
%                 figure, imshow(image1), hold on, plot(center1(1),center1(2),'*');
%                 figure, imshow(image2), hold on, plot(TemplateData(1).p(6),TemplateData(1).p(5),'*');
%                 
                meanIntensity = sum([des1(i,selCutCommon) des2Close(des2Ind,selCutCommon)])/(2*length(selCutCommon));
                ssdVal(des2Ind) = sqrt(ssdVal0/length(selCutCommon)); %*(length(selCutCommon)/minLengthRegion); %1 - length(selCutCommon)/maxLengthRegion;
                if 0
                    szBlock = sqrt(size(des1,2)/3);
                    des1Emp = zeros(1,szBlock*szBlock*3);
                    des2Emp = zeros(1,szBlock*szBlock*3);
                    des1Emp(selCutCommon)=des1(i,selCutCommon);
                    des2Emp(selCutCommon)=des2Close(des2Ind,selCutCommon);
                    block10 = uint8(reshape(des1Emp,[szBlock szBlock 3]));
                    block20 = uint8(reshape(des2Emp,[szBlock szBlock 3]));
                    block1 = rgb2gray(block10); block2 = rgb2gray(block20);
                    histBlock1 = imhist(block1,nBins);
                    histBlock2 = imhist(block2,nBins);
                    histDiff = sum(abs(histBlock1 - histBlock2));
                    ssdVal(des2Ind) = histDiff;
                    %         figure, imshow(img1),showellipticfeaturesSPL(featMatch1);
                    %                     figure, imshow(block1); figure, imshow(block2);
                end
            else
                ssdVal(des2Ind) = 5000;
            end
        end
        [ssdVal indCloseSSD] = sort(ssdVal);
        indCloseFinal = indCloseBothSides;
    else
        threshSSD = 25;
        des2Close = des2(indClose,:);
        szDes2Close = size(des2Close,1);
        [ssdVal,indCloseSSD] = closestPt(des1(i,:), des2Close,1,min(20,szDes2Close),size(des1,2),ssd);
        meanIntensity = mean([repmat(des1(i,:),length(indCloseSSD),1) des2Close(indCloseSSD,:)],2);
        
        ssdVal= sqrt(ssdVal);%/size(des1,1));
        [ssdVal indSortd] = sort(ssdVal);
        indCloseSSD = indCloseSSD(indSortd);
        indCloseFinal = indClose;
        
        if 0
            szBlock = sqrt(size(des1,2)/3);
            block1 = uint8(reshape(des1(i,:),[szBlock szBlock 3]));
            block2 = uint8(reshape(des2Close(indCloseSSD(2),:),[szBlock szBlock 3]));
            figure, imshow(block1); figure, imshow(block2);
        end
    end
    
    %     szBlock = sqrt(size(des1,2)/3);
    if ~isempty(ssdVal)
        if ssdVal(1) < threshSSD %& minInd2==i
            indMatch = indCloseFinal(indCloseSSD(1));
            ssdVals{i} = ssdVal(1);
            %         featMatch1{i} = f1(ceil(i/2),:);
            %         featMatch2{i} = f2(ceil(indMatch/2),:);
            match{i} = [i indMatch];
        else
            ssdVals{i} = [];
            match{i} = [];
        end
    else
        ssdVals{i} = [];
        match{i} = [];
    end
    
    if 0 %debug
        idx1 = i; %i;
        idx2 = 2*24;indCloseFinal(indCloseSSD(2)); 4;%minInd1; indBest(3);%minInd1; %201
        
        %         idx1 = matchMat(indDup(2),1); idx2 = matchMat(indDup(2),2);
        image1 = (imread(img1));
        image2 = (imread(img2));
        
        figure, imshow(image1), hold on, showellipticfeaturesSPL(f1(idx1,:));
        figure, imshow(image2), hold on, showellipticfeaturesSPL(f2(idx2,:));
        
        figure, imshow(image1), hold on, showellipticfeaturesSPL(f1(ceil(idx1/2),:));
        figure, imshow(image2), hold on, showellipticfeaturesSPL(f2(ceil(idx2/2),:));
        
        szBlock = sqrt(size(des1,2)/3);
        block1 = uint8(reshape(des1(idx1,:),[szBlock szBlock 3]));
        block2 = uint8(reshape(des2(idx2,:),[szBlock szBlock 3]));
        %         figure, imshow(img1),showellipticfeaturesSPL(featMatch1);
        figure, imshow(block1); figure, imshow(block2);
        
    end
    
end

matchMat = cell2mat(match');
ssdValsMat = cell2mat(ssdVals');
% matchMat = cell2mat(match');
% matchMat = cell2mat(match');

szMatches = size(matchMat,1);
valid = ones(szMatches,1);
featMatch1Final=[];featMatch2Final=[];matchFinal=[];

idx1 = matchMat(:,1); idx2 = matchMat(:,2);
if strcmp(detType,'harronmser')
    idx1Corrected = ceil(idx1/2);
    idx2Corrected = ceil(idx2/2);
else
    idx1Corrected = idx1;
    idx2Corrected = idx2;
end

featMatch1 = f1(idx1Corrected,:);
featMatch2 = f2(idx2Corrected,:);
for i1=1:szMatches
    if valid(i1)
        indDup = find(featMatch1(:,1)==featMatch1(i1,1) & featMatch1(:,2)==featMatch1(i1,2));
        if length(indDup)>2
            aa=1;
        end
        [~,bestInd] = min(ssdValsMat(indDup));
        bestSSDInd = indDup(bestInd);
        indLowSSD = setdiff(indDup,bestSSDInd);
        valid(indDup) = 0;
        featMatch1Final = [featMatch1Final; featMatch1(bestSSDInd,:)];
        featMatch2Final = [featMatch2Final; featMatch2(bestSSDInd,:)];
        matchFinal = [matchFinal; matchMat(bestSSDInd,:)];
        %     featMatches = [featMatch1(:,1:2) featMatch2(:,1:2)];
        % [~,indUniqueMatch] = unique(featMatches,'rows'); %this is just to eliminate points that have matched from both sides
        % matchCell = matchCell(indUniqueMatch);
        % featMatch1 = featMatch1(indUniqueMatch,:);
        % featMatch2 = featMatch2(indUniqueMatch,:);
    end
end

if strcmp(detType,'harronmser')
    matchFinal = ceil(matchFinal./2);
end
% matchMat = cell2mat(matchCell);
% indMatch1 = find(matchMatFinal);
% match(2,:)  = matchMat(indMatch1);
% match(1,:) = indMatch1;
if 0
    idx1 = matchFinal(:,1); %i;
    idx2 = matchFinal(:,2);%minInd1; indBest(3);%minInd1; %201
    
    %         idx1 = matchMat(indDup(2),1); idx2 = matchMat(indDup(2),2);
    image1 = (imread(img1));
    image2 = (imread(img2));
    
    figure, imshow(image1), hold on, showellipticfeaturesSPL(featMatch1);
    figure, imshow(image2), hold on, showellipticfeaturesSPL(featMatch1);
    
    figure, imshow(image1), hold on, showellipticfeaturesSPL(f1(idx1,:));
    figure, imshow(image2), hold on, showellipticfeaturesSPL(f2(idx2,:));
    
end

if 0
    matchMatFinal = zeros(size(des1,1),size(des2,1));
    minVal = 0;
    while 1
        minValNew  = min(min(matchMat));
        if minValNew > 100
            break;
        end
        [mini minj] = find(matchMat==minValNew);
        matchMat(mini,:) = 10000;
        matchMat(:,minj) = 10000;
        matchMatFinal(mini(1),minj(1)) = minValNew;
        minVal = minValNew;
        featMatch1 = [featMatch1; f1(mini(1),:)];
        featMatch2 = [featMatch2; f2(minj(1),:)];
        
    end
end

end


function sc_cost = getbestMatch(des1Eg,des2)

for j=1:size(des2,2)
    %     diff = sqrt(sum((repmat(des1(i,:),size(des2,1),1) - des2).^2,2));        % Computes vector of dot products
    costmat=hist_cost_2(des1Eg,des2{j}); % compute pairwise cost between all shape contexts
    % calculate shape context cost
    [a1,b1]=min(costmat,[],1);
    [a2,b2]=min(costmat,[],2);
    sc_cost(j) =max(mean(a1),mean(a2));
end

end