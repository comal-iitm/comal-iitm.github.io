function RenameDisparityFilesKitti
%for caltech, one set must be in reverse direction. and take care of double
%images of the first. Maybe this has already been deleted.

dirData = '../../images1/'; %'../../imagesOrigSize';
dirDataToWrite = '../../images1/disp';
imext = '.png'; %'png', 'ppm' and 'jpg'

Tuples = getTuples(dirData,imext);
pgmConvert=0;
if pgmConvert
  ext='pgm';
else
  ext='ppm';
end

[datasets indUnique] = unique(Tuples(:,1));
numImagesAll = [0; indUnique];
% numImagesAll = [0; indUnique(2:end) - indUnique(1:end-1)];

pairsInit = reshape(1:4*indUnique,2,round(4*indUnique/2))'; %multiply by 4 to get 4 copies from two stereo pairs and two flow pairs
indStereo = 1:2:2*indUnique;
pairs = pairsInit(indStereo,:);
pairs(:,2) = pairs(:,2) +1; %only for flow

for dIm = 1:indUnique
    mvcommand = sprintf('mv %s%s/%s %s%s/flow%d_%d.png',dirData,Tuples{1,1},Tuples{dIm,2},dirData,Tuples{1,1},pairs(dIm,1),pairs(dIm,2));
    system(mvcommand);    
end

 
end