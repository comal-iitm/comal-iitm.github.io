function [imBlocks indBlock indBlockSz] = getAllblocks(I,iSz,t)
%imBlocks is the set of image blocks extracted from the image I
%indBlock is the top-left coordinates of each imBlock
%indBLockSz is the size of each imBlock

commonVar = globalVariables(t);
[ysize xsize] = size(I); %Obtain the image size
shift =  round(iSz*commonVar.shiftSizeFactor/5)*5; %The shift or stride
[yInd xInd]=meshgrid(1:shift:ysize,1:shift:xsize); %Mesh grid gives us the list of points in the image where we take ROI
[szIndX szIndY] = size(yInd);
yInd=reshape(yInd,szIndX*szIndY,1); %List of all possible y coords with the correct number of repetitions
xInd=reshape(xInd,szIndX*szIndY,1); %List of all possible x coords with the correct number of repetitions
if commonVar.displayflag
    figure, imshow(I,[]), hold on, plot(xInd,yInd,'*b');
end

sz0 =  round(iSz*commonVar.iterBlockFactor/5)*5; %Get the actual shift using some factor mentioned
sz = round(sz0*commonVar.blockMultFactor);%block size
xIndEnd = xInd+sz; yIndEnd = yInd+sz; %The shifted coordinates
xBor = xIndEnd > xsize; %See which indices cross the border
xInd(xBor) = xInd(xBor)  - (xIndEnd(xBor) - xsize); %For those points, shift the start point to the left
xIndEnd(xBor) = xsize;

yBor = yIndEnd > ysize; %Similar to the above
yInd(yBor) = yInd(yBor)  - (yIndEnd(yBor) - ysize);
yIndEnd(yBor) = ysize;

xyInd = unique([xInd yInd],'rows'); %Obtain the unique pair of starting points
xyIndEnd = unique([xIndEnd yIndEnd],'rows'); %Obtain the unique pair of end points 
xInd = xyInd(:,1); yInd = xyInd(:,2); %All possible x and y start coordinates
xIndEnd = xyIndEnd(:,1); yIndEnd = xyIndEnd(:,2); %All possible x and y end points

if commonVar.displayflag
    hold on, plot(xInd,yInd,'*r');
end

delList=[];

for i=1:length(xInd) %Obtain all the image blocks and store them in the cells imBlocks
    IBlock = I(yInd(i):yIndEnd(i),xInd(i):xIndEnd(i));
    imBlocks{i}  = IBlock;
    indBlockSz{i} = size(IBlock);
    if indBlockSz{i}(1)*indBlockSz{i}(2) < (sz^2)/2
        delList = [delList; i];
    end
end

xInd(delList) = []; yInd(delList) = [];
imBlocks(delList) =[];
indBlockSz(delList) =[];
imBlocks = imBlocks';
indBlockSz = indBlockSz';
indBlock = mat2cell([xInd yInd],ones(length(xInd),1));
%testing:

if commonVar.displayflag
    %specify some a
    plot(xInd(a),yInd(a),'*r');
    figure, imshow(imBlocks{a});
end
