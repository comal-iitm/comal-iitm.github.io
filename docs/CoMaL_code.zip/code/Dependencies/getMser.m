function [boundaryVals regionsDec strength plusOrMinus] = getMser(img) %resizefactor

    delta = 0;
    theta = 0;
    
    commonVar  = globalVariables(1);
    
    boundaryVals={}; regionsDec=cell(1); strength=cell(1); plusOrMinus =cell(1);
    img_ = img;
    img = rgb2gray(img);
    %img = uint32(img);
    sizeIm  = size(img);
    ysize = sizeIm(1) ; xsize = sizeIm(2);
    
    iSz = commonVar.sigSmin(1);
    %img = BoundaryGaussianSmoothing_2D(img,2);
    
    for i1=1

        indBlock = [1, 1]; %The location of the image block
        indBlockSz = [size(img,2), size(img,1)]; %The size of the image block
        
        topIm = indBlock(2);
        bottomIm = indBlock(2) + indBlockSz(2) - 1;
        leftIm = indBlock(1);
        rightIm = indBlock(1) + indBlockSz(1) - 1;
        
        subBlock = img(topIm:bottomIm, leftIm:rightIm); %Obtain the image block
        sizeImg = size(subBlock); 
        imgFormatd = uint8(subBlock)'; sizeImg(3) = 1; %Some formatted image? 
        
        %strength has 1st var as the margin and 2nd var as the threshold
        
        [regions strength_ plusOrMinus_] = extremaExpt(imgFormatd, sizeImg, delta); %boundaryValsPlus boundaryValsMinus
        
        if 0,
            
            figure(2);
            imshow(img_);
            hold on;
            for i = 1:size(regions,2)
                plot(regions{i}(1,:), regions{i}(2,:));
            end;
        
        end;
        
        strength{i1} = strength_;
        plusOrMinus{i1} = plusOrMinus_;
        if ~isempty(regions)
             %regionsDec1  = decodeRLE(regions_temp); %This decode the RLE to another normal format of regions specification
             regionsDec0 = regions;
        else
            regionsDec0 = [];
        end
        
        for ind=1:length(regionsDec0)
            %[~,colNo] = find(regionsDec0{ind}<=0);
            %regionsDec0{ind}(:,colNo) = [];
            sel = uint32(sub2ind(sizeImg, regionsDec0{ind}(1,:), regionsDec0{ind}(2,:)));
           
            regionsDec0{ind} = sel;
        end
        regionsDec{i1} = regionsDec0;
    end
    
    %%

    commonVar.displayflag = 0;
    if commonVar.displayflag
        if 0 %some testing of packing into regions is happening right
            sz0 =  round(commonVar.sigSminInit*commonVar.iterBlockFactor/5)*5;
            sz = round(sz0*commonVar.blockMultFactor);%block size

            indTest = 8;
            mask = zeros(sz+1,sz+1); mask(regionsDec{indTest})=1; figure, imshow(mask);
            %         mask = zeros(sz,sz); mask(regionsMinus{indTest})=1;figure, imshow(mask);

            sel = uint32(sub2ind([51 51], regionsDec{ind}(1,:), regionsDec{ind}(2,:)));
            %
        end
        figure, imshow(img,[]), hold on,
        for i=1:length(boundaryVals)
            plot(boundaryVals{i}(2,:), boundaryVals{i}(1,:),'.');
        end
    end
    commonVar.displayflag=0;

end