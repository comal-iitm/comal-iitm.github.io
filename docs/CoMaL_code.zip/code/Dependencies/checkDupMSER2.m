function indInvalid  = checkDupMSER2(cornersDup,regions,indBlockDup)

numCorners = size(cornersDup,1);
pairs = nchoosek(1:numCorners,2);

valid = ones(numCorners,1);
commonVar = globalVariables(1);
sigS = cornersDup(1,3)/commonVar.smoothingFactor;
range = round(sigS*commonVar.iterBlockFactor/5)*5;
sz = round(range*commonVar.blockMultFactor);%block size
%%
for i=1:size(pairs,1)
    corNo = pairs(i,:);
    if valid(corNo(1)) & valid(corNo(2))
        for cor=1:2
            cornerWrtImage = cornersDup(cor,:);
            cornerWrtBlock = cornerWrtImage(1:2) - indBlockDup{corNo(cor)} + 1;
            topIm = max(1,round(cornerWrtBlock(2)-range));
            bottomIm = min(sz+1,round(cornerWrtBlock(2)+range));
            leftIm = max(1,round(cornerWrtBlock(1)-range));
            rightIm = min(sz+1,round(cornerWrtBlock(1)+range));
            
            
            mask = zeros(sz+1,sz+1);
            mask(regions{corNo(cor)}) = 1;
            maskCorner{cor} = mask(topIm:bottomIm,leftIm:rightIm);
            
            %             sel = find(maskCorner);
            
            strength(cor) = cornerWrtImage(13);
        end
        if (size(maskCorner{1})==size(maskCorner{2}))
            diffAmt = imabsdiff(maskCorner{1},maskCorner{2}) ;
            
            sumAmt = or(maskCorner{1},maskCorner{2}) ;
            %         indCommon = intersect(indValid{1},indValid{2});
            %         maxLen = max(length(indValid{1}),length(indValid{2}));
            diffAmtFull = sum(sum(diffAmt));%/maxLen;
            sumAmtFull = sum(sum(sumAmt));
            
            diffAvg = diffAmtFull/sumAmtFull;
            
            if diffAvg < 0.35
                if 0
                    figure, imshow(maskCorner{1});
                    figure, imshow(maskCorner{2});
                    close all;
                end
                if strength(1) <= strength(2)
                    valid(corNo(1))=0;
                else
                    valid(corNo(2))=0;
                end
            else
                aa=1;
                if 0
                    figure, imshow(maskCorner{1});
                    figure, imshow(maskCorner{2});
                    close all;
                end
                
            end
        end
    end
end

indInvalid = find(valid==0);
