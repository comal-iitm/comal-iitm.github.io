function [xNormResampled yNormResampled idxCorrected indmapnew resampledBasisDistNorm] = ResampleAffineContour(xNorm,yNorm,idx,indmap,circflag)
% stack=dbstack;
% Timing('ResampleAffineContour',1,stack(2).name);

% Calculating dS between the points on the normalized contour. Then these
% dS's are accumulated to get the S (along the curve) from the beginning to
% every point on the contour.
if length(yNorm) < 2
        disp('Problem with Resampling: Size less than 2')
end

if (circflag ==1)
    xNormCirc = [xNorm; xNorm(1)]; %[xNorm(end-1:end); xNorm; xNorm(1:2)];
    yNormCirc = [yNorm; yNorm(1)]; %[yNorm(end-1:end); yNorm; yNorm(1:2)];
else
    xNormCirc = xNorm;
    yNormCirc = yNorm;
end

% when the last few lines are called anywhere EXCEPT while calculating
% boundary in preInit circflag is NEVER 1. Now, the boundary
% ALWAYS gets cut before being warped.

basisDistNorm = sqrt(sum(diff([xNormCirc'; yNormCirc'],1,2).^2,1));


%[xNormCirc, yNormCirc, cumBasisNorm, maxBasisPts] = mex_basisDistNorm(xNorm, yNorm, circflag);

cumBasisNorm = [0 cumsum(basisDistNorm)];

% So, if the points on the boundary were to be equispaced, there would be
% 'maxBasisPts' points.
maxBasisPts = floor(cumBasisNorm(end) + 0.5) ;

try
   idxCorrected = floor(cumBasisNorm(idx) + 0.5) + 1;
   if (idxCorrected == maxBasisPts + 1) 
       idxCorrected = 1; 
   end
 catch
    disp('Stop')

    xNormResampled = [];
    yNormResampled = [];
%     idxCorrected = [];
    idxCorrected = 0;
    indmapnew = [];
    resampledBasisDistNorm = 0;
end

%disp(['idx= ' num2str(idx) ' idxCorrected= ' num2str(idxCorrected)])
%basisNorm = 0:maxBasisPts;

% 'basisFloor' are the nearest integers smaller than the S (curve length)
% from the beginning of the curve to each point. Denotes the position it
% should occupy in the resampled array. 'basisFrac' is the fractional curve
% length that the unresamped points is ahead of the resampled one. 


% Bilinear interpolation --- 
% dist2*xN   <-(dist1)->   (xN,yN)          <-(dist2)->          (dist2)*xN
% o---------------------------x-------------------------------------------o 
% xNorm(curind)       xNormResampled                                xNorm(curind)
% Distances of the point 'x' from 'o's on either side In a case like above,
% the total weight of 'x' is considered 1 and it gets distributed as

[xNormResampled, yNormResampled, indmapnew, resampledBasisDistNorm] = FastResampleC(maxBasisPts,cumBasisNorm,xNormCirc,yNormCirc,indmap);


% xNormResampled = zeros(maxBasisPts,1);
% yNormResampled = zeros(maxBasisPts,1);
% indmapnew = zeros(maxBasisPts,1);
% 
% curind = 1;
% sumdistArr = [];
% % resolution = 1/granularity;
% 
% % for i=0:resolution:maxBasisPts-1
% for i=0:maxBasisPts-1
%     
% %     resampledIdx = int32(i*granularity);
%     while (cumBasisNorm(curind+1) < i)
%         curind = curind + 1;
%     end
%     
%     dist1 = i - cumBasisNorm(curind);
%     dist2 = cumBasisNorm(curind + 1) - i;
%     
%     %     if (dist1 < 0 || dist2 < 0)
%     %         crazy = 1;
%     %     end
%     
%     sumdist = dist1 + dist2;
%     %     sumdistArr = [sumdistArr sumdist];
%     
%     xNormResampled(i+1) = (xNormCirc(curind) * dist2  + xNormCirc(curind + 1) * dist1)/sumdist;
%     yNormResampled(i+1) = (yNormCirc(curind) * dist2  + yNormCirc(curind + 1) * dist1)/sumdist;
%     
%     if (dist1 < dist2)
%         indmapnew(i+1) = curind;
%     else
%         indmapnew(i+1) = curind+1;
%         if (curind+1 == size(xNormCirc,1))
%             indmapnew(i+1) = 1;
%         end
%     end
%     
%     try
%         indmapnew(i+1) = indmap(indmapnew(i+1));
%     catch
%         disp('Stop')
%     end
%     
%     %     if (dist1 < dist2)
%     %         indmap(i+1) = curind;
%     %     else
%     %         if (curind == maxBasisPts)
%     %            indmap(i+1) = 1;
%     %         else
%     %             indmap(i+1) = curind+1;
%     %         end
%     %     end
%     
% end

resampledBasisDistNorm = sqrt(sum(diff([xNormResampled(1:end-1)'; yNormResampled(1:end-1)'],1,2).^2,1));

%Timing('ResampleAffineContour',0,stack(2).name);

        
    


% W{1}=abs(1-basisFrac);      X{1}=basisFloor;  
% W{2}=abs(basisFrac);        X{2}=basisFloor+1; 
% 
% for i=1:2
%   X{i}(X{i}(:)<1)=1; X{i}(X{i}(:)>maxBasisPts)=maxBasisPts;
%   
%   xNormResampled(X{i})=xNormResampled(X{i}) + xNorm.*(W{i}(:));
%   yNormResampled(X{i})=yNormResampled(X{i}) + yNorm.*(W{i}(:));
%   
% end
% plot(xNormResampled,yNormResampled,'.r');
% hold off

