function initCornersMat0  = InitDupRem(initCornersMat0,blockSize,regionSet,plusOrMinusSet,indBlock,sizeIm,t)

del = 5; nonLcsBasedOverErr = 0; lcsBasedOverErr = 4; isInit=1;
valid = ones(size(initCornersMat0,1),1);

for initCor = 1:size(initCornersMat0,1)
    if valid(initCor)
        corner = initCornersMat0(initCor,:);
        indNeighb = find(initCornersMat0(:,1)>corner(1)-del & initCornersMat0(:,1)< corner(1)+del & initCornersMat0(:,2)>corner(2)-del & initCornersMat0(:,2)<corner(2)+del);
        blockNumNeighb = initCornersMat0(indNeighb,11);
        
        if ~isempty(indNeighb) & ~all(indNeighb==initCor)
            regionsNeighb={};plusOrMinusNeighb=[];topLeftNeighb=[];
            for iNeigh=1:length(indNeighb)
                regionsNeighb{iNeigh} = regionSet{indNeighb(iNeigh)};%{regionNumForABlock(iNeigh)};
                plusOrMinusNeighb(iNeigh,1) = plusOrMinusSet(indNeighb(iNeigh));%(regionNumForABlock(iNeigh));
                topLeftNeighb(iNeigh,:) = fliplr(indBlock{blockNumNeighb(iNeigh)});
                
                if 0 %commonVar.displayflag
                    for iNeigh=1:length(indNeighb)
                        mask = zeros(blockSize(1),blockSize(2));
%                         regionSet = regionsDec{blockNumNeighb(iNeigh)};
                        region = regionSet{indNeighb(iNeigh)};
                        mask(region) = 1;
                        figure, imshow(mask);
                        blockStart  = indBlock{blockNumNeighb(iNeigh)};
                        corner0 = initCornersMat0(indNeighb(iNeigh),:);
                        corner0(1:2) = corner0(1:2) - (blockStart -1);
                        hold on, showellipticfeaturesSPL(corner0);
                    end
                end
            end
            blockSzNeighb = repmat(blockSize,length(indNeighb),1); %block size same for all during init
            boundaryNeighb=[];
            [cornersBlockMat cornersBlockMatOrigForm indOut indSelect]= overlapCheck(initCornersMat0(indNeighb,:)',sizeIm,lcsBasedOverErr,regionsNeighb, blockSzNeighb, topLeftNeighb,plusOrMinusNeighb,boundaryNeighb,t,nonLcsBasedOverErr); %cornersBlockMatOrigForm if needed
            indNeighb = indNeighb(indOut); indDel = setdiff(1:length(indNeighb),indSelect);
            indDelNeigh = indNeighb(indDel);
            valid(indDelNeigh) = 0;
        end
    end
    
    
end

select = find(valid == 1);
initCornersMat0 = initCornersMat0(select,:);
% regionNumMat0 = regionNumMat0(select);