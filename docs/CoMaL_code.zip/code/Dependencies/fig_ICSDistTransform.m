function fig_ICSDistTransform(imName0,threshI,delta)

imgName = sprintf('./images_figure/%s',imName0);
[imGraySmooth szIm] = fig_getSmoothImage(imgName);

[bICSSmX bICSSmY] = fig_getSmoothICS(imGraySmooth, threshI);
[bUpSmX bUpSmY] = fig_getSmoothICS(imGraySmooth, threshI+delta);

bwICS = zeros(szIm(1),szIm(2));
for i=1:size(bICSSmX,1)
    bwICS(round(bICSSmX(i)),round(bICSSmY(i))) = 1;
end

[dtMapICS ptClose] = bwdist(bwICS);
for i=1:length(bUpSmX)
    icsClose(i) = ptClose(round(bUpSmX(i)),round(bUpSmY(i)));
end
[icsCloseX icsCloseY]  = ind2sub(szIm(1:2),icsClose);

figure, imshow(dtMapICS,[]), hold on;
plot(bICSSmY,bICSSmX,'Linewidth',4,'Color','r'); 
    
figure, imshow(imgName); hold on,
plot(bICSSmY,bICSSmX,'Linewidth',6,'Color','k');plot(bUpSmY,bUpSmX,'Linewidth',6,'Color','k'); 

% plot circles
plot(bUpSmY(1:15:end),bUpSmX(1:15:end),'o','MarkerSize',12,'Color','r','MarkerFaceColor','g'); 
plot(icsCloseY(1:15:end),icsCloseX(1:15:end),'o','MarkerSize',12,'Color','r','MarkerFaceColor','g'); 

for i=1:15:length(bUpSmX)
plot([bUpSmY(i) icsCloseY(i)],[bUpSmX(i) icsCloseX(i)],'Linewidth',3,'Color','m')
end

end

% fig_ICSDistTransform('lll2.jpeg',100,10)

function [imGraySmooth szIm] = fig_getSmoothImage(imgName)

im = imread(imgName);
szIm = size(im);
imGray = rgb2gray(im);  H = fspecial('disk',25); imGraySmooth = imfilter(imGray,H,'replicate');

end