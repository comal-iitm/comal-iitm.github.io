function RunRepeatabilityAllImageMatching
overErr= 4;

if 1
    if 0
        Select; %choose threshold for overlap check
    end
    [repeatHom, correspHom, ~,~,repeatMultMatchesT,correspMultMatchesT] = testMserSimple('harronmser',overErr,0); %testMserSimple(detType,desciptor,firsttime)
    [~,~, matching_scoreHom,nb_of_matchesHom] = testMserSimple('harronmser',overErr,1);
      
    
       
%     OtherDetectors('hr3');
    [repeatHr3, correspHr3, ~,~] = testMserSimple('hr3',overErr,0);
    [~,~, matching_scoreHr3,nb_of_matchesHr3] = testMserSimple('hr3',overErr,1);
    
    
%     OtherDetectors('hs2');
    [repeatHs2, correspHs2, ~,~] = testMserSimple('hs2',overErr,0);
    [~,~, matching_scoreHs2,nb_of_matchesHs2] = testMserSimple('hs2',overErr,1);
    
    
%     OtherDetectors('fas');
    [repeatFas, correspFas, ~,~] = testMserSimple('fas',overErr,0,2,4);
    [~,~, matching_scoreFas,nb_of_matchesFas] = testMserSimple('fas',overErr,1,2,4);
    repeatFas(4:5) = 0; correspFas(4:5) = 0;
    matching_scoreFas(4:5) = 0; nb_of_matchesFas(4:5) = 0;
    
end

mark=['-yv';'-gs';'-m+';'-bp';'-rd';'-kx'];

hFig1 = figure;clf;
grid on;
ylabel('Repeatability %','FontSize',40,'FontWeight','bold')

xlabelString = 'Increasing blur';
figure(hFig1); axis([1.8 6 0 102]);
xAxis = 2:6;

xlabel(xlabelString,'FontSize',40,'FontWeight','bold');

hold on;
hFig2 = figure;clf;
grid on;
ylabel('Number of Correspondences','FontSize',40,'FontWeight','bold')
xlabel(xlabelString,'FontSize',40,'FontWeight','bold');
hold on;


figure(hFig1);  plot(xAxis,repeatHom,mark(6,:),'Linewidth',10,'MarkerSize',24);
%             figure(hFig2); axis([1.8 6 10 900]);
figure(hFig2);  plot(xAxis,correspHom,mark(6,:),'Linewidth',10,'MarkerSize',24);


% figure(hFig1);  plot(xAxis,repeatHr1,mark(1,:),'Linewidth',2,'MarkerSize',14);
figure(hFig1);  plot(xAxis,repeatHr3,mark(2,:),'Linewidth',10,'MarkerSize',24);
% figure(hFig1);  plot(xAxis,repeatHs1,mark(3,:),'Linewidth',2,'MarkerSize',14);
figure(hFig1);  plot(xAxis,repeatHs2,mark(4,:),'Linewidth',10,'MarkerSize',24);
figure(hFig1);  plot(xAxis,repeatFas,mark(5,:),'Linewidth',10,'MarkerSize',24);

% figure(hFig2);  plot(xAxis,correspHr1,mark(1,:),'Linewidth',2,'MarkerSize',14);
figure(hFig2);  plot(xAxis,correspHr3,mark(2,:),'Linewidth',10,'MarkerSize',24);
% figure(hFig2);  plot(xAxis,correspHs1,mark(3,:),'Linewidth',2,'MarkerSize',14);
figure(hFig2);  plot(xAxis,correspHs2,mark(4,:),'Linewidth',10,'MarkerSize',24);
figure(hFig2);  plot(xAxis,correspFas,mark(5,:),'Linewidth',10,'MarkerSize',24);

figure(hFig1);set(gca,'FontWeight','bold');
h_legend= legend('CoMIC','Harris','Hessian','Fast-9','Location','SouthEast'); %legend('ProfuseMser','Harris1','Harris2','Hessian1','Hessian2','Fast-9','Location','SouthEast');
set(gca,'FontWeight','bold');
set(h_legend, 'FontSize',45)
set(gca,'FontWeight','bold','LineWidth',5,'FontSize',40);


figure(hFig2);set(gca,'FontWeight','bold');
h_legend = legend('CoMIC','Harris','Hessian','Fast-9','Location','SouthEast'); 
set(gca,'FontWeight','bold');
set(h_legend, 'FontSize',45)
set(gca,'FontWeight','bold','LineWidth',5,'FontSize',40);

hFig3 = figure;clf;
grid on;
ylabel('Matching Score%','FontSize',40,'FontWeight','bold')

xlabelString = 'Increasing blur';
figure(hFig3); axis([1.8 6 0 102]);
xAxis = 2:6;
xlabel(xlabelString,'FontSize',40,'FontWeight','bold');


hold on;
hFig4 = figure;clf;
grid on;
ylabel('Number of matches','FontSize',40,'FontWeight','bold')
xlabel(xlabelString,'FontSize',40,'FontWeight','bold');
hold on;

figure(hFig3);  plot(xAxis,matching_scoreHom,mark(6,:),'Linewidth',10,'MarkerSize',24);
%             figure(hFig2); axis([1.8 6 10 900]);
figure(hFig4);  plot(xAxis,nb_of_matchesHom,mark(6,:),'Linewidth',10,'MarkerSize',24);


% figure(hFig3);  plot(xAxis,matching_scoreHr1,mark(1,:),'Linewidth',2,'MarkerSize',14);
figure(hFig3);  plot(xAxis,matching_scoreHr3,mark(2,:),'Linewidth',10,'MarkerSize',24);
% figure(hFig3);  plot(xAxis,matching_scoreHs1,mark(3,:),'Linewidth',2,'MarkerSize',14);
figure(hFig3);  plot(xAxis,matching_scoreHs2,mark(4,:),'Linewidth',10,'MarkerSize',24);
figure(hFig3);  plot(xAxis,matching_scoreFas,mark(5,:),'Linewidth',10,'MarkerSize',24);

% figure(hFig4);  plot(xAxis,nb_of_matchesHr1,mark(1,:),'Linewidth',2,'MarkerSize',14);
figure(hFig4);  plot(xAxis,nb_of_matchesHr3,mark(2,:),'Linewidth',10,'MarkerSize',24);
% figure(hFig4);  plot(xAxis,nb_of_matchesHs1,mark(3,:),'Linewidth',2,'MarkerSize',14);
figure(hFig4);  plot(xAxis,nb_of_matchesHs2,mark(4,:),'Linewidth',10,'MarkerSize',24);
figure(hFig4);  plot(xAxis,nb_of_matchesFas,mark(5,:),'Linewidth',10,'MarkerSize',24);


figure(hFig3);set(gca,'FontWeight','bold');
h_legend=legend('CoMic','Harris','Hessian','Fast-9','Location','SouthEast'); 
set(h_legend, 'FontSize',25)
set(gca,'FontWeight','bold','FontSize',30);
set(h_legend, 'FontSize',45)
set(gca,'FontWeight','bold','LineWidth',10,'FontSize',40);

figure(hFig4);set(gca,'FontWeight','bold');
h_legend=legend('CoMic','Harris','Hessian','Fast-9','Location','NorthEast'); 
set(h_legend, 'FontSize',25)
set(gca,'FontWeight','bold','FontSize',30);
set(h_legend, 'FontSize',45)
set(gca,'FontWeight','bold','LineWidth',5,'FontSize',40);

end