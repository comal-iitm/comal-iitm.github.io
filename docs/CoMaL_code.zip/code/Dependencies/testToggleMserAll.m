function testToggleMserAll(imgNo)

imgNo=6;

ptFile = sprintf('../data/results/bike/img%d.harronmser.txt',imgNo-1);
[feat s1 dimdesc1]=loadFeatures(ptFile);
commonVar = globalVariables(imgNo);
numClose = 25;

for i=1:size(feat,2)
    point = feat(:,i);
    pointScale = sqrt(1/point(3));
    [~,scaleNo] = min(abs(commonVar.sigSmin - pointScale));
    load(sprintf('matlab%d_%d.mat',imgNo,scaleNo));
    ptsToCompare = initCornersMat;
    [vals,ind] = closestPt(point',ptsToCompare,1,numClose); %
    ind = ind(vals<10);
    ptsToCompareClose = ptsToCompare(ind,:);
    
    for split0=1:size(ptsToCompareClose,1)
        blockNo = ptsToCompareClose(split0,11);
        indNo = ptsToCompareClose(split0,12);
        bNo = ptsToCompareClose(split0,15);
        regionDec0{split0} = regionsDec{blockNo}{indNo};
        plusOrMinus0(split0,1) = plusOrMinus{blockNo}(indNo);
        boundaryAll0{split0} = boundaryAll{blockNo}{indNo}{bNo};
        circFlagListSplit0(split0,1) = circFlagList{blockNo}(indNo);
    end
    
    figure, imshow(sprintf('../images/bike/img%d.ppm',imgNo)), hold on,
    
    MaxOrMinScaleFlag = 1;
    [cornersBlocktest,~,~,regionsFinal0test, blockSzFinal0test, topLeftFinal0test plusOrMinusFinal0test] = getConvergedCorner(ptsToCompareClose,regionDec0,plusOrMinus0,imgPath,boundaryAll0,circFlagListSplit0,imgNo,resizefactor,1,MaxOrMinScaleFlag);   %boundaryAll not sent during parfor %imBlocks must be uint32; method1,method2 as op
    
end

end