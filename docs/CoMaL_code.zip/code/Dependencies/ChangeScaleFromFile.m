function ChangeScaleFromFile(dataset)

detType = 'harronmser';
imgPath = sprintf('../images/%s/img1.ppm',dataset);
I = rgb2gray(imread(imgPath));
[ysize xsize]  = size(I);
   
for imgNo=1:6
pt1= sprintf('../data/results/%s/img%d.%s.txt',dataset,imgNo-1,detType);
pt1Des= sprintf('../data/results/%s/img%d.%sDes.txt',dataset,imgNo-1,detType);
[f1 s1 dimdesc1]=loadFeatures(pt1);
[f1Des s1 dimdesc1]=loadFeatures(pt1Des);

f1(3:5,:) = f1(3:5,:).*(1.4*1.4);
f1Des(3:5,:) = f1Des(3:5,:).*(1.4*1.4);

f1= f1'; f1Des= f1Des';

writeToFileTest(pt1,f1,1,xsize,ysize,0,(imgNo));
writeToFileTestForDesc(pt1Des,f1Des,1,xsize,ysize,0,(imgNo),1);

end