function [indValid coordFg gtAll featByBB featIndBB gtObjId ] = getFgBB(xyCoord, dataset, imgnoStr, dilVal,fgType,imSize) %fgType will be used later

imgDirPath = sprintf('../Images/%s',dataset);
imgPath = sprintf('%s/img%s.ppm',imgDirPath,imgnoStr);
%     convertGt(dataset,dataset); %convert for PROST dataset
sizeOrig = dlmread(sprintf('%s/original_size.txt',imgDirPath));
dSetNo = getParamsAndDataset(dataset);
imgnoInt = str2double(imgnoStr);
indValid=cell(length(dilVal),1); coordFg=cell(length(dilVal),1);
gtObjId = [];

if dSetNo==6
    gtPath = sprintf('%s/groundtruth.mat',imgDirPath);
    gt = load(gtPath);
    groundtruth = gt.tracklets{imgnoInt};
    totObj = size(groundtruth,2);
%     indValid=cell(totObj,1); coordFg=cell(totObj,1);
    leftGtInit=[];widInit=[];topGtInit=[];htInit=[];
    for numObj = 1:totObj
        leftGtInit(numObj) = groundtruth(numObj).x1; topGtInit(numObj) = groundtruth(numObj).y1;
        widInit(numObj) = groundtruth(numObj).x2-groundtruth(numObj).x1+1; htInit(numObj) = groundtruth(numObj).y2-groundtruth(numObj).y1+1;
        gtObjId(numObj) = groundtruth(numObj).id;
    end
    scaleFac = 700./sizeOrig(1); %mismatch with next one is just a difference in the way size has ben saved in original_size.txt. 
    
else
    gtPath = sprintf('%s/groundtruth.txt',imgDirPath);
    groundtruth = csvread(gtPath);
    leftGtInit = groundtruth(imgnoInt,1); topGtInit = groundtruth(imgnoInt,2);
    widInit = groundtruth(imgnoInt,3); htInit = groundtruth(imgnoInt,4);
    scaleFac = 700./sizeOrig(2); 
end

if 0
    aa = imresize(img,[sizeOrig(2) sizeOrig(1)]);
    figure, imshow(aa,[])
    rectangle('Position', [leftGtInit topGtInit widInit htInit],'LineWidth',2);
end

featByBB = cell(size(topGtInit,2),1);
featIndBB = cell(size(topGtInit,2),1);
gtAll =  cell(size(topGtInit,2),1);
for numDil=1:length(dilVal)
    for numObj=1:size(topGtInit,2)
        %adjust for scale
        topLeftGt = [topGtInit(numObj)-1 leftGtInit(numObj)-1].*(scaleFac) + 1;
        topGt = topLeftGt(1); leftGt = topLeftGt(2);
        widHtGt = [htInit(numObj) widInit(numObj)].*(scaleFac);
        wid = widHtGt(2); ht = widHtGt(1);
        if 0
            figure, imshow(imgPath)
            rectangle('Position', [leftGt topGt wid ht],'LineWidth',2);
            rectangle('Position', [leftBox topBox wid+80 ht+80],'LineWidth',2);
            
            %%%%%%
            imResize = imresize(imread(imgPath),1/scaleFac);
            h = visualization('init',imResize);
            nimages = length(dir(fullfile(imgDirPath, '*.ppm')));
            visualization('update',imResize,h,imgnoInt,nimages,dataset);
            for numObj = 1:totObj
                drawBox2D(h,gt.tracklets{imgnoInt}(numObj));
            end
            
        end
        %dilate/expand to fit in block indices
        if exist('imSize','var')
          sizeIm  =  imSize;
        else
          img = imread(imgPath);
          sizeIm  =  size(img);        
        end
        
        ysize = sizeIm(1) ; xsize = sizeIm(2);
        
        %gettting valid features inside BB
        botGt = topGt + ht; rightGt = leftGt + wid;
        topBox = max(topGt - dilVal(numDil),1);
        leftBox = max(leftGt - dilVal(numDil),1);
        botBox1 = min(botGt + dilVal(numDil),ysize); %these two need not be expanded as much as top and bottom
        rightBox1 = min(rightGt + dilVal(numDil),xsize);
        indValidObj = find(xyCoord(:,1)>=leftBox & xyCoord(:,1)<=rightBox1 & xyCoord(:,2)>=topBox & xyCoord(:,2)<=botBox1);
        indValid{numDil} = [indValid{numDil}; indValidObj];        
        featByBB{numObj} = xyCoord(indValidObj,:);
        featIndBB{numObj} = indValidObj;
        gtAll{numObj} = [leftGt topGt wid ht (leftGt + wid/2) (topGt + ht/2)]';
            
        %getting all the points inside BB
        if 1
        botBox = min(botGt + dilVal(numDil),ysize);
        rightBox = min(rightGt + dilVal(numDil),xsize);
        [col row] = meshgrid(round(leftBox:rightBox), round(topBox:botBox));
        [szCoord1 szCoord2] = size(col);
        colReshape = reshape(col,szCoord1*szCoord2,1);
        rowReshape = reshape(row,szCoord1*szCoord2,1);
        coordFgObj = [colReshape  rowReshape];
        coordFg{numDil} = [coordFg{numDil}; coordFgObj];
        end
    end
    
%     indValid{numDil} = unique(indValid{numDil}); %commented Mar 17 2015
if 0
coordFg{numDil} = unique(coordFg{numDil},'rows');
end
    if 0
        img = imread(sprintf('../images/%s/img%s.ppm',dataset,imgnoStr));
        figure, imshow(img,[]), hold on,
        plot(xyCoord(:,1),xyCoord(:,2),'*g');
        plot(xyCoord(indValid{numDil},1),xyCoord(indValid{numDil},2),'*');
       
        figure, imshow(img,[]), hold on,
        plot(coordFg{numDil}(:,1),coordFg{numDil}(:,2),'*');
    end
end
end