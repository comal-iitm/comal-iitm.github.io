function fig_gaussianweighting2(imName0,threshI)

imgName = sprintf('./images_figure/%s',imName0);
[imGraySmooth szIm] = fig_getSmoothImage(imgName);
[bICSSmX bICSSmY] = fig_getSmoothICS(imGraySmooth, threshI);

%% getting corner manually
windowWidth = 15;
figure, imshow(imGraySmooth), hold on, plot(bICSSmY,bICSSmX);
x0 = 43; y0= 71;
% [x0 y0] =  ginput(1);

%% theta of tangent
[vals,centBound] = closestPt([x0 y0],[bICSSmY bICSSmX],1,1); %
boundaryRight = [bICSSmX(centBound-windowWidth:centBound) bICSSmY(centBound-windowWidth:centBound)];
boundaryLeft = [bICSSmX(centBound:centBound+windowWidth) bICSSmY(centBound:centBound+windowWidth)];
[thetaNormal thetaTangent] = CalculateDirNormAndTan(boundaryRight,boundaryLeft);

%% gaussian
Tphi = (thetaNormal+5); %+5 is hack, change sigma according to the orientation of the gaussian
sigma1 = 250; sigma2 = 40;
[x y] = meshgrid(1:szIm(2), 1:szIm(1));
gauss2DRot = exp(-[(cos(Tphi)*(x-x0)-sin(Tphi)*(y-y0))/sigma1].^2 - [(sin(Tphi)*(x-x0)+cos(Tphi)*(y-y0))/sigma2].^2); %co * (all_this)

%% display
figure, imshow(gauss2DRot,[]), hold on;
plot(bICSSmY,bICSSmX,'Linewidth',4,'Color','c');
%plot tangent and normal
slopeTangent = tand(thetaTangent); interceptTangent=y0-slopeTangent*x0;
yi2 = polyval([slopeTangent,interceptTangent],[1 150]); plot([1 150],yi2,'r','Linewidth',2);
slopeNormal = tand(thetaNormal); interceptNormal=y0-slopeNormal*x0;
yi2 = polyval([slopeNormal,interceptNormal],[1 150]); plot([1 150],yi2,'r','Linewidth',2);

plot(bICSSmY(centBound),bICSSmX(centBound),'o','MarkerSize',8,'Color','r','MarkerFaceColor','g');

end

