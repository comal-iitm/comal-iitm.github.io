function tSet = getWrongRunImages


dirData = '../images';
Tuples = getTuples(dirData);
tSet=[];
for t = 1:141
    
    imgPath = fullfile(dirData,Tuples{t,1},Tuples{t,2});
    img = (imread(imgPath)); %give initial image a little smoothing
    if ~strcmp(Tuples{t,1},'boat')
        img = rgb2gray(img);
    end
    
    img = uint32(img);
    %     img = BoundaryGaussianSmoothing_2D(img,2);
    sizeIm  = size(img);
    ysize = sizeIm(1) ; xsize = sizeIm(2);
    imgInd = regexp(Tuples{t,2}, '[0-9]');
    imgno =  Tuples{t,2}(imgInd); % needs adjusting for non-single digit img nos
    
    
    gt = load(sprintf('../images/%s/gt.mat',Tuples{t,1}));
    sizeOrig = dlmread(sprintf('../images/%s/original_size.txt',Tuples{t,1}));
    scaleFac = [700 1000]./[sizeOrig(2) sizeOrig(1)]; %sizeOrig;
    groundtruth = gt.reqgt;
    leftGtInit = groundtruth(str2num(imgno),1); topGtInit = groundtruth(str2num(imgno),2);
    widInit = groundtruth(str2num(imgno),3); htInit = groundtruth(str2num(imgno),4);
    if 0
        aa = imresize(img,[sizeOrig(2) sizeOrig(1)]);
        figure, imshow(aa,[])
        rectangle('Position', [leftGtInit topGtInit widInit htInit],'LineWidth',2);
    end
    topLeftGt = [topGtInit-1 leftGtInit-1].*scaleFac + 1;
    topGt = topLeftGt(1); leftGt = topLeftGt(2);
    widHtGt = [htInit widInit].*scaleFac;
    wid = widHtGt(2); ht = widHtGt(1);
    if 0
        figure, imshow(img,[])
        rectangle('Position', [leftGt topGt wid ht],'LineWidth',2);
    end
    botGt = topGt + ht; rightGt = leftGt + wid;
    if (rightGt + 80) > ysize %| (rightGt + 80) > xsize
        tSet = [tSet t];
    end
end
end
