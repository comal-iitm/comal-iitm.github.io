function convertGt(dataset,dataset1)

dir = '../images'; dataset = 'boxz'; dataset1 = 'box';
file1 = sprintf('%s/%s/%s_gt.txt',dir,dataset,dataset1);
file2 = sprintf('%s/%s/%s_GRAD.txt',dir,dataset,dataset1);
fileWrite = sprintf('%s/%s/groundtruth.txt',dir,dataset);

gtMain=csvread(file1);
gtFillUp=csvread(file2);

gtFinal = gtFillUp;
numImages = size(gtFinal,1);
step = 1:5:numImages;
gtFinal(step,:) = gtMain(step,:);

dist2Gt = mod((1:numImages)-1,5);
for imgnoInt = 1:length(dist2Gt)
    if dist2Gt(imgnoInt)
        sizeOrig = dlmread(sprintf('../images/%s/original_size.txt',dataset));
        scaleFac = 700./sizeOrig(2); %sizeOrig;
        
        % get gt values for the initial one
        leftGtInit = gtFillUp(imgnoInt,1); topGtInit = gtFillUp(imgnoInt,2);
        widInit = gtFillUp(imgnoInt,3); htInit = gtFillUp(imgnoInt,4);
        topLeftGt = [topGtInit-1 leftGtInit-1].*(scaleFac) + 1;
        topGt = topLeftGt(1); leftGt = topLeftGt(2);
        widHtGt = [htInit widInit].*(scaleFac);
        wid = widHtGt(2); ht = widHtGt(1);
        botGt = topGt + ht; rightGt = leftGt + wid;
        
        %    get gt values for the sorted one
        [sortGtInds,sortInd] = sort([imgnoInt step]);
        indCur = find(sortInd==1);
        closestGtIndL = sortGtInds(indCur-1);
        if indCur<=length(step)
            closestGtIndU = sortGtInds(indCur+1); %check if it's 5 or 6
        else
            closestGtIndU = closestGtIndL;
        end
        leftGtInitL = gtMain(closestGtIndL,1); topGtInitL = gtMain(closestGtIndL,2);
        widInitL = gtMain(closestGtIndL,3); htInitL = gtMain(closestGtIndL,4);
        
        leftGtInitU = gtMain(closestGtIndU,1); topGtInitU = gtMain(closestGtIndU,2);
        widInitU = gtMain(closestGtIndU,3); htInitU = gtMain(closestGtIndU,4);
        
        leftGtDist = leftGtInitL + (dist2Gt(imgnoInt))*(leftGtInitU-leftGtInitL)/5;
        topGtDist = topGtInitL + (dist2Gt(imgnoInt))*(topGtInitU-topGtInitL)/5;
        
        topLeftGtDist0 = [topGtDist-1 leftGtDist-1].*(scaleFac) + 1;
        leftGtDist0 = topLeftGtDist0(2); topGtDist0 = topLeftGtDist0(1);
        htGtDist = max(htInitL, htInitU); htGtDist0 = htGtDist*(scaleFac) ;
        widGtDist = max(widInitL,widInitU); widGtDist0 = widGtDist*(scaleFac);
        botGtDist0 = topGtDist0 + htGtDist0; rightGtDist0 = leftGtDist0 + widGtDist0;
        if 0
            imgnoStr = getImgnoInStrOrInt(imgnoInt,2);
            imgPath = sprintf('../images/%s/img%s.ppm',dataset,imgnoStr);
            figure, imshow(imgPath);
            rectangle('Position', [leftGt topGt wid ht],'LineWidth',2);
            rectangle('Position', [leftGtDist0 topGtDist0 widGtDist0 htGtDist0],'LineWidth',2,'EdgeColor','r');
            rectangle('Position', [leftGtInitL-1 topGtInitL-1 widInitL-1 htInitL-1]*scaleFac + 1,'LineWidth',2,'EdgeColor','m');
            rectangle('Position', [leftGtInitU-1 topGtInitU-1 widInitU-1 htInitU-1]*scaleFac + 1,'LineWidth',2,'EdgeColor','g');
        end
        
        [col row] = meshgrid(round(leftGt:rightGt), round(topGt:botGt));
        [colDist rowDist] = meshgrid(round(leftGtDist0:rightGtDist0), round(topGtDist0:botGtDist0));
        if length(setdiff(row(:),rowDist(:))) > 0.18*ht || length(setdiff(col(:),colDist(:)))> 0.18*wid
            gtFinal(imgnoInt,:) = [leftGtDist topGtDist widGtDist htGtDist];
        end
    end
end

dlmwrite(fileWrite,gtFinal);
