function [featMatch1Final featMatch2Final matchFinal overlapPer] = matchDescriptors(des1,des2,f1,f2,detType,img1,img2,matchesSavePath,overRad)

distThresh = 20; threshSSD = 0.05; largeNum = 5000;
des1 = double(des1); des2 = double(des2);
img{1} = img1; img{2} = img2; %just take the image numbers and do all the loading here
szFeat = size(des1,1);
ssdVals = cell(szFeat,1);
match = cell(szFeat,1);
szBlock = sqrt(size(des1,2)/3);
ssdVals =  largeNum*ones(szFeat,1);
matchMat = 100*ones(size(des1,1),size(des2,1));
matchFinal=[];
featMatch1Final=[]; featMatch2Final=[];
for i = 1 : szFeat
    indCloseSSD=[];ssdVal=[];
    [distVals ,indClose] = closestPt(f1(i,:), f2,1,min(60,size(f2,1)));
    
    numMaxOverlap = round((pi*overRad*overRad)/4);
    distVals0 = closestPt(f1(i,:), f1,1,min(numMaxOverlap,size(f1,1)));
    indOvrLap = find(distVals0 <= overRad);
    overlapPerF(i) = length(indOvrLap)-1;
    
    ind0 = find(distVals < distThresh);
    indClose = indClose(ind0);
    try %the detector prolly didn't run correctly. Ignore this error
        des2Close = des2(indClose,:);
    catch
        disp(size(des2));
        disp(img2);
    end
    
    if ~isempty(indClose)
    areaDiff0 = largeNum*ones(length(indClose),1);
    areaDiff{1}=areaDiff0; areaDiff{2}=areaDiff0;
    sc_cost = largeNum*ones(length(indClose),1);
    idxF1= i;    idxF2 = indClose;
    
    if strcmp(detType,'harronmser')
        %shape context check
        bound1 = des1(i).boundary;
        sc1 = getShapeContext(bound1);
        for des2Ind=1:length(indClose)
            bound2 = des2Close(des2Ind).boundary;
            sc2 = getShapeContext(bound2);
            sc_cost0 = getbestMatch(sc1,sc2);
            if sc_cost0 < 0.18
                sc_cost(des2Ind) = getbestMatch(sc1,sc2);
            end
        end
        
        %region check
        selCutMain{1} = des1(i).region;
        selCutMain{2} = setdiff(1:szBlock*szBlock,selCutMain{1});
        %         mask1 = zeros(sz1,sz2);  mask1(selCutBothSides{1}) = 1;
        
        for side1=1:2
            for des2Ind=1:length(indClose)
                selCut{1} = des2Close(des2Ind).region;                
                selCut{2} = setdiff(1:szBlock*szBlock,selCut{2});
                for side2=1:2
                    minLengthRegion = max(length(selCutMain{side1}),length(selCut{side2}));
                    areaDiffSamp = length(setxor(selCutMain{side1},selCut{side2}));
                    if areaDiffSamp < 0.6*minLengthRegion
                        areaDiff{side2}(des2Ind) = areaDiffSamp;
                    end
                end
            end
            
            for side2=1:2    
                [areaLeastVal areaLeastInd] = sort(areaDiff{side2}); %mean(areaDiff);
                numShifts = 2;
                ssdVal = largeNum*ones(length(indClose),1);
                %         tic;
                for des2LeastInd=1:min(4,length(indClose))%
                    if areaLeastVal(des2LeastInd) < largeNum %areaLeastVal
                        des2Ind = areaLeastInd(des2LeastInd);
                        %             des2Ind = areaLeastInd;
                        selCut0 = des2Close(des2Ind).region;
                        if side2==1, selCut = selCut0; else selCut = setdiff(1:szBlock*szBlock,selCut0); end
                            center = [round(f1(idxF1,:)); round(f2(idxF2(des2Ind),:))];
                            ssdVal(des2Ind) = AlignGetSSD3(selCutMain{side1},selCut,img,center, szBlock,numShifts);
                        end
                end
                
            [minSSDVal1(side2) indTemp] = min(ssdVal);
            minSSDInd1(side2) = des2Ind(indTemp);
            end
            [minSSDVal2(side1) indTemp] = min(minSSDVal1);
        end
                
        match{i} = [idxF1 idxF2(indCloseSSD(1)) side1 side2];
        %         tt=toc;
        
    else
        %         selCutCommon = 1:numel(selCutRGBMain);
        numShifts = 1;
        for des2Ind=1:length(indCloseBothSides)
            if 0
                center = [round(f1(idxF1,:)); round(f2(idxF2(des2Ind),:))];
                ssdVal(des2Ind)  = AlignGetSSD(selCutCommon,selCutCommon,img,center, szBlock,numShifts); %[ssdVal(des2Ind) shiftErrors]
                %             mid = round(length(shiftErrors)-1)/2 + 1;
                %             ssdVal(des2Ind)  = shiftErrors(mid)/length(selCutCommon);
            else
                minShiftError = AlignGetSSD2(des1(i,:),des2Close(des2Ind,:),szBlock,numShifts);
                %                 I_error = double(imabsdiff(des1(i,:),des2Close(des2Ind,:)))./255;
                ssdVal(des2Ind) = minShiftError/length(selCutRGBMain); %sum(I_error)
                
            end
        end
    end
    
    if 0
        des1Emp = zeros(1,szBlock*szBlock*3);
        des2Emp = zeros(1,szBlock*szBlock*3);
        des1Emp(selCutCommon)=des1(i,selCutCommon);
        des2Emp(selCutCommon)=des2Close(des2Ind,selCutCommon);
        
        des1Emp = des1(i,:);
        des2Emp = des2Close(des2Ind,:);
        
        block10 = uint8(reshape(des1Emp,[szBlock szBlock 3]));
        block20 = uint8(reshape(des2Emp,[szBlock szBlock 3]));
        figure, imshow(block10); figure, imshow(block20);
        block1 = rgb2gray(block10); block2 = rgb2gray(block20);
        figure, imshow(block1); figure, imshow(block2);
        %                     [block1 block2] = Align(block1,block2);
        histBlock1 = imhist(block1,nBins);
        histBlock2 = imhist(block2,nBins);
        histDiff = sum(abs(histBlock1 - histBlock2));
        ssdVal(des2Ind) = histDiff;
        %         figure, imshow(img1),showellipticfeaturesSPL(featMatch1);
        %                     figure, imshow(block1); figure, imshow(block2);
    end
    
    [ssdVal indCloseSSD] = sort(ssdVal);
    
    if ~isempty(ssdVal)
        if ssdVal(1) < threshSSD %& minInd==i
            indMatch = idxF2(indCloseSSD(1));
            ssdVals(i) = ssdVal(1);
            match{i} = [idxF1 indMatch];
            if ~strcmp(detType,'harronmser')
                matchMat(idxF1,indMatch) = ssdVals(i);
            end
        end
    end
    
    if strcmp(detType,'harronmser')
        if mod(i,2)==0
            if ssdVals(i) < largeNum || ssdVals(i-1) < largeNum
                if ssdVals(i)  >  ssdVals(i-1)
                    matchSide = [match{i-1} 0];
                    minSSD = ssdVals(i-1);
                else
                    matchSide = [match{i} 1];
                    minSSD = ssdVals(i);
                end
                matchFinal = [matchFinal; matchSide];
                matchMat(matchSide(1),matchSide(2)) = minSSD;
            end
        end
    end
    end
end
overlapPer = mean(overlapPerF);

if ~strcmp(detType,'harronmser')
    matchFinal = [cell2mat(match) ssdVals(ssdVals<5000)];
end

if ~isempty(matchFinal)
    matchMatF = zeros(size(des1,1),size(des2,1));
    minVal = 0;
    while 1
        minValNew  = min(min(matchMat));
        if minValNew >= 100
            break;
        end
        [mini minj] = find(matchMat==minValNew);
        matchMat(mini,:) = 100;
        matchMat(:,minj) = 100;
        matchMatF(mini(1),minj(1)) = minValNew;
        minVal = minValNew;
    end
    [fx fy] = find(matchMatF>0);
    [~, del] = setdiff(matchFinal(:,1:2),[fx fy],'rows');
    matchFinal(del,:)=[];
    
    featMatch1Final = f1(matchFinal(:,1),:);
    featMatch2Final = f2(matchFinal(:,2),:);
end

save(matchesSavePath,'matchFinal');

if 0
    figure, imshow(img1), showellipticfeaturesSPL(featMatch1Final);
    figure, imshow(img2), showellipticfeaturesSPL(featMatch2Final);
end

% featAvgMovtOld = 10; featAvgMovtNew = 5;
if 0
    % while featAvgMovtNew > wind*featAvgMovtOld || featAvgMovtNew < (1/wind)*featAvgMovtOld
    featMovt = sum((featMatch1Final(:,1:2) - featMatch2Final(:,1:2)).^2,2);
    %     featAvgMovtOld = featAvgMovtNew;
    featAvgMovt = mean(featMovt);
    featFg  = find(featMovt > 1); % wind = 0.09; wind*featAvgMovt
    featMatch1Final = featMatch1Final(featFg,:);
    featMatch2Final = featMatch2Final(featFg,:);
    matchFinal = matchFinal(featFg,:);
    %     featAvgMovtNew = featAvgMovt;
    % end
end

end


function sc_cost = getbestMatch(des1Eg,des2)

for j=1:size(des2,2)
    %     diff = sqrt(sum((repmat(des1(i,:),size(des2,1),1) - des2).^2,2));        % Computes vector of dot products
    costmat=hist_cost_2(des1Eg,des2{j}); % compute pairwise cost between all shape contexts
    % calculate shape context cost
    [a1,b1]=min(costmat,[],1);
    [a2,b2]=min(costmat,[],2);
    sc_cost(j) =max(mean(a1),mean(a2));
end

end

function idxCorrected = IndDetType(detType,idx)
if strcmp(detType,'harronmser')
    idxCorrected = ceil(idx./2);
else
    idxCorrected = idx;
end

end