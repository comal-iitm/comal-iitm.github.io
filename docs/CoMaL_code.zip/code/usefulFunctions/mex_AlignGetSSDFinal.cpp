#include "mex.h"
#include <iostream>
#include <stdio.h>
#include <matrix.h>
#include <math.h>

using namespace std;

#define pr(a,i,j,k,s1,s2,s3) a[(i) + (j)*(s1) + (k)*(s1)*(s2)] 

int sign(int a)
{
	int out = 0;
	if( a == 0 )
	{
		out = 0;
	}
	else if(a > 0)
	{
		out = 1;
	}
	else out = -1;

	return out;
}

void meshGrid(int* xgv, int* ygv, int N, int M, int* &X, int* &Y)
{
	X = new int[M*N];
	Y = new int[M*N];
	
	for(int i=0; i<M; i++)
	{
		for(int j=0; j<N; j++)
		{
			X[i*N + j] = xgv[j];
		}
	}

	for(int j=0; j<N; j++)
	{
		for(int i=0; i<M; i++)
		{
			Y[i*N + j] = ygv[i];
		}
	}
	/*	
	cout << "\n--------- X ---------\n\n";
	for(int i=0; i<M; i++)
	{
		for(int j=0; j<N; j++)
		{
			cout<< X[i*N + j] << ' ';
		}
		cout << endl;
	}
	
	cout << "\n--------- Y ---------\n\n";
	for(int i=0; i<M; i++)
	{
		for(int j=0; j<N; j++)
		{
			cout<< Y[i*N + j] << ' ';
		}
		cout << endl;
	}
	*/ 
}

void imshiftMine(int shifts[2], double* imBlock1, double* imBlock2, int M, int N, int P, double* &imBlockSh1_out, double* &imBlockSh2_out)
{
	
	//cout << "M: " << M << " N:" << N << " P:" << P << endl;
	//cout << "Shifts: " << shifts[0] << ", " << shifts[1] << endl;
	
	double *imBlockSh1, *imBlockSh2;

	int shXA = abs(shifts[0]);
	int shYA = abs(shifts[1]);

	//cout << "Abs shifts: " << shXA << ", " << shYA << endl;

		
	imBlockSh1 = new double[M*N*P];
	imBlockSh2 = new double[M*N*P];

	//cout << "Here 1" << endl;
	
	for(int i=0; i<M*N*P; i++)
	{
		imBlockSh1[i] = imBlock1[i];
		imBlockSh2[i] = imBlock2[i];
	}

	double *imBlockSh1_, *imBlockSh2_;
	
	//cout << "Sign: " << sign(shifts[0]) << endl;
		
	switch (sign(shifts[0]))
	{
		case -1:
			
			//cout << "Here 2" << endl;
			
			imBlockSh1_ = new double[(M-shXA)*N*P];
			imBlockSh2_  = new double[(M-shXA)*N*P];
				
			for(int k=0; k<P; k++)
			{
				for(int i=0; i<M-shXA; i++)
				{
					for(int j=0; j<N; j++)
					{
							pr(imBlockSh1_, i, j, k, M-shXA, N, P) = pr(imBlockSh1, i, j, k, M, N, P);
							//cout << pr(imBlockSh1_, i, j, k, M-shXA, N, P) << ' ';
					}
					//cout << endl;
				}
				//cout << "\n---------------------------\n\n";
			}
		
			for(int k=0; k<P; k++)
			{
				for(int i=shXA; i<M; i++)
				{
					for(int j=0; j<N; j++)
					{
						
						pr(imBlockSh2_, i-shXA, j, k, M-shXA, N, P) = pr(imBlockSh2, i, j, k, M, N, P);
						//cout << pr(imBlockSh2_, i-shXA, j, k, M-shXA, N, P) << ' ';
					}
					//cout << endl;
				}
				//cout << "\n-------------------------\n\n";
			}
				
			delete [] imBlockSh1;
			delete [] imBlockSh2;
				
			imBlockSh1 = imBlockSh1_;
			imBlockSh2 = imBlockSh2_;
			
			break;
		
		case 1:
			
			//cout << "Here 3" << endl; 
				
			imBlockSh2_ = new double[(M-shXA)*N*P];
			imBlockSh1_ = new double[(M-shXA)*N*P];
		
				
			for(int k=0; k<P; k++)
			{
				for(int i=0; i<M-shXA; i++)
				{
					//cout << i+1 << ") ";
					for(int j=0; j<N; j++)
					{
						pr(imBlockSh2_, i, j, k, M-shXA, N, P) = pr(imBlockSh2, i, j, k, M, N, P);
						//cout << pr(imBlockSh2_, i, j, k, M-shXA, N, P) << ' ';
					}
					//cout << endl;
				}
				//cout << "\n----------------------------\n\n";
			}

			
			for(int k=0; k<P; k++)
			{
				for(int i=shXA; i<M; i++)
				{
					//cout << i + 1 << ") ";
					for(int j=0; j<N; j++)
					{
						pr(imBlockSh1_, i-shXA, j, k, M-shXA, N, P) = pr(imBlockSh1, i, j, k, M, N, P);
						//cout << pr(imBlockSh1_, i-shXA, j, k, M-shXA, N, P) << ' ';
					}
					//cout << endl;
				}
				//cout << "\n------------------------------\n\n";
			}

			delete [] imBlockSh1;
			delete [] imBlockSh2;
			
			imBlockSh1 = imBlockSh1_;
			imBlockSh2 = imBlockSh2_;
			
			break;
		
	}
	
	switch (sign(shifts[1]))
	{
		case -1:
			
			//cout << "Here 4" << endl;
			
			imBlockSh1_ = new double[(M-shXA)*(N-shYA)*P];
			imBlockSh2_ = new double[(M-shXA)*(N-shYA)*P];
				
			for(int k=0; k<P; k++)
			{
				for(int i=0; i<M-shXA; i++)
				{
					for(int j=0; j<N-shYA; j++)
					{
						pr(imBlockSh1_, i, j, k, M-shXA, N-shYA, P) = pr(imBlockSh1, i, j, k, M-shXA, N, P);
						//cout << pr(imBlockSh1_, i, j, k, M-shXA, N-shYA, P) << ' ';
					}
					//cout << endl;
				}
				//cout << "\n----------------------\n\n";
			}
							
			for(int k=0; k<P; k++)
			{
				for(int i=0; i<M-shXA; i++)
				{
					for(int j=shYA; j<N; j++)
					{
						//cout << "Missing here? \n";
						pr(imBlockSh2_, i, j-shYA, k, M-shXA, N-shYA, P) = pr(imBlockSh2, i, j, k, M-shXA, N, P);
						//cout << pr(imBlockSh2_, i, j-shYA, k, M-shXA, N-shYA, P) << ' ';
					}
					//cout << endl;
				}
				//cout << "\n---------------------------\n\n";
			}
			
			delete [] imBlockSh1;
			delete [] imBlockSh2;
			
			imBlockSh1 = imBlockSh1_;
			imBlockSh2 = imBlockSh2_;
			
			break;
		
		case 1:
			
			//cout << "Here 5" << endl;
			
			imBlockSh2_ = new double[(M-shXA)*(N-shYA)*P];
			imBlockSh1_ = new double[(M-shXA)*(N-shYA)*P];
			
			
			for(int k=0; k<P; k++)
			{
				for(int i=0; i<M-shXA; i++)
				{
					//cout << i+1 << ") ";
					for(int j=0; j<N-shYA; j++)
					{
						pr(imBlockSh2_, i, j, k, M-shXA, N-shYA, P) = pr(imBlockSh2, i, j, k, M-shXA, N, P);
						//cout << pr(imBlockSh2_, i, j, k, M-shXA, N-shYA, P) << ' ';
					}
					//cout << endl;
				}
				//cout << "\n-----------------------------\n\n";
			}


			for(int k=0; k<P; k++)
			{
				for(int i=0; i<M-shXA; i++)
				{
					//cout << i+1 << ") ";
					for(int j=shYA; j<N; j++)
					{
						pr(imBlockSh1_, i, j-shYA, k, M-shXA, N-shYA, P) = pr(imBlockSh1, i, j, k, M-shXA, N, P);
						//cout << pr(imBlockSh1_, i, j-shYA, k, M-shXA, N-shYA, P) << ' ';
					}
					//cout << endl;
				}
				//cout << "\n----------------------------\n\n";
			}

			delete [] imBlockSh1;
			delete [] imBlockSh2;
			
			imBlockSh1 = imBlockSh1_;
			imBlockSh2 = imBlockSh2_;
			
			break;	
	}
	
	imBlockSh1_out = imBlockSh1;
	imBlockSh2_out = imBlockSh2;
}

void mexFunction(int nlhs, mxArray *plhs[ ], int nrhs, const mxArray *prhs[ ])
{
	if(nrhs != 3)
	{
		mexErrMsgTxt("Syntax error [ssdVal] = mex_AlignGetSSDFinal(templates, masks, numShifts)");
	}
	
	enum {TEMP=0, MASK, NUMSH};

	double ssdVal = 5000;
	
	const mxArray *tempCell = prhs[TEMP];
	const mxArray *maskCell = prhs[MASK];
	const mxArray *numShifts = prhs[NUMSH];
	const mxArray *temp1;
	const mxArray *mask1;

	const mwSize *dimsTemp;
	const mwSize *dimsMask;

	dimsTemp = mxGetDimensions(tempCell);
	dimsMask = mxGetDimensions(maskCell);
		
	double* tempPtr; 
	double* maskPtr;

	double* templates[2] ;
	double* masks[2];
	
	const int *tempDim;
	const int *maskDim;
	int iter = 0;	
	for(mwIndex i=0; i<dimsTemp[1]; i++)
	{
		temp1 = mxGetCell(tempCell, i);
		tempPtr = mxGetPr(temp1);
		tempDim = mxGetDimensions(temp1);
		
		int totalSize = tempDim[0]*tempDim[1]*tempDim[2];
		
		//cout << "Template size: " << tempDim[0] << "x" << tempDim[1] << "x" << tempDim[2] << endl;
		templates[iter] =	new double[totalSize];
			
		for(int iter3=0; iter3<tempDim[2]; iter3++)
		{
			for(int iter1=0; iter1<tempDim[0]; iter1++)
			{
				for(int iter2=0; iter2<tempDim[1]; iter2++)
				{
					pr(templates[i], iter1, iter2, iter3, tempDim[0], tempDim[1], tempDim[2]) = pr(tempPtr, iter1, iter2, iter3, tempDim[0], tempDim[1], tempDim[2]);
					//cout << pr(templates[iter], iter1, iter2, iter3, tempDim[0], tempDim[1], tempDim[2]) << ' ';
				}
				//cout << endl;
			}
			//cout << "\n------------------------\n\n";
		}

		mask1 = mxGetCell(maskCell, i);
		maskPtr = mxGetPr(mask1);
		maskDim = mxGetDimensions(mask1);

		totalSize = maskDim[0]*maskDim[1];
		
		//cout << "Mask dims: " << maskDim[0] << "x" << maskDim[1] << endl;
		masks[iter] = new double[totalSize];
		
		for(int iter1=0; iter1<maskDim[0]; iter1++)
		{
			for(int iter2=0; iter2<maskDim[1]; iter2++)
			{
				pr(masks[i], iter1, iter2, 0, maskDim[0], maskDim[1], 1) = pr(maskPtr, iter1, iter2, 0, maskDim[0], maskDim[1], 1);
				//cout << pr(masks[i], iter1, iter2, 0, maskDim[0], maskDim[1], 1) << ' ';
			}
			//cout << endl;
		}
		
		iter ++;
	}
				
	double* numShiftsPtr = mxGetPr(numShifts);
	//cout<<*numShiftsPtr<<endl;

	int* xgv = new int[2* int(*numShiftsPtr) + 1];
	iter = 0;
	
	for(int val = -int(*numShiftsPtr); val <= int(*numShiftsPtr); val++)
	{
		xgv[iter++] = val;
	}

	int *XshiftN, *YshiftN;
	int M = 2*int(*numShiftsPtr) + 1;
	int N =	2*int(*numShiftsPtr) + 1;

	meshGrid(xgv, xgv, M, N, XshiftN, YshiftN);
		
	double* shiftErrors = new double[M*N];
	for(int i=0; i<M*N; i++)
	{
		shiftErrors[i] = 5000000;
	}

	for(int shift=0; shift < M*N; shift++)
	{
		double *templateSh1, *templateSh2;
		double *maskSh1, *maskSh2;
		
		int XYshift[2];

		XYshift[0] = XshiftN[shift];
		XYshift[1] = YshiftN[shift];

		//cout << "Shift: " << XYshift[0] << " " << XYshift[1] << endl;

		int shXA = abs(XshiftN[shift]);
		int shYA = abs(YshiftN[shift]);

		imshiftMine(XYshift, templates[0], templates[1], tempDim[0], tempDim[1], tempDim[2], templateSh1, templateSh2); 
		imshiftMine(XYshift, masks[0], masks[1], maskDim[0], maskDim[1], 1, maskSh1, maskSh2);
			
		int tempDim_0 = tempDim[0] - shXA;
		int tempDim_1 = tempDim[1] - shYA;
		int maskDim_0 = maskDim[0] - shXA;
		int maskDim_1 = maskDim[1] - shYA;
		
		//cout << "Reached final \n";	
		double errors = 0;
		double count = 0;
		for(int x=0; x<tempDim_0; x++)
		{
			for(int y=0; y<tempDim_1; y++)
			{

				double b = pr(maskSh1, x, y, 0, maskDim_0, maskDim_1, 1);
				
				for(int z=0; z<tempDim[2]; z++)
				{
					double a1 = pr(templateSh1, x, y, z, tempDim_0, tempDim_1, tempDim[2]);
					double a2 = pr(templateSh2, x, y, z, tempDim_0, tempDim_1, tempDim[2]);
					errors += b*((a1 - a2 >= 0)?(a1 - a2):(a2-a1));
					count += b;
				}
			}
		}
		
		if(count != 0)
		    shiftErrors[shift] = errors/count;
		

		delete [] templateSh1;
		delete [] templateSh2;
		delete [] maskSh1;
		delete [] maskSh2;
	}
	
	double ssdMin = shiftErrors[0];
	for(int i=0; i<M*N; i++)
	{
		if(shiftErrors[i] < ssdMin)
		{
			ssdMin = shiftErrors[i];
		}
	}
	
	plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);
	double* out = mxGetPr(plhs[0]);
	out[0] = ssdMin;

	//cout << "Min ssd: " << ssdMin << endl;
	
	delete [] XshiftN;
	delete [] YshiftN;
	delete [] templates[0];
	delete [] templates[1];
	delete [] masks[0];
	delete [] masks[1];
	delete [] shiftErrors;
}
	
