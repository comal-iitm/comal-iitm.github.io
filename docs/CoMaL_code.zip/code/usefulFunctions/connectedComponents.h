#include <iostream>
#include <stdio.h>
#include <fstream>
#include <string>
#include <vector>
#include <stdlib.h>
#include <algorithm>
#include <sstream>
#include <time.h>

#define cm(i, j, nrows) ((i) + (j)*(nrows))

using namespace std;

void doLabel(int* img, int nrows, int ncols, int* &labels, int conn);

