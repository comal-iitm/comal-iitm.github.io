#include "mex.h"
#include <iostream>
#include <stdio.h>
#include <matrix.h>
#include <math.h>

using namespace std;

#define PI 3.14159265

// Coded for finding only one closest point 

void mexFunction(int nout, mxArray *out[], int nin, const mxArray *in[])
{

	enum {IN_CPOS=0, IN_RELCPOS, IN_CLO};
	enum {OUT_VALS=0, OUT_INDS, OUT_DVR};

	double *cornerpos, *relCornerpos, *closest;
	double *vals, *inds, *distvalRaw;

	out[OUT_VALS] = mxCreateDoubleMatrix(1, 1, mxREAL);
	out[OUT_INDS] = mxCreateDoubleMatrix(1, 1, mxREAL);
	out[OUT_DVR] = mxCreateDoubleMatrix(1, 2, mxREAL);

	cornerpos = mxGetPr(in[IN_CPOS]);
	relCornerpos = mxGetPr(in[IN_RELCPOS]);
	closest = mxGetPr(in[IN_CLO]);

	vals = mxGetPr(out[OUT_VALS]);
	inds = mxGetPr(out[OUT_INDS]);
	distvalRaw = mxGetPr(out[OUT_DVR]);

	const int *dims = mxGetDimensions(in[IN_RELCPOS]);
	int numCornersRel = dims[0];

	double *distval_temp = new double[numCornersRel*2];
	double *distval = new double[numCornersRel];

	double minval = 100000.0;
	int minind = 0;
	double maxval = 0;
	int maxind = 0;

	for(int i=0; i<numCornersRel; i++)
	{
		distval_temp[i] = cornerpos[0] - relCornerpos[i];
		distval_temp[i+numCornersRel] = cornerpos[1] - relCornerpos[i+numCornersRel];
		distval[i] = distval_temp[i]*distval_temp[i]+distval_temp[i+numCornersRel]*distval_temp[i+numCornersRel];
		
		if( distval[i] < minval )
		{
			minval = distval[i];
			minind = i;
		}

		if( distval[i] > maxval )
		{
			maxval = distval[i];
			maxind = i;
		}
	}		

	if(closest[0] == 1)
	{
		vals[0] = sqrt(minval);
		inds[0] = minind+1;

		distvalRaw[0] = distval_temp[minind];
		distvalRaw[1] = distval_temp[minind+numCornersRel];
	}
	else
	{
		vals[0] = sqrt(maxval);
		inds[0] = maxind+1;

		distvalRaw[0] = distval_temp[maxind];
		distvalRaw[1] = distval_temp[maxind+numCornersRel];
	}

	delete [] distval;
	delete [] distval_temp;

}
