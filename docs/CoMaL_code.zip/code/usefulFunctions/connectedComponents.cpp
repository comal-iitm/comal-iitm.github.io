#include "connectedComponents.h"

// Follows column major storage of arrays

void doLabel(int* img, int nrows, int ncols, int* &labels, int conn)
{
	int SET = 0;
	if( conn == 4)
	{
		SET = 0;
	}
	else if( conn == 8)
	{
		SET = 1;
	}
	else
	{
		cerr << "Wrong connectivity specified, it must be 4 or 8!" << endl;
		exit(EXIT_FAILURE);
	}
	
	labels = new int[nrows*ncols];
	int unionFind[2000];
	int unionFindMax = 0;
	int currIdx = 0;
	
	for(int i=0; i<nrows; i++)
	{
		for(int j=0; j<ncols; j++)
		{
			if(img[cm(i, j, nrows)] != 0)
			{
				int indices_to_check[] = {-1, -1, -1, -1};
				int possibilities[] = {-1, -1, -1, -1}; 
				bool isNew = true;

				if(i != 0 && j != 0 && SET == 1)
				{
					indices_to_check[0] = cm(i-1, j-1, nrows);
				}
				if(i != 0)
				{
					indices_to_check[1] = cm(i-1, j, nrows);
				}
				if(j != 0)
				{
					indices_to_check[2] = cm(i, j-1, nrows);
				}
				if(i != 0 && j != ncols-1 && SET == 1)
				{
					indices_to_check[3] = cm(i-1, j+1, nrows);
				}

				int min_element = 100000;
				int min_element_idx = 0;
				for(int k=0; k < 4; k++)
				{
					if(img[indices_to_check[k]] == 1 && indices_to_check[k] != -1)
					{
						isNew = false;
						possibilities[k] = (labels[indices_to_check[k]]);
						if( min_element > labels[indices_to_check[k]] )
						{
							min_element = labels[indices_to_check[k]];
							min_element_idx = indices_to_check[k];
						}
					}
				}
				
				if(isNew)
				{
					labels[cm(i, j, nrows)] = currIdx;
					unionFind[currIdx] = currIdx;
					currIdx++;
					unionFindMax++;
				}
				else
				{
					labels[cm(i, j, nrows)] = min_element;
					for(int l=0; l < 4; l++)
					{
						if(possibilities[l] != min_element && possibilities[l] != -1)
						{
							unionFind[possibilities[l]] = min_element;
						}
					}
				}

			}
			else
			{
				labels[cm(i, j, nrows)] = -1;
			}
		}
	}
	
	for(int i=0; i<unionFindMax; i++)
	{
		int root = unionFind[i];
		while(root != unionFind[root])
		{
			root = unionFind[root];
		}
		unionFind[i] = root;
	}
	
	for(int i=0; i<nrows; i++)
	{
		for(int j=0; j<ncols; j++)
		{
			if(labels[cm(i, j, nrows)] != -1)
			{
				labels[cm(i, j, nrows)] = unionFind[labels[cm(i, j, nrows)]] + 1;
			}
			else
			{
				labels[cm(i, j, nrows)] = 0;
			}
		}
	}
}
