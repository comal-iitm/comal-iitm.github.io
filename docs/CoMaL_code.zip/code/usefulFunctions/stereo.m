function stereo      

if stereo
            for imgNo = startimgno:endimgno
                datapath = fullfile('..','data','results',sprintf('%s',datasets{d}));
                file1 =fullfile(sprintf('%s',datapath),'img1.comic.txt');
                file2 =fullfile(sprintf('%s',datapath),sprintf('img%d.comic.txt',imgNo-1));
                imf1 = fullfile(dirData,datasets{d},'img1.ppm');
                Hom = fullfile(sprintf('%s',datapath),'Hunity');
                resizefactor=1;
                [f1New ysize xsize]= AddDisparityMain(file1,file2,datapath);
                [erro,repeat,corresp, match_score,matches, twi]=repeatabilityHarrOnMser(file1,file2,Hom,imf1,imf1,1,resizefactor,t);
                %collect rep values right here and save. Use GNU plot
                
            end
            
        end
