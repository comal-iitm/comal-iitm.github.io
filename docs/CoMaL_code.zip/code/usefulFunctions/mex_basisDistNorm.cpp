#include "mex.h"
#include <stdio.h>
#include <matrix.h>
#include <math.h>

void mexFunction(int nout, mxArray *out[], int nin, const mxArray *in[])
{
	enum {IN_X=0, IN_Y, IN_CIRC};
	enum {OUT_X=0, OUT_Y, /*OUT_BDN,*/ OUT_CBN, OUT_MBP};

	double *xNorm, *yNorm, *circflag;
	double *xNormCirc, *yNormCirc;
	double /**basisDistNorm,*/ *cumBasisNorm, *maxBasisPts;
	
	const int* dims = mxGetDimensions(in[IN_X]);
	
	int dims_new;

	xNorm = mxGetPr(in[IN_X]);
	yNorm = mxGetPr(in[IN_Y]);
	circflag = mxGetPr(in[IN_CIRC]);
	
	if(*circflag == 1)
	{
		out[OUT_X] = mxCreateDoubleMatrix(dims[0]+1, dims[1], mxREAL);
		out[OUT_Y] = mxCreateDoubleMatrix(dims[0]+1, dims[1], mxREAL);
		//out[OUT_BDN] = mxCreateDoubleMatrix(1, dims[0], mxREAL);
		out[OUT_CBN] = mxCreateDoubleMatrix(1, dims[0]+1, mxREAL);

		xNormCirc = mxGetPr(out[OUT_X]);
		yNormCirc = mxGetPr(out[OUT_Y]);

		for(int i=0; i<dims[0]; i++)
		{
			xNormCirc[i] = xNorm[i];
			yNormCirc[i] = yNorm[i];
		}

		xNormCirc[dims[0]] = xNorm[0];
		yNormCirc[dims[0]] = yNorm[0];

		dims_new = dims[0]+1;
	}
	else
	{
		out[OUT_X] = mxCreateDoubleMatrix(dims[0], dims[1], mxREAL);
		out[OUT_Y] = mxCreateDoubleMatrix(dims[0], dims[1], mxREAL);
		//out[OUT_BDN] = mxCreateDoubleMatrix(1, dims[0]-1, mxREAL);
		out[OUT_CBN] = mxCreateDoubleMatrix(1, dims[0], mxREAL);

		xNormCirc = mxGetPr(out[OUT_X]);
		yNormCirc = mxGetPr(out[OUT_Y]);

		for(int i=0; i<dims[0]; i++)
		{
			xNormCirc[i] = xNorm[i];
			yNormCirc[i] = yNorm[i];
		}

		xNormCirc[dims[0]] = xNorm[0];
		yNormCirc[dims[0]] = yNorm[0];

		dims_new = dims[0];
	}

	out[OUT_MBP] = mxCreateDoubleMatrix(1, 1, mxREAL);

	//basisDistNorm = mxGetPr(out[OUT_BDN]);
	cumBasisNorm = mxGetPr(out[OUT_CBN]);
	maxBasisPts = mxGetPr(out[OUT_MBP]);

	for(int i=1; i < dims_new; i++)
	{
		//basisDistNorm[i-1] = sqrt((xNormCirc[i]-xNormCirc[i-1])*(xNormCirc[i]-xNormCirc[i-1]) + (yNormCirc[i] - yNormCirc[i-1])*(yNormCirc[i] - yNormCirc[i-1]));
		
		if(i == 0)
		{
			cumBasisNorm[i] = 0;
		}
		else
		{
			//cumBasisNorm[i] = cumBasisNorm[i-1] + basisDistNorm[i-1];
			cumBasisNorm[i] = cumBasisNorm[i-1] + sqrt((xNormCirc[i]-xNormCirc[i-1])*(xNormCirc[i]-xNormCirc[i-1]) + (yNormCirc[i] - yNormCirc[i-1])*(yNormCirc[i] - yNormCirc[i-1]));

		}
	}
	
	maxBasisPts[0] = floor(cumBasisNorm[dims_new-1] + 0.5);

}



			
