#include "mex.h"
#include <stdio.h>
#include <matrix.h>
#include <math.h>
#include <iostream>

using namespace std;

void mexFunction(int nout, mxArray *out[], int nin, const mxArray *in[])
{
	enum {IN_NBINS_T=0, IN_NBINS_R, IN_NSAMP, IN_FZ, IN_VEC, IN_TAQ, IN_RAQ};
	enum {OUT_BH=0};
	
	double *nbins_theta, *nbins_r, *nsamp, *theta_array_q, *r_array_q;
	mxLogical *fz, *in_vec;
	double *BH;
	double* my_sn;

	nbins_theta = mxGetPr(in[IN_NBINS_T]);
	nbins_r = mxGetPr(in[IN_NBINS_R]);
	nsamp = mxGetPr(in[IN_NSAMP]);
	fz = mxGetLogicals(in[IN_FZ]);
	in_vec = mxGetLogicals(in[IN_VEC]);
	theta_array_q = mxGetPr(in[IN_TAQ]);
	r_array_q = mxGetPr(in[IN_RAQ]);

	const int* dims = mxGetDimensions(in[IN_FZ]);
	int nbins = int(nbins_theta[0] * nbins_r[0]);
	
	out[OUT_BH] = mxCreateDoubleMatrix((int)*nsamp, nbins, mxREAL);
	
	BH = mxGetPr(out[OUT_BH]);

	int *fzn = new int[dims[1]]();
	
	//vector<double> my_sn(int(nbins_theta[0] * nbins_r[0]), 0);

	for(int n=0; n < (int)*nsamp; n++)
	{
		my_sn = new double[int(nbins_theta[0] * nbins_r[0])]();
		
		//for(int i=0; i <my_sn.size(); i++)
		//{
		//	my_sn[i] = 0;
		//}

		//printf("Here 2.2\n");

		for(int i=0; i < dims[1]; i++)
		{
			fzn[i] = fz[dims[0]*i + n]  && in_vec[i];
			
		}
		
		for(int i=0; i < dims[1]; i++)
		{	
			if( fzn[i] == 1)
			{
				for(int j=0; j < dims[1]; j++)
				{
					if( fzn[j] == 1)
					{
						int d1 = (int)theta_array_q[n + dims[0]*i]-1;
						int d2 = (int)r_array_q[n + dims[0]*j]-1;

						//cout << theta_array_q[n+dims[0]*i] << ":";
						//cout << r_array_q[n+dims[0]*j] << ":";
						
						if(d1 < (int)nbins_theta[0] && d2 < (int)nbins_r[0] && d1 >=0 && d2 >=0 )		
						{
							my_sn[d1 + d2*(int)nbins_theta[0]] = 1;
							//cout << my_sn[d1 + d2*(int)nbins_theta[0]] << endl;
						}	
						//else
						//	cout << "Trouble in the mill" << endl;
					}
				}
			}
		}

		for(int i=0; i < int(nbins_theta[0]*nbins_r[0]); i++)
		{
			BH[n + int(*nsamp)*i] = my_sn[i];
		}
		
		delete [] my_sn;

	}
	
	delete [] fzn;

}
