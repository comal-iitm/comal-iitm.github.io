#include "mex.h"
#include <iostream>
#include <stdio.h>
#include <matrix.h>
#include <math.h>
#include "boundaries.h"
#include "mwsize.h"
#include "connectedComponents.h"

using namespace std;

// Assuming no holes

void mexFunction(int nout, mxArray *out[], int nin, const mxArray *in[])
{

	enum {IN_BW=0};
	enum {OUT_B=0, OUT_L, OUT_N};

	double *BW;
	double *B, *L, *N;

	int conn = 8;

	Boundaries boundaries;
	const int* dims = mxGetDimensions(in[IN_BW]);

	out[OUT_L] = mxCreateDoubleMatrix(dims[0], dims[1], mxREAL);
	out[OUT_B] = mxCreateDoubleMatrix(1, 1, mxREAL);
	out[OUT_N] = mxCreateDoubleMatrix(1, 1, mxREAL);

	boundaries.setNumCols(dims[1]);
	boundaries.setNumRows(dims[0]);
	boundaries.setConnectivity(conn);

	BW = mxGetPr(in[IN_BW]);
	L = mxGetPr(out[OUT_L]);
	N = mxGetPr(out[OUT_N]);
	
	int *binImg = new int[dims[0]*dims[1]];
	int *L_temp;
	
	for(int i=0; i<dims[0]; i++)
	{
		for(int j=0; j<dims[1]; j++)
		{
			if(BW[i + j*dims[0]] != 0)
			{
				binImg[i + j*dims[0]] = 1;
			}
			else
			{
				binImg[i + j*dims[0]] = 0;
			}
		}
	}

	doLabel(binImg, dims[0], dims[1], L_temp, conn);
		
	for(int i=0; i<dims[0]; i++)
	{
		for(int j=0; j<dims[1]; j++)
		{
			L[i+j*dims[0]] = (double)L_temp[i+j*dims[0]];
		}
	}

	out[OUT_B] = boundaries.findBoundaries(L);
		
	const int* dims2 = mxGetDimensions(out[OUT_B]);
	N[0] = dims2[0];

	delete [] L_temp;
}	
