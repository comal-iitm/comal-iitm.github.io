#include <math.h>
#include "mex.h"

/* Input Arguments */

#define	SIGMA_IN	prhs[1]
#define	SIGNAL_IN	prhs[0]


/* Output Arguments */

#define	OUT	plhs[0]

void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray *prhs[] )
     
{ 
    double *convsignal; 
    double *sigma,*signal; 
    mwSize m,N1; 
    int nbytes,bytes_to_copy1,bytes_to_copy2, threesigma, n, i,N,kernelWidth;
   
    /* Check for proper number of arguments */
    
    if (nrhs != 2) { 
	mexErrMsgTxt("Two input arguments required."); 
    } else if (nlhs > 1) {
	mexErrMsgTxt("Too many output arguments."); 
    } 
    
    /* Check the dimensions of signal.  signal can be 4 X 1 or 1 X 4. */ 
    
    m = mxGetM(SIGNAL_IN); 
    N1 = mxGetN(SIGNAL_IN);
/*    printf("\nnum of rows is %d\n",(int) m);    
    printf("\nnum of cols is %d\n",(int) N1);    
  */  
    sigma = mxGetPr(SIGMA_IN); 
    signal = mxGetPr(SIGNAL_IN);
   /* printf("\nsignal is %f\n",signal[0]);    
    printf("\nsigma is %f\n",sigma[0]);    */
  
  	kernelWidth = 2*sigma[0]+1;   
    /*printf("\nkernel width is %f\n",kernelWidth);    */
  	
/*    threesigma=ceil((3*sigma[0]+1)/2)*2-1; */
/*    n=(threesigma-1)/2; */
    
    N= m-kernelWidth+1;
/*	N =  kernelWidth;	*/
    /*printf("\noutput size is %d\n",(int) N);    */
   
    OUT = mxCreateDoubleMatrix(N, N1, mxREAL); 
    convsignal = mxGetPr(OUT);
    
  /*  printf("alloc");
    */
    for (i=0;i<kernelWidth;i++) { 
    convsignal[0] += signal[i];
    }

    
    for (i=1;i<N;i++) {      /* this N s before the 1.5*sig extension*/

    convsignal[i]=convsignal[i-1]+signal[i+kernelWidth-1]-signal[i-1]; 
    }

    for (i=0;i<N;i++) {      /* this N s before the 1.5*sig extension*/
    convsignal[i] /= kernelWidth; 
    }

    return;
    
}
