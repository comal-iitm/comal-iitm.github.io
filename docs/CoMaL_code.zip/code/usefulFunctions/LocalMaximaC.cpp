#include <math.h>
#include "mex.h"

#include <vector>
#include <algorithm>
#include <iostream> 


/* Input Arguments */


#define	SZPT prhs[0]
#define	PT prhs[1]
#define	CORXYSIG prhs[2]

/* Output Arguments */

#define	AA1 plhs[0]
#define	AA2 plhs[1]
#define SIZEAA plhs[2]

#define verbose 0

void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray*prhs[] )
     
{ 
    double *szpt,*pt,*cor_xy_sig, *sizeaa;
    double *aa1, *aa2;
    mwSize N, sz;
    int i,j, k = 0, ind1;
    double max, array, dist1, dist2, sumdist; 
    int sizeaaint = 0;
    /*aa[][2]*/
    
    /* Check for proper number of arguments */
    
    if (nrhs != 3) { 
	mexErrMsgTxt("Three input arguments required."); 
    } else if (nlhs > 3) {
	mexErrMsgTxt("Too many output arguments."); 
    } 
    
    szpt = mxGetPr(SZPT); 
    pt = mxGetPr(PT); 
    cor_xy_sig = mxGetPr(CORXYSIG);
    
/*    int* aa_indices = (int *) malloc(pt * size(int));
    double *aa_cor_vals = (double *) malloc(pt* size(double));
  */
    
    AA1 = mxCreateDoubleMatrix(pt[0], 1, mxREAL);
    aa1 = mxGetPr(AA1);
    AA2 = mxCreateDoubleMatrix(pt[0], 1, mxREAL);
    aa2 = mxGetPr(AA2);
    SIZEAA = mxCreateDoubleMatrix(1,1,mxREAL);
    sizeaa = mxGetPr(SIZEAA);
    
      
/*    printf("\nszpt is %f\n",szpt[0]);   
    printf("\npt is %f\n",pt[0]);    
  */  
    
    std::vector<double> heap, heap2;
 
    for (j = 1; j < 2*szpt[0] + 1; j++) {
        heap.push_back(cor_xy_sig[j-1]);
    }
    
    make_heap(heap.begin(), heap.end());
   
    
    for (j = 2*szpt[0] +1; j <= pt[0] +2*szpt[0]; j++) {

        double max = 0.0, max2 = 0.0;             

        heap.push_back(cor_xy_sig[j - 1]);
        push_heap(heap.begin(), heap.end());
       
        while (max == max2) {
            
            max = heap[0];
            
            if (heap2.empty())
                max2 = -1.0;
            else{
                max2 = heap2[0];
            }
            
            if (max == max2) {
                pop_heap(heap.begin(), heap.end());
                heap.pop_back();
            
                pop_heap(heap2.begin(), heap2.end());
                heap2.pop_back();
                                
            }
            
        }
                
        
        if (max == cor_xy_sig[j - (int) szpt[0] - 1]) {
            aa1[sizeaaint]= j-2*szpt[0];
            aa2[sizeaaint] = cor_xy_sig[j - (int) szpt[0] - 1];
            sizeaaint=sizeaaint+1;
        }
        
        heap2.push_back(cor_xy_sig[j- 2* (int) szpt[0] - 1]);
        push_heap(heap2.begin(), heap2.end());
        
    }
    
    
    /*    for (j = szpt[0] + 1; j <= pt[0] +szpt[0]; j++) {
        max=0;
        for (i=j-szpt[0]; i<=j+szpt[0]; i++)
        {
          if (cor_xy_sig[i - 1]>max) max=cor_xy_sig[i - 1];
        }
 
       if (max == cor_xy_sig[j - 1]) {
            aa1[sizeaaint]= j-szpt[0];
            aa2[sizeaaint] = cor_xy_sig[j - 1];
            sizeaaint=sizeaaint+1;
        }
    }
     */
    
    sizeaa[0] = sizeaaint;
    

    /*N = mxGetM(AA);*/ 

        
}
