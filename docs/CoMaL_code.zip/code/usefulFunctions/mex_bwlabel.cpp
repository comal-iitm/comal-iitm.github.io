#include "mex.h"
#include <iostream>
#include <stdio.h>
#include <matrix.h>
#include <math.h>
#include "boundaries.h"
#include "mwsize.h"
#include "connectedComponents.h"

using namespace std;

// Assuming no holes

void mexFunction(int nout, mxArray *out[], int nin, const mxArray *in[])
{

	enum {IN_BW=0, IN_CONN};
	enum {OUT_L=0};

	double *BW, *CONN;
	double *B, *L, *N;

	const int* dims = mxGetDimensions(in[IN_BW]);

	out[OUT_L] = mxCreateDoubleMatrix(dims[0], dims[1], mxREAL);

	BW = mxGetPr(in[IN_BW]);
	CONN = mxGetPr(in[IN_CONN]);

	L = mxGetPr(out[OUT_L]);
	
	int *binImg = new int[dims[0]*dims[1]];
	int *L_temp;
	
	for(int i=0; i<dims[0]; i++)
	{
		for(int j=0; j<dims[1]; j++)
		{
			if(BW[i + j*dims[0]] != 0)
			{
				binImg[i + j*dims[0]] = 1;
			}
			else
			{
				binImg[i + j*dims[0]] = 0;
			}
		}
	}

	doLabel(binImg, dims[0], dims[1], L_temp, CONN[0]);
		
	for(int i=0; i<dims[0]; i++)
	{
		for(int j=0; j<dims[1]; j++)
		{
			L[i+j*dims[0]] = (double)L_temp[i+j*dims[0]];
		}
	}

	delete [] L_temp;
}	
