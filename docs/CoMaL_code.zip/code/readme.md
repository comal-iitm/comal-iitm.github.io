Demofile: demo.m

The experiments were performed on images for vehicle tracking, stereo and optical flow from KIITI (http://www.cvlibs.net/datasets/kitti/eval_tracking.php) and the CoMaL dataset (http://comal-iitm.github.io/). 

Download the detectors you want to compare them against. Sample detectors such as Harris, Hessian, FAST and the sample descriptor SIFT is provided with the dataset.

Check  getParamsAndDataset.m and getParamsAndDataset.m for naming conventions.


