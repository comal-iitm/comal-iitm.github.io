Download images_demo.zip and place the "bg" and "images" alongside the "code" folder. Run the demo file: demo.m.

For the full experiments performed on images for vehicle tracking, stereo and optical flow, download corresponding images from KIITI (http://www.cvlibs.net/datasets/kitti/eval_tracking.php) and the CoMaL dataset (http://comal-iitm.github.io/). 

Download the detectors you want to compare them against. Sample detectors such as Harris, Hessian, FAST and the sample descriptor SIFT is provided with the dataset.

Check  getParamsAndDataset.m and getParamsAndDataset.m for naming conventions.


