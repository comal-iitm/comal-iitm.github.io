
function Tuples = demo()

close all; clc;
addpath(genpath('.')); dirData = '../Images'; addpath(dirData);

firstImgBasedThresh = 0; imgnoBase=1;
numFrames = 5; delta = 5; sxi2 = 8.4; dilValComp=4; fgTypeComp = 'full'; numCores = 4;

Tuples = getTuplesExpt(dirData);
[datasets indUnique] = unique(Tuples(:,1));
indUnique = [0; indUnique];
numImagesAll = indUnique(2:end) - indUnique(1:end-1);
for d = 1:length(datasets),
    
    dset = datasets{d};
    numFrames = numImagesAll(d); %indUnique(d+1) - indUnique(d);
    indValid  = strcmp(Tuples(:, 1), dset); % Binary values stating if ith image belongs to this dataset
    TuplesD = Tuples(indValid, :); % Obtains only the images from this dataset
    imSize = size(imread(sprintf('%s/%s/%s', dirData, TuplesD{1, 1}, TuplesD{1, 2})));
    imToRun = (1:numFrames)' ; % Number of images to run on
    dSetNo = getParamsAndDataset(dset); % Returns the current dataset number
    imRunWrong = []; imRunEmpty=[]; thresh=[];
    for iR = 1%:length(imToRun)
        t = imToRun(iR);
        imTuple = TuplesD(t,:);
        fprintf('imTuple: %s\n', imTuple{2});
        
        %% Feature point detection
        [cornersFinal, boundaryFinal, maskFinal] = COMICDetector2(imTuple,dSetNo,dilValComp,fgTypeComp,delta,numCores);
        fig = figure('visible', 'off');
        imgPath = fullfile(dirData,imTuple{1},imTuple{2});
        imshow(imread(imgPath));
        hold on; plot(cornersFinal(1,:), cornersFinal(2,:), 'b*');
        
        if( exist(strcat(sprintf('../ExptOutputs/'),imTuple{1})) ~= 7)
            mkdir(strcat(sprintf('../ExptOutputs/'),imTuple{1}));
        end;
        saveas(fig, strcat(sprintf('../ExptOutputs/'),imTuple{1},'/',sprintf('%.4d.jpg', iR)));
    end
end
end