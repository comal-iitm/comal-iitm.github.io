function [commonVar repVar] = globalVariables(t)
scaleFactor = ones(1,13000); %[1 1 1 1 1 1]; %[1 1.13];

commonVar = struct('displayflag', 0, 'granularity2',1, 'granularity',1, 'momScaleFactor',1.33, 'ScaleDependCornerMax',1,...
     'dispAllDetectors',1,'smoothingFactor',1.4,'cornerSigmaFactor',1,'sigSmax',46,'sigSminInit',6/scaleFactor(t),'nptsmax',300,...
      'shiftSizeFactor',7,'iterBlockFactor',4,'blockMultFactor',3,'overErr',0, 'overErrOther',0,'isparfor',1); %'sigSminInit',6/1.13, 'blockMultFactor',4.5, 'iterBlockFactor',4
%'shiftSizeFactor',4 ; 'shiftSizeFactor',7

  i=1; sz = commonVar.sigSminInit;
    while sz < commonVar.sigSmax
        allSizes(i) = sz;
        sz = 1.4*sz; %Needs change
        i=i+1;
    end
    
    adaptParams = [1 0 1];
%     allSizes = allSizes - mod(allSizes,16); needed only if u use getAllBlocksOld
    commonVar.sigSmin = allSizes;
    commonVar.adaptflag = adaptParams;


%  commonVar = struct('shiftSize',25,'szBlock',100,'rangeInit',25); %Orig 'shiftSize',25,'szBlock',100, 'rangeInit',25

repVar = struct('optimizedRepCorresp',0,'optimizeRepeatabilityMemory',0);

% if optimizeRepeatabilityMemory
%     optimizedRepCorresp = 1;
% end